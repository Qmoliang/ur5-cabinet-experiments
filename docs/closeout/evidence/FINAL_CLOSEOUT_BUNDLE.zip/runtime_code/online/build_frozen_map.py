"""Rebuild a run's final map by replaying its published camera poses in order.

Usage: build_frozen_map.py RUN_CASE_DIR OUT.pkl
Saves {"proxies": PointCloudProxySet incl. frontier, "frontier_cells": n}.
"""
import os
import pickle
import sys
from pathlib import Path

import numpy as np

os.environ["UR5_FRONTIER"] = "1"
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_protocol_v3_async_online as online  # noqa: E402

case, out = Path(sys.argv[1]), Path(sys.argv[2])
run = next(p for p in case.iterdir() if p.is_dir())
sources = np.load(run / "causal_source_configurations.npz")
worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=float(os.environ.get("UR5_CENTERVOX", "0.0075")), maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm"), scene_version="camera_quarter")
packet = None
for frame, (q, cycle) in enumerate(zip(sources["q"], sources["source_cycles"])):
    packet = worker.process(q, frame, int(cycle), int(cycle) * 0.02, include_dense_snapshot=False)
frontier = int(packet.frame_row.get("frontier_cells", 0))
with open(out, "wb") as handle:
    pickle.dump({"proxies": packet.proxies, "frontier_cells": frontier}, handle)
final = np.load(run / "final_causal_proxies.npz")
print(f"{case.name}: {len(sources['q'])} frames, {len(packet.proxies.centers)} proxies "
      f"({frontier} frontier) vs recorded final {len(final['centers'])}")
worker.close()
