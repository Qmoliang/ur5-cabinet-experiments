from pathlib import Path
import os,json,time
os.sched_setaffinity(0,{40,41,42,43})
import numpy as np
from pilot_adapter import ROOT,build
ctx=build('iris_4shelves_t2');guard=ctx.guard;guard.margin=ctx.controller.safety_margin
qg=np.array(json.loads((ROOT/'GOAL_BRANCH_PORTS.json').read_text())['ports'][0]['goal_q']);records=[]
for f in sorted((ROOT/'trials').glob('certified*')):
 if not (f/'result.json').exists():continue
 z=np.load(f/'trajectory.npz');ix=np.flatnonzero(z['control_mode']=='CERT_ENTER')
 if not len(ix):records.append(dict(name=f.name,entered=False));continue
 q=z['q'][int(ix[0])];count=max(1,int(np.ceil(np.max(np.abs(qg-q))/.04)));failed=[];started=time.monotonic()
 for i in range(count):
  a=q+(qg-q)*(i/count);b=q+(qg-q)*((i+1)/count)
  if not guard.segment(ctx.proxy_guard,a,b):failed.append(i)
 rec=dict(name=f.name,entered=True,first_actual_enter_cycle=int(ix[0]),passed=not failed,intervals=count,failed_intervals=failed,environment_margin_m=guard.margin,wall_s=time.monotonic()-started,scope='fresh-model replay of entire fixed terminal contraction; same continuous certificate implementation, separate from independent executed-trajectory audit')
 records.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'TERMINAL_CERTIFICATE_REPLAY.json').write_text(json.dumps(records,indent=2))
assert all(not r['entered'] or r['passed'] for r in records)
