"""Several moving objects (racket-shaped) for the dodge-then-reach test (E1).

The controllers never learn what an object is or how many there are: they get
one certificate cover (static + every object's certificates) and one velocity
per certificate (zero for static ones).  The objects here only drive the
simulation.

Each object is a 26 x 26 x 2 cm head with a 30 cm handle trailing behind it
(racket.py geometry), a MuJoCo mocap body `object<k>`, and one behaviour:

  strike  aimed at where a distal arm sphere will be when the object arrives
          (its current velocity extrapolated), travels `overshoot` past it,
          dwells, withdraws.
  miss    the same, aimed 21 cm to the side (a near miss: should not cost the
          arm much).
  block   moves into the corridor between the gripper and the target, stays
          `block_dwell_s`, withdraws (the arm has to wait).
  sudden  sits still beside the start-to-target line from t = 0 (it looks
          static), then strikes when triggered.

Objects are launched during the approach, before the arm reaches the cabinet:
when the gripper is `progress` (a random 15-30 cm) from the scene's bounding box
(the cabinet), never once it is within MIN_OUTSIDE (10 cm) of it.  Never from
behind or through the scene: a direction is accepted only if the object's
start is 20 cm clear of the scene and its centre path never passes through a
scene box (2 cm margin).  An object must also leave the arm room to dodge: the
distal arm's certificate spheres pushed 25 cm along the object's motion must
stay clear of the scene and the floor (no squeezing the arm against the cabinet).
"""
from __future__ import annotations

import os
from dataclasses import replace

import numpy as np

from known_volume import build_volume_cover
from racket import _geometry
from robot import BoxObstacle, certificate_world_positions

PARK = np.array([5.0, 5.0, 5.0])
BEHAVIOURS = ("strike", "miss", "block", "sudden")
BOUND_RADIUS = 0.20  # covers head (0.13 half width) plus margin
MIN_OUTSIDE = 0.10     # no launch once the gripper is this close to the cabinet box
PATH_MARGIN = 0.02
ROOM_DISTANCE = 0.25   # a dodge must be possible: free space behind the arm along the motion
ROOM_MARGIN = 0.005    # beyond each arm sphere's radius


def env_count() -> int:
    return int(os.environ.get("UR5_OBJECTS") or "0")


def mjcf_bodies(count: int) -> str:
    out = ""
    for k in range(count):
        # Geometry is set per launch by moving geoms is not possible with
        # mocap, so every object uses the face-on-to-z layout and the
        # direction-specific layout is applied through the body quaternion.
        head, handle, offset = (" ".join(map(repr, v)) for v in _geometry(np.array([0.0, 0.0, -1.0])))
        out += (f'\n    <body name="object{k}" mocap="true" pos="{5.0 + k} 5.0 5.0">'
                f'\n      <geom name="object{k}_head" type="box" size="{head}" rgba=".9 .3 .1 1" contype="1" conaffinity="1" />'
                f'\n      <geom name="object{k}_handle" type="box" pos="{offset}" size="{handle}" rgba=".3 .2 .1 1" contype="1" conaffinity="1" />'
                f'\n    </body>')
    return out


def _rotation_z_to(direction):
    """Rotation taking -z (the MJCF layout's motion axis) to `direction`."""
    a = np.array([0.0, 0.0, -1.0])
    b = direction / np.linalg.norm(direction)
    v = np.cross(a, b)
    c = float(a @ b)
    if np.linalg.norm(v) < 1e-9:
        return np.eye(3) if c > 0 else np.diag([1.0, -1.0, -1.0])
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * (1.0 / (1.0 + c))


def _quat(rotation):
    m = rotation
    w = np.sqrt(max(0.0, 1.0 + m[0, 0] + m[1, 1] + m[2, 2])) / 2.0
    if w < 1e-6:
        # 180 degrees: pick the largest diagonal axis.
        i = int(np.argmax(np.diag(m)))
        axis = np.zeros(3)
        axis[i] = 1.0
        return np.r_[0.0, axis]
    return np.array([w, (m[2, 1] - m[1, 2]) / (4 * w), (m[0, 2] - m[2, 0]) / (4 * w), (m[1, 0] - m[0, 1]) / (4 * w)])


def _segment_box_clear(p0, p1, boxes, dilation):
    """True if the segment p0-p1 stays `dilation` away from every box (sampled)."""
    for s in np.linspace(0.0, 1.0, 41):
        p = p0 + s * (p1 - p0)
        for b in boxes:
            lo = np.asarray(b.center) - np.asarray(b.half_size) - dilation
            hi = np.asarray(b.center) + np.asarray(b.half_size) + dilation
            if np.all(p > lo) and np.all(p < hi):
                return False
    return True


class MovingObject:
    def __init__(self, k, behaviour, speed, trigger_offset_s, rng, *, start_distance=0.45, overshoot=0.10,
                 dwell_s=0.5, block_dwell_s=1.5):
        self.k, self.behaviour, self.speed = k, behaviour, float(speed)
        self.trigger_offset_s = float(trigger_offset_s)
        self.rng = rng
        self.start_distance, self.overshoot = start_distance, overshoot
        self.dwell_s = block_dwell_s if behaviour == "block" else dwell_s
        self.t0 = None          # launch time
        self.start = None       # launch position
        self.direction = None
        self.travel = 0.0
        self.parked = PARK + np.array([float(k), 0.0, 0.0])
        self.static_position = None   # "sudden": visible and still before launch
        self.local_cover = None
        self.rotation = np.eye(3)
        self.launched = False
        self.failed_launch = False

    # ---- kinematics ----------------------------------------------------
    @property
    def move_s(self):
        return self.travel / self.speed

    def position(self, t):
        if self.t0 is None or t < self.t0:
            return self.static_position
        s = t - self.t0
        if s < self.move_s:
            return self.start + self.direction * self.speed * s
        if s < self.move_s + self.dwell_s:
            return self.start + self.direction * self.travel
        s -= self.move_s + self.dwell_s
        if s < self.move_s:
            return self.start + self.direction * (self.travel - self.speed * s)
        return None

    def velocity(self, t):
        if self.t0 is None or t < self.t0:
            return np.zeros(3)
        s = t - self.t0
        if s < self.move_s:
            return self.direction * self.speed
        if s < self.move_s + self.dwell_s:
            return np.zeros(3)
        if s < 2 * self.move_s + self.dwell_s:
            return -self.direction * self.speed
        return np.zeros(3)

    def done(self, t):
        return self.launched and self.position(t) is None

    def active(self, t):
        return self.position(t) is not None


class MovingObjects:
    def __init__(self, model, robot, representation, cell_span, scene_boxes, target, initial_ee, *, count, speed,
                 seed, behaviours=None, progress=None):
        self.model, self.robot = model, robot
        self.representation, self.cell_span = representation, cell_span
        self.boxes = list(scene_boxes)
        self.target = np.asarray(target, dtype=float)
        self.initial_ee = np.asarray(initial_ee, dtype=float)
        rng = np.random.default_rng(1000 + int(seed))
        self.rng = rng
        if behaviours is None:
            behaviours = ["strike"]
            if count >= 2:
                behaviours.append(rng.choice(["miss", "block", "sudden"]))
            if count >= 3:
                behaviours.append(rng.choice(["strike", "block", "sudden"]))
        # Trigger distance (m) from the gripper to the cabinet box.
        self.progress = float(progress if progress is not None else rng.uniform(0.15, 0.30))
        self.box_low = np.min([np.asarray(b.center) - np.asarray(b.half_size) for b in self.boxes], axis=0)
        self.box_high = np.max([np.asarray(b.center) + np.asarray(b.half_size) for b in self.boxes], axis=0)
        offsets = [0.0] + list(rng.uniform(0.0, 0.4, max(0, count - 1)))
        self.objects = [MovingObject(k, behaviours[k], speed, offsets[k], rng) for k in range(count)]
        self.mocap = [model.body(f"object{k}").mocapid[0] for k in range(count)]
        self.geoms = {model.geom(f"object{k}_{part}").id for k in range(count) for part in ("head", "handle")}
        self.trigger_s = None
        self.min_distance = np.inf
        self.not_launched = 0
        self.rejected_no_room = 0
        self._place_sudden()

    # ---- launch ----------------------------------------------------------
    def _cover_for(self, obj, direction):
        head, handle, offset = _geometry(np.array([0.0, 0.0, -1.0]))
        rotation = _rotation_z_to(direction)
        obj.rotation = rotation
        # Cover built in the object frame and rotated exactly (centres R c,
        # ellipsoid shapes R S R^T, AABB half extents sqrt(diag)).
        frame_boxes = (BoxObstacle(f"object{obj.k}_head", (0.0, 0.0, 0.0), head, "shelf"),
                       BoxObstacle(f"object{obj.k}_handle", offset, handle, "shelf"))
        local = build_volume_cover(frame_boxes, self.representation, self.cell_span)
        shapes = np.einsum("ij,njk,lk->nil", rotation, local.ellipsoid_shapes, rotation)
        if self.representation == "ellipsoid":
            half = np.sqrt(np.einsum("nii->ni", shapes))
        else:
            half = local.aabb_half_extents
        obj.local_cover = replace(local, centers=local.centers @ rotation.T, ellipsoid_shapes=shapes,
                                  aabb_half_extents=half)
        # For distance reporting only: world-axis AABBs of the rotated boxes.
        obj.local_boxes = [BoxObstacle(b.name, tuple(rotation @ np.asarray(b.center)),
                                       tuple(np.abs(rotation) @ np.asarray(b.half_size)), "shelf")
                           for b in frame_boxes]

    def _place_sudden(self):
        for obj in self.objects:
            if obj.behaviour != "sudden":
                continue
            line = self.target - self.initial_ee
            mid = self.initial_ee + 0.5 * line
            side = np.cross(line, [0.0, 0.0, 1.0])
            side = side / max(np.linalg.norm(side), 1e-9)
            for sign in (1.0, -1.0):
                p = mid + sign * 0.30 * side
                p[2] = max(p[2], 0.25)
                if _segment_box_clear(p, p, self.boxes, BOUND_RADIUS):
                    break
            obj.static_position = p
            direction = -sign * side
            self._cover_for(obj, direction)

    def _room(self, positions, d):
        """True if the distal arm can be pushed ROOM_DISTANCE along d without meeting the scene or floor."""
        half = len(positions) // 2
        distal = positions[half:]
        radii = np.array([s.radius for s in self.robot])[half:] + ROOM_MARGIN
        steps = np.linspace(0.025, ROOM_DISTANCE, 14)
        points = distal[:, None, :] + steps[None, :, None] * d[None, None, :]
        if np.any(points[..., 2] < radii[:, None]):
            return False
        for b in self.boxes:
            lo = np.asarray(b.center) - np.asarray(b.half_size)
            hi = np.asarray(b.center) + np.asarray(b.half_size)
            outside = np.linalg.norm(np.maximum(0.0, np.maximum(lo - points, points - hi)), axis=2)
            if np.any(outside < radii[:, None]):
                return False
        return True

    def _sample_direction(self, aim, positions, obj, end_offset=None):
        for _ in range(400):
            d = self.rng.normal(size=3)
            d[2] = -abs(d[2]) if self.rng.random() < 0.6 else d[2]
            d /= np.linalg.norm(d)
            if d[2] > 0.5:   # not from below
                continue
            if not self._room(positions, d):
                self.rejected_no_room += 1
                continue
            behind = max(0.0, float(np.max((aim - positions) @ d)))
            reach = behind + obj.start_distance
            start = aim - reach * d
            end = aim + (obj.overshoot if end_offset is None else end_offset) * d
            if start[2] < BOUND_RADIUS + 0.02:
                continue
            # Start well clear of the scene; the centre path never passes through
            # a box (it may end brushing the scene front, as a real swing would).
            if (_segment_box_clear(start, start, self.boxes, BOUND_RADIUS)
                    and _segment_box_clear(start, end, self.boxes, PATH_MARGIN)):
                return d, start, reach
        return None

    def update(self, data, t, ee, dt):
        """Trigger and launch objects (called every cycle before the controller)."""
        positions = certificate_world_positions(data, self.robot)
        previous = getattr(self, "_previous_positions", None)
        sphere_velocity = np.zeros_like(positions) if previous is None else (positions - previous) / dt
        self._previous_positions = positions
        if self.trigger_s is None:
            to_box = float(np.linalg.norm(np.maximum(0.0, np.maximum(self.box_low - ee, ee - self.box_high))))
            inside = to_box < MIN_OUTSIDE
            if to_box <= self.progress and not inside:
                self.trigger_s = t
            elif inside:
                # Already at the cabinet before the trigger: launch nothing (logged).
                self.trigger_s = -1.0
                self.not_launched = len(self.objects)
        if self.trigger_s is None or self.trigger_s < 0:
            return
        for obj in self.objects:
            if obj.launched or obj.failed_launch or t < self.trigger_s + obj.trigger_offset_s:
                continue
            pick = len(positions) // 2 + int(self.rng.integers(len(positions) - len(positions) // 2))
            aim_sphere, velocity = positions[pick], sphere_velocity[pick]
            if obj.behaviour == "block":
                aim = ee + 0.4 * (self.target - ee)
                end_offset = 0.0
            else:
                aim = aim_sphere.copy()
                end_offset = None
            if obj.behaviour == "sudden":
                start = obj.static_position
                aim = positions[np.argmin(np.linalg.norm(positions - start, axis=1))]
                d = aim - start
                reach = float(np.linalg.norm(d))
                d /= reach
                if not self._room(positions, d):
                    # No room to dodge this one: it stays where it is (static).
                    self.rejected_no_room += 1
                    obj.failed_launch = True
                    self.not_launched += 1
                    continue
                self._cover_for(obj, d)
                obj.start, obj.direction, obj.travel = start, d, reach + obj.overshoot
            else:
                # Aim where the arm will be on arrival (two fixed-point passes).
                for _ in range(2):
                    found = self._sample_direction(aim, positions, obj, end_offset)
                    if found is None:
                        break
                    d, start, reach = found
                    if obj.behaviour in ("strike",):
                        aim = aim_sphere + velocity * (reach / obj.speed)
                if found is None:
                    obj.failed_launch = True
                    self.not_launched += 1
                    continue
                d, start, reach = found
                if obj.behaviour == "miss":
                    side = np.cross(d, [0.0, 0.0, 1.0])
                    if np.linalg.norm(side) < 1e-6:
                        side = np.array([1.0, 0.0, 0.0])
                    side /= np.linalg.norm(side)
                    start = start + 0.21 * side
                self._cover_for(obj, d)
                obj.start, obj.direction = start, d
                obj.travel = reach + (obj.overshoot if end_offset is None else end_offset)
            obj.t0 = t
            obj.launched = True

    # ---- covers ----------------------------------------------------------
    def world_cover(self, static_cover, t, *, sweep_s=0.0):
        """Static cover + every visible object's certificates at time t.

        Returns (cover, velocities (n, 3), index_half_extents) where the index
        half extents of moving certificates are grown by |v| * sweep_s (swept
        broadphase: a fast object gets rows before it is near).
        """
        covers, velocities = [], []
        for obj in self.objects:
            p = obj.position(t)
            if p is None or obj.local_cover is None:
                continue
            covers.append(replace(obj.local_cover, centers=obj.local_cover.centers + p))
            velocities.append(np.repeat(obj.velocity(t)[None, :], len(obj.local_cover.centers), axis=0))
        cover = static_cover
        if covers:
            from racket import combined_cover
            for c in covers:
                cover = combined_cover(cover, c)
        v = np.zeros((len(cover.centers), 3))
        if velocities:
            v[len(static_cover.centers):] = np.concatenate(velocities)
        half = np.asarray(cover.aabb_half_extents, dtype=float).copy()
        if sweep_s > 0.0:
            half += np.linalg.norm(v, axis=1, keepdims=True) * sweep_s
        return cover, v, half

    def any_visible(self, t):
        return any(obj.position(t) is not None for obj in self.objects)

    def all_done(self, t):
        return self.trigger_s is not None and all(o.done(t) or o.failed_launch or self.trigger_s < 0
                                                    for o in self.objects)

    def place(self, data, t):
        for obj, m in zip(self.objects, self.mocap):
            p = obj.position(t)
            data.mocap_pos[m] = obj.parked if p is None else p
            data.mocap_quat[m] = _quat(obj.rotation)

    def measure(self, data, t):
        positions = certificate_world_positions(data, self.robot)
        radii = np.array([s.radius for s in self.robot])
        best = np.inf
        for obj in self.objects:
            p = obj.position(t)
            if p is None or obj.local_cover is None:
                continue
            for b in obj.local_boxes:
                lo = p + np.asarray(b.center) - np.asarray(b.half_size)
                hi = p + np.asarray(b.center) + np.asarray(b.half_size)
                d = np.linalg.norm(np.maximum(0, np.maximum(lo - positions, positions - hi)), axis=1) - radii
                best = min(best, float(d.min()))
        self.min_distance = min(self.min_distance, best)
        return None if not np.isfinite(best) else best

    def describe(self):
        return [dict(k=o.k, behaviour=o.behaviour, speed=o.speed, launched=o.launched,
                     failed_launch=o.failed_launch,
                     t0=o.t0, direction=None if o.direction is None else o.direction.tolist())
                for o in self.objects]
