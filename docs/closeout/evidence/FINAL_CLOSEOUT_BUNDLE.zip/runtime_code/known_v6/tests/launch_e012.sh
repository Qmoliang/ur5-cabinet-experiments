#!/bin/bash
# E0: static regression of the combined rule (280 tasks, same as the benchmark's LiuQP-E-geodesic):
#     combined (should equal LiuQP exactly) and combined with fixed tau on every row (NEO-style damper on static rows).
# E1: dodge-then-reach, unlabeled moving objects, known positions, acceleration limit 10 rad/s^2 for every controller:
#     liuqp, liuqphe (horizon 0.3 s + escape), neo_matched, neo_paper, combined
#     x drawer, cage, iris_ur3_shelf_t0 x held-out start seeds 101-120 x (k=0 | k=1,2,3 x 0.25,0.5,1.0 m/s).
# E2: combined ablations on the E1 grid: -damper -adaptive -buffer -sweep -yield -escape +horizon.
# 40 workers x 2 CPUs (CPUs 0-79).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
E0=$PWD/e0; E1=$PWD/e1; E2=$PWD/e2
jobs=()
SCENES0="drawer cage cage_wide exit wall2 iris_4shelves_t0 iris_4shelves_t2 iris_bins_t0 iris_bins_t1 iris_bins_t2 iris_bins_t3 iris_ur3_shelf_t0 iris_ur3_shelf_t1 iris_ur3_shelf_t2"
for seed in $(seq 1 20); do
  for scene in $SCENES0; do
    jobs+=("$E0/combined $scene $seed UR5_CONTROLLER=combined")
    jobs+=("$E0/combined_fixedtau $scene $seed UR5_CONTROLLER=combined UR5_COMBINED_OFF=adaptive")
  done
done
add_grid() {   # add_grid <root> <variant> <env...>
  local root=$1 variant=$2; shift 2
  for seed in $(seq 101 120); do
    for scene in drawer cage iris_ur3_shelf_t0; do
      jobs+=("$root/${variant}_k0_v0.0 $scene $seed $* UR5_ACCEL_LIMIT=10")
      for k in 1 2 3; do
        for v in 0.25 0.5 1.0; do
          jobs+=("$root/${variant}_k${k}_v$v $scene $seed $* UR5_ACCEL_LIMIT=10 UR5_OBJECTS=$k UR5_OBJECT_SPEED=$v")
        done
      done
    done
  done
}
add_grid $E1 liuqp UR5_CONTROLLER=liuqp
add_grid $E1 liuqphe UR5_CONTROLLER=liuqp UR5_RACKET_HORIZON=0.3 UR5_ESCAPE=1
add_grid $E1 neo_matched UR5_CONTROLLER=neo_matched
add_grid $E1 neo_paper UR5_CONTROLLER=neo_paper
add_grid $E1 combined UR5_CONTROLLER=combined
for part in damper adaptive buffer sweep yield escape; do
  add_grid $E2 minus_$part UR5_CONTROLLER=combined UR5_COMBINED_OFF=$part
done
add_grid $E2 plus_horizon UR5_CONTROLLER=combined UR5_COMBINED_HORIZON=0.3
echo "${#jobs[@]} jobs" > $PWD/e012.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 40)); do
    set -- ${jobs[$i]}
    out=$1; scene=$2; seed=$3; shift 3
    id=${scene}_ellipsoid_geodesic_native_seed$(printf "%02d" $seed)
    [ -f $out/$id/summary.json ] && continue
    ./known_job.sh $out $scene ellipsoid geodesic_native $seed $((w * 2)) "$@"
  done
}
for w in $(seq 0 39); do worker $w & done
wait
echo DONE > $PWD/e012.done
