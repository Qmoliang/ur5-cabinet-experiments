"""Check: every point inside the MuJoCo object geoms lies inside the object's certificate cover."""
import os
import sys

os.environ.setdefault("UR5_OBJECTS", "1")
os.environ.setdefault("UR5_SCENE_JSON", "assets/scene.json")
sys.path[:0] = ["src", "src/core", "."]
import mujoco  # noqa: E402
import numpy as np  # noqa: E402

import run  # noqa: E402
from objects import MovingObjects  # noqa: E402
from robot import build_model, build_robot_certificate  # noqa: E402

scene = run.load_scene()
model = build_model(scene)
data = mujoco.MjData(model)
robot = [s for s in build_robot_certificate(model) if s.body_id != model.body("object0").id]
objs = MovingObjects(model, robot, "ellipsoid", 0.075, scene.boxes, np.array(scene.waypoints[-1]),
                     np.array([0.3, 0.2, 0.6]), count=1, speed=0.25, seed=1, behaviours=["strike"])
obj = objs.objects[0]
rng = np.random.default_rng(0)
for trial in range(4):
    d = rng.normal(size=3)
    d /= np.linalg.norm(d)
    objs._cover_for(obj, d)
    p = np.array([0.3, 0.1, 0.7])
    obj.static_position = p
    objs.place(data, 0.0)
    mujoco.mj_forward(model, data)
    cover = obj.local_cover
    centers = cover.centers + p
    inverse = np.linalg.inv(cover.ellipsoid_shapes)
    worst = 0.0
    for part in ("head", "handle"):
        g = model.geom(f"object0_{part}").id
        R = data.geom_xmat[g].reshape(3, 3)
        half = model.geom_size[g]
        pts = (rng.uniform(-1, 1, (4000, 3)) * half) @ R.T + data.geom_xpos[g]
        delta = pts[:, None, :] - centers[None, :, :]
        measure = np.einsum("pni,nij,pnj->pn", delta, inverse, delta).min(axis=1)
        worst = max(worst, float(measure.max()))
        outside = int((measure > 1 + 1e-9).sum())
        print(f"dir {np.round(d, 2)} {part}: points outside cover {outside}/4000, worst measure {measure.max():.3f}")
