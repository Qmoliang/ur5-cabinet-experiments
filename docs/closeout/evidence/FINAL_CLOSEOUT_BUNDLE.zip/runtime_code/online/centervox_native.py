"""ctypes wrapper for centervox_native.cpp (see that file for what each kernel proves)."""
from __future__ import annotations

import ctypes
from pathlib import Path

import numpy as np

_LIB = None


def _lib():
    global _LIB
    if _LIB is None:
        lib = ctypes.CDLL(str(Path(__file__).resolve().parent / "centervox_kernels.so"))
        dp = ctypes.POINTER(ctypes.c_double)
        lp = ctypes.POINTER(ctypes.c_int64)
        up = ctypes.POINTER(ctypes.c_uint8)
        lib.cv_containment.argtypes = [ctypes.c_int64, dp, dp, dp, up]
        lib.cv_containment.restype = ctypes.c_int32
        lib.cv_frame_uncertainty.argtypes = [ctypes.c_int64, ctypes.c_int64, dp, dp, lp, dp, dp]
        lib.cv_frame_uncertainty.restype = ctypes.c_int32
        lib.cv_translate_mean.argtypes = [ctypes.c_int64, ctypes.c_int64, dp, dp, lp, dp, dp]
        lib.cv_translate_mean.restype = ctypes.c_int32
        lib.cv_bounds_in_frames.argtypes = [ctypes.c_int64, ctypes.c_int64, dp, lp, dp, dp]
        lib.cv_bounds_in_frames.restype = ctypes.c_int32
        _LIB = lib
    return _LIB


def _ptr(array, kind):
    return array.ctypes.data_as(ctypes.POINTER(kind))


def containment_values(inner, outer):
    """(values, needs_exact) with the closed-form rule of _batch_containment_values."""
    inner = np.ascontiguousarray(inner, dtype=np.float64).reshape(-1, 3, 3)
    outer = np.ascontiguousarray(outer, dtype=np.float64).reshape(-1, 3, 3)
    n = len(inner)
    values = np.empty(n, dtype=np.float64)
    flags = np.empty(n, dtype=np.uint8)
    if n:
        _lib().cv_containment(n, _ptr(inner, ctypes.c_double), _ptr(outer, ctypes.c_double),
                              _ptr(values, ctypes.c_double), _ptr(flags, ctypes.c_uint8))
    return values, flags.astype(bool)


def frame_uncertainty_lapack_frames(shapes, displacements, groups, group_count):
    """As frame_uncertainty, but the group frames come from NumPy/LAPACK eigh of
    the group means, the same frames the Python construction uses."""
    shapes = np.ascontiguousarray(shapes, dtype=np.float64).reshape(-1, 3, 3)
    displacements = np.ascontiguousarray(displacements, dtype=np.float64).reshape(-1, 3)
    groups = np.ascontiguousarray(groups, dtype=np.int64).reshape(-1)
    count = int(group_count)
    translated = np.empty_like(shapes)
    means = np.empty((count, 3, 3), dtype=np.float64)
    lib = _lib()
    lib.cv_translate_mean(len(shapes), count, _ptr(shapes, ctypes.c_double), _ptr(displacements, ctypes.c_double),
                          _ptr(groups, ctypes.c_int64), _ptr(translated, ctypes.c_double), _ptr(means, ctypes.c_double))
    _, frames = np.linalg.eigh(means)
    frames = np.ascontiguousarray(frames)
    out = np.empty((count, 3, 3), dtype=np.float64)
    lib.cv_bounds_in_frames(len(shapes), count, _ptr(translated, ctypes.c_double), _ptr(groups, ctypes.c_int64),
                            _ptr(frames, ctypes.c_double), _ptr(out, ctypes.c_double))
    return out, translated


def frame_uncertainty(shapes, displacements, groups, group_count):
    """(frame_uncertainty per group, translated per point) for the legacy Q+U path."""
    shapes = np.ascontiguousarray(shapes, dtype=np.float64).reshape(-1, 3, 3)
    displacements = np.ascontiguousarray(displacements, dtype=np.float64).reshape(-1, 3)
    groups = np.ascontiguousarray(groups, dtype=np.int64).reshape(-1)
    translated = np.empty_like(shapes)
    frames = np.empty((int(group_count), 3, 3), dtype=np.float64)
    _lib().cv_frame_uncertainty(len(shapes), int(group_count), _ptr(shapes, ctypes.c_double),
                                _ptr(displacements, ctypes.c_double), _ptr(groups, ctypes.c_int64),
                                _ptr(translated, ctypes.c_double), _ptr(frames, ctypes.c_double))
    return frames, translated
