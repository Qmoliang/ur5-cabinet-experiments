"""NEO (external_neo/neo_controller.py) behind the known-map runner's controller interface.

Same certificate cover as LiuQP: the ellipsoid distance backend for
ellipsoid covers, the sphere backend (external_neo/sphere_study) for sphere
covers.  `set_cover` swaps the obstacle set (e.g. when the racket moves).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "external_neo"))
from neo_controller import EllipsoidDistances, NEOController  # noqa: E402

INFLUENCE = {"neo_matched": 0.046, "neo_paper": 0.30}


class SphereDistances:
    """external_neo/sphere_study SphereDistances (copied: that module imports the old runner)."""

    def __init__(self, cover):
        self.cover = cover

    def query(self, positions, radii, influence=np.inf):
        delta = self.cover.centers[None, :, :] - positions[:, None, :]
        length = np.linalg.norm(delta, axis=2)
        distance = length - radii[:, None] - self.cover.sphere_radii[None, :]
        ri, oi = np.nonzero(distance <= influence + 1e-10)
        if np.any(length[ri, oi] < 1e-14):
            raise RuntimeError("Coincident sphere centers: separating normal undefined")
        normal = delta[ri, oi] / length[ri, oi, None]
        return ri, oi, distance[ri, oi], normal, 0.0


class NEOMetrics:
    def __init__(self, info):
        self.info = info
        self.status = str(info.get("status", ""))

    def as_dict(self):
        d = dict(self.info)
        d.setdefault("total_controller_ms", 0.0)
        d["broadphase_candidate_pairs"] = int(d.get("distance_candidate_pairs", 0))
        d["active_obstacle_rows"] = int(d.get("obstacle_rows", 0))
        d.setdefault("qp_iterations", 0)
        d.setdefault("geometry_ms", 0.0)
        d.setdefault("limiting_robot_index", -1)
        d.setdefault("limiting_proxy_id", -1)
        d.setdefault("min_clearance", d.get("min_candidate_clearance_m"))
        return d


class NEOAdapter:
    def __init__(self, model, data, robot, cover, representation, kind):
        self.representation = representation
        self.neo = MovingObstacleNEO(model, data, robot, cover, INFLUENCE[kind])
        self.set_cover(cover)
        self.osqp_max_iterations = 0  # reported by the runner; NEO uses quadprog/SLSQP

    def set_cover(self, cover, velocities=None):
        """Obstacle set, and per-obstacle velocities (None = all static)."""
        self.neo.obstacle_velocities = None if velocities is None else np.asarray(velocities, dtype=float)
        if self.representation == "sphere":
            self.neo.geometry = SphereDistances(cover)
        elif getattr(self.neo.geometry, "cover", None) is not cover:
            self.neo.geometry = EllipsoidDistances(cover)

    fallback_cycles = 0

    def solve(self, target):
        try:
            qdot, info = self.neo.solve(np.asarray(target, dtype=float))
        except RuntimeError as error:
            if not getattr(self.neo, "safety_fallback", False):
                raise
            # Same least-violation fallback as the LiuQP variants (src/fallback.py).
            from fallback import W_MOVING, W_STATIC, least_violation
            H, g, A, lo, hi, *_ = self.neo.assemble(np.asarray(target, dtype=float))
            kinds = self.neo.row_kinds
            keep = kinds != "task"
            weights = np.where(kinds == "moving", W_MOVING, W_STATIC)
            qdot = least_violation(A[keep], lo[keep], hi[keep], (kinds == "joint")[keep], weights[keep])
            status = "fallback"
            if qdot is None:
                qdot = np.zeros(6)
                status = "fallback failed"
            self.fallback_cycles += 1
            info = dict(status=status, primary_solver_status=str(error)[:120], qdot_norm=float(np.linalg.norm(qdot)))
        return qdot, NEOMetrics(info)


import neo_controller as _neo  # noqa: E402


class MovingObstacleNEO(NEOController):
    """NEO with moving obstacles: each obstacle damper row also gets n . v_obstacle.

    NEO's damper bounds the approach rate n.J u <= xi (d - d_s) / (d_i - d_s)
    (normals point robot -> obstacle).  For an obstacle moving at v the rate
    that matters is n.(J u - v), so the row becomes
        n.J u <= xi (d - d_s) / (d_i - d_s) + n.v,
    with the obstacle at its current position.  Static obstacles have v = 0,
    which leaves the original NEO unchanged.
    """

    obstacle_velocities = None
    acceleration_limit = None   # rad/s^2 about applied_velocity (same limit as LiuQP's)
    applied_velocity = None
    self_rows = None            # pilot: safety_rows.SelfCollisionRows (NEO damper form)
    safety_fallback = False
    row_kinds = None

    def assemble(self, target):
        H, g, mat, low, high, J, v, e, jm, info = super().assemble(target)
        if self.acceleration_limit is not None and self.applied_velocity is not None:
            # The first six rows are the joint velocity rows (identity).
            step = self.acceleration_limit * _neo.DT
            lo = np.maximum(low[:6], self.applied_velocity - step)
            hi = np.minimum(high[:6], self.applied_velocity + step)
            ok = lo <= hi
            low, high = low.copy(), high.copy()
            low[:6] = np.where(ok, lo, low[:6])
            high[:6] = np.where(ok, hi, high[:6])
        positions, jac, radii = _neo.certificate_world_state(self.model, self.data, self.robot)
        n_obstacle = len(mat) - 9 - 6 * len(positions)
        kinds = np.array(["joint"] * 6 + ["task"] * 3 + ["workspace"] * (6 * len(positions)) + ["static"] * n_obstacle)
        if self.self_rows is not None:
            pairs = self.self_rows.geometry(positions, jac[:, :, :6], radii)
            if pairs:
                # NEO velocity damper on the self gap: n (J_i - J_j) u <= gap / d_i, d_i = 0.05 m.
                mat = np.vstack([mat, np.array([row for _a, _b, _gap, row in pairs])])
                low = np.r_[low, np.full(len(pairs), -np.inf)]
                high = np.r_[high, np.array([gap / 0.05 for _a, _b, gap, _row in pairs])]
                kinds = np.r_[kinds, np.array(["self"] * len(pairs))]
        self.row_kinds = kinds
        if self.obstacle_velocities is None:
            return H, g, mat, low, high, J, v, e, jm, info
        ri, oi, dist, normals, _ = self.geometry.query(positions, radii, self.influence)
        active = dist < self.influence
        extra = np.einsum("pi,pi->p", normals[active], self.obstacle_velocities[oi[active]])
        count = int(active.sum())
        if count:
            high = high.copy()
            # The obstacle rows are the block NEO appends before the self rows.
            n_self = int(np.sum(self.row_kinds == "self"))
            end = len(high) - n_self
            high[end - count:end] += extra
            moving = np.abs(extra) > 0
            self.row_kinds = self.row_kinds.copy()
            self.row_kinds[np.arange(end - count, end)[moving]] = "moving"
        import os
        moving_influence = float(os.environ.get("UR5_NEO_MOVING_INFLUENCE") or 0.0)
        if moving_influence > self.influence:
            ri, oi, dist, normals, _ = self.geometry.query(positions, radii, moving_influence)
            is_moving = np.any(self.obstacle_velocities[oi] != 0.0, axis=1)
            sel = is_moving & (dist < moving_influence)
            if sel.any():
                rows = np.einsum("pi,pij->pj", normals[sel], jac[ri[sel]][:, :, :6])
                bound = ((dist[sel] - self.safety) / (moving_influence - self.safety)
                         + np.einsum("pi,pi->p", normals[sel], self.obstacle_velocities[oi[sel]]))
                mat = np.vstack([mat, rows])
                low = np.r_[low, np.full(len(rows), -np.inf)]
                high = np.r_[high, bound]
                self.row_kinds = np.r_[self.row_kinds, np.array(["moving"] * len(rows))]
        return H, g, mat, low, high, J, v, e, jm, info
