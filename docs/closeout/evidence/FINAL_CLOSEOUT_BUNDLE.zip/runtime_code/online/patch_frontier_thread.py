"""Move the frontier onto the map thread, driven by the occupancy change journal."""
from pathlib import Path
p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/run_protocol_v3_async_online.py")
s = p.read_text()

def sub(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)

sub("""        self.occupancy = NativeIncrementalOccupancyMap(
            MAP_VOXEL_SIZE, track_state_deltas=track_map_deltas
        )
""", """        # Frontier proxies (UR5_FRONTIER=1) follow the map's change journal.
        self._frontier = None
        if os.environ.get("UR5_FRONTIER", "0") == "1":
            from frontier import IncrementalFrontier, region_of_interest
            self._frontier = IncrementalFrontier(
                *region_of_interest(self.scene.boxes), MAP_VOXEL_SIZE
            )
        self.occupancy = NativeIncrementalOccupancyMap(
            MAP_VOXEL_SIZE,
            track_state_deltas=track_map_deltas or self._frontier is not None,
        )
""")
sub("""                occupancy_keys, occupancy_states = (
                    self.occupancy.snapshot_delta_arrays()
                )
            return (
                stats,
                (time.perf_counter() - map_started) * 1000.0,
                occupancy_keys,
                occupancy_states,
            )
""", """                occupancy_keys, occupancy_states = (
                    self.occupancy.snapshot_delta_arrays()
                )
            # The frontier runs here too, hidden behind the CenterVox update.
            # It shares the delta export when one is recorded, so the journal
            # is drained exactly once per map.
            frontier = None
            if self._frontier is not None:
                frontier_started = time.perf_counter()
                if include_map_delta and not include_dense_snapshot:
                    delta_keys, delta_states = occupancy_keys, occupancy_states
                else:
                    delta_keys, delta_states = self.occupancy.snapshot_delta_arrays()
                self._frontier.apply(delta_keys, delta_states)
                frontier = self._frontier.cells() + (
                    (time.perf_counter() - frontier_started) * 1000.0,
                )
            return (
                stats,
                (time.perf_counter() - map_started) * 1000.0,
                occupancy_keys,
                occupancy_states,
                frontier,
            )
""")
sub("""            map_update_ms,
            occupancy_keys,
            occupancy_states,
        ) = map_future.result()""", """            map_update_ms,
            occupancy_keys,
            occupancy_states,
            frontier,
        ) = map_future.result()""")
sub("""        if os.environ.get("UR5_FRONTIER", "0") == "1":
            from frontier import frontier_cells, merge_frontier, region_of_interest
            frontier_started = time.perf_counter()
            known_keys, known_states = self.occupancy.snapshot_arrays()
            roi_lower, roi_upper = region_of_interest(self.scene.boxes)
            centres, radius, cells = frontier_cells(
                known_keys, known_states, MAP_VOXEL_SIZE, roi_lower, roi_upper
            )
            proxies = merge_frontier(proxies, centres, radius, cells)
            frontier_count = int(len(centres))
            frontier_ms = (time.perf_counter() - frontier_started) * 1000.0
""", """        if frontier is not None:
            from frontier import merge_frontier
            centres, radius, cells, frontier_ms = frontier
            merge_started = time.perf_counter()
            proxies = merge_frontier(proxies, centres, radius, cells)
            frontier_count = int(len(centres))
            frontier_merge_ms = (time.perf_counter() - merge_started) * 1000.0
""")
sub("""        frontier_ms = 0.0
""", """        frontier_ms = 0.0
        frontier_merge_ms = 0.0
""")
sub("""            "frontier_ms": frontier_ms,
""", """            "frontier_ms": frontier_ms,
            "frontier_merge_ms": frontier_merge_ms,
""")
p.write_text(s)
print("patched")
