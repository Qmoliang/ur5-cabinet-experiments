from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='goal_entry_v3':";new="        if job.get('policy_version')=='goal_entry_v4':\n            from goal_entry_policy_v4 import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_v3':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'entry_v3_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('entry_v3','entry_v4');j['policy_version']='goal_entry_v4'
(ROOT/'entry_v4_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_v4';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'ENTRY_V4_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},goal_data_sha256=hashlib.sha256((ROOT/'GOAL_BRANCH_PORTS.json').read_bytes()).hexdigest(),change='align self proposal bounds with existing certificate roundoff and existing linear acceptance tolerance; directly certify the same piecewise optimizer to avoid redundant numerical perturbation',objective_unchanged=True,hard_safety_unchanged=True,no_route=True),indent=2))
print(json.dumps(jobs))
