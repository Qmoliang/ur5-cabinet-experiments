from pathlib import Path
import json,hashlib,zipfile,shutil,datetime
from zoneinfo import ZoneInfo
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'delivery';OUT.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
evidence=read(ROOT/'MECHANISM_EVIDENCE.json');assert not evidence['freeze_changed'] and not evidence['protected_old_changed']
freeze=read(ROOT/'FINAL_FREEZE.json');assert all(sha(ROOT/n)==h for n,h in freeze['manifest'].items())
source_index={}
for p in list(ROOT.glob('*.py'))+list((ROOT/'revisions').rglob('*.py'))+[ROOT/'code/online/protocol_liuqp_controller.py']:
 source_index.setdefault(sha(p),[]).append(str(p.relative_to(ROOT)))
records=[]
for f in sorted((ROOT/'trials').iterdir()):
 job=read(f/'job.json');r=read(f/'result.json') if (f/'result.json').exists() else {};a=read(f/'audit.json') if (f/'audit.json').exists() else {};m=read(f/'memory_audit.json') if (f/'memory_audit.json').exists() else {};ps=r.get('policy_summary') or {};interrupted=read(f/'DEVELOPMENT_INTERRUPT.json') if (f/'DEVELOPMENT_INTERRUPT.json').exists() else None
 source=read(f/'source_hashes.json');missing={n:h for n,h in source.items() if h not in source_index}
 status='development_interrupted' if interrupted else r.get('status','startup_error' if (f/'error.json').exists() else 'no_result')
 record=dict(name=f.name,version=job.get('policy_version'),status=status,raw_result_status=r.get('status'),sim_s=r.get('sim_s'),wall_s=r.get('wall_s'),error_mm=r.get('final_error_mm'),goal_hold=r.get('maximum_hold'),goal_reached=bool(r.get('goal_hold_reached') and not interrupted),safety_passed=a.get('safety_passed'),memory_passed=m.get('passed'),validated_arrival=bool(not interrupted and a.get('safe_arrival') and m.get('passed') and not ps.get('memory_certificate_failures',0)),minimum_proxy_gap_mm=a.get('minimum_proxy_gap_mm'),minimum_self_gap_mm=None if not a else a['physical_motion']['minimum_self_m']*1000,workspace_passed=None if not a else a['workspace']['passed'],memory_count=ps.get('memory_count'),inherited_memory_count=m.get('inherited_count'),controller_p99_ms=r.get('controller_ms_p99'),guard_modified=r.get('guard',{}).get('modified'),latency_model=r.get('latency_model'),latency_tail_uses=r.get('latency_trace_tail_uses'),certificate_calls=ps.get('continuation_certificates'),certificate_passes=ps.get('continuation_passes'),certificate_rejections=ps.get('continuation_gate_rejections'),counterexample_fractions_added=ps.get('continuation_counterexample_fractions_added'),admission_rejections=ps.get('admission_rejection_detail'),maximin_no_gain=ps.get('maximin_no_gain'),forbidden_calls=r.get('forbidden_calls'),source_unavailable=missing,job=job,interruption=interrupted)
 if (f/'error.json').exists():record['error']=read(f/'error.json')
 records.append(record)
lookup={x['name']:x for x in records}
group_names={'fixed_failures':['certified_failure_1','certified_failure_2'],'actual_failure_snapshots':['certified_end_1','certified_end_2'],'measured_latency':['certified_measured_1','certified_measured_2'],'original_start':['certified_original_start'],'deterministic_repeat':['certified_failure_1_repeat'],'old_policy_references':['reference_failure_1','reference_failure_2'],'matched_mean_ablation':['ablation_mean_1','ablation_mean_2']}
groups={k:dict(names=ns,completed=sum(n in lookup and lookup[n]['sim_s'] is not None for n in ns),arrivals=sum(lookup.get(n,{}).get('goal_reached',False) for n in ns),validated_arrivals=sum(lookup.get(n,{}).get('validated_arrival',False) for n in ns)) for k,ns in group_names.items()}
final_names=[j['name'] for j in freeze['jobs']];final=[lookup[n] for n in final_names];assert len(final)==8 and all(r['sim_s'] is not None for r in final)
assert all(r['safety_passed'] is not None and r['memory_passed'] is not None for r in records if r['sim_s'] is not None)
inputs=read(ROOT/'INPUTS.json')
for item in inputs:assert sha(Path(item['input_file']))==item['input_sha256'] and sha(Path(item['scene']))==item['scene_sha256']
out=dict(completed_at=datetime.datetime.now(datetime.timezone.utc).astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),scope='same MuJoCo UR5e shelf and frozen observed map; fixed terminal feedback certificate; no RRT or future configuration optimization',groups=groups,final_counts=dict(runs=8,arrivals=sum(r['goal_reached'] for r in final),validated_arrivals=sum(r['validated_arrival'] for r in final),failures=[r['name'] for r in final if not r['goal_reached']],all_safety_passed=all(r['safety_passed'] and r['memory_passed'] for r in final)),records=records,missing_sources={r['name']:r['source_unavailable'] for r in records if r['source_unavailable']},integrity=evidence,inputs=inputs,planned_development_not_run=['continuation_measured_2_maximin'],metadata_correction=evidence['metadata_correction'])
assert not out['missing_sources'],out['missing_sources']
(OUT/'RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
lines=['面向后续进入证书的 LiuQP：同一货架实验','完成时间：'+out['completed_at'],'','结果：最终冻结8次中7次到达、1次未到达。7次包含同一固定时序的确定性重复，不是独立样本成功率。所有最终实际轨迹均通过原独立物理安全与记忆审计。','场景、终态、阈值、原始停滞快照、原观测地图保持不变；无RRT调用，无未来六维构型优化，无航点链。','终端反馈固定为qdot=alpha*(qg-q)，其整段几何轨迹用标量s确定；这包含未来运动验证，不是纯瞬时末端吸引。不能把它描述成原LiuQP软目标没有改变。','','各组结果：']
for k,g in groups.items():
 lines.append(f"{k}: 到达 {g['arrivals']}/{g['completed']}；独立审计到达 {g['validated_arrivals']}/{g['completed']}")
 for name in g['names']:
  r=lookup[name];lines.append(f"  {name}: {r['status']}, {r['sim_s']:.2f}s, {r['error_mm']:.9f}mm, 原安全={r['safety_passed']}, 记忆={r['memory_passed']}, 延迟尾部使用={r['latency_tail_uses']}")
lines+=['','机制证据：','两条上一版失败对照各15001个关节状态逐元素重现，最大差为0。新方法修复了这两条同输入失败；重复时序1的整条轨迹也一致。','两条实际失败快照续跑分别保留4条、3条原防回退约束，并从续跑第0周期独立审计，不删除原记忆来获得成功。','失败时序1：末端误差先由378.13mm增至616.88mm，准备阶段基座/肩/肘变化约+0.618/+1.043/+0.253rad；40.52s首次获得进入证书，50.92s完成到达。说明实际执行了退让与姿态调整，而非只核验公式。','整段证书在新进程由实际首次执行进入状态重放通过。实际进入速度与认证收缩方向的偏离最大约2.5e-12rad/s。该重放复用连续证书实现，另有独立实际轨迹审计，二者不混称。','成对消融保留最终证书、终端目标和缓存，仅替换最弱间隙为平均阻塞：时序1失败、时序2成功；最终最弱间隙为2/2。支持该目标在这两例有帮助，不构成大样本普遍优势。','','仍未解决：','原始起点300s仍未到达，误差649.120892871mm，全程未获得进入证书；不是安全门拒绝进入后的碰撞。准备势函数和缓存/延迟作用下，实际最弱间隙仍可能反复恶化。','该原始起点运行用了旧失败延迟序列，并在耗尽后重复末尾延迟937次；不能称为全程同一旧延迟序列。两条主要失败修复及其重复均无尾部扩展。','两次自然延迟31.24s和211.88s差异很大，尚不能声称稳定时效或实机50Hz。控制器p99在数百毫秒量级，仿真延迟模型已计入。','本轮新增方法没有证明任意通道可达，也没有新增全局防循环定理。它构造的是固定终端反馈可见域，域外准备仍可能陷入新的局部极小。','地图冻结、运动学反馈、没有实体机或接触动力学，也没有持续扩展观测地图的闭环。','','开发失败及中止（单独统计）：']
for r in records:
 if r['name'] not in {n for ns in group_names.values() for n in ns}:lines.append(f"  {r['name']}: {r['status']}, sim_s={r['sim_s']}, error_mm={r['error_mm']}")
lines+=['continuation_measured_2_maximin 尚未启动即取消：已识别未分段整段证书的计算膨胀，保留第1条开发运行的中止前缀。','两次启动中止来自事件日志重复mode字段，修复后使用新目录；未算入最终8次。','原reference_failure_1的工作空间数值边界审计未通过，原标记保留；其与旧失败轨迹完全一致。最终8次均直接通过原审计，不依赖放宽阈值或补充审计。','','元数据纠正：'+out['metadata_correction'],'','完整性：前轮344个保护文件及本轮最终冻结源码无变化；所有运行源码哈希均能对应归档版本。']
(OUT/'FINAL_REPORT.txt').write_text('\n'.join(lines),encoding='utf-8')
for n in ['DERIVATION.txt','MECHANISM_EVIDENCE.json','TERMINAL_CERTIFICATE_REPLAY.json','SNAPSHOT_PROBE.json','FINAL_FREEZE.json','ABLATION_FREEZE.json','DELAY_PROVENANCE.json']:
 if (ROOT/n).exists():shutil.copy2(ROOT/n,OUT/n)
fig,ax=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
def plot(axis,name,label,style='-'):
 z=np.load(ROOT/'trials'/name/'trajectory.npz');axis.plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,style,label=label,lw=1.5)
for i in [1,2]:plot(ax[0,0],'reference_failure_'+str(i),'Old failure '+str(i),'--');plot(ax[0,0],'certified_failure_'+str(i),'New fixed delay '+str(i))
for i in [1,2]:plot(ax[0,1],'certified_end_'+str(i),'Old failure snapshot '+str(i))
for i in [1,2]:plot(ax[1,0],'certified_measured_'+str(i),'Measured delay '+str(i))
plot(ax[1,0],'certified_original_start','Original start (failed)','--')
for i in [1,2]:plot(ax[1,1],'ablation_mean_'+str(i),'Mean objective '+str(i),'--');plot(ax[1,1],'certified_failure_'+str(i),'Maximin '+str(i))
for axis,title in zip(ax.flat,['Exact failed-delay replays','Continue actual failed states with memory','Natural delay and original start','Matched objective ablation']):
 axis.set_title(title);axis.set_yscale('log');axis.axhline(1,color='.5',ls=':',lw=.8);axis.set_xlabel('Simulated time (s)');axis.set_ylabel('Goal error (mm)');axis.grid(alpha=.2);axis.legend(fontsize=7)
fig.savefig(OUT/'comparison.png',dpi=160);plt.close(fig)
(OUT/'REPRODUCE.txt').write_text(f'''Remote root: {ROOT}
Python: /home/hsjed/envs/ur5cab/bin/python
Use a NEW trial folder with the selected frozen job.json; never overwrite runs.
Worker: pilot_worker_continuation.py; policy_version=continuation_certified.
Environment: OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 PYTHONDONTWRITEBYTECODE=1
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
Run: python pilot_worker_continuation.py trials/NEW_RUN
Audits: python audit_certificate_batch.py NEW_RUN
Inherited-memory audit: audit_continuation_memory.py (checks from cycle zero).
The large observed maps, UR5e model assets and native dependencies remain at
paths recorded in INPUTS.json. This archive is source/results, not standalone.
Both fixed failure delays are derived solely from old controller timings;
no previous q trajectory or RRT path is used as a control reference.
''')
files=list(ROOT.glob('*.py'))+list(ROOT.glob('*.json'))+list(ROOT.glob('*.txt'))+list(ROOT.glob('*.npy'))+list((ROOT/'trials').rglob('*'))+list((ROOT/'revisions').rglob('*'))
files += [p for p in (ROOT/'code').rglob('*') if p.suffix in ['.py','.json','.cpp','.h','.hpp','.xml','.txt','.sh']]
files += [p for p in OUT.iterdir() if p.name not in ['sources_and_results.zip','BUNDLE_MANIFEST.json']]
manifest={};archive=OUT/'sources_and_results.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):
  if p.is_file() and '__pycache__' not in p.parts:
   rel=str(p.relative_to(ROOT));z.write(p,rel);manifest[rel]=dict(bytes=p.stat().st_size,sha256=sha(p))
(OUT/'BUNDLE_MANIFEST.json').write_text(json.dumps(dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,files=manifest),indent=2))
print(json.dumps(dict(final_counts=out['final_counts'],groups=groups,total_attempts=len(records),archive_bytes=archive.stat().st_size,missing_sources=out['missing_sources']),ensure_ascii=False))
