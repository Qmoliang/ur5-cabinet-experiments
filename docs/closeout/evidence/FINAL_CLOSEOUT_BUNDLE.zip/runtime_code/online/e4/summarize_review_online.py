"""Reviewer batch, online: every controller with its real compute time (UR5_COMPUTE_DELAY=1).
Sources: review_online/ (seeds 1-20) + pilot_online/neo_{matched,paper}_delay (seeds 1-5, same code path).
clean = 5 mm held 1 s (after every racket has gone), no protective stop.  'launched' = a racket was launched
(depends on the controller's own approach).  Three racket views: launched-only, all runs (intent to treat),
and paired on starts where both controllers launched.  CIs: Wilson 95%; paired tests: exact McNemar."""
import collections
import csv
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from review_stats import mcnemar, rate  # noqa: E402

V = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
CONDS = ["k0_v0.0", "k1_v0.25", "k1_v0.5", "k2_v0.5"]
NAMES = {"k0_v0.0": "no racket", "k1_v0.25": "1 racket @0.25 m/s", "k1_v0.5": "1 racket @0.5 m/s",
         "k2_v0.5": "2 rackets @0.5 m/s"}
SCENES = ["drawer", "cage_wide", "shelf"]
MAIN = ["liuqp_delay", "combined_delay", "neo_matched_delay", "neo_split_delay", "neo_paper_delay"]


def outcome(f):
    s = json.load(open(f))
    e = s.get("e4") or {}
    p = e.get("protective_stop") or {}
    kinds = p.get("kinds") or {}
    o = e.get("objects") or {}
    stopped = bool(p.get("stopped"))
    cause = None
    if stopped:
        cause = "hit" if "object" in kinds else "scene" if "scene" in kinds else "floor" if "floor" in kinds else "self"
    reached = (bool(e.get("success_after")) if (e.get("object_count") or 0) > 0
               else e.get("first_success_5mm_s") is not None)
    status = collections.Counter(r["status"] for r in csv.DictReader(open(f.parent / "cycles.csv")))
    per = e.get("per_object") or []
    return dict(launched=any(d.get("launched") for d in o.get("described", [])), clean=reached and not stopped,
                cause=cause, t=e.get("first_success_5mm_s"), step99=s.get("control_compute_ms_p99", np.nan),
                step50=s.get("control_compute_ms_p50", np.nan), held=(e.get("delay") or {}).get("held_cycles") or 0,
                fb=status.get("fallback", 0), fbfail=status.get("fallback failed", 0),
                delays=[x["detection_delay_s"] for x in per
                        if x.get("launched") and x.get("detection_delay_s") is not None],
                missed=sum(1 for x in per if x.get("launched") and x.get("missed")),
                objs=sum(1 for x in per if x.get("launched")))


R = {}
unfinished = []
for root, only in ((V / "review_online", None), (V / "pilot_online", ("neo_matched_delay", "neo_paper_delay"))):
    for run in root.glob("*/*_s*"):
        if not run.is_dir():
            continue
        name, cond = run.parent.name.rsplit("_k", 1)
        cond = "k" + cond
        if only and name not in only:
            continue
        scene, seed = run.name.rsplit("_s", 1)
        if only and int(seed) > 5:
            continue
        f = next(run.glob("A-CV-*/summary.json"), None)
        if f is None:
            unfinished.append(str(run.relative_to(V)))
            continue
        R[(name, cond, scene, int(seed))] = outcome(f)
print(f"{len(R)} runs; unfinished {len(unfinished)} {unfinished[:5]}")


def cell(out, counted):
    c = collections.Counter(o["cause"] for o in counted if o["cause"])
    return (f"{sum(o['clean'] for o in counted)}/{len(counted)} [{c['hit']} {c['scene']} {c['floor']} {c['self']}] "
            f"L{len(counted)}/{len(out)}")


print("\n== T1 per scene: clean/counted [hit scene floor self] Llaunched/runs (racket cells count launched runs)")
for scene in SCENES:
    print(f"  {scene}")
    for name in MAIN:
        cells = []
        for cond in CONDS:
            out = [o for (n, c, s, _), o in R.items() if (n, c, s) == (name, cond, scene)]
            cells.append(cell(out, out if cond == "k0_v0.0" else [o for o in out if o["launched"]]))
        ts = [o["t"] for (n, c, s, _), o in R.items()
              if (n, c, s) == (name, "k0_v0.0", scene) and o["clean"] and o["t"]]
        print(f"    {name:18s} " + "  ".join(f"{x:24s}" for x in cells)
              + (f" reach {np.median(ts):4.1f}s" if ts else ""))

print("\n== T2 pooled over scenes, rackets: launched-only clean | hit ; all-runs clean (intent to treat)")
for cond in CONDS[1:]:
    print(f"  {NAMES[cond]}")
    for name in MAIN:
        out = [o for (n, c, _s, _), o in R.items() if n == name and c == cond]
        la = [o for o in out if o["launched"]]
        print(f"    {name:18s} clean {rate(sum(o['clean'] for o in la), len(la))}  "
              f"hit {rate(sum(o['cause'] == 'hit' for o in la), len(la))}  "
              f"all-runs clean {rate(sum(o['clean'] for o in out), len(out))}")

print("\n== T3 paired vs combined_delay (same scene/seed/condition; rackets: both launched): "
      "only combined clean | only other clean, McNemar p")
for cond in CONDS:
    for name in MAIN:
        if name == "combined_delay":
            continue
        b = c = n = 0
        for (nm, cd, sc, sd), o in R.items():
            if nm != name or cd != cond:
                continue
            r = R.get(("combined_delay", cd, sc, sd))
            if r is None or (cond != "k0_v0.0" and not (o["launched"] and r["launched"])):
                continue
            n += 1
            b += r["clean"] and not o["clean"]
            c += o["clean"] and not r["clean"]
        print(f"  {NAMES[cond]:20s} combined vs {name:18s} n {n:3d}  only combined {b:3d}  "
              f"only other {c:3d}  p {mcnemar(b, c):.3g}")


def paired_k0(a, b, scenes, seeds=range(1, 21)):
    rows = []
    for scene in scenes:
        x = [(R.get((a, "k0_v0.0", scene, s)), R.get((b, "k0_v0.0", scene, s))) for s in seeds]
        x = [(p, q) for p, q in x if p and q]
        only_a = sum(p["clean"] and not q["clean"] for p, q in x)
        only_b = sum(q["clean"] and not p["clean"] for p, q in x)
        stops_a = collections.Counter(p["cause"] for p, _ in x if p["cause"])
        stops_b = collections.Counter(q["cause"] for _, q in x if q["cause"])
        ta = [p["t"] for p, _ in x if p["clean"] and p["t"]]
        tb = [q["t"] for _, q in x if q["clean"] and q["t"]]
        rows.append(f"    {scene:10s} n {len(x):2d}  A clean {sum(p['clean'] for p, _ in x):2d} "
                    f"t {np.median(ta) if ta else float('nan'):4.1f}s stops {dict(stops_a)}   "
                    f"B clean {sum(q['clean'] for _, q in x):2d} t {np.median(tb) if tb else float('nan'):4.1f}s "
                    f"stops {dict(stops_b)}   discordant {only_a}/{only_b} p {mcnemar(only_a, only_b):.3g}")
    return rows


print("\n== T4 ablations, no racket, paired by start (A = main configuration)")
for ctl in ("liuqp", "combined"):
    print(f"  {ctl}: A ellipsoid vs B sphere")
    print("\n".join(paired_k0(f"{ctl}_delay", f"{ctl}_delay_sphere", SCENES)))
    print(f"  {ctl}: A geodesic vs B straight (drawer)")
    print("\n".join(paired_k0(f"{ctl}_delay", f"{ctl}_delay_straight", ["drawer"])))
    for v in ("dropout5", "noise3"):
        print(f"  {ctl}: A clean camera vs B {v} (seeds 1-10)")
        print("\n".join(paired_k0(f"{ctl}_delay", f"{ctl}_delay_{v}", SCENES, range(1, 11))))

print("\n== T5 compute per configuration (all runs): whole-step ms p50 / p99 (medians), held cycles median, "
      "runs with fallback / failed fallback, detection")
for name in sorted({k[0] for k in R}):
    out = [o for k, o in R.items() if k[0] == name]
    d = [x for o in out for x in o["delays"]]
    print(f"  {name:28s} n {len(out):3d}  step {np.nanmedian([o['step50'] for o in out]):6.1f} / "
          f"{np.nanmedian([o['step99'] for o in out]):6.1f} ms  held {np.median([o['held'] for o in out]):5.0f}  "
          f"fallback runs {sum(o['fb'] > 0 for o in out):3d}  failed-fallback runs {sum(o['fbfail'] > 0 for o in out):3d}  "
          f"detect {1000 * np.median(d) if d else float('nan'):4.0f} ms  "
          f"missed {sum(o['missed'] for o in out)}/{sum(o['objs'] for o in out)}")
