from pathlib import Path
import sys,runpy
R=Path(__file__).resolve().parent;rt=Path(sys.argv[1]);folder=sys.argv[2];cpus=sys.argv[3];sys.path.insert(0,str(rt));import pilot_adapter
pilot_adapter.U=R.parent.parent;pilot_adapter.BASE=pilot_adapter.U/'closeout/final_r17';sys.argv=[str(R/'audit_strict_memory.py'),folder,cpus];runpy.run_path(sys.argv[0],run_name='__main__')
