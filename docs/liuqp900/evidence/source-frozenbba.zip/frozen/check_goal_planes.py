from pathlib import Path
import os,json,numpy as np
os.sched_setaffinity(0,{48,49,50,51})
from pilot_adapter import ROOT,build
from goal_side_plane_policy import LowDimPolicy
R=ROOT;job=json.loads((R/'reproduction_jobs.json').read_text())[0];ctx=build(job['task']);p=LowDimPolicy(ctx,job,lambda **kw:None);out=[]
for name in ['exact_failure_trace','old_zero_delay']:
 q=np.load(R/'trials'/name/'trajectory.npz')['q'][-1];p.k=0;state=p.continuation_witnesses(q);r=min([x for x in state['rows'] if x['kind']=='environment'],key=lambda x:x['slack']);i,j=r['id'];n,offset=p.plane(i,j);s=r['fraction'];errs=[]
 def val(qq):return float(n@p.future_guard.positions((1-s)*qq+s*p.qg)[i]-offset)
 for k in range(6):
  e=np.eye(6)[k]*1e-6;errs.append(abs((val(q+e)-val(q-e))/2e-6-r['b'][k]))
 assert max(errs)<1e-6
 out.append(dict(source=name,maximum_gradient_error=max(errs),goal_plane_slack=float(n@p.goal_points[i]-offset),virtual_slack=r['slack'],physical_sampled_deficit=state['physical_sampled_deficit']))
(R/'GOAL_PLANE_GRADIENT_CHECK.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
