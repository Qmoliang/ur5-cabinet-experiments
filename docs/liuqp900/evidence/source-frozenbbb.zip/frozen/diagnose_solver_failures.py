import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from scipy.optimize import linprog
from pilot_adapter import ROOT
out=[]
for name in ['entry_v5_memory_stall_3','entry_v6_memory_stall_3','entry_v6_memory_initial']:
    folder=ROOT/'trials'/name;r=json.loads((folder/'result.json').read_text());record=dict(name=name,status=r['status'],sim_s=r['sim_s'],error_mm=r['final_error_mm'])
    if (folder/'error.json').exists():record['error']=json.loads((folder/'error.json').read_text())
    candidates=sorted(folder.glob('snapshot_final_*.npz'))
    if candidates:
        path=candidates[-1];z=np.load(path);m=json.loads(path.with_suffix('.json').read_text());A=z['A'];l=z['l'];u=z['u'];up=np.isfinite(u);lo=np.isfinite(l);B=np.vstack([A[up],-A[lo]]);b=np.r_[u[up],-l[lo]]
        options=dict(primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9)
        feasible=linprog(np.zeros(6),A_ub=B,b_ub=b,bounds=[(None,None)]*6,method='highs',options=options)
        phase=linprog(np.r_[np.zeros(6),1.],A_ub=np.c_[B,-np.ones(len(B))],b_ub=b,bounds=[(None,None)]*6+[(0,None)],method='highs',options=options)
        physical_u=u.copy()
        for i,row in enumerate(m['row_ids']):
            if row[0] in ('collision','frontier'):physical_u[i]+=.0005/.02
        physical=linprog(np.zeros(6),A_ub=B,b_ub=np.r_[physical_u[up],-l[lo]],bounds=[(None,None)]*6,method='highs',options=options)
        record.update(snapshot=path.name,original_feasible=bool(feasible.success),original_lp_status=feasible.message,uniform_row_relaxation=None if not phase.success else float(phase.fun),hard_margin_linearized_set_feasible=bool(physical.success))
        if phase.success:
            ids=[m['row_ids'][i] for i in np.flatnonzero(up)]+[m['row_ids'][i] for i in np.flatnonzero(lo)];record['phase_one_active_rows']=[dict(row=ids[i],dual=float(phase.ineqlin.marginals[i]),bound=float(b[i])) for i in np.argsort(phase.ineqlin.marginals)[:8]]
    else:record['exact_final_qp_snapshot_missing']=True
    out.append(record);print(json.dumps(record),flush=True)
(ROOT/'SOLVER_FAILURE_DIAGNOSIS.json').write_text(json.dumps(out,indent=2))
