from concurrent.futures import ProcessPoolExecutor
import multiprocessing as mp,os
from guidance_core import UnifiedGuidance
from planner_core import worker_init
from proxy_geometry import from_known_cover
def create(model,robot,controller,target,initial_q,cover):
 cpus=sorted(os.sched_getaffinity(0))[:2]
 executor=ProcessPoolExecutor(max_workers=1,mp_context=mp.get_context("spawn"),initializer=worker_init,initargs=(cpus,))
 return UnifiedGuidance(model,robot,controller,target,initial_q,from_known_cover(cover),0,executor=executor,blocking=True)
