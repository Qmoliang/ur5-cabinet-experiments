"""Online no-object map check: per run reach (5 mm, held to the end), time to 5 mm, final error, penetration,
unseen-space certificates at the end, controller p99, map age."""
import csv, glob, json, sys
from pathlib import Path
import numpy as np

root = Path(sys.argv[1])
for d in sorted(p for p in root.iterdir() if p.is_dir()):
    inner = next(d.glob("A-CV-*"), None)
    if inner is None or not (inner / "summary.json").exists():
        print(f"{d.name:14s} (no summary)"); continue
    s = json.load(open(inner / "summary.json"))
    r = list(csv.DictReader(open(inner / "cycles.csv")))
    e = np.array([float(x["error_m"]) for x in r]); t = np.array([float(x["time_s"]) for x in r])
    below = e < 0.005
    held = np.flatnonzero(~below)
    first_held = None if below[-1] is False or not below[-1] else (t[held[-1] + 1] if len(held) else t[0])
    p = np.load(inner / "final_causal_proxies.npz")
    U = p["proxy_uncertainty_shapes"]
    unseen = int(np.all(np.abs(U.reshape(len(U), -1)) < 1e-15, axis=1).sum())
    age = [float(x["snapshot_age_ms"]) for x in r if x["snapshot_age_ms"]]
    print(f"{d.name:14s} reached {'yes' if first_held is not None else 'NO '}  t5mm {first_held if first_held is not None else '-':>6}  "
          f"final {e[-1]*1e3:6.1f} mm  pen {s.get('maximum_penetration_m', 0)*1e3:4.1f} mm  unseen {unseen:6d}  "
          f"p99 {s.get('controller_ms_p99', 0):5.1f} ms  map age p50 {np.median(age)/1e3 if age else 0:4.2f} s")
