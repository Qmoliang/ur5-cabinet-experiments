from pathlib import Path
import json,hashlib,zipfile,shutil,datetime,platform,sys
from zoneinfo import ZoneInfo
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'delivery';OUT.mkdir(exist_ok=True)
OLD=ROOT.parent/'liuqp_release_study_20261106';LOW=ROOT.parent/'liuqp_lowdim_pilot_20261106'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(path):
    data=read(path);bad=[name for name,digest in data.items() if not Path(name).exists() or sha(Path(name))!=digest]
    return dict(checked=len(data),unchanged=len(data)-len(bad),changed_or_missing=bad)
integrity=dict(previous_release_study=check(ROOT/'PROTECTED_PREVIOUS_STUDY.json'),first_lowdim_study=check(OLD/'PROTECTED_PREVIOUS_STUDY.json'),formal_original=check(LOW/'PROTECTED_SOURCE_HASHES.json'))
assert all(not x['changed_or_missing'] for x in integrity.values())
inputs=read(ROOT/'INPUTS.json')
for item in inputs:
    assert sha(Path(item['input_file']))==item['input_sha256'];assert sha(Path(item['scene']))==item['scene_sha256']
snapshot=LOW/'confirm_original_shelf_t2_baseline_300s_final_snapshot.npz'
index={}
for p in list(ROOT.glob('*.py'))+list((ROOT/'revisions').rglob('*.py'))+[ROOT/'code/online/protocol_liuqp_controller.py']:
    index.setdefault(sha(p),[]).append(str(p.relative_to(ROOT)))
records=[]
for folder in sorted((ROOT/'trials').iterdir()):
    if not (folder/'result.json').exists():continue
    r=read(folder/'result.json');job=read(folder/'job.json');a=read(folder/'audit.json') if (folder/'audit.json').exists() else None;m=read(folder/'memory_audit.json') if (folder/'memory_audit.json').exists() else None
    ps=r.get('policy_summary') or {};events=ps.get('events',[]);tr=np.load(folder/'trajectory.npz');q=tr['q'];errors=tr['goal_error'];port=ps.get('goal_port',{})
    freeze=read(folder/'source_hashes.json');missing={name:digest for name,digest in freeze.items() if digest not in index}
    activated=[e for e in events if e['event'] in ('actual_cartesian_stall_activates_target_end_module','original_liuqp_stall_activates_target_end_module')]
    safe_arrival=bool(a and a['safe_arrival']);memory_ok=bool(m and m['passed'] and not ps.get('memory_certificate_failures',0))
    record=dict(name=folder.name,version=job.get('policy_version'),start='fixed_real_stall' if job.get('start_snapshot') else 'original_public_start',latency_model=r.get('latency_model','measured_control_compute'),status=r['status'],simulation_s=r['sim_s'],wall_s=r['wall_s'],error_mm=r['final_error_mm'],minimum_goal_error_mm=None if not len(errors) else float(errors.min()*1000),peak_goal_error_mm=None if not len(errors) else float(errors.max()*1000),physical_safety=None if a is None else a['safety_passed'],physical_goal_arrival=safe_arrival,memory_audit=None if m is None else m['passed'],memory_runtime_failures=ps.get('memory_certificate_failures',0),validated_arrival=safe_arrival and memory_ok,minimum_proxy_gap_mm=None if a is None else a['minimum_proxy_gap_mm'],minimum_self_gap_mm=None if a is None else 1000*a['physical_motion'].get('minimum_self_m',float('nan')),memory_count=ps.get('memory_count',0),phase_changes=sum(e['event']=='mode_changed' for e in events),queue_flushes=r.get('mode_command_queue_flushes'),surface_transfers=ps.get('surface_proxy_transfers',0),controller_p99_ms=r.get('controller_ms_p99'),guard_p99_ms=r.get('guard',{}).get('ms_p99'),qp_failure_events=r.get('qp_failure_events',[]),qp_braking_steps=r.get('qp_certified_braking_steps',0),numerical_fallback_rejections=r.get('numerical_fallback_rejections',0),activation=activated,source_unavailable=missing,job=job)
    if port:
        qg=np.asarray(port['goal_q']);P=np.asarray(port['posture_matrix']);record['final_posture_distance_rad']=float(np.linalg.norm(q[-1]-qg));record['final_memory_posture_error_m']=np.asarray(P@(q[-1]-qg)).tolist();record['goal_q']=qg.tolist()
    if a is not None:
        record.update(environment_audit=a['physical_motion'].get('environment_passed'),self_audit=a['physical_motion'].get('self_passed'),workspace_audit=a['workspace']['passed'],minimum_workspace_sampled_slack_m=a['workspace']['minimum_sampled_slack_m'],workspace_uncertified_intervals=len(a['workspace']['bad_intervals']))
    if (folder/'error.json').exists():record['execution_error']=read(folder/'error.json')['error']
    if job.get('start_snapshot'):record['start_snapshot_sha256']=sha(Path(job['start_snapshot']))
    record['failure_interpretation']='development interruption; only the executed prefix is audited' if r['status']=='interrupted_defective_certificate' else 'see status and separate physical/memory audits'
    records.append(record)
byname={r['name']:r for r in records}
groups={
 'fixed_snapshot_final_execution':[f'entry_final_memory_stall_{i}' for i in [1,2,3]],
 'online_before_progress_reset':['entry_final_memory_initial'],
 'online_after_progress_reset':[f'online_activation_reset_{i}' for i in [1,2,3]],
 'recorded_failed_delay_stress':['failed_latency_schedule_replay'],
 'same_control_law_before_execution_recovery':[f'entry_v7_memory_stall_{i}' for i in [1,2,3]],
 'versioned_ablations':['entry_v7_only_stall','entry_v7_clearance_exit_stall']}
cohorts={name:dict(runs=items,attempted=sum(i in byname for i in items),validated_arrivals=sum(i in byname and byname[i]['validated_arrival'] for i in items),all_audited=all(i in byname and byname[i]['physical_safety'] is not None and byname[i]['memory_audit'] is not None for i in items)) for name,items in groups.items()}
out=dict(completed_local_time=datetime.datetime.now(datetime.timezone.utc).astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),scope='same shelf, seed 1, original physical safety, fixed causal observed map; UR5e kinematic closed loop, no RRT route or global path search; not hardware or generalization evidence',inputs=inputs,original_stall_snapshot=dict(path=str(snapshot),sha256=sha(snapshot)),integrity=integrity,cohorts=cohorts,counts=dict(runs=len(records),audited=sum(r['physical_safety'] is not None for r in records),safety_audits_passed=sum(r['physical_safety'] is True for r in records),safety_audits_not_passed=sum(r['physical_safety'] is False for r in records),memory_audits_passed=sum(r['memory_audit'] is True for r in records),validated_arrivals=sum(r['validated_arrival'] for r in records),development_interruptions=sum(r['status']=='interrupted_defective_certificate' for r in records)),source_coverage=dict(missing_count=sum(len(r['source_unavailable']) for r in records),missing={r['name']:r['source_unavailable'] for r in records if r['source_unavailable']}),records=records)
(OUT/'RESULTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
table=['逐次运行记录：不同开发版本不可混合解释为某算法成功率。','name | start | status | sim_s | error_mm | physical safety | memory | arrival']
for r in records:table.append(f"{r['name']} | {r['start']} | {r['status']} | {r['simulation_s']:.2f} | {r['error_mm']} | {r['physical_safety']} | {r['memory_audit']} | {r['validated_arrival']}")
(OUT/'RESULTS.txt').write_text('\n'.join(table),encoding='utf-8')
report=['目标端引导 LiuQP：本轮实现与验证','完成时间：'+out['completed_local_time'],'',
'结论：已实现目标端局部反推与持续绕行控制，但不能宣称可靠性问题已经解决。必须同时看固定快照、在线触发和失败时序复现，不能只取最后一组成功。','',
'实现遵循原意：从目标端推导进入方向、完整终态的零空间姿态偏置与持续绕行记忆；不调用 RRT 搜索，不生成当前状态到目标的关节路径。',
'正常动作仍由当前速度 QP 求解，原物理安全和到达标准保留。暂态原 QP 不可行时仅执行已有证书允许的制动，再重试原 QP；停车后仍无解则失败。','',
'必须并列报告以下结果：']
for name,group in cohorts.items():
    report.append(f"{name}: {group['validated_arrivals']}/{group['attempted']} 经物理与记忆审计的到达")
    for item in group['runs']:
        if item in byname:
            r=byname[item];error_text='n/a' if r['error_mm'] is None else f"{r['error_mm']:.6f}";report.append(f"  {item}: {r['status']}, {r['simulation_s']:.2f} s, {error_text} mm, 认证制动 {r['qp_braking_steps']} 周期, 记忆 {r['memory_count']} 条")
report+=['',
'固定快照的三个最终回放不能代表所有进入状态。未重置进展参考的原初态整程失败也保留：激活时相对固定快照腕部相差约 1.59 rad，而且只过四个周期就进入绕行。之后的整程复验只修正进展参考初始化，不更换初态。',
'失败延迟序列回放只替换命令计算延迟，不输入旧运动轨迹。它是离线时序诊断，不能与实际测得延迟的运行混成成功率，也不能被隐藏。',
'该回放与此前失败运行的 12139 个关节状态逐项完全相同，最大关节轨迹差和目标误差差均为 0，且没有使用人工延长的延迟序列尾部。失败可以在同一输入下由同一调度模式确定性重现。',
'在该失败末态重新构造当前目标导向的切向基后，多个局部速度都能通过完整安全门。这个只读诊断没有执行它们，也没有证明最终到达；它表明在线保存的方向族耗尽不等于物理无路，方向记忆与目标侧参考的更新仍需解决。',
'此前同一持久绕行控制律也有失败：必须参考上表 execution-recovery 前的三次记录，不能只展示最后一个较好的批次。','',
'安全审计的限定：49 条轨迹都完成审计，44 条通过原完整安全审计，5 条非成功轨迹的工作空间连续认证未通过；这些失败结果没有改判。五条记录的环境碰撞、自碰与代理检查通过，工作空间最低采样余量约为 -1e-10 m，处于数值边界，不能把它描述为已确认的宏观碰撞，也不能把采样结果代替连续证明。所有计入到达的运行均通过完整物理与记忆审计。','',
'本轮真正推导并实现的内容：',
'1. 静态终态 IK 与局部回退段认证，提供进入轴和受阻部位的目标侧几何；这不证明当前到该入口的连通性。',
'2. 当前任务雅可比 K_sigma 与零空间 N_sigma=I-K_sigma^dagger K_sigma。正常时跟踪末端进入场；绕行时跟踪受阻点的安全法向/切向分量。完整终态只作为零空间姿态偏置。',
'3. 切向方向跨代理变化持续运输，法向修正不再退出绕行阶段；避免重复切回最终点吸引而反复制动。',
'4. 以实际净特征进展和目标侧相容性决定退出，并保留逐段、逐制动可认证的防回陷半空间；其目标终态始终在内，但不能保证连通性。',
'5. 原硬约束、追加约束及新目标的 KKT 作用映射成原执行 QP 的有效梯度，并验证实际执行解；QP 与制动安全证书的数值保留量已对齐。','',
'失败分析中区分了：旧增广余量求解器假停滞、局部姿态投影混淆构型分支、自碰证书与提案差异、OPEN/BYPASS 抖动、实际方向族耗尽、原 QP 暂态不可行、在线激活历史污染和时序敏感性。各类证据单独保存，未把它们统称为局部极小。',
'两次精确回放表明，原 QP 暂态不可行可在一次已有认证制动后恢复；这支持有限恢复分支，不支持放宽硬安全或在空可行集里凭目标函数产生动作。','',
'结论边界：',
'这是已实现的研究控制器，不是全局逃逸定理。目标端信息是局部的，没有获得 RRT 反向树的连接关系。固定快照、在线触发及延迟压力的结果必须一起判断。',
'目标姿态是内部准备参考；到达仍按原末端位置任务判定，不声称额外完成了未给定的末端姿态精确跟踪。',
'没有真实硬件、持续新感知、传感噪声或跨 seed/场景验证；控制与安全认证耗时单独记录，不宣称硬实时。',
'原项目与前两轮记录哈希保持不变：'+json.dumps(integrity,ensure_ascii=False),
'本轮运行统计（混合开发版本）：'+json.dumps(out['counts'],ensure_ascii=False),
'详细公式见 FINAL_METHOD.txt；中间推导见 DERIVATION.txt；全部失败与中止前缀见 RESULTS.json 与压缩包。']
(OUT/'FINAL_REPORT.txt').write_text('\n'.join(report),encoding='utf-8')
for name in ['FINAL_METHOD.txt','DERIVATION.txt','GOAL_PORTS.json','GOAL_BRANCH_PORTS.json','ENTRY_PREFLIGHT.json','ENTRY_BRANCH_PREFLIGHT.json','PIECEWISE_VALIDATION.json','SELF_CERTIFICATE_VALIDATION.json','SURFACE_PREFLIGHT.json','ENTRY_FAILURE_DIAGNOSIS.json','ENTRY_ADMISSION_DIAGNOSIS.json','DUAL_PROVENANCE_DIAGNOSIS.json','SOLVER_FAILURE_DIAGNOSIS.json','CERTIFIED_STOP_REPLAY.json','ACTIVATION_DIAGNOSIS.json','FINAL_ROBUSTNESS_DIAGNOSIS.json','FAILED_DELAY_SOURCE.json','V3_DEVELOPMENT_INTERRUPTION.json']:
    if (ROOT/name).exists():shutil.copy2(ROOT/name,OUT/name)
fig,axs=plt.subplots(2,2,figsize=(13,8.5),constrained_layout=True)
fixed=groups['fixed_snapshot_final_execution']+groups['recorded_failed_delay_stress']
for index_,name in enumerate(fixed):
    path=ROOT/'trials'/name/'trajectory.npz'
    if not path.exists():continue
    z=np.load(path);label=f'Stall replay {index_+1}' if index_<3 else 'Recorded failed-delay test';style='-' if index_<3 else '--';t=np.arange(1,len(z['goal_error'])+1)*.02
    axs[0,0].plot(t,z['goal_error']*1000,style,label=label,lw=1.4)
    port=read(ROOT/'trials'/name/'result.json')['policy_summary']['goal_port'];qg=np.asarray(port['goal_q']);axs[1,0].plot(np.arange(len(z['q']))*.02,np.linalg.norm(z['q']-qg,axis=1),style,label=label,lw=1.3)
for index_,name in enumerate(groups['online_after_progress_reset']):
    path=ROOT/'trials'/name/'trajectory.npz'
    if path.exists():
        z=np.load(path);axs[0,1].plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,label=f'Online run {index_+1}',lw=1.4)
z=np.load(ROOT/'trials/entry_final_memory_initial/trajectory.npz');axs[0,1].plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,'--',color='.55',label='Before activation-history reset',lw=1)
for label,name in [('Earlier chattering version','entry_v6_memory_stall_1')]+[(f'Final replay {i}',f'entry_final_memory_stall_{i}') for i in [1,2,3]]:
    r=read(ROOT/'trials'/name/'result.json');ev=[e for e in r['policy_summary']['events'] if e['event']=='mode_changed'];times=np.r_[0,[e['cycle']*.02 for e in ev],r['sim_s']];counts=np.r_[1,np.arange(1,len(ev)+1)+1,len(ev)+1]
    axs[1,1].step(times,counts,where='post',label=label,lw=1.3)
axs[0,0].set_title('Same real-stall snapshot');axs[0,1].set_title('Same original start: online activation')
for ax in axs[0]:ax.set_ylabel('Goal error (mm, log)');ax.set_yscale('log');ax.axhline(1,color='.3',ls=':',lw=.8)
axs[1,0].set_title('Posture reference is guidance, not a new goal tolerance');axs[1,0].set_ylabel('Joint distance to terminal reference (rad)')
axs[1,1].set_title('Persistent surface task: phase-switch count');axs[1,1].set_ylabel('1 + phase changes (log)');axs[1,1].set_yscale('log')
for ax in axs.ravel():ax.set_xlabel('Simulated time (s)');ax.grid(alpha=.2);ax.legend(fontsize=7)
fig.suptitle('Goal-end LiuQP: repeated arrivals and a reproducible failure',fontsize=13);fig.savefig(OUT/'comparison.png',dpi=170);plt.close(fig)
import scipy,mujoco,osqp
sys.path.insert(0,str(ROOT/'vendor'));import clarabel
environment=dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,mujoco=mujoco.__version__,osqp=osqp.__version__,clarabel=clarabel.__version__,platform=platform.platform(),worker_cpu_sets=[[48,49,50,51],[52,53,54,55]],worker_openblas_threads=1,worker_omp_threads=2)
(OUT/'ENVIRONMENT.json').write_text(json.dumps(environment,indent=2))
repro=f'''Remote root: {ROOT}
Python: /home/hsjed/envs/ur5cab/bin/python

Validated integration entry: pilot_worker_integration.py, policy_version=goal_entry_activated.
Copy a job from integration_jobs.json or entry_final_jobs.json into a NEW trial directory;
never overwrite an existing run. Preserve the correct worker/policy combination.
Environment: OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6 PYTHONDONTWRITEBYTECODE=1
Run: python pilot_worker_integration.py trials/NEW_DIRECTORY
Physical audit: python audit_pilot.py trials/NEW_DIRECTORY 56,57,58,59
Memory audit: python audit_goal_memory.py trials/NEW_DIRECTORY 56,57,58,59

The latest executable policy has a research inheritance chain. Actual objective is in
goal_entry_policy_v6.py; persistent surface logic is in v5/v7; the activated wrapper
only resets progress references on handoff. Inherited legacy parameter summaries
are not authoritative; use the frozen job, source hashes and FINAL_METHOD.txt.

This archive contains source and recorded experiments, not a standalone environment.
The 89 MB observed-map NPZ, model assets and native/runtime dependencies remain at
the recorded server paths. INPUTS.json and RESULTS.json record their identity.
Do not reproduce an old trial by using the latest policy indiscriminately: select
the archived sources matching its source_hashes.json.
No hardware has been commanded. No current-to-goal route is computed by this method.
'''
(OUT/'REPRODUCE.txt').write_text(repro)
selected=list(ROOT.glob('*.py'))+list(ROOT.glob('*.json'))+list(ROOT.glob('*.txt'))+list(ROOT.glob('*.npy'))+list(ROOT.glob('*.npz'))
selected+=list((ROOT/'revisions').rglob('*'))+list((ROOT/'trials').rglob('*'))
selected+=[p for p in (ROOT/'code').rglob('*') if p.suffix in ('.py','.json','.cpp','.h','.hpp','.sh','.xml','.txt')]
selected+=[p for p in OUT.iterdir() if p.suffix!='.zip' and p.name!='BUNDLE_MANIFEST.json']
manifest={};archive=OUT/'goal_entry_sources_and_results.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(set(selected)):
        if not p.is_file() or '__pycache__' in p.parts:continue
        name=str(p.relative_to(ROOT));z.write(p,name);manifest[name]=dict(bytes=p.stat().st_size,sha256=sha(p))
(OUT/'BUNDLE_MANIFEST.json').write_text(json.dumps(dict(archive_bytes=archive.stat().st_size,archive_sha256=sha(archive),files=manifest),indent=2))
print(json.dumps(dict(counts=out['counts'],cohorts=cohorts,integrity=integrity,source_coverage=out['source_coverage'],archive_bytes=archive.stat().st_size),ensure_ascii=False),flush=True)
