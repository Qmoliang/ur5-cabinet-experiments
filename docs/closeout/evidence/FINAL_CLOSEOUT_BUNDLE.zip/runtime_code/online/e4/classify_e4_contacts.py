"""Replay E4 runs with penetrating non-object contacts against the static scene (no objects):
classify as cabinet (scene geom), floor, or self (robot-robot), with the deepest cabinet penetration."""
import collections
import json
import sys
from pathlib import Path

import numpy as np

sys.path[:0] = ["/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6"]
import mujoco  # noqa: E402

import run_protocol_v3_async_online as online  # noqa: E402
from model import build_model, set_configuration  # noqa: E402

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e4")
model = build_model(online._protocol_scene("camera_quarter"))
data = mujoco.MjData(model)
table = collections.defaultdict(collections.Counter)
deepest = collections.defaultdict(float)
for f in sorted(ROOT.glob("*_k*_v*/seed*/summary.json")):
    s = json.load(open(f))
    if not s["e4"]["static_penetrating_cycles"]:
        continue
    ctl = f.parent.parent.name.split("_k")[0]
    inner = next(f.parent.glob("A-CV-*"))
    kinds = set()
    for q in np.load(inner / "q_history.npy")[::2]:
        set_configuration(model, data, q)
        for k in range(data.ncon):
            c = data.contact[k]
            if c.dist >= -1e-8:
                continue
            b1, b2 = int(model.geom_bodyid[c.geom1]), int(model.geom_bodyid[c.geom2])
            names = {model.geom(c.geom1).name, model.geom(c.geom2).name}
            if "floor" in names:
                kinds.add("floor")
            elif b1 == 0 or b2 == 0:
                kinds.add("cabinet")
                deepest[ctl] = min(deepest[ctl], float(c.dist))
            else:
                kinds.add("self")
    for kind in kinds:
        table[ctl][kind] += 1
    table[ctl]["runs"] += 1
for ctl, counts in sorted(table.items()):
    print(f"{ctl:10s} runs with non-object penetration {counts['runs']}: cabinet {counts['cabinet']}, "
          f"floor {counts['floor']}, self {counts['self']}; deepest cabinet {deepest[ctl] * 1000:.1f} mm")
