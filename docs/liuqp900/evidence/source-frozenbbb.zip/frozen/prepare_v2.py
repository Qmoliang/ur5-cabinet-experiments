from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
p=ROOT/'pilot_worker_reheading.py';s=p.read_text();old="        if job.get('policy_version')=='reheading':";new="        if job.get('policy_version')=='reheading_v2':\n            from reheading_policy_v2 import LowDimPolicy\n        elif job.get('policy_version')=='reheading':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'jobs.json').read_text())[1:]
for j in jobs:j['name']=j['name'].replace('reheading_','reheading_v2_',1);j['policy_version']='reheading_v2'
(ROOT/'v2_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/reheading_v2';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'V2_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='reselection also covers an executable but stagnant heading dominated by a certified target-side alternative; moving reheading first brakes then recomputes at the stopped state',threshold_derivation='existing 0.2mm progress requirement / existing 100-cycle window; not a new fitted gain',objective_and_safety_unchanged=True),indent=2))
print(json.dumps([j['name'] for j in jobs]))
