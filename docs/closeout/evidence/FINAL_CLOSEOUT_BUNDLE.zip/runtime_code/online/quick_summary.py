"""One line per run: reach, error, penetration, map timing, look events."""
import csv, json, sys
from pathlib import Path
import numpy as np
for root in sys.argv[1:]:
    for case in sorted(Path(root).glob("seed*")):
        if not case.is_dir():
            continue
        d = next((p for p in case.iterdir() if p.is_dir()), None)
        summary = next(d.glob("*summary*.json"), None) if d else None
        if summary is None:
            print(case.name, "no summary"); continue
        s = json.load(open(summary))
        frames = list(csv.DictReader(open(d / "perception_frames.csv")))[1:]
        med = lambda k: round(float(np.median([float(r[k]) for r in frames if r.get(k) not in (None, "")])), 1) if frames and k in frames[0] else None
        cycles = list(csv.DictReader(open(d / "cycles.csv")))
        last = cycles[-1]
        pen = min(float(r["minimum_contact_distance"]) for r in cycles if r.get("minimum_contact_distance") not in (None, "", "None")) if "minimum_contact_distance" in last else None
        events = s.get("active_look_events")
        print(f"{root.split('/')[-1]}/{case.name}: reached={s.get("success")} "
              f"err={1000*float(last['error_m']):.1f}mm pipeline={med('frame_pipeline_ms')} proxy={med('proxy_update_ms')} "
              f"frontier={med('frontier_ms')} merge={med('frontier_merge_ms')} mvt={med('mvt_update_ms')} "
              f"age={med('publish_snapshot_age_ms')} looks={None if events is None else [(e.get('start_cycle'), e.get('reason')) for e in events]}")
