from pathlib import Path
import json,hashlib,zipfile,shutil,sys,subprocess
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_lowdim_pilot_20261106';OUT=ROOT/'delivery';OUT.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def check(manifest):
    m=read(manifest);bad=[str(p) for name,digest in m.items() if not (p:=Path(name)).exists() or sha(p)!=digest]
    return dict(checked=len(m),unchanged=len(m)-len(bad),changed_or_missing=bad)
integrity=dict(previous_study=check(ROOT/'PROTECTED_PREVIOUS_STUDY.json'),formal_original=check(OLD/'PROTECTED_SOURCE_HASHES.json'))
inputs=read(ROOT/'INPUTS.json')
for e in inputs:
    e['actual_input_sha256']=sha(Path(e['input_file']));e['actual_scene_sha256']=sha(Path(e['scene']))
    assert e['actual_input_sha256']==e['input_sha256'] and e['actual_scene_sha256']==e['scene_sha256']
assert all(not x['changed_or_missing'] for x in integrity.values())
source_index={}
for p in list(ROOT.glob('*.py'))+list((ROOT/'revisions').rglob('*.py'))+[ROOT/'code/online/protocol_liuqp_controller.py']:
    source_index.setdefault(sha(p),[]).append(str(p.relative_to(ROOT)))
records=[]
for folder in sorted((ROOT/'trials').iterdir()):
    if not (folder/'result.json').exists():continue
    r=read(folder/'result.json');job=read(folder/'job.json');a=read(folder/'audit.json') if (folder/'audit.json').exists() else None
    z=np.load(folder/'trajectory.npz');qs=z['q'];es=z['goal_error'];ps=r.get('policy_summary') or {}
    source=read(folder/'source_hashes.json');missing={name:digest for name,digest in source.items() if digest not in source_index}
    rec=dict(name=folder.name,start='real_stall' if job.get('start_snapshot') else 'original',status=r['status'],simulation_s=r['sim_s'],final_error_mm=r['final_error_mm'],safe_arrival=False if a is None else a['safe_arrival'],safety_audit=None if a is None else a['safety_passed'],minimum_proxy_gap_mm=None if a is None else a['minimum_proxy_gap_mm'],controller_p99_ms=r['controller_ms_p99'],guard_modified=r['guard'].get('modified'),guard_failed=r['guard'].get('failed'),joint_base_net_change_rad=float(qs[-1,0]-qs[0,0]),elbow_net_change_rad=float(qs[-1,2]-qs[0,2]),joint_base_minimum_lower_reserve_rad=float(np.min(qs[:,0]+6.26819)),cumulative_goal_distance_increase_mm=float(np.maximum(np.diff(es),0).sum()*1000),release_events=[x for x in ps.get('events',[]) if x['event'] in ('release_selected','release_recovered','mode_changed')],rejections=ps.get('rejections'),source_unavailable=missing,polish_max_velocity_difference=ps.get('polish_max_velocity_difference'),job=job)
    rec.update(minimum_goal_error_mm=float(np.min(es)*1000) if len(es) else None,peak_goal_error_mm=float(np.max(es)*1000) if len(es) else None,blocker_selected_count=sum(x['event']=='blocker_selected' for x in ps.get('events',[])),early_pruned_row_exits=sum(x['event']=='blocker_no_longer_active' for x in ps.get('events',[])),retained_geometry_queries=ps.get('retained_geometry_queries'),pruned_row_continuations=ps.get('pruned_row_continuations'),augmented_failures=ps.get('augmented_failures'),certificate_rejections=ps.get('certificate_rejections'))
    rec['geometric_events']=[x for x in ps.get('events',[]) if x['event'] in ('blocker_selected','blocker_no_longer_active','blocker_released_with_task_progress','retained_geometry_cleared')]
    if (folder/'error.json').exists():rec['execution_error']=read(folder/'error.json')['error']
    records.append(rec)
coverage=dict(trials=len(records),missing_source_count=sum(len(x['source_unavailable']) for x in records),per_trial={r['name']:r['source_unavailable'] for r in records if r['source_unavailable']})
report=dict(scope='Single development shelf case; kinematic UR5e closed loop; frozen causal observed map; no runtime planner/route/waypoint; not hardware or generalization evidence',inputs=inputs,integrity=integrity,source_coverage=coverage,records=records,counts=dict(runs=len(records),audited=sum(x['safety_audit'] is not None for x in records),safe_arrivals=sum(x['safe_arrival'] for x in records),real_stall_starts=sum(x['start']=='real_stall' for x in records),real_stall_safe_arrivals=sum(x['start']=='real_stall' and x['safe_arrival'] for x in records)))
(OUT/'RESULTS.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
lines=['同一货架复验结果（开发实验，不是独立测试集）','详见 DERIVATION_REVIEW.txt；每个失败与数值中止均保留。',json.dumps(report['counts'],ensure_ascii=False),'','name | start | status | sim_s | error_mm | safety | arrival | min_gap_mm']
for r in records:lines.append(f"{r['name']} | {r['start']} | {r['status']} | {r['simulation_s']:.2f} | {r['final_error_mm']} | {r['safety_audit']} | {r['safe_arrival']} | {r['minimum_proxy_gap_mm']}")
lines+=['','原始结果与前一轮文件完整性：',json.dumps(integrity,ensure_ascii=False),'','代码版本覆盖：',json.dumps(coverage,ensure_ascii=False)]
(OUT/'RESULTS.txt').write_text('\n'.join(lines),encoding='utf-8')
shutil.copy2(ROOT/'DERIVATION_REVIEW.txt',OUT/'DERIVATION_REVIEW.txt')
for name in ['SUCCESS_FAILURE_COMPARISON.json','REJECTION_CLASSIFICATION.json','OBJECTIVE_PREFLIGHT.json','POSTURE_VALUE_PROBES.json','CONTRACT_DIAGNOSIS.json','FEASIBILITY_DIAGNOSIS.json','RETAINED_GEOMETRY_VALIDATION.json']:
    if (ROOT/name).exists():shutil.copy2(ROOT/name,OUT/name)
fig,axs=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
comparison=read(ROOT/'SUCCESS_FAILURE_COMPARISON.json');guided=Path(comparison['records'][0]['source'])
curves=[('Original LiuQP',OLD/'trials/confirm_original_shelf_t2_baseline_300s'),('Historical RRT-guided',guided),('Prototype v1 (arrival)',ROOT/'trials/reserve_release'),('Revised + spatial',ROOT/'trials/polished_joint_spatial_hard_gate'),('Retained geometric release',ROOT/'trials/retained_blocker_gate')]
for label,p in curves:
    if not (p/'trajectory.npz').exists():continue
    z=np.load(p/'trajectory.npz');q=z['q'];e=z['goal_error'];t=np.arange(1,len(e)+1)*.02
    axs[0,0].plot(t,1000*e,label=label,lw=1.4);axs[1,0].plot(np.arange(len(q))*.02,q[:,0]+6.26819,label=label,lw=1.4)
for label,name in [('Joint release only','release_only_v2_from_stall'),('Retained geometry: success','retained_blocker_from_stall'),('Same code: repeat 1','retained_stall_repeat_1'),('Same code: repeat 2','retained_stall_repeat_2')]:
    p=ROOT/'trials'/name/'trajectory.npz'
    if not p.exists():continue
    z=np.load(p);q=z['q'];e=z['goal_error'];t=np.arange(1,len(e)+1)*.02
    axs[0,1].plot(t,1000*e,label=label,lw=1.4);axs[1,1].plot(np.arange(len(q))*.02,q[:,0]+6.26819,label=label,lw=1.4)
axs[0,0].set_title('Same original initial state');axs[0,1].set_title('Start at the actual 300 s stalled state')
for ax in axs[0]:ax.set_ylabel('Goal error (mm, log scale)');ax.set_yscale('log');ax.axhline(1,color='gray',ls=':',lw=.7)
for ax in axs[1]:ax.set_ylabel('Base lower-limit reserve (rad)')
for ax in axs.ravel():ax.set_xlabel('Simulated time (s)');ax.grid(alpha=.2);ax.legend(fontsize=7)
fig.suptitle('Same shelf: one audited stall recovery; two repeats fail within 300 s',fontsize=12)
fig.savefig(OUT/'comparison.png',dpi=170);plt.close(fig)
repro='''Reproduction and scope

Remote study root:
%s
Python: /home/hsjed/envs/ur5cab/bin/python

Final code entry: pilot_worker.py; policy_version=retained_blocker imports retained_blocker_policy.py.
Copy a frozen job to a NEW trials directory; never overwrite an existing run.
Set OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=2,
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6, PYTHONDONTWRITEBYTECODE=1.
Launch with: python pilot_worker.py trials/NEW_RUN
Independent audit: python audit_pilot.py trials/NEW_RUN 56,57,58,59

The bundle preserves sources, archived revisions, trial inputs/results, traces,
snapshots and audits. Large external observed-map NPZ (89 MB), MuJoCo assets,
native libraries and Python environment remain on the server; INPUTS.json
records absolute paths and SHA-256. This is not a self-contained environment.
For an older trial, use source_hashes.json and the archived matching source;
do not treat running latest code on an old job as an exact reproduction.
The reference guided trajectory is offline diagnostic evidence only.
This task uses position/velocity kinematics, not rigid-body dynamics or hardware.
''' % ROOT
(OUT/'REPRODUCE.txt').write_text(repro)
subprocess.run([sys.executable,str(ROOT/'write_final_report.py')],check=True)
selected=list(ROOT.glob('*.py'))+list(ROOT.glob('*.json'))+list(ROOT.glob('*.txt'))
selected+=list((ROOT/'revisions').rglob('*'))+list((ROOT/'trials').rglob('*'))
selected+=[p for p in (ROOT/'code').rglob('*') if p.suffix in ('.py','.json','.cpp','.h','.hpp','.sh','.xml','.txt')]
selected+=[p for p in OUT.iterdir() if p.suffix!='.zip' and p.name!='BUNDLE_MANIFEST.json']
manifest={}
with zipfile.ZipFile(OUT/'study_sources_and_results.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for p in sorted(set(selected)):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=str(p.relative_to(ROOT));archive.write(p,rel);manifest[rel]=dict(bytes=p.stat().st_size,sha256=sha(p))
zip_path=OUT/'study_sources_and_results.zip'
(OUT/'BUNDLE_MANIFEST.json').write_text(json.dumps(dict(archive_sha256=sha(zip_path),archive_bytes=zip_path.stat().st_size,files=manifest),indent=2))
print(json.dumps(dict(counts=report['counts'],integrity=integrity,source_coverage=coverage,archive_bytes=zip_path.stat().st_size),ensure_ascii=False),flush=True)
