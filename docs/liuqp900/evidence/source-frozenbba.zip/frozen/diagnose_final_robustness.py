import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy_activated import LowDimPolicy
old=ROOT/'trials/entry_v7_memory_stall_2';new=ROOT/'trials/failed_latency_schedule_replay'
a=np.load(old/'trajectory.npz');b=np.load(new/'trajectory.npz');n=min(len(a['q']),len(b['q']))
comparison=dict(old_run=old.name,new_run=new.name,same_state_count=len(a['q'])==len(b['q']),compared_states=n,maximum_joint_trajectory_difference=float(np.max(np.abs(a['q'][:n]-b['q'][:n]))),maximum_goal_error_difference=float(np.max(np.abs(a['goal_error'][:n-1]-b['goal_error'][:n-1]))),new_latency_tail_uses=json.loads((new/'result.json').read_text()).get('latency_trace_tail_uses'))
q=b['q'][-1];job=json.loads((new/'job.json').read_text());result=json.loads((new/'result.json').read_text());ctx=build('iris_4shelves_t2',start=q);c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,np.zeros(6));p.memories=json.loads((new/'goalward_memories.json').read_text());p.blocker_id=result['policy_summary'].get('blocker_id');p.mode='BYPASS';s=c.pilot_nominal;arrays=c.last_qp_arrays;directions=[]
if p.blocker_id is not None:
    geometry=p._geometry();point,normal,J,gap=geometry;tangent=p._tangent(geometry);binormal=np.cross(normal,tangent);binormal/=np.linalg.norm(binormal)
    for label,direction in [('goal_tangent',tangent),('reverse_goal_tangent',-tangent),('orthogonal_tangent',binormal),('reverse_orthogonal_tangent',-binormal)]:
        p.tangent_override=direction;chosen=p._try_direction(c,s,arrays,direction@J);p.tangent_override=None
        directions.append(dict(direction=label,certified=chosen is not None,velocity=None if chosen is None else chosen[0]['velocity'].tolist(),safe_scale=None if chosen is None else chosen[1][1]))
out=dict(delay_replay=comparison,final_error_mm=result['final_error_mm'],active_memory_count=len(p.memories),selected_body_or_pair=p.blocker_id,local_direction_replay=directions,stored_online_tangent_reconstructed=False,direction_basis='fresh goal-oriented tangent and its orthogonal tangent at the failed state, not the transported direction stored by the online controller',scope='read-only final-state action coverage test; no alternate direction was executed or counted as arrival, and no global route is inferred')
(ROOT/'FINAL_ROBUSTNESS_DIAGNOSIS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
