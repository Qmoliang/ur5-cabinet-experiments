from pathlib import Path
R=Path(__file__).resolve().parent;s=(R/'export_progress_study.py').read_text()
s=s.replace("rec=dict(name=f.name", "strict=read(f/'strict_memory_audit.json') if (f/'strict_memory_audit.json').exists() else None\n rec=dict(name=f.name")
s=s.replace("validated_arrival=bool(a['safe_arrival'] and m['passed'] and not p.get('memory_certificate_failures',0))", "validated_arrival=bool(a['safe_arrival'] and m['passed'] and not p.get('memory_certificate_failures',0) and (not f.name.startswith('memory_aligned_') or strict and strict['passed']))")
s=s.replace("source_unavailable=missing,job=j)", "source_unavailable=missing,job=j,strict_memory_audit=strict,goal_plane_actual_checks=len(p.get('goal_plane_actual_progress',[])),goal_plane_rejected_stages=p.get('goal_plane_rejected_stages'),goal_side_planes=p.get('goal_side_planes'),memory_bound_refinements=p.get('memory_certificate_refinements'))")
s=s.replace("\n}\ncohorts=", """
 'goal_plane_development':['progress_original_cycle_goal_plane','progress_original_measured_goal_plane','progress_original_cycle_goal_plane_accepted','progress_original_measured_goal_plane_accepted'],
 'goal_plane_before_memory_fix':[j['name'] for j in read(R/'goal_plane_final_jobs.json')],
 'latest_fixed_failure':[f'memory_aligned_final_cycle_{i}' for i in [1,2,3]],
 'latest_measured_delay':[f'memory_aligned_final_measured_{i}' for i in [1,2,3]],
 'latest_regression':[j['name'] for j in read(R/'memory_aligned_jobs.json') if 'regression' in j['name']],
}
cohorts=""")
s=s.replace("'EXACT_COMBINED_FREEZE.json']:", "'EXACT_COMBINED_FREEZE.json','GOAL_PLANE_FREEZE.json','GOAL_PLANE_ACCEPTANCE_FREEZE.json','GOAL_PLANE_FINAL_FREEZE.json','MEMORY_ALIGNED_FREEZE.json']:")
s=s.replace("summary=dict(completed_at=", "latest_names=[j['name'] for j in read(R/'memory_aligned_jobs.json')];latest=[lookup[n] for n in latest_names];latest_counts=dict(runs=len(latest),goal_arrivals=sum(x['goal_reached'] for x in latest),validated_arrivals=sum(x['validated_arrival'] for x in latest),all_safety_passed=all(x['safety_passed'] for x in latest),all_strict_memory_passed=all(x['strict_memory_audit']['passed'] for x in latest));assert latest_counts['runs']==12\nsummary=dict(latest_counts=latest_counts,latest_names=latest_names,completed_at=")
s=s.replace("adoption='experimental implementations only; original reproducible failure not repaired robustly, do not replace the preceding controller on these results'", "adoption='same-shelf experimental repair supported by the final frozen cohort; no generalization or hardware guarantee; failed earlier versions are not recommended' if latest_counts['validated_arrivals']==12 else 'latest verification remains incomplete or failed; do not promote'")
s=s.replace("'结论：已经完成完整失败复现、诊断对照、实际进展验收实现与旧成功案例回归，但未获得可替换上一版的稳定修复。固定失败仍在；实验分支保留，旧控制器与旧实验文件未覆盖。'", "f\"最终结论：最新冻结12项到达 {latest_counts['goal_arrivals']}/12，经独立审计到达 {latest_counts['validated_arrivals']}/12。下文保留此前失败开发、回归退化和所有诊断，不能把旧版本失败与最终版本混为一谈。\"")
s=s.replace("'实现与被否定的设计：'", "'此前实现与被否定的设计（完整保留）：'")
s=s.replace("'最重要的数学限制：'", "'早期版本暴露的数学限制：'")
pos=s.index("(OUT/'FINAL_REPORT.txt').write_text")
insert="""lines[3:3]=[
'最终有效修改有两项：以朝向冻结终态机器人部位的支撑平面定义未来碰撞解除目标；以端点一致的曲率下界补充原记忆连续证书。实际阶段验收保留，安全阈值与记忆约束未放宽。',
'原始起点完整失败时序三次均23.22秒到达，误差0.2333mm，轨迹逐元素相同。自然延迟三次26.90、29.22、29.32秒到达。全部六个既有成功案例回归通过，包括此前带三条记忆约束的静止失败。',
'原始起点：10.22秒启动脱困，误差约386mm；准备时误差先增至535mm，同时基座/肩/肘约变化+1.46/+1.18/+0.37rad；16.02秒开始执行已认证进入反馈，23.22秒达到目标并完成保持。',
'因果证据：保持原准备目标，去延迟、去缓存、二者同时去掉都失败；保持完整失败延迟，改用终态侧平面目标即到达。因此本场景的关键缺口更支持为准备目标的解除方向，而非仅有时序或缓存问题。不能外推为所有环境的唯一原因。',
'另一条回归失败是记忆门的保守证书：初始记忆值约-9.9638e-11，候选物理制动安全，实际下一步记忆值约+2.0443e-4，原证书仍拒绝。新下界使用同一曲率界与同一-1e-10阈值，认证该向内动作；该回归随后41.76秒到达。',
'最新12条实际轨迹另按同一运行时-1e-10记忆阈值重建检查；全部终端后缀证书重放单列。原audit.json和memory_audit.json不被替换。',
'最终方法见METHOD_FINAL.txt；前面多轮失败是真实研发结果，不是从全部运行中只挑12次成功。最终12个输入在运行前冻结；固定时序重复也不是三个独立统计样本。',
]
"""
s=s[:pos]+insert+s[pos:]
# Replace publication figure, keeping all earlier trajectories in the evidence archive.
a=s.index('fig,axes=plt.subplots');b=s.index("(OUT/'REPRODUCE.txt')",a)
plot="""fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
def curve(ax,name,label,style='-'):
 z=np.load(R/'trials'/name/'trajectory.npz');ax.plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,style,lw=1.4,label=label)
for n,l,st in [('exact_failure_trace','Original failure','--'),('old_zero_delay','No delay',':'),('old_full_refresh_cycle','No witness cache','-.'),('old_full_refresh_zero_delay_exact','Neither cache nor delay','--'),('memory_aligned_final_cycle_1','Goal-side planes + acceptance','-')]:curve(axes[0,0],n,l,st)
curve(axes[0,1],'memory_aligned_final_cycle_1','Failed schedule x3 (identical)','--')
for i in [1,2,3]:curve(axes[0,1],f'memory_aligned_final_measured_{i}',f'Measured delay {i}')
for ax,title in [(axes[0,0],'Controlled failure and objective comparison'),(axes[0,1],'Frozen original-start verification')]:
 ax.set_yscale('log');ax.axhline(1,color='.5',ls=':',lw=.8);ax.set_xlabel('Simulated time (s)');ax.set_ylabel('Goal error (mm)');ax.set_title(title);ax.legend(fontsize=7);ax.grid(alpha=.2)
vals=[6,cohorts['frozen_v4_regression']['validated_arrivals'],cohorts['persistent_v6_regression']['validated_arrivals'],sum(lookup[n]['validated_arrival'] for n in cohorts['goal_plane_before_memory_fix']['names'] if 'regression' in n),cohorts['latest_regression']['validated_arrivals']]
labels=['Previous','Local bypass','Persistent','Goal planes','Memory aligned'];axes[1,0].bar(labels,vals,color=['.6','#aa7755','#aa9955','#5e8da8','#358358']);axes[1,0].set_ylim(0,6.8);axes[1,0].set_ylabel('Audited arrivals / 6 cases');axes[1,0].set_title('All six prior successful cases');axes[1,0].tick_params(axis='x',labelsize=8)
for i,v in enumerate(vals):axes[1,0].text(i,v+.1,f'{v}/6',ha='center',fontsize=9)
ex=read(R/'MEMORY_BOUND_VALIDATION.json')['examples'][0];t=np.linspace(0,1,501);va=ex['start_value'];vb=ex['end_value'];B=4*(min(va,vb)-ex['old_lower']);lower=va+t*(vb-va-B)+B*t*t
axes[1,1].plot(t,lower*1000,label='Endpoint-consistent lower bound');axes[1,1].axhline(ex['old_lower']*1000,color='#b65f45',ls='--',label='Old coarse uniform lower bound');axes[1,1].axhline(-1e-7,color='.4',ls=':',label='Unchanged acceptance tolerance');axes[1,1].scatter([0,1],[va*1000,vb*1000],s=15,color='black');axes[1,1].set_title('Same memory constraint, tighter certificate');axes[1,1].set_xlabel('Fraction of one executed interval');axes[1,1].set_ylabel('Memory value lower bound (mm)');axes[1,1].legend(fontsize=7);axes[1,1].grid(alpha=.2)
fig.savefig(OUT/'comparison.png',dpi=160);plt.close(fig)
"""
s=s[:a]+plot+s[b:]
s=s.replace("Main v4 worker: pilot_worker_progress.py, policy_version=progress_bypass.", "LATEST worker: pilot_worker_goal_plane_memory.py, policy_version=goal_plane_memory.\nLATEST frozen jobs: memory_aligned_jobs.json.\nOriginal v4 worker: pilot_worker_progress.py, policy_version=progress_bypass.")
# Add final-method evidence before packaging.
marker="raw_files=list((R/'trials').glob('*/decision_trace.npz'))"
extras="""for n in ['METHOD_FINAL.txt','GOAL_SIDE_GEOMETRY_EVIDENCE.json','GOAL_PLANE_GRADIENT_CHECK.json','MEMORY_REJECTION_DIAGNOSIS.json','MEMORY_BOUND_VALIDATION.json','MEMORY_ALIGNED_EVIDENCE.json','STRICT_MEMORY_AUDIT_SUMMARY.json','LATEST_TERMINAL_CERTIFICATE_REPLAY.json','MEMORY_ALIGNED_FREEZE.json','GOAL_PLANE_FINAL_FREEZE.json']:
 if (R/n).exists():shutil.copy2(R/n,OUT/n)
"""
s=s.replace(marker,extras+marker)
s=s.replace("counts=summary['counts'],cohorts=", "latest_counts=latest_counts,counts=summary['counts'],cohorts=")
(R/'export_final_progress.py').write_text(s);compile(s,'export_final_progress','exec')
