from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='goal_entry_v5':";new="        if job.get('policy_version')=='goal_entry_v6':\n            from goal_entry_policy_v6 import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_v5':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'entry_v5_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('entry_v5','entry_v6');j['policy_version']='goal_entry_v6';j['joint_metric']=False
(ROOT/'entry_v6_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_v6';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'ENTRY_V6_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},changes=['remove soft reserve penalty while retaining original hard joint and braking rows','use complete terminal posture only through the current-task nullspace, retaining wrist information without a configuration route','measure actual terminal posture preparation progress; no extra full-joint tracking target'],goal_endpoint_unchanged=True,hard_safety_unchanged=True,primary_optimization='six current velocities only'),indent=2))
print(json.dumps(jobs))
