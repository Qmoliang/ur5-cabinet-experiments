"""A start pose for the approach-phase test: the drawer task's start moved back so the gripper is
BACK_M in front of the cabinet box (frontier ROI), same height and orientation.  Damped least
squares on position + orientation, with a pull toward q0 so the arm keeps its posture; the result
must stay clear of the floor (5 cm) and the cabinet.  Usage: far_start.py [drawer|cage|shelf];
writes assets/far_start_q.npy (drawer) or assets/far_start_q_<scene>.npy."""
import os
import sys
from pathlib import Path

import mujoco
import numpy as np

HERE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
SCENE = sys.argv[1] if len(sys.argv) > 1 else "drawer"
if SCENE != "drawer":
    os.environ["UR5_E4_SCENE_JSON"] = str(HERE.parent / "known_v6" / "assets" / "scenes" /
                                          {"cage": "cage.json", "shelf": "iris_ur3_shelf_t0.json"}[SCENE])
OUT = HERE / "assets" / ("far_start_q.npy" if SCENE == "drawer" else f"far_start_q_{SCENE}.npy")
sys.path[:0] = [str(HERE)]
from frontier import region_of_interest  # noqa: E402
import run_protocol_v3_async_online as online  # noqa: E402
from model import (attachment_position, build_model, build_robot_certificate,  # noqa: E402
                   certificate_world_positions, set_configuration)

scene = online._protocol_scene("camera_quarter")
model = build_model(scene)
data = mujoco.MjData(model)
lo, hi = region_of_interest(scene.boxes)
q0 = np.asarray(scene.q0, float)
print("base body world position", np.round(data.xpos[model.body("base").id] if "base" in [model.body(i).name for i in range(model.nbody)] else data.xpos[1], 3))
site = model.site("attachment_site").id
robot = build_robot_certificate(model)
radii = np.array([s.radius for s in robot])
set_configuration(model, data, q0)
start = attachment_position(model, data)
_pos = certificate_world_positions(data, robot)
_low = np.argsort(_pos[:, 2] - radii)[:4]
print("q0 lowest spheres:", [(robot[i].body_name, round(float(_pos[i, 2] - radii[i]), 3)) for i in _low])
FIXED = {robot[i].body_name for i in range(len(robot)) if _pos[i, 2] - radii[i] < 0.02}
print("bodies touching the floor at q0 (fixed base):", FIXED)
R0 = data.site_xmat[site].reshape(3, 3).copy()
for back in (0.40, 0.35, 0.30, 0.25):
    goal = start.copy()
    goal[0] = lo[0] - back
    q = q0.copy()
    for _ in range(600):
        set_configuration(model, data, q)
        p = attachment_position(model, data)
        jp, jr = np.zeros((3, model.nv)), np.zeros((3, model.nv))
        mujoco.mj_jacSite(model, data, jp, jr, site)
        R = data.site_xmat[site].reshape(3, 3)
        rot_err = 0.5 * sum(np.cross(R[:, i], R0[:, i]) for i in range(3))
        J = np.vstack([jp[:, :6], 0.5 * jr[:, :6], 0.05 * np.eye(6)])
        e = np.r_[goal - p, 0.5 * rot_err, 0.05 * (q0 - q)]
        dq = np.linalg.lstsq(J, e, rcond=None)[0]
        q += np.clip(dq, -0.03, 0.03)
    set_configuration(model, data, q)
    p = attachment_position(model, data)
    pos = certificate_world_positions(data, robot)
    moving = np.array([s.body_name not in FIXED for s in robot])   # the fixed base sits on the floor
    floor = float((pos[moving, 2] - radii[moving]).min())
    box = float((np.linalg.norm(np.maximum(0, np.maximum(lo - pos, pos - hi)), axis=1) - radii).min())
    angle = float(np.degrees(np.arccos(np.clip((np.trace(R0.T @ data.site_xmat[site].reshape(3, 3)) - 1) / 2, -1, 1))))
    print(f"back {back:.2f}: gripper {np.round(p, 3)} (goal err {np.linalg.norm(goal - p) * 1000:.1f} mm), "
          f"floor clearance {floor:.3f}, cabinet clearance {box:.3f}, orientation change {angle:.1f} deg, "
          f"max joint change {np.max(np.abs(q - q0)):.2f} rad")
    if np.linalg.norm(goal - p) < 0.02 and floor > 0.05 and box > 0.05 and angle < 5.0:
        np.save(OUT, q)
        print("saved", np.round(q, 3))
        break
