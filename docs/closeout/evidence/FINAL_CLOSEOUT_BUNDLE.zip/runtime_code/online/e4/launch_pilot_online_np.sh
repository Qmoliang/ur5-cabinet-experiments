#!/bin/bash
# Online pilot, catch-up: plain NEO-paper (no compute hold) runs slowly in wall time (p99 ~0.4-0.7 s
# per solve x 3000 cycles), so the 40-min timeout killed runs without a summary, and one worker held
# all 60 of them.  Re-run every unfinished plain NEO-paper case and timed-out NEO-matched cases with a
# 4 h timeout and a 40 GB cap, 6 workers x 16 CPUs (CPUs 0-47, 64-111).  Partial runs go to
# pilot_online_timeout/.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/pilot_online
export UR5_NO_RETURN_FREE=1 E4_TIMEOUT=14400 E4_MEM=40G
mkdir -p pilot_online_timeout
jobs=()
for cond in "0 0.0" "1 0.25" "1 0.5" "2 0.5"; do
  for seed in 1 2 3 4 5; do
    for scene in drawer cage_wide shelf; do
      for ctl in neo_paper neo_matched; do
        set -- $cond
        out=$P/${ctl}_k$1_v$2/${scene}_s$seed
        ls $out/A-CV-*/summary.json >/dev/null 2>&1 && continue
        if [ $ctl = neo_matched ]; then
          [ -f $out/case.json ] || continue                  # main worker still owns unstarted cases
          ps -eo args | grep -v grep | grep -q -- "--out $out" && continue   # still running
        fi
        if [ -d $out ]; then d=pilot_online_timeout/${ctl}_k$1_v$2; mkdir -p $d; mv $out $d/; mv $out.log $d/ 2>/dev/null; fi
        jobs+=("$ctl $scene $seed $1 $2")
      done
    done
  done
done
echo "${#jobs[@]} catch-up jobs" > pilot_online_np.jobs
cpus=(0 16 32 64 80 96)
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 6)); do
    set -- ${jobs[$i]}
    ctl=$1; scene=$2; seed=$3; k=$4; v=$5
    out=$P/${ctl}_k${k}_v$v/${scene}_s$seed
    geo=; [ $scene = drawer ] && geo=1
    UR5_COMPUTE_DELAY=0 E4_GEODESIC=$geo E4_SCENE=$scene ./e4_map.sh $out $seed ${cpus[$w]} $ctl $k $v
  done
}
for w in 0 1 2 3 4 5; do worker $w & done
wait
echo DONE > pilot_online_np.done
