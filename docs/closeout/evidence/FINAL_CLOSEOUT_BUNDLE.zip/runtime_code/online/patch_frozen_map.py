"""--frozen-map: publish one fixed proxy set (a rebuilt final map) every frame."""
from pathlib import Path
root = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
p = root / "run_protocol_v3_async_online.py"
s = p.read_text()

def sub(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)

sub("""        effective_sphere_radii = (
            np.asarray(proxies.sphere_radii, dtype=float)
            + np.asarray(proxies.proxy_offset_radii, dtype=float)
        )
""", """        if os.environ.get("UR5_FROZEN_MAP"):
            proxies, frontier_count = _frozen_map()
        effective_sphere_radii = (
            np.asarray(proxies.sphere_radii, dtype=float)
            + np.asarray(proxies.proxy_offset_radii, dtype=float)
        )
""")
sub("""# Online geodesic attraction: set by run_one when UR5_ONLINE_GEODESIC=1.
""", """_FROZEN = {}


def _frozen_map():
    \"\"\"The fixed map for UR5_FROZEN_MAP (UR5_FROZEN_DROP_FRONTIER=1 drops unseen cells).\"\"\"
    if not _FROZEN:
        import pickle
        from dataclasses import replace
        with open(os.environ["UR5_FROZEN_MAP"], "rb") as handle:
            stored = pickle.load(handle)
        proxies, count = stored["proxies"], int(stored["frontier_cells"])
        if os.environ.get("UR5_FROZEN_DROP_FRONTIER", "0") == "1" and count:
            keep = len(proxies.centers) - count
            fields = ("centers", "sphere_radii", "ellipsoid_shapes", "rotations", "cluster_keys",
                      "proxy_offset_radii", "proxy_uncertainty_shapes", "base_sphere_radii",
                      "base_ellipsoid_shapes", "ellipsoid_outer_shapes", "proxy_ids")
            proxies = replace(proxies, **{name: getattr(proxies, name)[:keep] for name in fields
                                          if getattr(proxies, name) is not None})
            count = 0
        _FROZEN.update(proxies=proxies, count=count)
    return _FROZEN["proxies"], _FROZEN["count"]


# Online geodesic attraction: set by run_one when UR5_ONLINE_GEODESIC=1.
""")
p.write_text(s)

p = root / "run_v6_case.py"
s = p.read_text()
sub("""    os.environ["UR5_ACTIVE_LOOK"] = "1" if args.look else "0"
""", """    os.environ["UR5_ACTIVE_LOOK"] = "1" if args.look else "0"
    if args.frozen_map:
        os.environ["UR5_FROZEN_MAP"] = str(Path(args.frozen_map).resolve())
        os.environ["UR5_FROZEN_DROP_FRONTIER"] = "1" if args.drop_frontier else "0"
""")
sub("""    parser.add_argument("--look", action="store_true",""", """    parser.add_argument("--frozen-map", default="",
                        help="publish this fixed map (from build_frozen_map.py) every frame")
    parser.add_argument("--drop-frontier", action="store_true",
                        help="with --frozen-map: leave out the unseen-space cells")
    parser.add_argument("--look", action="store_true",""")
p.write_text(s)
print("patched")
