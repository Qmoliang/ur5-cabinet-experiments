"""UR5 versions of the IRIS-ZO benchmark environments (wernerpe/iris_benchmarks).

Geometry is taken from the benchmark SDF/URDF/directive files (box collision
geometry only), with the UR5 base where the benchmark robot base is:

iris_ur3_shelf  6DOFUR3: shelves.sdf welded at (0.4, 0, 0.4) plus two
                0.03 x 0.03 x 0.12 posts at shelf (-0.1, 0, -0.07) and
                (0, 0, 0.2); scaled x1.7 about the base for the UR5's reach
                (UR3 ~0.5 m, UR5 ~0.85 m).
iris_4shelves   7DOF4SHELVES: four shelves1.sdf at (+-0.48, +-0.56, 0.4) and
                the 1.2 x 1.8 x 0.1 lid at z = 0.95.
iris_bins       7DOFBINS: shelves (with back wall) at (0.85, 0, 0.4) and two
                bins at (0, +-0.6, 0) yawed 90 deg; the bin's 0.35 rad sloped
                panel is replaced by its axis-aligned bounding box
                (conservative).  The table top is the floor (z = 0).
The ground slab is left out of the certified cover, as in the other scenes
(MuJoCo's floor plane still detects contact).  Not included: 7DOFIIWA
(shelves_big.sdf's link vs collision poses are ambiguous), 14DOFIIWAS
(two arms), the flippers and the Allegro hand.
Each scene lists candidate targets; feasibility is checked separately.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

T = 0.016  # shelf board thickness


def box(name, center, size):
    return {"name": name, "center": [float(v) for v in center],
            "half_size": [float(v) / 2.0 for v in size], "material": "shelf"}


def shelves(prefix, origin, back_wall=False, scale=1.0):
    """shelves.sdf / shelves1.sdf / models/shelves/shelves.sdf in world, axis-aligned."""
    o = np.asarray(origin, dtype=float)
    parts = [
        ("right_wall", (0, 0.292, 0), (0.3, T, 0.783)),
        ("left_wall", (0, -0.292, 0), (0.3, T, 0.783)),
        ("bottom", (0, 0, -0.3995), (0.3, 0.6, T)),
        ("top", (0, 0, 0.3995), (0.3, 0.6, T)),
        ("shelf_lower", (0, 0, -0.13115), (0.3, 0.6, T)),
        ("shelf_upper", (0, 0, 0.13115), (0.3, 0.6, T)),
    ]
    if back_wall:  # back_wall pose (0.15, 0, 0) yaw 90 deg: 0.6 x 0.016 x 0.783 -> 0.016 x 0.6 x 0.783
        parts.append(("back_wall", (0.150, 0, 0), (T, 0.6, 0.783)))
    return [box(f"{prefix}_{n}", (o + scale * np.asarray(c)) , scale * np.asarray(s)) for n, c, s in parts]


def ur3_shelf():
    s = 1.7
    origin = s * np.array([0.4, 0.0, 0.4])
    boxes = shelves("shelf", origin, scale=s)
    for i, offset in enumerate(((-0.1, 0, -0.07), (0.0, 0, 0.2))):
        boxes.append(box(f"post_{i}", origin + s * np.asarray(offset), s * np.array([0.03, 0.03, 0.12])))
    front = origin[0] - s * 0.15
    mid_z = origin[2]
    targets = [[front + 0.10, 0.15, mid_z - 0.05], [front + 0.12, -0.18, mid_z + 0.05],
               [front + 0.15, 0.20, mid_z - 0.10]]
    return dict(name="iris_ur3_shelf", boxes=boxes, targets=targets)


def four_shelves():
    boxes = []
    for i, (x, y) in enumerate(((0.48, -0.56), (0.48, 0.56), (-0.48, -0.56), (-0.48, 0.56))):
        boxes += shelves(f"shelves{i + 1}", (x, y, 0.4))
    boxes.append(box("lid", (0, 0, 0.95), (1.2, 1.8, 0.1)))  # lid.urdf box rolled 90 deg about x
    targets = [[0.42, -0.50, 0.40], [0.42, 0.50, 0.40], [0.45, -0.56, 0.62], [-0.42, -0.50, 0.40]]
    return dict(name="iris_4shelves", boxes=boxes, targets=targets)


def bins():
    boxes = shelves("shelf", (0.85, 0.0, 0.4), back_wall=True)
    # bin.sdf collisions in the bin_base link frame; link yaw 90 deg, frame yaw 90 deg -> 180 deg total.
    parts = [("front", (0.22, 0, 0.105), (0.05, 0.63, 0.21)), ("back", (-0.22, 0, 0.105), (0.05, 0.63, 0.21)),
             ("left", (0, 0.29, 0.105), (0.49, 0.05, 0.21)), ("right", (0, -0.29, 0.105), (0.49, 0.05, 0.21)),
             ("bottom", (0.0, 0.0, 0.0075), (0.49, 0.63, 0.015))]
    yaw = math.pi
    rot = np.array([[math.cos(yaw), -math.sin(yaw), 0], [math.sin(yaw), math.cos(yaw), 0], [0, 0, 1]])
    # sloped panel: pose (0.182, 0, 0.102), pitch 0.35, size 0.05 x 0.63 x 0.21 -> its AABB
    pitch = 0.35
    ext_x = 0.5 * (0.05 * math.cos(pitch) + 0.21 * math.sin(pitch))
    ext_z = 0.5 * (0.05 * math.sin(pitch) + 0.21 * math.cos(pitch))
    parts.append(("slope_aabb", (0.182, 0, 0.102), (2 * ext_x, 0.63, 2 * ext_z)))
    for side, y in (("R", -0.6), ("L", 0.6)):
        base = np.array([0.0, y, 0.0])
        for n, c, size in parts:
            centre = base + rot @ np.asarray(c)
            dims = np.abs(rot) @ np.asarray(size)
            boxes.append(box(f"bin{side}_{n}", centre, dims))
    targets = [[0.0, 0.6, 0.16], [0.0, -0.6, 0.16], [0.76, 0.0, 0.40], [0.74, 0.12, 0.62]]
    return dict(name="iris_bins", boxes=boxes, targets=targets)


SCENES = {"iris_ur3_shelf": ur3_shelf, "iris_4shelves": four_shelves, "iris_bins": bins}

if __name__ == "__main__":
    import sys
    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    for name, make in SCENES.items():
        scene = make()
        (out / f"{name}_candidates.json").write_text(json.dumps(scene, indent=1))
        print(name, len(scene["boxes"]), "boxes,", len(scene["targets"]), "candidate targets")
