#!/bin/bash
# Fast frontier map + active looking: 20 start poses x 3 variants, real time,
# 7 runs at a time on separate 16-CPU slices, variants mixed in every wave.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
OUT=v6runs/online_fastmap
mkdir -p $OUT
jobs=()
for seed in $(seq 1 20); do
  for variant in fast look look_reuse; do jobs+=("$variant $seed"); done
done
run() { # variant seed slot
  local flags=""
  case $1 in fast) flags="--frontier --geodesic";; look) flags="--frontier --geodesic --look";; look_reuse) flags="--frontier --geodesic --look --reuse";; esac
  local id=${1}_seed$(printf "%02d" $2)
  systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS \
    timeout 2400 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py ellipsoid --map incremental \
    --timing paced --cpus $(($3 * 16)):16 --start-seed $2 $flags --out $OUT/$id > $OUT/$id.log 2>&1
}
for ((start = 0; start < ${#jobs[@]}; start += 7)); do
  for slot in 0 1 2 3 4 5 6; do
    index=$((start + slot))
    [ $index -lt ${#jobs[@]} ] || break
    run ${jobs[$index]} $slot &
  done
  wait
done
echo DONE > $OUT/FASTMAP_DONE
