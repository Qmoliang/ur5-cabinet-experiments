"""known_v6/run.py: 5 mm success tolerance, NEO option, moving racket.

UR5_SUCCESS_TOL   success tolerance in m (default 0.005)
UR5_CONTROLLER    liuqp (default) | neo_matched | neo_paper
UR5_RACKET=1      add the racket (src/racket.py); UR5_RACKET_DIR, _TRIGGER, _SPEED
"""
from pathlib import Path

p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
s = p.read_text()


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)


sub("SUCCESS_TOLERANCE = 0.001\n", 'SUCCESS_TOLERANCE = float(os.environ.get("UR5_SUCCESS_TOL", "0.005"))\n')

# racket mocap body in the scene model
sub("""        return head + marker + tail[:line_end] + geoms + tail[line_end:]""",
    """        if os.environ.get("UR5_RACKET", "0") == "1":
            from racket import mjcf_body
            geoms += mjcf_body()
        return head + marker + tail[:line_end] + geoms + tail[line_end:]""")

# controller choice and racket after the LiuQP setup
sub("""    controller.osqp_max_iterations = int(osqp_max_iterations)
    guidance = None""", """    controller.osqp_max_iterations = int(osqp_max_iterations)
    controller_kind = os.environ.get("UR5_CONTROLLER", "liuqp")
    liuqp_controller = controller
    if controller_kind != "liuqp":
        from neo_adapter import NEOAdapter
        controller = NEOAdapter(model, data, robot, cover, representation, controller_kind)
    racket = None
    if os.environ.get("UR5_RACKET", "0") == "1":
        from racket import Racket, combined_cover
        racket = Racket.from_env(model, robot, representation, MAXIMUM_CELL_SPAN)
        racket_index = None
    controller_error = None
    racket_contact_cycles = 0
    racket_geoms = {model.geom(n).id for n in ("racket_head", "racket_handle")} if racket is not None else set()
    hold_after_racket = 0
    success_after_racket = False
    guidance = None""")

# per cycle: racket into the obstacle set (predicted at t + dt), solve with error capture
sub("""            qdot, metrics = controller.solve(command)
            q_after = q_before + qdot * DT
            set_configuration(model, data, q_after)""", """            racket_distance = None
            if racket is not None:
                t_now = cycle * DT
                racket.arm_at_trigger(data, t_now)
                moving = racket.world_cover(t_now + DT)
                obstacles = cover if moving is None else combined_cover(cover, moving)
                if controller_kind == "liuqp":
                    if racket_index is not None:
                        racket_index.close()
                        racket_index = None
                    active_index = index
                    if moving is not None:
                        racket_index = NativeMultilevelMVT(
                            obstacles.centers, obstacles.aabb_half_extents + MVT_OUTWARD_PADDING,
                            base_voxel_size=MVT_BASE_VOXEL_SIZE,
                            maximum_query_half_extent=float(np.max(robot_radii) + query_padding),
                            query_padding=query_padding, simd=True)
                        active_index = racket_index
                    if moving is not None or getattr(racket, "_was_active", False):
                        kwargs = dict(proxy_ids=obstacles.proxy_ids, obstacle_index=active_index,
                                      obstacle_offsets=np.zeros(len(obstacles.centers)))
                        if representation == "sphere":
                            kwargs["obstacle_radii"] = obstacles.sphere_radii
                        else:
                            kwargs["obstacle_shapes"] = obstacles.ellipsoid_shapes
                        controller.update_obstacles(obstacles.centers, **kwargs)
                    racket._was_active = moving is not None
                else:
                    controller.set_cover(obstacles)
            try:
                qdot, metrics = controller.solve(command)
            except RuntimeError as error:
                controller_error = f"cycle {cycle}: {error}"
                break
            q_after = q_before + qdot * DT
            if racket is not None:
                racket.place(data, (cycle + 1) * DT)
            set_configuration(model, data, q_after)
            if racket is not None:
                racket_distance = racket.measure(data, (cycle + 1) * DT)
                if any(data.contact[k].geom1 in racket_geoms or data.contact[k].geom2 in racket_geoms
                       for k in range(data.ncon) if data.contact[k].dist < -1e-8):
                    racket_contact_cycles += 1""")

sub("""            else:
                success_hold = 0

            elapsed_ms = (time.perf_counter() - cycle_started) * 1000.0""", """            else:
                success_hold = 0
            if racket is not None and racket.start is not None and racket.position((cycle + 1) * DT) is None:
                hold_after_racket = hold_after_racket + 1 if (error < SUCCESS_TOLERANCE and not penetrating) else 0
                success_after_racket = success_after_racket or hold_after_racket >= SUCCESS_HOLD_CYCLES

            elapsed_ms = (time.perf_counter() - cycle_started) * 1000.0""")

sub("""                "control_wall_ms": elapsed_ms,
                **metrics.as_dict(),""", """                "control_wall_ms": elapsed_ms,
                "racket_distance_m": racket_distance,
                **metrics.as_dict(),""")

sub("""        index.close()
    wall_duration""", """        index.close()
        if racket is not None and racket_index is not None:
            racket_index.close()
    wall_duration""")

sub("""        "attraction_mode": attraction_mode,
""", """        "attraction_mode": attraction_mode,
        "controller": controller_kind,
        "controller_error": controller_error,
        "racket": None if racket is None else dict(
            direction=racket.direction.tolist(), trigger_s=racket.trigger_s, speed_mps=racket.speed,
            min_distance_m=finite_or_none(racket.min_distance), contact_cycles=racket_contact_cycles,
            max_retreat_m=racket.max_retreat, success_after_racket=success_after_racket),
""")
p.write_text(s)
print("patched")
