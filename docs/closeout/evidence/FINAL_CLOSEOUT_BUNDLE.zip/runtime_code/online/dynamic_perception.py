"""Moving-object perception from the fixed external depth cameras only (E4).

Nothing here knows what an object is.  Per fixed camera and pixel a background
depth is kept; a pixel whose environment return is clearly in front of its
background (FOREGROUND_MARGIN) is foreground.  Robot returns are removed with
the same kinematic self filter the map uses (robot geoms only -- the moving
objects are not labelled).  Foreground points of all fixed cameras are fused,
voxelised (VOXEL), split into connected clusters and associated with tracks by
nearest predicted centroid; a track's velocity is the filtered centroid
motion.  Each cluster voxel becomes one sphere certificate (voxel half
diagonal + SPHERE_MARGIN) carrying its track's velocity.  A camera sees only
the near face of an object, so every foreground point also marks the space
just behind it along its ray (SHADOW_STEPS).

Background start: the first frame; pixels without a return there (open space
beyond range) are infinitely far, pixels hidden by the robot are unknown.
Background update: a pixel whose return is farther than its background, or
whose background is still unknown (e.g. hidden by the robot at start), adopts
the new depth after STABLE_FRAMES consistent frames.  Returns in front of the
background never update it, so an object that stops stays foreground (a
dynamic certificate with ~zero velocity) instead of being absorbed.

The detector runs in its own process (DetectorProcess) at DETECT_HZ; the
control loop sends it the simulator state of the frame time and uses the
latest result.  Ground-truth object pixels (geom ids) are counted for
evaluation only and never used for detection.
"""
from __future__ import annotations

import multiprocessing as mp
import os
import time

import numpy as np

DETECT_HZ = 25.0
WIDTH, HEIGHT = 160, 90
VOXEL = 0.04
FOREGROUND_MARGIN = 0.03
STABLE_FRAMES = 5
MIN_CLUSTER_POINTS = 12   # counts shadow points too (4 per seen pixel)
SPHERE_MARGIN = 0.01
TRACK_GATE = 0.12
TRACK_TIMEOUT_S = 0.2
VELOCITY_ALPHA = 0.5
SHADOW_STEPS = (0.02, 0.04, 0.06)   # occlusion shadow behind every foreground point, m


def _neighbour_offsets():
    offsets = []
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dz in (-1, 0, 1):
                if (dx, dy, dz) > (0, 0, 0):
                    offsets.append((dx, dy, dz))
    return np.array(offsets, dtype=np.int64)


OFFSETS = _neighbour_offsets()


def cluster_points(points, voxel=VOXEL, min_points=MIN_CLUSTER_POINTS):
    """Connected 26-neighbour voxel clusters: list of (voxel centres, point count, centroid)."""
    if len(points) == 0:
        return []
    from scipy.sparse import coo_matrix
    from scipy.sparse.csgraph import connected_components

    keys = np.floor(points / voxel).astype(np.int64)
    unique, inverse, counts = np.unique(keys, axis=0, return_inverse=True, return_counts=True)
    lookup = {tuple(k): i for i, k in enumerate(unique)}
    rows, cols = [], []
    for i, k in enumerate(unique):
        for off in OFFSETS:
            j = lookup.get((k[0] + off[0], k[1] + off[1], k[2] + off[2]))
            if j is not None:
                rows.append(i)
                cols.append(j)
    n = len(unique)
    graph = coo_matrix((np.ones(len(rows)), (rows, cols)), shape=(n, n))
    count, labels = connected_components(graph, directed=False)
    out = []
    inverse = np.asarray(inverse).reshape(-1)
    for c in range(count):
        members = np.nonzero(labels == c)[0]
        total = int(counts[members].sum())
        if total < min_points:
            continue
        mask = np.isin(inverse, members)
        out.append(((unique[members] + 0.5) * voxel, total, points[mask].mean(axis=0)))
    return out


class FixedCameraTracker:
    def __init__(self, model, camera_names, object_geom_ids=()):
        import mujoco

        from depth_camera_perception import UR5MountedDepthCamera

        self.model = model
        self.data = mujoco.MjData(model)
        self.camera = UR5MountedDepthCamera(model, tuple(camera_names), width=WIDTH, height=HEIGHT,
                                            pixel_stride=1, occluding_self_filter=True, native_raycast=True)
        # Kinematic self filter: robot geoms only.  Moving objects are bodies
        # too but must not be filtered by label.
        self.camera.robot_geom_ids = {
            g for g in range(model.ngeom)
            if int(model.geom_bodyid[g]) != 0
            and not model.body(int(model.geom_bodyid[g])).name.startswith("object")
        }
        self.object_geom_ids = {int(g) for g in object_geom_ids}   # evaluation only
        self.background = {}
        self.candidate = {}
        self.candidate_count = {}
        self.tracks = []
        self.next_track = 0

    def _background_step(self, observation):
        name = observation.camera_name
        size = WIDTH * HEIGHT
        pix = observation.pixel_index
        depth = observation.optical_depths
        env = np.asarray(observation.endpoint_is_occupied, dtype=bool)
        if name not in self.background:
            # First frame: pixels without a return (open space beyond range)
            # are infinitely far, so anything appearing there is foreground at
            # once; pixels hidden by the robot are unknown (NaN).
            bg = np.full(size, np.inf)
            bg[pix[~env]] = np.nan
            bg[pix[env]] = depth[env]
            self.background[name] = bg
            self.candidate[name] = np.full(size, np.nan)
            self.candidate_count[name] = np.zeros(size, dtype=np.int32)
        bg, cand, count = self.background[name], self.candidate[name], self.candidate_count[name]
        b = bg[pix]
        known = ~np.isnan(b)
        foreground = env & known & (depth < b - FOREGROUND_MARGIN)
        update = env & (~known | (depth > b + FOREGROUND_MARGIN))
        same = np.abs(depth - cand[pix]) < 0.01
        count[pix[update & same]] += 1
        fresh = update & ~same
        cand[pix[fresh]] = depth[fresh]
        count[pix[fresh]] = 1
        settled = update & (count[pix] >= STABLE_FRAMES)
        bg[pix[settled]] = depth[settled]
        steady = env & known & ~foreground & ~update
        count[pix[steady]] = 0
        return foreground

    def step(self, t, q, mocap_pos, mocap_quat):
        import mujoco

        from model import set_configuration

        self.data.mocap_pos[:] = mocap_pos
        self.data.mocap_quat[:] = mocap_quat
        set_configuration(self.model, self.data, q)
        mujoco.mj_forward(self.model, self.data)
        observations = self.camera.capture(self.data)
        foreground_points = []
        true_pixels = {}
        for observation in observations:
            fg = self._background_step(observation)
            seen = observation.points[fg]
            foreground_points.append(seen)
            if len(seen):
                # Occlusion shadow: the object may extend behind what is seen.
                rays = seen - observation.camera_position[None, :]
                rays /= np.linalg.norm(rays, axis=1, keepdims=True)
                for depth in SHADOW_STEPS:
                    foreground_points.append(seen + depth * rays)
            for g in observation.geom_ids:
                if int(g) in self.object_geom_ids:
                    body = int(self.model.geom_bodyid[int(g)])
                    true_pixels[body] = true_pixels.get(body, 0) + 1
        points = np.vstack(foreground_points) if foreground_points else np.empty((0, 3))
        clusters = cluster_points(points)
        # Associate clusters with tracks (greedy nearest predicted centroid).
        for tr in self.tracks:
            tr["predicted"] = tr["centroid"] + tr["velocity"] * (t - tr["t"])
        used = set()
        assignments = []
        for ci, (_cells, _n, centroid) in sorted(enumerate(clusters), key=lambda x: -x[1][1]):
            best, best_d = None, np.inf
            for ti, tr in enumerate(self.tracks):
                if ti in used:
                    continue
                gate = TRACK_GATE + np.linalg.norm(tr["velocity"]) * (t - tr["t"])
                d = float(np.linalg.norm(centroid - tr["predicted"]))
                if d < gate and d < best_d:
                    best, best_d = ti, d
            assignments.append((ci, best))
            if best is not None:
                used.add(best)
        live = []
        for ci, ti in assignments:
            cells, n, centroid = clusters[ci]
            if ti is None:
                tr = dict(id=self.next_track, centroid=centroid, velocity=np.zeros(3), t=t, hits=1, first_t=t)
                self.next_track += 1
                self.tracks.append(tr)
            else:
                tr = self.tracks[ti]
                dt = max(t - tr["t"], 1e-3)
                measured = (centroid - tr["centroid"]) / dt
                tr["velocity"] = measured if tr["hits"] == 1 else (
                    VELOCITY_ALPHA * measured + (1 - VELOCITY_ALPHA) * tr["velocity"])
                tr["centroid"], tr["t"] = centroid, t
                tr["hits"] += 1
            tr["cells"] = cells
            live.append(tr["id"])
        self.tracks = [tr for tr in self.tracks if t - tr["t"] <= TRACK_TIMEOUT_S]
        centers, radii, velocities, ids = [], [], [], []
        for tr in self.tracks:
            if tr["id"] not in live:
                continue
            cells = tr["cells"]
            v = tr["velocity"] if tr["hits"] >= 2 else np.zeros(3)
            centers.append(cells)
            radii.append(np.full(len(cells), 0.5 * np.sqrt(3.0) * VOXEL + SPHERE_MARGIN))
            velocities.append(np.repeat(v[None, :], len(cells), axis=0))
            ids.append(np.full(len(cells), tr["id"]))
        if centers:
            centers, radii = np.vstack(centers), np.concatenate(radii)
            velocities, ids = np.vstack(velocities), np.concatenate(ids)
        else:
            centers, radii = np.empty((0, 3)), np.empty(0)
            velocities, ids = np.empty((0, 3)), np.empty(0, dtype=int)
        tracks = [dict(id=tr["id"], centroid=tr["centroid"].tolist(), velocity=tr["velocity"].tolist(),
                       hits=tr["hits"]) for tr in self.tracks if tr["id"] in live]
        return dict(t=float(t), centers=centers, radii=radii, velocities=velocities, track_ids=ids,
                    tracks=tracks, foreground_points=int(len(points)), true_pixels=true_pixels)


def _detector_main(conn, cpu, camera_names, environment):
    os.environ.update(environment)
    if cpu is not None:
        try:
            os.sched_setaffinity(0, {int(cpu)})
        except (AttributeError, OSError):
            pass
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import run_protocol_v3_async_online as online
    from model import build_model

    scene = online._protocol_scene(environment.get("UR5_E4_SCENE_VERSION", "camera_quarter"))
    model = build_model(scene)
    object_geoms = [g for g in range(model.ngeom)
                    if model.body(int(model.geom_bodyid[g])).name.startswith("object")]
    tracker = FixedCameraTracker(model, camera_names, object_geoms)
    conn.send("ready")
    while True:
        message = conn.recv()
        if message is None:
            break
        t, q, mocap_pos, mocap_quat = message
        started = time.perf_counter()
        result = tracker.step(t, q, mocap_pos, mocap_quat)
        result["compute_ms"] = (time.perf_counter() - started) * 1000.0
        conn.send(result)


class DetectorProcess:
    """The detector in its own process; send() when idle, poll() every cycle."""

    def __init__(self, camera_names, cpu=None):
        context = mp.get_context("spawn")
        self.conn, child = context.Pipe()
        keys = ("UR5_STATIC_CAMERAS", "UR5_OBJECTS", "UR5_E4_SCENE_VERSION", "UR5_SCENE_JSON", "UR5_E4_SCENE_JSON")
        environment = {k: os.environ[k] for k in keys if k in os.environ}
        self.process = context.Process(target=_detector_main, args=(child, cpu, tuple(camera_names), environment),
                                       daemon=True)
        self.process.start()
        if self.conn.recv() != "ready":
            raise RuntimeError("detector process failed to start")
        self.busy = False

    def send(self, t, q, mocap_pos, mocap_quat):
        if self.busy:
            return False
        self.conn.send((float(t), np.asarray(q, float).copy(), np.asarray(mocap_pos, float).copy(),
                        np.asarray(mocap_quat, float).copy()))
        self.busy = True
        return True

    def poll(self):
        if self.busy and self.conn.poll():
            self.busy = False
            return self.conn.recv()
        return None

    def close(self):
        try:
            self.conn.send(None)
        except (BrokenPipeError, OSError):
            pass
        self.process.join(timeout=5)
        if self.process.is_alive():
            self.process.terminate()
