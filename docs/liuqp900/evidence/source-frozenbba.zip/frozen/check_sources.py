from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_lowdim_pilot_20261106'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=list(ROOT.glob('*.py'))+list((ROOT/'revisions').rglob('*.py'))+[ROOT/'code/online/protocol_liuqp_controller.py']
index={sha(p):str(p) for p in paths};missing={}
for p in (ROOT/'trials').glob('*/source_hashes.json'):
    for name,digest in json.loads(p.read_text()).items():
        if digest not in index:missing.setdefault(digest,dict(name=name,trials=[]))['trials'].append(p.parent.name)
recovered=ROOT/'revisions/recovered_hash_exact';recovered.mkdir(exist_ok=True)
for digest,record in list(missing.items()):
    candidates=[];old=OLD/record['name']
    if old.exists():candidates.append(old.read_bytes())
    if record['name']=='pilot_worker.py':
        s=(OLD/'pilot_worker.py').read_text()
        s=s.replace("        if job.get('policy_version')=='v4':","        if job.get('policy_version')=='trace_v4':\n            from trace_policy import LowDimPolicy\n        elif job.get('policy_version')=='v4':")
        candidates.append(s.encode())
    if record['name']=='diagnose_contract.py':
        for p in paths:
            if p.name==record['name']:
                candidates.append(p.read_bytes().replace(b'{48,49,50,51}',b'{56,57,58,59}'))
    if record['name']=='export_study.py':
        candidates.append((ROOT/'export_study.py').read_bytes().replace(b'peak_goal_error_mm=float(np.max(es)*1000) if len(es) else None,',b''))
    for data in candidates:
        if hashlib.sha256(data).hexdigest()==digest:
            target=recovered/(digest[:12]+'_'+Path(record['name']).name);target.write_bytes(data);record['recovered']=str(target.relative_to(ROOT));break
out=dict(missing_or_recovered=list(missing.values()),unavailable=[x for x in missing.values() if 'recovered' not in x])
(ROOT/'SOURCE_RECOVERY.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
