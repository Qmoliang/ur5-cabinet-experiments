#!/bin/bash
# Fair timing: each variant alone, same cores, seeds 1 (easy) and 2 (trapped), one at a time.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
COMMON="UR5_KNOWN_INDEX=ball_tree UR5_PYTHON_PLANES=1"
for seed in 1 2; do
  ./known_seed_one.sh $PWD/xt_b0 ellipsoid 0.075 $seed 120 $COMMON
  ./known_seed_one.sh $PWD/xt_x1 ellipsoid 0.075 $seed 120 $COMMON UR5_ATTRACTION=geodesic
  ./known_seed_one.sh $PWD/xt_x2 ellipsoid 0.075 $seed 120 $COMMON UR5_LINK_REGIONS=1
  ./known_seed_one.sh $PWD/xt_x3 ellipsoid 0.075 $seed 120 $COMMON UR5_ATTRACTION=geodesic UR5_LINK_REGIONS=1
done
~/envs/ur5cab/bin/python - <<'EOF'
import csv, glob, json
import numpy as np
for v in ("xt_b0", "xt_x1", "xt_x2", "xt_x3"):
    for d in sorted(glob.glob(f"{v}/ellipsoid_075mm_seed*")):
        c = list(csv.DictReader(open(d + "/cycles.csv")))
        get = lambda k: np.array([float(r[k]) for r in c])
        s = json.load(open(d + "/summary.json"))
        print(f"{v} {d[-6:]} reached={s['success']} controller_ms p50={np.median(get('total_controller_ms')):.2f} "
              f"p99={np.percentile(get('total_controller_ms'), 99):.2f} geometry_ms p50={np.median(get('geometry_ms')):.2f} "
              f"solve_ms p50={np.median(get('solve_ms')):.2f} rows p50={np.median(get('active_obstacle_rows')):.0f}")
EOF
