from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;O=R.parent/'liuqp_entry_certificate_20261107';base=json.loads((R/'goal_plane_acceptance_jobs.json').read_text())[0];jobs=[]
for i in [1,2,3]:jobs.append(dict(base,name='goal_plane_final_cycle_'+str(i)))
for i in [1,2,3]:
 j=dict(base);j.pop('latency_cycle_file');j.update(name='goal_plane_final_measured_'+str(i));jobs.append(j)
for oldname,newname in [('certified_failure_1','goal_plane_regression_failed_1'),('certified_failure_2','goal_plane_regression_failed_2'),('certified_end_1','goal_plane_regression_end_1'),('certified_end_2','goal_plane_regression_end_2'),('certified_measured_1','goal_plane_regression_stall_1'),('certified_measured_2','goal_plane_regression_stall_2')]:
 j=json.loads((O/'trials'/oldname/'job.json').read_text());j.pop('cpus',None);j.update(name=newname,policy_version='goal_plane_acceptance',trace_decisions=True,wall_limit_s=1200)
 if j.get('latency_ticks_file'):j['strict_latency_trace']=True
 jobs.append(j)
(R/'goal_plane_final_jobs.json').write_text(json.dumps(jobs,indent=2));s=(R/'launch_frozen.py').read_text().replace("ROOT/'pilot_worker_progress.py'","ROOT/'pilot_worker_goal_plane_acceptance.py'").replace('[48,49,50,51]','[32,33,34,35]').replace('[52,53,54,55]','[36,37,38,39]').replace('[56,57,58,59]','[56,57,58,59]');(R/'launch_goal_plane_final.py').write_text(s)
a=R/'revisions/goal_plane_final';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
(R/'GOAL_PLANE_FINAL_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['goal_plane_acceptance_policy.py','goal_side_plane_policy.py','diagnostic_exact_pruned_policy.py','pilot_worker_goal_plane_acceptance.py','code/online/protocol_liuqp_controller.py','code/common/policy.json','GOAL_BRANCH_PORTS.json','INPUTS.json']},scope='three complete failed-cycle repetitions, three measured-delay original starts, all six unique preceding successful cases; freeze before these outcomes; no selection or parameter changes'),indent=2));print('frozen',len(jobs),'goal-plane acceptance trials')
