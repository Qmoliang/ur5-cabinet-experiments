"""Check the map key convention and measure frontier size/cost on a recorded trajectory."""
import sys
import time
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
from frontier import FREE, OCCUPIED, frontier_cells  # noqa: E402
from run_protocol_v3_async_online import MAP_VOXEL_SIZE, PerceptionWorker  # noqa: E402

ROI_LOWER = np.array([0.33, 0.0, 0.0])   # cabinet box (x 0.35-0.83, y 0.02-0.79, z 0-1.035) + 2 cm
ROI_UPPER = np.array([0.85, 0.81, 1.055])
worker = PerceptionWorker("ellipsoid", "mvt_simd", centervox_size=0.0075, maximum_uncertainty_union_inflation=1.05,
                          certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty",
                          direct_thin_axis_inflation=1.0, direct_tangent_subdivisions=1, direct_partition_mode="grid",
                          sphere_cover_mode="matched", ellipsoid_cover_mode="matched",
                          radius_limit_representation="both", camera_width=320, camera_height=180,
                          camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm"),
                          scene_version="camera_quarter")
q_history = np.load("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/online_improved/base_seed02/" +
                    next(p.name for p in Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/online_improved/base_seed02").iterdir() if p.is_dir())
                    + "/q_history.npy")
for frame, cycle in enumerate(range(0, 600, 50)):
    packet = worker.process(q_history[cycle], frame, cycle, cycle * 0.02, transferable=True, include_dense_snapshot=True)
    keys, states = packet.occupancy_keys, packet.occupancy_states
    if frame == 0:
        occupied = (keys[states == OCCUPIED] + 0.5) * MAP_VOXEL_SIZE
        proxies = packet.proxies.centers
        from scipy.spatial import cKDTree
        d, _ = cKDTree(proxies).query(occupied[:: max(1, len(occupied) // 2000)])
        print(f"key convention check: occupied voxel centres (key+0.5)*voxel are {1000 * np.median(d):.1f} mm "
              f"(median) from the nearest proxy centre; map voxel {MAP_VOXEL_SIZE * 1000:.0f} mm")
    t = time.perf_counter()
    centres, radius = frontier_cells(keys, states, MAP_VOXEL_SIZE, ROI_LOWER, ROI_UPPER)
    ms = 1000 * (time.perf_counter() - t)
    print(f"cycle {cycle:3d}: known voxels {len(keys):8d} (free {int(np.sum(states == FREE)):8d}), "
          f"frontier cells in cabinet box {len(centres):6d} (r={radius * 1000:.1f} mm), {ms:.0f} ms; "
          f"proxies {len(packet.proxies.centers)}")
worker.close()
