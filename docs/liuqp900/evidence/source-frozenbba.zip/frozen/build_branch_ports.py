"""Retain terminal base/elbow branch identity in two fixed UR5 coordinates."""
import os,json
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
from pilot_adapter import ROOT,build,POLICY
from collision_oracle import CollisionOracle
ctx=build('iris_4shelves_t2');oracle=CollisionOracle(ctx.model,ctx.robot,ctx.arrays,ctx.q0,margin=POLICY['operating_margin_m'])
source=json.loads((ROOT/'GOAL_PORTS.json').read_text());ports=[]
p0=oracle.gripper_position(ctx.q0);outward_reference=(p0-ctx.target)/np.linalg.norm(p0-ctx.target)
for previous in source['ports']:
    port=dict(previous);qg=np.array(port['goal_q']);ee,J,gaps,G,work,W=oracle.evaluate(qg)
    # These coordinates are fixed by UR5 kinematic branch identity, not shelf
    # identifiers, a successful trajectory, or fitted per-run gains.
    P=np.zeros((2,6));P[0,0]=np.linalg.norm(J[:,0]);P[1,2]=np.linalg.norm(J[:,2]);assert np.linalg.matrix_rank(np.vstack([J,P]),tol=1e-8)==5
    lift=np.linalg.pinv(np.vstack([J,P]),rcond=1e-8);rays=[]
    for direction in [outward_reference]+[sign*np.eye(3)[axis] for axis in range(3) for sign in [1.,-1.]]:
        radius=ctx.controller.near_distance
        for _ in range(7):
            qb=qg+lift@np.r_[radius*direction,np.zeros(2)]
            if np.all(qb>=oracle.lower) and np.all(qb<=oracle.upper) and oracle.segment_certified(qg,qb):
                vector=oracle.gripper_position(qb)-ctx.target;length=float(np.linalg.norm(vector));outward=vector/length
                rays.append(dict(outward=outward.tolist(),radius_m=length,linear_radius_m=radius,alignment=float(outward@outward_reference),backward_configuration_for_certificate_only=qb.tolist()));break
            radius*=.5
    assert rays
    chosen=max(rays,key=lambda r:(r['linear_radius_m'],r['alignment']))
    port.update(posture_matrix=P.tolist(),posture_coordinates=['base_angle_unwrapped','elbow_flexion'],coordinate_selection='fixed UR5 branch identity; scale by target translational Jacobian column lengths',all_entry_rays=rays,**chosen)
    ports.append(port)
out=dict(source_goal_sha256=__import__('hashlib').sha256((ROOT/'GOAL_PORTS.json').read_bytes()).hexdigest(),task=source['task'],ports=ports,optimized_route=False,goal_pose_changed=False)
(ROOT/'GOAL_BRANCH_PORTS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
