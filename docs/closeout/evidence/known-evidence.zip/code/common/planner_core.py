"""Identical bounded search over supplied known/observed proxy arrays."""
import os,time,hashlib
import numpy as np
from scipy.optimize import minimize
from scipy.stats import qmc
from unified_policy import POLICY
from collision_oracle import CollisionOracle,SearchDeadline
from position_ik import candidates as analytic_candidates

# One bounded worker-local state; exact geometry hashes prevent reuse across maps.
_SEARCH_STATE={}
def geometry_key(arrays,initial_q,target):
 h=hashlib.sha256()
 for name in sorted(arrays):
  value=arrays[name];h.update(name.encode())
  if isinstance(value,str):h.update(value.encode())
  else:
   a=np.ascontiguousarray(value);h.update(str((a.shape,a.dtype.str)).encode());h.update(a.tobytes())
 h.update(np.asarray(initial_q,dtype=float).tobytes());h.update(np.asarray(target,dtype=float).tobytes())
 return h.hexdigest()

def worker_init(cpus=None):
 if cpus:os.sched_setaffinity(0,set(cpus))
 os.environ["OPENBLAS_NUM_THREADS"]="1";os.environ["OMP_NUM_THREADS"]="1";os.environ["UNIFIED_PLANNER_PROCESS"]="1"
 from proxy_geometry import NativeEllipsoidSupport
 NativeEllipsoidSupport().set_pair_threads(1)

def local_goals(oracle,q0,target,rng,limit):
 goals=[];diagnostics=[];anchor=q0.copy()
 for attempt in range(2):
  if time.perf_counter()>limit:break
  seedq=anchor if attempt==0 else np.clip(q0+rng.normal(0,.1,6),oracle.lower,oracle.upper)
  def constraint(x):
   ee,J,g,G,w,W=oracle.evaluate(x[:6]);return np.r_[g-x[6],w,.0007-np.linalg.norm(ee-target)]
  def jacobian(x):
   ee,J,g,G,w,W=oracle.evaluate(x[:6]);d=ee-target;return np.vstack([np.c_[G,-np.ones(len(g))],np.c_[W,np.zeros(len(w))],np.r_[-d/max(np.linalg.norm(d),1e-12)@J,0.]])
  objective=lambda x:-x[6]+1e-6*np.sum((x[:6]-q0)**2)
  gradient=lambda x:np.r_[2e-6*(x[:6]-q0),-1.]
  r=minimize(objective,np.r_[seedq,POLICY["goal_margin_m"]],jac=gradient,method="SLSQP",bounds=list(zip(oracle.lower,oracle.upper))+[(POLICY["goal_margin_m"],.012)],constraints=[dict(type="ineq",fun=constraint,jac=jacobian)],options=dict(maxiter=160,ftol=1e-10))
  anchor=r.x[:6];error=float(np.linalg.norm(oracle.gripper_position(anchor)-target));slack=oracle.exact_clearance(anchor)
  diagnostics.append(dict(kind="local",iterations=int(r.nit),error_m=error,slack_m=slack,message=str(r.message)))
  if error<.0008 and slack>=0:goals.append(anchor.copy());break
 return goals,diagnostics

class BiTree:
 def __init__(self,oracle,start,goal,rng,pad):
  self.oracle=oracle;self.rng=rng;self.lower=np.maximum(np.minimum(start,goal)-pad,oracle.lower);self.upper=np.minimum(np.maximum(start,goal)+pad,oracle.upper);self.trees=[([start.copy()],[-1]),([goal.copy()],[-1])];self.swapped=False;self.iterations=0
 def extend(self,tree,target):
  points,parents=tree;idx=int(np.argmin(np.linalg.norm(np.asarray(points)-target,axis=1)));d=target-points[idx];length=np.linalg.norm(d);new=target if length<=.08 else points[idx]+d*(.08/length)
  if not self.oracle.free(new) or not self.oracle.segment_free(points[idx],new):return None
  points.append(new.copy());parents.append(idx);return len(points)-1
 def branch(self,tree,index):
  path=[]
  while index>=0:path.append(tree[0][index]);index=tree[1][index]
  return path[::-1]
 def advance(self,count=64):
  for _ in range(count):
   self.iterations+=1;sample=self.trees[1][0][0] if self.iterations%10==0 else self.rng.uniform(self.lower,self.upper);i=self.extend(self.trees[0],sample)
   if i is not None:
    target=self.trees[0][0][i]
    while True:
     j=self.extend(self.trees[1],target)
     if j is None:break
     if np.linalg.norm(self.trees[1][0][j]-target)<1e-9:
      path=self.branch(self.trees[0],i)+self.branch(self.trees[1],j)[::-1][1:]
      return path[::-1] if self.swapped else path
   self.trees.reverse();self.swapped=not self.swapped
  return None

def search(model,robot,arrays,initial_q,q0,target,generation,request_index,budget=None):
 start=time.perf_counter();budget=POLICY["planner_budget_s"] if budget is None else budget
 seed=POLICY["planner_seed"]+1000*request_index;rng=np.random.default_rng(seed);oracle=None
 result=dict(status="no_goal",generation=int(generation),request_index=request_index,planner_seed=seed,path=[],q_start=np.asarray(q0).tolist())
 try:
  key=geometry_key(arrays,initial_q,target)
  if _SEARCH_STATE.get("key")!=key:
   _SEARCH_STATE.clear();_SEARCH_STATE.update(key=key,oracle=CollisionOracle(model,robot,arrays,initial_q),goals=[])
  state=_SEARCH_STATE;oracle=state["oracle"];oracle.deadline=start+budget;oracle.margin=POLICY["goal_margin_m"];q0=np.asarray(q0);target=np.asarray(target)
  result["phase"]="local_goals";goals=list(state["goals"]);diagnostics=[]
  result["reused_goal_count"]=len(goals)
  oracle.deadline=start+budget*.35
  if not goals:
   try:goals,diagnostics=local_goals(oracle,q0,target,rng,oracle.deadline)
   except SearchDeadline:goals=[];diagnostics=[dict(kind="local",status="phase_budget_exhausted")]
  oracle.deadline=start+budget;result["goal_diagnostics"]=diagnostics
  # The global kinematic fallback sees only the robot and supplied proxy certifier.
  result["phase"]="global_goals"
  if len(goals)<8 and time.perf_counter()<start+budget*.65:
   params=(qmc.Sobol(3,scramble=True,seed=seed).random_base2(15)*2-1)*np.pi
   if not np.any(oracle.execution.body_masks[:,5]):params[:,2]=q0[5]
   pool=analytic_candidates(model,target,params,q0)
   order=np.argsort(np.linalg.norm(pool-q0,axis=1),kind="stable")
   # Preserve shoulder/elbow/wrist diversity. The closest six poses may all
   # occupy one disconnected approach branch in a cluttered workspace.
   azimuth=np.arctan2(target[1],target[0])
   def branch(q):return (int(np.cos(q[0]-azimuth)>=0),int(np.sin(q[2])>=0),int(np.sin(q[4])>=0))
   groups={}
   for q in pool[order]:groups.setdefault(branch(q),[]).append(q)
   cursors={k:0 for k in groups};represented={branch(q) for q in goals}
   while groups and time.perf_counter()<start+budget*.65:
    advanced=False
    for k in list(groups):
     if k in represented:continue
     i=cursors[k]
     if i>=len(groups[k]):continue
     advanced=True;cursors[k]+=1;q=groups[k][i]
     if not oracle.free(q):continue
     if np.linalg.norm(oracle.gripper_position(q)-target)>.0008:continue
     if any(np.max(np.abs(q-x))<.1 for x in goals):continue
     goals.append(q.copy());represented.add(k)
    if not advanced:break
   result["goal_branches"]=[list(branch(q)) for q in goals]
  state["goals"]=list(goals)
  result["goals"]=len(goals);result["goals_found_s"]=time.perf_counter()-start;result["phase"]="start_bridge"
  if not goals:return result
  goals.sort(key=lambda q:float(np.linalg.norm(q-q0)))
  oracle.margin=POLICY["environment_margin_m"]
  if not oracle.free(q0):result["status"]="start_not_certified";return result
  origin=q0.copy();bridge=[]
  oracle.margin=POLICY["operating_margin_m"]
  if not oracle.free(origin):
   start_pose=None
   for sigma in [.02,.05,.1,.2]:
    for _ in range(40):
     candidate=np.clip(q0+rng.normal(0,sigma,6),oracle.lower,oracle.upper)
     if not oracle.free(candidate):continue
     oracle.margin=POLICY["environment_margin_m"];ok=oracle.segment_certified(q0,candidate);oracle.margin=POLICY["operating_margin_m"]
     if ok:start_pose=candidate;break
    if start_pose is not None:break
   if start_pose is None:result["status"]="no_clear_start";return result
   bridge=[q0.copy()];origin=start_pose
  result["phase"]="direct_connection"
  reuse=False
  if "origin" in state:
   oracle.margin=POLICY["environment_margin_m"]
   reuse=oracle.segment_free(origin,state["origin"]) and oracle.segment_certified(origin,state["origin"])
   oracle.margin=POLICY["operating_margin_m"]
  if reuse:
   if not np.array_equal(origin,state["origin"]):bridge.append(origin.copy())
   origin=state["origin"].copy();trees=state["trees"];path=state.get("pending_path")
   result["reused_tree_nodes"]=sum(len(t.trees[0][0])+len(t.trees[1][0]) for t in trees)
  else:
   state.pop("pending_path",None);path=None
   trees=[BiTree(oracle,origin,g,np.random.default_rng(seed+17*i+int(pad*10)),pad) for pad in [.5,1.5,3.5] for i,g in enumerate(goals)]
   state.update(origin=origin.copy(),trees=trees)
  if path is None:
   for goal in goals:
    if oracle.segment_free(origin,goal):path=[origin,goal];break
  result["phase"]="rrt"
  while path is None and time.perf_counter()<oracle.deadline:
   for tree in trees:
    path=tree.advance(8)
    if path is not None:break
  if path is None:result["status"]="no_route";return result
  state["pending_path"]=list(path)
  result["phase"]="continuous_validation"
  path=bridge+path
  oracle.margin=POLICY["environment_margin_m"]
  # Certify bounded joint spans first. Certifying a long shortcut directly
  # can consume the budget in loose global arc bounds before any route exists.
  bounded=[path[0]]
  for a,b in zip(path[:-1],path[1:]):
   count=max(1,int(np.ceil(np.max(np.abs(b-a))/.08)))
   bounded.extend(a+(b-a)*t for t in np.linspace(0,1,count+1)[1:])
  path=bounded
  result["validation_edges"]=len(path)-1;result["validated_edges"]=0
  for a,b in zip(path[:-1],path[1:]):
   if not oracle.segment_certified(a,b):
    state.pop("pending_path",None);state.pop("origin",None);state.pop("trees",None)
    result["status"]="path_not_continuously_certified";return result
   result["validated_edges"]+=1
  # The certified route is usable even if optional shortening runs out of time.
  result["phase"]="shortcut"
  for _ in range(12):
   if len(path)<3 or time.perf_counter()>oracle.deadline-.5:break
   i,j=sorted(rng.choice(len(path),2,replace=False))
   if j>i+1:
    try:ok=oracle.segment_free(path[i],path[j]) and oracle.segment_certified(path[i],path[j])
    except SearchDeadline:break
    if ok:path=path[:i+1]+path[j:]
  result["path_continuously_certified"]=True
  chain=[]
  for a,b in zip(path[:-1],path[1:]):
   count=max(1,int(np.ceil(np.max(np.abs(b-a))/POLICY["path_spacing_rad"])))
   chain.extend((a+(b-a)*t).tolist() for t in np.linspace(0,1,count+1)[1:])
  result.update(status="path",phase="finished",path=chain,goal=path[-1].tolist(),goal_slack_m=None,nodes=sum(len(t.trees[0][0])+len(t.trees[1][0]) for t in trees))
  return result
 except SearchDeadline:
  result["status"]="budget_exhausted";return result
 except Exception as exc:
  import traceback
  result.update(status="error",error=repr(exc),traceback=traceback.format_exc());return result
 finally:
  result["seconds"]=time.perf_counter()-start
  if oracle is not None:result["checks"]=oracle.checks
