import os,json
os.sched_setaffinity(0,{48,49,50,51})
import numpy as np
from pilot_adapter import ROOT,build,online
from goal_entry_policy_v3 import LowDimPolicy
old=ROOT.parent/'liuqp_release_study_20261106'
states=[('initial',None),('real_stall',np.load(ROOT.parent/'liuqp_lowdim_pilot_20261106/confirm_original_shelf_t2_baseline_300s_final_snapshot.npz')['q']),('later_trap',np.load(old/'trials/release_only_v2_from_stall/trajectory.npz')['q'][-1])]
out=[]
for name,q in states:
    ctx=build('iris_4shelves_t2',start=q);c=ctx.controller
    c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
    p=LowDimPolicy(ctx,dict(method='release',operating_gate=False),lambda **kw:None);p.observe(0,ctx.q0,np.zeros(6));s=c.pilot_nominal;arrays=c.last_qp_arrays
    extraH,extrag=p._terms(c,s);a=p._solve(c,s,arrays);feature=p.feature(p.q);direction=p.goal_feature-feature;distance=np.linalg.norm(direction);direction/=distance;delta=min(p.radius/2,distance/4)
    m=dict(normal=direction.tolist(),offset=float(direction@feature+delta),progress_buffer_m=delta)
    analytic=p._gradient(m,s);fd=[]
    for j in range(6):fd.append((p._value(m,p.q+1e-6*np.eye(6)[j])-p._value(m,p.q-1e-6*np.eye(6)[j]))/2e-6)
    rec=dict(state=name,error_mm=1000*p.error,posture_error=(p.P@(p.q-p.qg)).tolist(),minimum_extra_hessian_eigenvalue=float(np.linalg.eigvalsh(extraH).min()),memory_hit_value=p._value(m,p.q),memory_goal_value=p._value(m,p.qg),memory_gradient_error=float(np.max(np.abs(analytic-fd))),objective_solved=a is not None)
    assert rec['memory_gradient_error']<1e-6 and rec['memory_hit_value']<0 and rec['memory_goal_value']>0 and rec['minimum_extra_hessian_eigenvalue']>-1e-8
    if a is not None:
        rec['velocity']=a['velocity'].tolist();admit=p._admit(c,arrays,a);rec['admitted_scale']=None if admit is None else admit[1]
        rec['goal_rate_mm_s']=float((ctx.target-p.ee)/p.error@s['J']@a['velocity'])*1000
        rec['posture_squared_error_rate']=float((p.P@(p.q-p.qg))@p.P@a['velocity'])
    out.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'ENTRY_BRANCH_PREFLIGHT.json').write_text(json.dumps(out,indent=2))
