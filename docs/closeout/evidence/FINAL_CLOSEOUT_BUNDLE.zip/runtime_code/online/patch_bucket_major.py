"""Bucket-major snapshot assembly from cached per-bucket arrays (UR5_BUCKET_MAJOR=1, default on).

Each cached bucket fit already holds its cells' representatives, covers,
uncertainty shapes and local proxy indices in item.keys order, and those cells
are unchanged unless the bucket was refitted.  Concatenating them bucket by
bucket gives the same certificates and the same cell -> proxy assignment as the
per-cell Python assembly; only the order of cells (now bucket-major) differs,
and the manager publishes that order as _last_ordered_keys.
"""
from pathlib import Path

p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/incremental_proxy_manager.py")
s = p.read_text()


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)


sub('''    def _fit_incremental_snapshot(
        self,
        ordered_keys: list[tuple[int, ...]],
        changed_keys: set[tuple[int, ...]],
        directional: bool,
    ) -> PointCloudProxySet:''', '''    def _fit_incremental_snapshot(
        self,
        ordered_keys: list[tuple[int, ...]],
        changed_keys: set[tuple[int, ...]],
        directional: bool,
        bucket_major: bool = False,
    ) -> PointCloudProxySet:''')

sub('''        bucket_items = [self._bucket_fits[key] for key in sorted(members)]
        key_to_proxy: dict[tuple[int, int, int], int] = {}''', '''        bucket_items = [self._bucket_fits[key] for key in sorted(members)]
        if bucket_major:
            return self._assemble_bucket_major(sorted(members), members, bucket_items, directional)
        key_to_proxy: dict[tuple[int, int, int], int] = {}''')

# the new assembler, placed right before _fit_incremental_snapshot
sub('''    def _fit_incremental_snapshot(
        self,''', '''    def _assemble_bucket_major(self, bucket_keys, members, bucket_items, directional):
        """Global snapshot from cached per-bucket arrays, cells in bucket-major order."""
        ordered: list[tuple[int, ...]] = []
        index_parts, cluster_parts = [], []
        proxy_base = 0
        for bucket_key, item in zip(bucket_keys, bucket_items):
            if item.keys != tuple(members[bucket_key]):
                raise AssertionError("cached proxy bucket membership is stale")
            ordered.extend(item.keys)
            local_count = len(item.proxies.centers)
            index_parts.append(np.asarray(item.proxies.filtered_cluster_indices, dtype=np.int64) + proxy_base)
            cluster_parts.append(np.column_stack((
                np.repeat(np.asarray(bucket_key, dtype=np.int64)[None, :], local_count, axis=0),
                np.arange(local_count, dtype=np.int64))))
            proxy_base += local_count
        self._fit_ordered_keys = ordered
        filtered = np.concatenate([np.asarray(item.proxies.filtered_points, dtype=float) for item in bucket_items])
        offsets = np.concatenate([
            np.asarray(item.proxies.filtered_point_offsets, dtype=float)
            if item.proxies.filtered_point_offsets is not None
            else np.asarray([self._cells[key].cover_radius for key in item.keys], dtype=float)
            for item in bucket_items])
        filtered_uncertainty = (
            np.concatenate([np.asarray(item.proxies.filtered_uncertainty_shapes, dtype=float) for item in bucket_items])
            if directional else None)
        cat = lambda name: self._concatenate_proxy_field(bucket_items, name)
        return PointCloudProxySet(
            raw_points=filtered.copy(),
            filtered_points=filtered,
            centers=cat("centers"),
            sphere_radii=cat("sphere_radii"),
            ellipsoid_shapes=cat("ellipsoid_shapes"),
            rotations=cat("rotations"),
            cluster_keys=np.concatenate(cluster_parts, axis=0),
            filtered_cluster_indices=np.concatenate(index_parts),
            maximum_ellipsoid_overshoot=max(item.proxies.maximum_ellipsoid_overshoot for item in bucket_items),
            surface_cover_radius=max(item.proxies.surface_cover_radius for item in bucket_items),
            proxy_offset_radii=cat("proxy_offset_radii"),
            filtered_uncertainty_shapes=filtered_uncertainty,
            filtered_point_offsets=offsets,
            proxy_uncertainty_shapes=cat("proxy_uncertainty_shapes") if directional else None,
            base_sphere_radii=cat("base_sphere_radii"),
            base_ellipsoid_shapes=cat("base_ellipsoid_shapes"),
            ellipsoid_outer_shapes=cat("ellipsoid_outer_shapes"),
            maximum_uncertainty_union_inflation=max(
                item.proxies.maximum_uncertainty_union_inflation for item in bucket_items),
            certificate_radius_limit=self.certificate_radius_limit,
            uncertainty_fusion_mode=self.uncertainty_fusion_mode,
            sphere_cover_mode=self.sphere_cover_mode,
            # matched/matched only (see the caller): the values the per-cell
            # assembly uses in that mode.
            sphere_cover_candidate_count=0,
            sphere_cover_selected_count=0,
            sphere_cover_reverse_deleted=0,
            certificate_cover_mode="matched",
            certificate_cover_candidate_count=0,
            certificate_cover_selected_count=0,
            certificate_cover_reverse_deleted=0,
            certificate_cover_minimum_unique_witnesses=0,
        )

    def _fit_incremental_snapshot(
        self,''')

# update(): the per-cell representative loop only fed len(filtered) here
sub('''        ordered_keys = sorted(self._cells)
        representatives: list[np.ndarray] = []
        cover_radii: list[float] = []
        uncertainty_shapes: list[np.ndarray] = []
        for key in ordered_keys:
            cell = self._cells[key]
            representative = cell.representative
            representatives.append(representative)
            cover_radii.append(cell.cover_radius)
            if directional:
                if cell.uncertainty_shape is None:
                    raise AssertionError("directional CenterVox cell lost its shape")
                uncertainty_shapes.append(cell.uncertainty_shape)
        filtered = np.asarray(representatives)
        offsets = np.asarray(cover_radii)
        cell_merge_done = time.perf_counter()''', '''        ordered_keys = sorted(self._cells)
        if directional and any(cell.uncertainty_shape is None for cell in self._cells.values()):
            raise AssertionError("directional CenterVox cell lost its shape")
        filtered_count = len(ordered_keys)
        cell_merge_done = time.perf_counter()''')

sub('''        else:
            proxies = self._fit_incremental_snapshot(
                ordered_keys, changed, directional
            )
        bucket_fit_done = time.perf_counter()''', '''        else:
            bucket_major = (
                os.environ.get("UR5_BUCKET_MAJOR", "1") == "1"
                and self.sphere_cover_mode == "matched"
                and self.ellipsoid_cover_mode == "matched"
            )
            proxies = self._fit_incremental_snapshot(
                ordered_keys, changed, directional, bucket_major=bucket_major
            )
            if bucket_major:
                ordered_keys = self._fit_ordered_keys
        bucket_fit_done = time.perf_counter()''')

sub('''            center_voxels=len(filtered),''', '''            center_voxels=filtered_count,''')
p.write_text(s)
print("patched")
