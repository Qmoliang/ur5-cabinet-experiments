from pathlib import Path
import os,json,time
os.sched_setaffinity(0,{48,49,50,51})
import numpy as np
from pilot_adapter import ROOT,build
from continuation_policy import LowDimPolicy as Full
R=ROOT;f=R/'trials/exact_failure_trace';d=dict(np.load(f/'decision_trace.npz'));tr=dict(np.load(f/'trajectory.npz'));job=json.loads((f/'job.json').read_text());ctx=build(job['task']);p=Full(ctx,job,lambda **kw:None);g=p.future_guard;pg=ctx.proxy_guard

def same_witness(q,lo,hi):
 vals=[]
 for s in np.unique(d['fraction'][lo:hi]):
  ids=np.flatnonzero(d['fraction'][lo:hi]==s)+lo;points=g.positions((1-s)*q+s*p.qg)
  e=ids[d['kind'][ids]==0]
  if len(e):
   ri=d['ids'][e,0];oi=d['ids'][e,1];dist,_=pg.point_geometry(points[ri],oi,optimizer=True);vals.extend((dist-g.radii[ri]-ctx.controller.safety_margin).tolist())
  for idx in ids[d['kind'][ids]!=0]:
   i,j=d['ids'][idx]
   if d['kind'][idx]==1:vals.append(float(points[i,j%3]-g.radii[i]-g.workspace_lower[j%3] if j<3 else g.workspace_upper[j%3]-points[i,j%3]-g.radii[i]))
   else:vals.append(float(np.linalg.norm(points[i]-points[j])-g.radii[i]-g.radii[j]-g.self_margin))
 return min(vals,default=0.)
rows=[];anchors=[];last=-100;started=time.monotonic()
for i,k in enumerate(d['cycles']):
 lo,hi=d['offsets'][i:i+2]
 if hi==lo:continue
 h=d['h'][lo:hi];B=d['b'][lo:hi];minimum=float(h.min());delta=tr['q'][k+1]-tr['q'][k]
 rec=dict(call=i,cycle=int(k),cached_min_m=minimum,predicted_immediate_gain_m=float(min(h+.02*B@d['proposed'][i])-minimum),applied_linear_gain_m=float(min(h+B@delta)-minimum),same_witness_actual_gain_m=float(same_witness(tr['q'][k+1],lo,hi)-minimum),same_call_executed=bool(d['applied_ids'][k]==i),refresh_count=int(d['refresh'][i]))
 rows.append(rec)
 if k-last>=100:
  p.k=int(k);full=Full.continuation_witnesses(p,tr['q'][k]);rec['refreshed_min_m']=-full['deficit'];rec['hidden_witness_loss_m']=rec['refreshed_min_m']-minimum;rec['full_worst']=[] if not full['rows'] else [{x:v for x,v in r.items() if x!='b'} for r in sorted(full['rows'],key=lambda r:r['slack'])[:2]];anchors.append(rec);last=k
  if len(anchors)%30==0:print('refreshed',len(anchors),'cycle',k,flush=True)
for a,b in zip(anchors[:-1],anchors[1:]):a['executed_window_margin_change_m']=b['refreshed_min_m']-a['refreshed_min_m'];a['window_cycles']=b['cycle']-a['cycle']
positive=[r for r in rows if r['predicted_immediate_gain_m']>1e-9];sw=[r for r in anchors if r['hidden_witness_loss_m']<-.0002];reg=[r for r in anchors if r.get('executed_window_margin_change_m',0)<-.0002]
summary=dict(gradient_decisions=len(rows),positive_predicted_improvements=len(positive),positive_prediction_but_applied_linear_nonpositive=sum(r['applied_linear_gain_m']<=1e-9 for r in positive),positive_prediction_but_same_witness_actual_nonpositive=sum(r['same_witness_actual_gain_m']<=1e-9 for r in positive),requests_not_applied_immediately=sum(not r['same_call_executed'] for r in rows),full_map_anchors=len(anchors),anchors_missing_worse_witness_over_0_2mm=len(sw),maximum_hidden_witness_loss_mm=max([-r['hidden_witness_loss_m']*1000 for r in anchors],default=0),windows_regressing_over_0_2mm=len(reg),scope='Full map means all published proxy geometry at the fixed scalar witness fractions; this is not a continuous entry certificate or a causal claim by itself',wall_s=time.monotonic()-started)
(R/'FAILURE_DECOMPOSITION.json').write_text(json.dumps(dict(summary=summary,anchors=anchors,decisions=rows),indent=2));print(json.dumps(summary,indent=2))
