from pathlib import Path
import shutil,json,hashlib,numpy as np
R=Path(__file__).resolve().parent;O=R.parent/'liuqp_entry_certificate_20261107';assert not (R/'code').exists()
files=list(O.glob('*.py'))+list(O.glob('*.json'))+list((O/'trials').glob('*/*.json'))+list((O/'trials').glob('*/*.npz'))
(R/'PROTECTED_PREVIOUS_STUDY.json').write_text(json.dumps({str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},indent=2))
for f in ['code','vendor']:shutil.copytree(O/f,R/f,ignore=shutil.ignore_patterns('__pycache__'))
for p in O.glob('*.py'):
 if p.name not in ['setup_study.py','remote_transfer.py']:shutil.copy2(p,R/p.name)
for n in ['INPUTS.json','GOAL_PORTS.json','GOAL_BRANCH_PORTS.json']:shutil.copy2(O/n,R/n)
(R/'trials').mkdir()
f=O/'trials/certified_original_start';j=json.loads((f/'job.json').read_text());res=json.loads((f/'result.json').read_text());raw=np.load(j['latency_ticks_file']);n=res['controller_calls'];effective=raw[np.minimum(np.arange(n),len(raw)-1)];np.save(R/'EXACT_FAILURE_EFFECTIVE_TICKS.npy',effective)
assert n-len(raw)==res['latency_trace_tail_uses']==937
(R/'DELAY_PROVENANCE.json').write_text(json.dumps(dict(source_result=str(f/'result.json'),source_latency_file=j['latency_ticks_file'],source_ticks=len(raw),actual_calls=n,old_tail_repetitions=937,complete_effective_ticks=len(effective),rule='Expand exactly the ticks applied by the old worker, including old tail repetitions. Newly measured computation times were not applied in that run and cannot reproduce it.'),indent=2))
j.pop('cpus',None);j.update(name='exact_failure_trace',latency_ticks_file=str(R/'EXACT_FAILURE_EFFECTIVE_TICKS.npy'),trace_decisions=True,strict_latency_trace=True)
(R/'reproduction_jobs.json').write_text(json.dumps([j],indent=2));print('protected',len(files),'effective ticks',n)
