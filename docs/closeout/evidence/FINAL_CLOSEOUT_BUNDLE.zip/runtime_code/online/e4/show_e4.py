"""Print the E4 block of one or more online run summaries."""
import json
import sys
from pathlib import Path

for d in sys.argv[1:]:
    s = json.load(open(Path(d) / "summary.json"))
    e = s.get("e4") or {}
    print("==", d)
    keys = ("mode", "object_count", "success_after", "success_after_s", "first_success_5mm_s",
            "object_contact_cycles", "first_object_contact_s", "contact_bodies", "static_penetrating_cycles",
            "escape_cycles", "yield_cycles", "cold_retries", "peak_joint_ratio", "peak_tcp_speed",
            "detector_frames", "detector_latency_ms_p50", "detector_latency_ms_p95", "detector_compute_ms_p50",
            "frames_with_unmatched_tracks")
    print({k: e.get(k) for k in keys})
    o = e.get("objects") or {}
    print("  objects:", {k: o.get(k) for k in ("progress", "trigger_s", "not_launched", "rejected_no_room")})
    for po in e.get("per_object", []):
        print("  ", po)
    print("  controller p99 ms", s.get("controller_ms_p99") or s.get("total_controller_ms_p99"),
          "map age p50", s.get("publish_snapshot_age_ms_p50") or s.get("snapshot_age_ms_p50"))
