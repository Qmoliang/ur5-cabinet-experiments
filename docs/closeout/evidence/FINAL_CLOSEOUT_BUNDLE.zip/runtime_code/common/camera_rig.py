import numpy as np,mujoco
from unified_policy import POLICY
def fixed_rig(robot_model,initial_configurations,target):
 data=mujoco.MjData(robot_model);anchors=[]
 for q in initial_configurations:
  data.qpos[:6]=q;mujoco.mj_kinematics(robot_model,data);anchors.append(data.site_xpos[robot_model.site("attachment_site").id].copy())
 initial=np.mean(anchors,axis=0);spec=[];records=[]
 anchors={"start":initial,"goal":np.asarray(target)}
 for i,(role,offset) in enumerate(zip(POLICY["camera_anchor_roles"],POLICY["camera_offsets"])):
  anchor=anchors[role];position=anchor+np.asarray(offset);position[2]=max(position[2],POLICY["camera_minimum_height_m"]);cam=f"static_unified_{i}"
  spec.append(cam+":"+','.join(format(float(x),'.12g') for x in position)+":"+','.join(format(float(x),'.12g') for x in anchor))
  records.append(dict(name=cam,position=position.tolist(),look_at=anchor.tolist(),anchor_role=role))
 return ';'.join(spec),records
