from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'delivery'
report=json.loads((OUT/'RESULTS.json').read_text());rs={r['name']:r for r in report['records']}
target=['retained_blocker_gate','retained_blocker_from_stall','retained_stall_repeat_1','retained_stall_repeat_2']
lines=['LiuQP 同一货架脱困研究：本轮结论','',
'结论：已经产生一次从原算法真实停滞状态出发、完整到达且通过独立安全审计的轨迹；同版本两次重复失败，尚未得到稳定脱困算法。',
'没有更换场景，没有读取成功路线，没有引入路径/航点规划，也没有放宽原硬安全或目标保持要求。',
'这是 UR5e 运动学反馈仿真，使用冻结的因果观测地图和实测计算延迟；不是实体机实验，也不是持续新感知的未知环境完整验证。','',
'最终冻结版本的同场景结果：',
'run | 起点 | 时长(s) | 末端误差(mm) | 安全审计 | 到达']
for name in target:
    r=rs[name];lines.append(f"{name} | {r['start']} | {r['simulation_s']:.2f} | {r['final_error_mm']:.6f} | {r['safety_audit']} | {r['safe_arrival']}")
success=rs['retained_blocker_from_stall'];a=json.loads((ROOT/'trials/retained_blocker_from_stall/audit.json').read_text())
lines+=['',
f"成功的真实停滞恢复：{success['simulation_s']:.2f} s，最终 {success['final_error_mm']:.6f} mm，目标保持 50 周期；最小代理间隙 {a['minimum_proxy_gap_mm']:.9f} mm，真实货架盒最小间隙 {1000*a['physical_motion']['minimum_environment_m']:.6f} mm，自碰最小间隙 {1000*a['physical_motion']['minimum_self_m']:.6f} mm。", 
f"该运行保留几何查询 {success['retained_geometry_queries']} 次，其中 {success['pruned_row_continuations']} 次已不在当前筛选 QP 中。动作仍经原完整安全门检查。", 
'原直接目标 LiuQP 在同一货架的球/椭球表示下，300 s 后分别约剩 378.98/378.13 mm；历史 RRT 引导执行从原初态 47.74 s 到达。',
'两者启发了本轮研究，但不同起点的耗时不可直接比较。此前启发式 prototype v1 也曾从原初态 28.84 s 到达；其错误关节风险选择在其他试验失败，未将它包装成稳定成果。','',
'为什么原姿态调整不能释放真正阻塞：',
'(1) 原底座下限具有正 KKT 乘子，严格释放需要暂时增加任务代价；纯 Jv=0 姿态运动不能同时满足这项严格释放及所有活动约束。',
'(2) 后续约 48 mm 处的强约束作用在前臂靠肘部的球体，法向行约 [0.285677,-0.237178,0,0,0,0]。后四关节对这个间隙的一阶作用几乎为零。必须让底座/肩部协调退让，而不是继续盲目转腕。','',
'安全门拒绝分清了三类问题：',
'(1) 旧预认证绕过原执行器的关节裁剪；300 个分层拒绝样本按原流程裁剪后都在比例 1.0 通过。已修复接入，且单独复跑证明这项修复本身不能完成脱困。',
'(2) 原 QP 名义余量 6.5 mm 与执行硬安全 6 mm 不同；某些硬安全状态中的零速度并不满足名义 QP，不能一律称作零速局部极小。更强停止门消融也失败，保留记录。',
'(3) 增广优化的数值失败不等于物理无路；100.36 mm 末态的独立 LP/原 QP 都可行，而增广余量问题数值求解失败。最终先验证真正要执行的原六变量解，证书不过不发布。','',
'新的目标与状态逻辑：',
'原速度 QP f0(v)=0.5 v^T H v+g^T v，原可行集 C(q) 不变。',
'关节单侧余量代价 R(v)=0.5*omega*e^2*sum_j[(max(v_j,0)/r_j^+)^2+(max(-v_j,0)/r_j^-)^2]。',
'r 是扣除原制动行程后的剩余关节行程，分母下限来自 a*dt^2；离开边界的速度不使用该边界的小余量惩罚。',
'对当前真正阻塞几何 d_i(q)，取 b=grad d_i/||grad d_i||，解 min_{v in C, b^T v>=nu} f0(v)+R(v)。',
'nu 从原速度可行集支持函数的一半起，经过实际安全认证；等效原 QP 梯度为 g+grad R-alpha*b。',
'新增优化只作用于本周期速度，一个释放标量协调必要的末端退让与姿态调整。没有未来构型决策、搜索树或参考路线。',
'仅加 R 不够：grad R(0)=0，无法单独消除原来的精确零速平衡。真正起作用的是指向阻塞间隙的释放项及跨周期几何记忆。',
'真实最佳目标距离不再改善时触发释放；不把预测速度或往返振荡当作已取得进展。',
'选中的实际观测几何在 QP 行被筛除后仍被保留，直到真实间隙达到原近障阈值或任务已有净进展且不会立即重闭合。','',
'为什么仍不稳定：',
'打开单个代理的间隙，并不保证离开同一物理表面及相邻代理共同形成的受困区域。失败日志中多次在打开到 40 mm 后切回目标追踪，又进入相邻代理的阻塞。',
'现有记忆以单个代理与进入时任务势值为单位，尚不能稳定保持跨相邻表面的绕行进展；实测计算延迟也改变动作保持及切换时刻。重复失败说明它对这些变化仍敏感，尚未单独识别全部因果。',
'不能靠调大释放权重或把到达阈值改宽来宣称解决。后续真正未解决的是持久的表面/绕行阶段身份与退出条件，而不是有没有一个可行的瞬时姿态速度。','',
'证据边界：',
'已证明本次记录中存在无规划、同原安全条件的真实停滞恢复成功；不能证明所有局部极小可逃逸、同场景稳定成功、跨场景泛化或实体机实时可用。',
f"成功恢复运行控制计算 p99 约 {success['controller_p99_ms']:.2f} ms，超过 20 ms 控制周期，实验已计入延迟；不能据此声称满足硬实时。", 
'本轮所有失败、数值中止、冻结版本、候选与快照、独立审计均在压缩包中。RESULTS.json 提供逐次数据，DERIVATION_REVIEW.txt 提供完整数学推导，REPRODUCE.txt 说明服务器依赖和复现入口。',
'完整性：'+json.dumps(report['integrity'],ensure_ascii=False),
'开发运行统计（不同版本混合，不是某算法成功率）：'+json.dumps(report['counts'],ensure_ascii=False)]
(OUT/'FINAL_REPORT.txt').write_text('\n'.join(lines),encoding='utf-8');print(str(OUT/'FINAL_REPORT.txt'))
