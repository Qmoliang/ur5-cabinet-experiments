"""Dodge batch: per scene x direction x speed x controller -> runs avoided, contact time, dodge distance."""
import collections
import glob
import json
from pathlib import Path

import numpy as np

rows = collections.defaultdict(list)
for f in glob.glob("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/dodge/*/*_seed*/summary.json"):
    p = Path(f)
    ctl, direction, speed = p.parent.parent.name.rsplit("_", 2)
    scene = p.parent.name.split("_ellipsoid_")[0]
    rows[(scene, direction, float(speed[1:]), ctl)].append(json.load(open(f)))
print("scene | from | speed m/s | controller | avoided /20 | median contact cycles | median dodge mm | runs with controller failure | reached after")
for key in sorted(rows):
    rs = rows[key]
    info = [r.get("racket") or {} for r in rs]
    contact = [i.get("contact_cycles", 0) for i in info]
    avoided = sum(c == 0 for c in contact)
    print(f"{key[0]:10s} {key[1]:5s} {key[2]:4.2f} {key[3]:12s} avoided {avoided:2d}/{len(rs)}  "
          f"contact {np.median(contact):5.0f}  dodge {1000*np.median([i.get('max_dodge_m') or 0 for i in info]):6.1f}  "
          f"failures {sum(bool(r.get('controller_failure_cycles')) for r in rs):2d}  "
          f"after {sum(bool(i.get('success_after_racket')) for i in info):2d}")
totals = collections.defaultdict(lambda: [0, 0])
for (scene, direction, speed, ctl), rs in rows.items():
    a = sum((r.get("racket") or {}).get("contact_cycles", 0) == 0 for r in rs)
    totals[(speed, ctl)][0] += a
    totals[(speed, ctl)][1] += len(rs)
print("\navoided, all scenes and directions:")
for (speed, ctl), (a, n) in sorted(totals.items()):
    print(f"  {speed:4.2f} m/s {ctl:12s} {a:3d}/{n}")
