"""E1/E2 on runs where at least one object was actually launched (launch timing depends on each
controller's own arm path), plus launch rates, per scene and per object count/speed."""
import collections
import glob
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e1")
stats = collections.defaultdict(lambda: [0, 0, 0, 0])   # runs, launched, hit-free (launched), clean (launched)
both = collections.defaultdict(dict)
for f in glob.glob(str(ROOT / "*_k[123]_v*" / "*_seed*" / "summary.json")):
    p = Path(f)
    variant, count, speed = p.parent.parent.name.rsplit("_", 2)
    s = json.load(open(f))
    o = s["objects"]
    launched = sum(d["launched"] for d in o["described"])
    clean = (bool(o["success_after"]) and o["contact_cycles"] == 0 and s["static_penetrating_cycles"] == 0
             and s["peak_joint_speed_ratio"] <= 1 + 1e-6)
    for key in ((variant, "all"), (variant, count + "@" + speed[1:]), (variant, p.parent.name.split("_ellipsoid")[0])):
        r = stats[key]
        r[0] += 1
        if launched:
            r[1] += 1
            r[2] += o["contact_cycles"] == 0
            r[3] += clean
    both[(count + speed, p.parent.name)][variant] = (launched > 0, clean)
variants = sorted({k[0] for k in stats})
groups = sorted({k[1] for k in stats}, key=lambda g: (g != "all", g))
print(f"{ROOT}: launched runs only.  cell = clean / launched  (launched / runs)")
for g in groups:
    print(f"  {g:20s} " + "  ".join(
        f"{v[:12]:>12s} {stats[(v, g)][3]:3d}/{stats[(v, g)][1]:<3d}({stats[(v, g)][1]:3d}/{stats[(v, g)][0]:<3d})"
        for v in variants))
# Common set: the same (condition, scene, seed) launched for every controller.
common = [k for k, d in both.items() if len(d) == len(variants) and all(x[0] for x in d.values())]
print(f"\nruns where every controller had a launched object: {len(common)}")
for v in variants:
    print(f"  {v:14s} clean {sum(both[k][v][1] for k in common)}/{len(common)}")
