"""Compare B0 / X1 / X2 / X3 on the 20 known-cabinet start poses."""
import csv
import glob
import json
from pathlib import Path

import numpy as np

RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
VARIANTS = [("x_b0_baseline", "LiuQP (per-sphere planes)"), ("x_x1_geodesic", "+ geodesic attraction"),
            ("x_x2_linkplanes", "+ per-link planes"), ("x_x3_both", "+ both")]
TRAPPED = {2, 3, 5, 6, 8, 9, 10, 13, 14, 15, 18}
rows = []
for folder, name in VARIANTS:
    runs = {}
    for path in glob.glob(str(RUNS / folder / "ellipsoid_075mm_seed*" / "summary.json")):
        seed = int(path.split("seed")[1][:2])
        s = json.loads(Path(path).read_text())
        with open(Path(path).with_name("cycles.csv")) as handle:
            cycles = list(csv.DictReader(handle))
        runs[seed] = dict(
            success=s["success"], time=s.get("first_sustained_success_time_s"),
            penetrating=s["exact_penetrating_cycles"], final_mm=1000 * s["final_error_m"],
            rows=float(np.median([float(c["active_obstacle_rows"]) for c in cycles])),
            controller_ms=float(np.median([float(c["total_controller_ms"]) for c in cycles])),
            shared=s.get("shared_plane_solves"), per_sphere=s.get("per_sphere_plane_solves"),
            build_ms=s.get("attractor_build_ms"), cycles=len(cycles))
    if len(runs) != 20:
        print(f"{name}: {len(runs)} of 20 finished")
        continue
    trapped = [runs[s] for s in TRAPPED]
    easy = [runs[s] for s in set(runs) - TRAPPED]
    row = {
        "variant": name,
        "reached": sum(r["success"] for r in runs.values()),
        "reached_trapped": sum(r["success"] for r in trapped),
        "reached_easy": sum(r["success"] for r in easy),
        "penetrating_cycles": sum(r["penetrating"] for r in runs.values()),
        "trapped_time_median_s": float(np.median([r["time"] for r in trapped if r["success"]])) if any(r["success"] for r in trapped) else None,
        "easy_time_median_s": float(np.median([r["time"] for r in easy if r["success"]])) if any(r["success"] for r in easy) else None,
        "qp_obstacle_rows_median": float(np.median([r["rows"] for r in runs.values()])),
        "controller_ms_median": float(np.median([r["controller_ms"] for r in runs.values()])),
        "shared_plane_solves_per_cycle": (float(np.median([r["shared"] / r["cycles"] for r in runs.values()]))
                                          if runs[1]["shared"] is not None else None),
        "fallback_per_sphere_solves_per_cycle": (float(np.median([r["per_sphere"] / r["cycles"] for r in runs.values()]))
                                                 if runs[1]["per_sphere"] is not None else None),
        "geodesic_build_s": (runs[1]["build_ms"] / 1000) if runs[1]["build_ms"] else None,
        "failed_seeds": sorted(s for s in runs if not runs[s]["success"]),
        "failed_final_mm": {s: round(runs[s]["final_mm"], 1) for s in runs if not runs[s]["success"]},
    }
    rows.append(row)
    print(json.dumps(row))
(RUNS / "x_summary.json").write_text(json.dumps(rows, indent=2))
