"""Bounded goal/posture search on one immutable, fully certified online map.
No world geometry, saved answers, or future observations are used.
"""
from __future__ import annotations
import os,time,types
from dataclasses import dataclass
import numpy as np
import mujoco
from scipy.optimize import minimize
from run_protocol_v3_async_online import _build_mvt_only
from mixed_geometry import HybridProxyGuard as ContinuousProxyGuard
from escape_point import WORKSPACE_A, WORKSPACE_B, SELF_MARGIN
from guidance import rrt_connect, densify

class SearchDeadline(RuntimeError): pass

def worker_init(cpus):
    if cpus: os.sched_setaffinity(0,set(cpus))
    try: os.nice(5)
    except OSError: pass
    import ctypes
    try:
        ctypes.CDLL("libgomp.so.1").omp_set_num_threads(1)
    except OSError:
        pass

class OnlineOracle:
    def __init__(self,model,robot,proxies,initial_q,margin=.0066,representation="ellipsoid"):
        self.representation=representation;self.model=model;self.data=mujoco.MjData(model);self.robot=robot
        self.body_ids=np.array([x.body_id for x in robot]);self.local=np.array([x.local_center for x in robot]);self.radii=np.array([x.radius for x in robot])
        self.lower=model.jnt_range[:6,0]+.015;self.upper=model.jnt_range[:6,1]-.015
        self.site=model.site('attachment_site').id;self.margin=margin;self.checks=0;self.deadline=float('inf')
        self.index=_build_mvt_only(proxies,representation,self.radii,simd=True)
        packet=types.SimpleNamespace(proxies=proxies,mvt=self.index,ellipsoid_eigenvalues=None,ellipsoid_rotations=None,uncertainty_eigenvalues=None)
        self.guard=ContinuousProxyGuard(packet,representation);self.guard.support_kernel.set_pair_threads(1);self.proxies=proxies
        p=self.sphere_positions(initial_q);parent=model.body_parentid
        self.pairs=np.array([(i,j) for i in range(len(robot)) for j in range(i+1,len(robot)) if self.body_ids[i]!=self.body_ids[j] and parent[self.body_ids[i]]!=self.body_ids[j] and parent[self.body_ids[j]]!=self.body_ids[i] and np.linalg.norm(p[j]-p[i])-self.radii[i]-self.radii[j]>=SELF_MARGIN],dtype=int).reshape(-1,2)
        self._q=None;self._cache=None
    def close(self):self.index.close()
    def sphere_positions(self,q):
        self.data.qpos[:6]=q;mujoco.mj_kinematics(self.model,self.data)
        return self.data.xpos[self.body_ids]+np.einsum('nij,nj->ni',self.data.xmat[self.body_ids].reshape(-1,3,3),self.local)
    def gripper_position(self,q):
        self.sphere_positions(q);return self.data.site_xpos[self.site].copy()
    def evaluate(self,q):
        if time.perf_counter()>self.deadline:raise SearchDeadline()
        if self._q is not None and np.array_equal(q,self._q):return self._cache
        self.checks+=1;p=self.sphere_positions(q);mujoco.mj_comPos(self.model,self.data)
        jac=[]
        for i,pt in enumerate(p):
            jp=np.zeros((3,self.model.nv));mujoco.mj_jac(self.model,self.data,jp,None,pt,int(self.body_ids[i]));jac.append(jp[:,:6])
        jac=np.asarray(jac);ej=np.zeros((3,self.model.nv));mujoco.mj_jacSite(self.model,self.data,ej,None,self.site)
        ri=[];oi=[]
        for i,pt in enumerate(p):
            ids=self.guard._candidates(pt,pt,float(self.radii[i]+.030));ri.extend([i]*len(ids));oi.extend(ids)
        ri=np.asarray(ri,dtype=int);oi=np.asarray(oi,dtype=int);gaps=np.full(len(p),.030);gj=np.zeros((len(p),6))
        if len(oi):
            delta=self.proxies.centers[oi]-p[ri]
            if self.representation=='sphere':
                length=np.linalg.norm(delta,axis=1);normals=delta/np.maximum(length[:,None],1e-15)
                values=length-self.proxies.sphere_radii[oi]-self.radii[ri]-self.proxies.proxy_offset_radii[oi]
            else:
                Q=self.proxies.base_ellipsoid_shapes[oi]
                first=self.guard.support_kernel.closest_points_pairs_warm(p[ri],self.proxies.centers[oi],self.guard.eigenvalues[oi],self.guard.rotations[oi],np.full(len(oi),np.nan))
                normals=first[0]
                values=np.einsum('ni,ni->n',normals,delta)-np.sqrt(np.maximum(np.einsum('ni,nij,nj->n',normals,Q,normals),0))-self.radii[ri]-self.proxies.proxy_offset_radii[oi]
            half=getattr(self.proxies,'box_half_extents',None)
            if half is not None:
                mask=np.any(np.asarray(half)[oi]>0,axis=1)
                if np.any(mask):
                    c=self.proxies.centers[oi[mask]];h=np.asarray(half)[oi[mask]];x=p[ri[mask]];closest=np.clip(x,c-h,c+h);diff=closest-x;length=np.linalg.norm(diff,axis=1);bn=diff/np.maximum(length[:,None],1e-15);bg=length-self.radii[ri[mask]]
                    for k in np.flatnonzero(length<1e-12):
                        depth=h[k]-np.abs(x[k]-c[k]);axis=int(np.argmin(depth));bn[k]=0;bn[k,axis]=-1. if x[k,axis]>=c[k,axis] else 1.;bg[k]=-depth[axis]-self.radii[ri[mask][k]]
                    normals[mask]=bn;values[mask]=bg
            for i in np.unique(ri):
                ks=np.flatnonzero(ri==i);k=ks[np.argmin(values[ks])]
                if values[k]<gaps[i]:gaps[i]=values[k];gj[i]=-normals[k]@jac[i]
        work=(WORKSPACE_B[None]-p@WORKSPACE_A.T-self.radii[:,None]).ravel()
        wj=-np.einsum('wi,rij->rwj',WORKSPACE_A,jac).reshape(-1,6)
        a,b=self.pairs.T;delta=p[b]-p[a];length=np.linalg.norm(delta,axis=1)
        selfgap=length-self.radii[a]-self.radii[b]-SELF_MARGIN
        sj=np.einsum('ni,nij->nj',delta/np.maximum(length[:,None],1e-12),jac[b]-jac[a])
        ee=self.data.site_xpos[self.site].copy()
        self._q=np.asarray(q).copy();self._cache=(ee,ej[:,:6].copy(),gaps,gj,np.r_[work,selfgap],np.vstack([wj,sj]));return self._cache
    def clearance(self,q):
        if np.any(q<self.lower) or np.any(q>self.upper):return -np.inf
        ee,ej,g,gj,w,wj=self.evaluate(q)
        return float(min(np.min(g)-self.margin,np.min(w)))
    def exact_clearance(self,q):
        p=self.sphere_positions(q)
        slack=self.guard.certify(p,p,self.radii+self.margin).minimum_clearance_m
        work=np.min(WORKSPACE_B[None]-p@WORKSPACE_A.T-self.radii[:,None])
        a,b=self.pairs.T;selfgap=np.linalg.norm(p[b]-p[a],axis=1)-self.radii[a]-self.radii[b]-SELF_MARGIN
        return float(min(slack,work,np.min(selfgap)))
    def free(self,q):return self.clearance(q)>=0
    def segment_free(self,q0,q1,step=.005):
        n=max(1,int(np.ceil(np.max(np.abs(q1-q0))/step)))
        return all(self.free(q0+(q1-q0)*x) for x in np.linspace(0,1,n+1))

def search_goal(model,robot,proxies,initial_q,q0,target,generation,seed,budget=14.0,representation="ellipsoid"):
    started=time.perf_counter();oracle=None;result=dict(generation=int(generation),seed=int(seed),status='no_goal',q_start=np.asarray(q0).tolist())
    try:
        oracle=OnlineOracle(model,robot,proxies,initial_q,representation=representation);oracle.deadline=started+budget
        target=np.asarray(target);q0=np.asarray(q0);rng=np.random.default_rng(seed);best=None;attempts=[]
        anchor=q0.copy()
        for attempt in range(3):
            seedq=anchor if attempt<2 else np.clip(anchor+rng.normal(0,.10,6),oracle.lower,oracle.upper)
            def eq(x):return oracle.evaluate(x[:6])[0]-target
            def eqj(x):return np.c_[oracle.evaluate(x[:6])[1],np.zeros(3)]
            def con(x):
                ee,ej,g,gj,w,wj=oracle.evaluate(x[:6]);error=ee-target;return np.r_[g-x[6],w,.0007-np.linalg.norm(error)]
            def conj(x):
                ee,ej,g,gj,w,wj=oracle.evaluate(x[:6]);error=ee-target;goalrow=-(error/max(np.linalg.norm(error),1e-12))@ej;return np.vstack([np.c_[gj,-np.ones(len(g))],np.c_[wj,np.zeros(len(w))],np.r_[goalrow,0.]])
            def objective(x):return -x[6]+1e-6*np.sum((x[:6]-q0)**2)
            def objj(x):return np.r_[2e-6*(x[:6]-q0),-1.]
            r=minimize(objective,np.r_[seedq,.0061],jac=objj,method='SLSQP',bounds=list(zip(oracle.lower,oracle.upper))+[(.0066,.012)],constraints=[dict(type='ineq',fun=con,jac=conj)],options=dict(maxiter=200,ftol=1e-10))
            anchor=r.x[:6];error=float(np.linalg.norm(oracle.gripper_position(anchor)-target));slack=oracle.exact_clearance(anchor)
            attempts.append(dict(iterations=int(r.nit),message=str(r.message),error_m=error,slack_m=slack))
            if error<.0008 and slack>=0:best=anchor.copy();break
        result['attempts']=attempts
        if best is None:return result
        result['goal']=best.tolist();result['goal_slack_m']=oracle.exact_clearance(best)
        oracle.margin=.006001  # route feasibility uses the unchanged 6mm requirement, not extra goal comfort
        if not oracle.free(q0):result['status']='start_outside_margin';return result
        if oracle.segment_free(q0,best):path=[q0,best]
        else:
            path=rrt_connect(oracle,q0,best,rng,iterations=1500,margin=.5)
            if path is None:result['status']='no_route';return result
        chain=list(densify(path,step=.04))[1:]
        result.update(status='path',path=[q.tolist() for q in chain])
        return result
    except SearchDeadline:
        result['status']='budget_exhausted';return result
    except Exception as e:
        import traceback
        result.update(status='error',error=repr(e),traceback=traceback.format_exc());return result
    finally:
        result['seconds']=time.perf_counter()-started
        if oracle is not None:result['checks']=oracle.checks;oracle.close()
