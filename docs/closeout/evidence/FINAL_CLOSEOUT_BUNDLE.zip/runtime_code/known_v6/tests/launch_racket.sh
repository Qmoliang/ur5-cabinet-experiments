#!/bin/bash
# Known-map benchmark at 5 mm: scenes (ours + IRIS-ZO tasks) x LiuQP / NEO-matched / NEO-paper x
# sphere / ellipsoid x straight / geodesic x 20 start poses; then the racket batch.
# 40 workers x 2 CPUs (CPUs 0-79).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
B=$PWD/bench; R=$PWD/racket
SCENES=""
jobs=()
for seed in $(seq 1 20); do
  for scene in $SCENES; do
    for ctl in liuqp neo_matched neo_paper; do
      for rep in ellipsoid sphere; do
        [ $scene = exit ] && [ $rep = sphere ] && continue  # spheres cannot start inside the drawer
        for attr in straight geodesic_native; do jobs+=("$B/$ctl $scene $rep $attr $seed UR5_CONTROLLER=$ctl"); done
      done
    done
  done
done
for seed in $(seq 1 20); do
  for scene in drawer cage_wide; do
    for ctl in liuqp neo_matched neo_paper; do
      for rep in ellipsoid sphere; do
        for speed in 0.15 0.25 0.5; do
          jobs+=("$R/${ctl}_v$speed $scene $rep geodesic_native $seed UR5_CONTROLLER=$ctl UR5_RACKET=1 UR5_RACKET_DIR=0,-1,0 UR5_RACKET_TRIGGER=1.0 UR5_RACKET_SPEED=$speed")
        done
      done
    done
  done
done
echo "${#jobs[@]} jobs" > $R.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 40)); do
    set -- ${jobs[$i]}
    out=$1; scene=$2; rep=$3; attr=$4; seed=$5; shift 5
    id=${scene}_${rep}_${attr}_seed$(printf "%02d" $seed)
    [ -f $out/$id/summary.json ] && continue
    ./known_job.sh $out $scene $rep $attr $seed $((w * 2)) "$@"
  done
}
for w in $(seq 0 39); do worker $w & done
wait
echo DONE > $R.done
