from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;j=json.loads((R/'uncached_jobs.json').read_text())[0];j.pop('latency_cycle_file');j.update(name='old_full_refresh_zero_delay',compute_delay=False,wall_limit_s=3600)
(R/'combined_diagnostic_jobs.json').write_text(json.dumps([j],indent=2));(R/'COMBINED_DIAGNOSTIC_FREEZE.json').write_text(json.dumps(dict(job=j,scope='complete two-factor diagnosis: original objective and terminal feedback, no witness cache, zero compute delay; 300s motion horizon, separate 3600s compute budget; not a deployable real-time claim',sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['diagnostic_uncached_policy.py','pilot_worker_diagnostic.py']}),indent=2))
