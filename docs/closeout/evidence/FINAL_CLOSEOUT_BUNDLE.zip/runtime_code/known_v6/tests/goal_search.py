"""Search for a goal pose that is clear of the cover: gripper on the target and every
robot sphere pushed out to the 6 mm margin (soft residuals), then verified with
the exact checker.  Reports the best verified clearance per scene variant.
"""
import sys

sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/feasibility.py").read().split("variants = []")[0])
from scipy.optimize import least_squares  # noqa: E402
from scipy.spatial import cKDTree  # noqa: E402


def search(payload, rep, attempts=120, seed=0):
    scene = scene_of(payload)
    model = build_model(scene)
    robot = build_robot_certificate(model)
    radii = np.array([s.radius for s in robot])
    target = np.asarray(scene.waypoints[-1])
    cover = build_volume_cover(scene.boxes, rep, 0.075)
    index = NativeBallTree(cover.centers, cover.aabb_half_extents, query_padding=float(radii.max() + 0.06))
    checker = ConfigurationChecker(model, robot, cover.centers, rep, radii=cover.sphere_radii,
                                   shapes=cover.ellipsoid_shapes, margin=MARGIN, index=index)
    # dense samples of the cover (boundary + interior) for a smooth push-out residual
    u = np.random.default_rng(0).normal(size=(600, 3))
    u /= np.linalg.norm(u, axis=1, keepdims=True)
    shells = [0.4, 0.8, 1.0]
    pts = []
    for c, S, r in zip(cover.centers, cover.ellipsoid_shapes, cover.sphere_radii):
        root = np.sqrt(np.maximum(np.diag(S), 0)) if rep == "ellipsoid" else np.full(3, r)
        for k in shells:
            pts.append(c + k * u * root)
    tree = cKDTree(np.concatenate(pts))
    need = radii + MARGIN + 0.004

    def residual(q):
        p = checker.sphere_positions(q)
        d = tree.query(p)[0]
        return np.concatenate([1000.0 * (checker.gripper_position(q) - target), np.maximum(0.0, need - d) * 30.0])

    rng = np.random.default_rng(seed)
    best, best_q = -np.inf, None
    for _ in range(attempts):
        q = rng.uniform(np.maximum(checker.lower, -2 * np.pi), np.minimum(checker.upper, 2 * np.pi))
        r = least_squares(residual, q, bounds=(checker.lower, checker.upper), max_nfev=400)
        # Stage 2: put the gripper exactly on the target, staying near stage 1.
        anchor = r.x
        r = least_squares(lambda x: np.concatenate([checker.gripper_position(x) - target, 1e-3 * (x - anchor)]),
                          anchor, bounds=(checker.lower, checker.upper), xtol=1e-12, ftol=1e-12)
        if np.linalg.norm(checker.gripper_position(r.x) - target) > 2e-4:
            continue
        c = checker.clearance(r.x)
        if not np.isfinite(c):
            c = -1.0 + np.min(tree.query(checker.sphere_positions(r.x))[0] - radii - MARGIN)
        if c > best:
            best, best_q = c, r.x
        if best >= 0:
            break
    index.close()
    return best, best_q


if __name__ == "__main__":
    cases = [("bin 30 cm, 10 cm deep", make_scenes.bin_scene(0.66, 0.35, 0.256, 0.30, 0.10)),
             ("bin 40 cm, 15 cm deep", make_scenes.bin_scene(0.60, 0.30, 0.206, 0.40, 0.15))]
    for top in (0.55, 0.65):
        for depth in (0.05, 0.10, 0.15):
            cases.append((f"wall top {top*100:.0f} cm, target {depth*100:.0f} cm below top",
                          make_scenes.wall_scene(top, depth)))
    for label, payload in cases:
        for rep in ("ellipsoid", "sphere"):
            best, q = search(payload, rep)
            print(f"{label}, {rep}: best verified "
                  f"clearance {1000*best:.1f} mm ({'FREE' if best >= 0 else 'blocked'}) q={None if q is None else q.round(2).tolist()}",
                  flush=True)
