import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy_activated import LowDimPolicy as Original
from reheading_policy import LowDimPolicy as Reheading

folder=ROOT/'trials/reference_failed_schedule';state=json.loads((folder/'failed_heading_state.json').read_text());job=json.loads((folder/'job.json').read_text());q=np.array(state['q']);previous=np.array(state['previous'])
ctx=build('iris_4shelves_t2',start=q,previous=previous);c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
out=[]
for label,cls in [('transported_memory',Original),('target_reanchoring',Reheading)]:
    p=cls(ctx,job,lambda **kw:None);p.observe(state['cycle'],q,previous);p.mode=state['mode'];p.blocker_id=tuple(state['blocker_id']);p.circulation_tangent=np.array(state['stored_tangent']);p.reverse_used=state['reverse_used'];p.feature_last_progress=state['feature_last_progress'];p.pending_memory=state['pending_memory'];p.memories=state['memories']
    geometry=p._geometry();answer=p._surface_action(c,c.pilot_nominal,c.last_qp_arrays,geometry)
    r=dict(method=label,certified_action=answer is not None,actual_stored_tangent=state['stored_tangent'],cycle=state['cycle'])
    if answer is not None:
        r.update(new_tangent=answer[1].tolist(),velocity=answer[0][1][0].tolist(),safe_scale=answer[0][1][1],reheading_proposal=getattr(p,'pending_reheading',None))
    out.append(r)
assert not out[0]['certified_action'] and out[1]['certified_action']
(ROOT/'HEADING_STATE_REPLAY.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
