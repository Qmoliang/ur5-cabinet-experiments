#!/bin/bash
# Redesigned wall (wall2): sphere/ellipsoid x straight / geodesic / geodesic + whole arm, 20 start poses.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
jobs=()
for seed in $(seq 1 20); do
  for rep in ellipsoid sphere; do
    jobs+=("scenes $rep straight $seed none" "scenes $rep geodesic_native $seed none" "scenes_wholearm $rep geodesic_native $seed whole")
  done
done
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 40)); do
    set -- ${jobs[$i]}
    extra=""; [ $5 = whole ] && extra="UR5_WHOLE_ARM=1"
    ./known_job.sh $PWD/$1 wall2 $2 $3 $4 $((w * 2)) $extra
  done
}
for w in $(seq 0 39); do worker $w & done
wait
echo DONE > $PWD/WALL2_DONE
