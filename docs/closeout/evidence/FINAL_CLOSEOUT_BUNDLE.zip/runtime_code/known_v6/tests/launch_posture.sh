#!/bin/bash
# Wall scene: weak goal-posture term (UR5_POSTURE_GOAL), ellipsoid, 20 start poses.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
GOAL=/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/assets/scenes/wall_goal_ellipsoid.npy
jobs=()
for seed in $(seq 1 20); do
  jobs+=("geodesic_native 0.02 $seed" "geodesic_native 0.1 $seed" "straight 0.02 $seed")
done
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 30)); do
    set -- ${jobs[$i]}
    ./known_job.sh $PWD/scenes_posture_w$2 wall ellipsoid $1 $3 $((w * 2)) UR5_POSTURE_GOAL=$GOAL UR5_POSTURE_WEIGHT=$2
  done
}
for w in $(seq 0 29); do worker $w & done
wait
echo DONE > $PWD/POSTURE_DONE
