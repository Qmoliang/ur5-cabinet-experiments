"""At one online final pose: each robot sphere's gap to the online map vs to the known-cabinet cover.

Usage: pose_gaps.py FROZEN_MAP.pkl CASE_DIR KNOWN_PROXIES.npz
LiuQP keeps every gap >= the 6 mm safety margin; a sphere near 6 mm online but
far from it on the known cover is held only by online certificate thickness.
"""
import pickle
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
import run_protocol_v3_async_online as online  # noqa: E402
import mujoco  # noqa: E402

stored = pickle.load(open(sys.argv[1], "rb"))
proxies, frontier = stored["proxies"], stored["frontier_cells"]
keep = len(proxies.centers) - frontier
online_c, online_s = np.asarray(proxies.centers)[:keep], np.asarray(proxies.ellipsoid_outer_shapes)[:keep]
known = np.load(sys.argv[3])
known_c, known_s = known["centers"], known["ellipsoid_shapes"]
u = np.random.default_rng(0).normal(size=(2000, 3))
u /= np.linalg.norm(u, axis=1, keepdims=True)


def samples(c, S):
    w, v = np.linalg.eigh(S)
    return c + u @ (v @ np.diag(np.sqrt(np.maximum(w, 0))) @ v.T).T


online_pts = np.concatenate([samples(c, S) for c, S in zip(online_c, online_s)])
known_pts = np.concatenate([samples(c, S) for c, S in zip(known_c, known_s)])
scene = online._protocol_scene("camera_quarter")
model = online.build_model(scene)
data = mujoco.MjData(model)
robot = online.build_robot_certificate(model)
case = Path(sys.argv[2])
run = next(p for p in case.iterdir() if p.is_dir())
online.set_configuration(model, data, np.load(run / "q_history.npy")[-1])
positions = online.certificate_world_positions(data, robot)
radii = np.array([s.radius for s in robot])
from scipy.spatial import cKDTree  # noqa: E402
g_online = cKDTree(online_pts).query(positions)[0] - radii
g_known = cKDTree(known_pts).query(positions)[0] - radii
print(f"{case.name}: spheres within 10 mm of the online map (approximate boundary-sample gaps):")
for i in np.argsort(g_online)[:6]:
    print(f"  sphere {i:2d}: online map {1000*g_online[i]:5.1f} mm, known cover {1000*g_known[i]:5.1f} mm")
