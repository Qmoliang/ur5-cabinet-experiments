"""v4: spatial blocker typing and the specified near/far normal-cap hysteresis."""
import numpy as np
from lowdim_policy_v3 import LowDimPolicy as Previous
from lowdim_policy import unit,PARAMETERS

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.normal_cap_active=False;self.blocker_gap=float('inf');self.spatial_frame_updates=0

    def _frame(self,ctl,s,H,A,force=False):
        J=s['J'];weights=np.abs(s['y'])*np.linalg.norm(A,axis=1)
        spatial=[i for i,rid in enumerate(s['row_ids']) if rid[0] in ('collision','self','frontier','workspace')]
        if not spatial or max(weights[i] for i in spatial)<1e-6:
            self.normal_cap_active=False;self.blocker_gap=float('inf')
            if self.n is not None and not force:return
            new=unit(s['desired']);new=np.array([1.,0,0]) if new is None else new;rid=('no_active_spatial_blocker',-1,-1)
        else:
            i=max(spatial,key=lambda k:weights[k]);rid=tuple(s['row_ids'][i])
            old=next((j for j in spatial if tuple(s['row_ids'][j])==self.blocker),None)
            if old is not None and rid!=self.blocker and not force:
                if weights[i]<2*weights[old]:i=old
                else:
                    if self.pending_blocker!=rid:self.pending_blocker=rid;self.pending_blocker_since=self.k
                    if self.k-self.pending_blocker_since<10:i=old
            rid=tuple(s['row_ids'][i]);a=A[i]*(1 if s['y'][i]>=0 else -1)
            W=np.linalg.solve(H,J.T);L=W@np.linalg.pinv(J@W,rcond=1e-8);new=unit(L.T@a)
            if new is None:new=unit(s['desired'])
            if new is None:new=np.array([1.,0,0])
            l,u=ctl.last_qp_arrays[3:];self.blocker_gap=float(u[i]*ctl.dt) if np.isfinite(u[i]) else float('inf')
            if self.blocker_gap<.002:self.normal_cap_active=True
            elif self.blocker_gap>.004:self.normal_cap_active=False
        self.spatial_frame_updates+=1
        if self.n is not None and not force:
            cosine=float(np.clip(self.n@new,-1,1))
            if cosine<np.cos(np.pi/6) and np.max(np.abs(self.previous))>1e-8:self.brake_pending=True
            if cosine>-.99:
                axis=np.cross(self.n,new);t=self.t+np.cross(axis,self.t)+np.cross(axis,np.cross(axis,self.t))/(1+cosine)
                self.t=unit(t-new*(new@t));self.n=new;self.blocker=rid;return
        basis=np.eye(3)[np.argmin(np.abs(new))];base=unit(basis-new*(new@basis));angle=(self.trial//2)*np.pi/3;sign=1 if self.trial%2==0 else -1
        self.n=new;self.t=sign*(np.cos(angle)*base+np.sin(angle)*np.cross(new,base));self.blocker=rid
        self.emit('plane_selected',trial=self.trial,normal=self.n.tolist(),tangent=self.t.tolist(),blocker=rid,spatial_only=True,normal_cap_active=self.normal_cap_active,blocker_gap_m=self.blocker_gap)

    def _task(self,ctl,s,H,g,A,l,u,allow_retreat=True):
        J=s['J'];omega=ctl.task_weight
        directions=[(-self.n,'retreat'),(self.t,'tangent')] if self.k<self.retreat_until else [(self.t,'tangent'),(-self.n,'retreat')]
        if not allow_retreat:directions=[(self.t,'tangent')]
        for direction,role in directions:
            row=direction@J
            for cap in ([0.,.01,None] if self.normal_cap_active else [None]):
                normal=self.n@J;extra=[] if cap is None else [(normal,cap)]
                support=self._lp(row,A,l,u,extra)
                if support is None or support[0]<2*PARAMETERS['task_rate_floor']:continue
                rate=min(.5*support[0],PARAMETERS['task_rate_cap'])
                for _ in range(6):
                    if rate<PARAMETERS['task_rate_floor']:break
                    rows=[-row]+([] if cap is None else [normal]);bb=[-rate]+([] if cap is None else [cap])
                    result=self._qp(H,g,A,l,u,rows,bb)
                    if result is not None:
                        v,delta,eta,lam=result;coeff=-max(0.,lam[0])*direction+(0 if cap is None else max(0.,lam[1]))*self.n
                        if self._accept(v,delta,s['desired']-coeff/omega):
                            if role=='retreat' and self.k>=self.retreat_until:self.retreat_until=self.k+50;self.emit('retreat_phase',rate=rate)
                            return delta
                    rate*=.5
        return None

    def summary(self):
        report=super().summary();report.update(integration_revision='v4_spatial_blockers_and_near_far_cap',spatial_frame_updates=self.spatial_frame_updates,normal_cap_active=self.normal_cap_active)
        return report
