from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
p=ROOT/'verified_qp.py';s=p.read_text().replace('settings.max_iter=200','settings.max_iter=300').replace('settings.tol_gap_abs=1e-10;settings.tol_gap_rel=1e-10;settings.tol_feas=1e-10','settings.tol_gap_abs=1e-12;settings.tol_gap_rel=1e-12;settings.tol_feas=1e-12');p.write_text(s)
p=ROOT/'certified_auxiliary.py';s=p.read_text();old='    if primal>1e-7 or relative>1e-7 or comp>1e-7*(1+abs(obj)) or gap>1e-7*(1+abs(obj)) or eigen<=0:'
new='''    gap_certificate=(primal<=1e-12 and comp<=.5*max(eigen,0)*1e-10 and abs(gap)<=.5*max(eigen,0)*1e-10)
    stationarity_ok=relative<=1e-7 or gap_certificate
    if primal>1e-7 or not stationarity_ok or comp>1e-7*(1+abs(obj)) or gap>1e-8*(1+abs(obj)) or eigen<=0:'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='reserve_v3':";new="        if job.get('policy_version')=='viability':\n            from viability_policy import LowDimPolicy\n        elif job.get('policy_version')=='reserve_v3':";assert old in s;s=s.replace(old,new);p.write_text(s)
common=dict(task='iris_4shelves_t2',method='release',policy_version='viability',certified_auxiliary=True,representation='ellipsoid',solver_profile='verified_common',max_cycles=15000,stop_after_stall=False,wall_limit_s=900,operating_gate=True)
jobs=[]
for name,joint,spatial,release in [('contract_only',False,False,False),('joint_contract',True,False,True),('joint_spatial_contract',True,True,True),('joint_spatial_from_stall',True,True,True)]:
    job=dict(common,name=name,joint_metric=joint,spatial_metric=spatial,targeted_release=release)
    if name.endswith('from_stall'):job['start_snapshot']=str(ROOT.parent/'liuqp_lowdim_pilot_20261106/confirm_original_shelf_t2_baseline_300s_final_snapshot.npz')
    jobs.append(job)
(ROOT/'contract_jobs.json').write_text(json.dumps(jobs,indent=2))
files=list(ROOT.glob('*.py'))+[ROOT/'contract_jobs.json',ROOT/'INPUTS.json',ROOT/'code/online/protocol_liuqp_controller.py',ROOT/'code/common/policy.json']
(ROOT/'CONTRACT_STUDY_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},change='joint/spatial one-sided consumption cost; original deterministic stopping certificate repairs current velocity only; stronger nominal-margin gate after feasible activation',no_scene_change=True,no_path_or_waypoint=True,no_safety_relaxation=True),indent=2))
print(json.dumps(jobs))
