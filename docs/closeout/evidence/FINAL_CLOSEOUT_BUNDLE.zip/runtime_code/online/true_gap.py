"""At a run's final pose: true distance of each robot sphere to the real cabinet boxes.

The controller keeps every robot sphere SAFETY_MARGIN (6 mm) from the certified
obstacles; anything beyond that in the true gap is certificate thickness.
"""
import csv
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
import run_protocol_v3_async_online as online  # noqa: E402
import mujoco  # noqa: E402

scene = online._protocol_scene("camera_quarter")
model = online.build_model(scene)
data = mujoco.MjData(model)
robot = online.build_robot_certificate(model)
radii = np.array([s.radius for s in robot])
lo = np.array([np.asarray(b.center) - np.asarray(b.half_size) for b in scene.boxes])
hi = np.array([np.asarray(b.center) + np.asarray(b.half_size) for b in scene.boxes])
for case in sys.argv[1:]:
    run = Path(case) if (Path(case) / "q_history.npy").exists() else next(p for p in Path(case).iterdir() if p.is_dir())
    q = np.load(run / "q_history.npy")[-1]
    online.set_configuration(model, data, q)
    centres = online.certificate_world_positions(data, robot)
    # point-to-box distance for every sphere and box
    d = np.linalg.norm(np.maximum(0, np.maximum(lo[None] - centres[:, None], centres[:, None] - hi[None])), axis=2)
    gaps = d.min(axis=1) - radii
    nearest = np.argsort(gaps)[:4]
    last = list(csv.DictReader(open(run / "cycles.csv")))[-1]
    print(f"{Path(case).parent.name}/{Path(case).name}: err {1000*float(last['error_m']):.1f} mm, limiting sphere "
          f"{last['limiting_robot_index']}; tightest true gaps (sphere: mm to real cabinet): "
          + ", ".join(f"{i}: {1000*gaps[i]:.1f}" for i in nearest) + f"; limiting sphere true gap {1000*gaps[int(float(last['limiting_robot_index']))]:.1f} mm")
