from pathlib import Path
import json,hashlib,shutil,ast
ROOT=Path(__file__).resolve().parent
source=(ROOT/'goal_entry_policy.py').read_text();tree=ast.parse(source);cls=next(x for x in tree.body if isinstance(x,ast.ClassDef))
def method(name):return '    '+ast.get_source_segment(source,next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name==name))+'\n'
solve=method('_solve');call=method('__call__').replace("if key[0] not in ('collision','frontier'):","if key[0] not in ('collision','frontier','self','workspace'):").replace("toward=self.goal_points[self.blocker_id[1]]-point","toward=self._goal_point_for_blocker()-point")
prefix='''import numpy as np,mujoco
from goal_entry_policy import LowDimPolicy as Previous,JointControl
from piecewise_reserve import solve_reserve
from verified_qp import solve_verified,_solve_slsqp
from certified_auxiliary import verify_solution

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.feature_best=float('inf');self.feature_last_progress=0;self.feature_mode=None
    def observe(self,k,q,previous):
        super().observe(k,q,previous);distance=float(np.linalg.norm(self.feature(q)-self.goal_feature))
        if self.mode!=self.feature_mode:
            self.feature_mode=self.mode;self.feature_best=distance;self.feature_last_progress=k
        elif distance<self.feature_best-.0002:
            self.feature_best=distance;self.feature_last_progress=k
    def _select_blocker(self,s,arrays,nominal):
        if self.k-self.feature_last_progress<100 or self.error<.002:return None
        H,g,A,l,u=arrays;y=nominal.get('original_dual')
        if y is None:
            HH,gg=self._terms(self.ctx.controller,s);shadow=solve_verified(H+HH,g+gg,A,l,u)
            y=s['y'] if shadow is None else shadow.y
        options=[]
        for i,row in enumerate(s['row_ids']):
            if row[0] not in ('collision','frontier','self','workspace'):continue
            norm=np.linalg.norm(A[i]);force=max(0.,float(y[i]))*norm
            if norm<1e-10 or not np.isfinite(u[i]) or self.dt*u[i]>.0005 or force<=1e-6:continue
            key=tuple(row);prior=self.blocker_best.get(key)
            # The full method's no-return certificates carry the persistent
            # memory; a Cartesian-only tabu must not veto posture progress.
            if not self.memory_enabled and prior is not None and .5*self.error**2>=prior-1e-8:continue
            options.append((force,i,key))
        return max(options,key=lambda item:item[0]) if options else None
    def _geometry(self):
        kind,i,j=self.blocker_id
        if kind in ('collision','frontier'):return super()._geometry()
        guard=self.ctx.guard;points=guard.positions(self.q).copy();mujoco.mj_comPos(guard.model,guard.data)
        def jac(index):
            J=np.zeros((3,guard.model.nv));mujoco.mj_jac(guard.model,guard.data,J,None,points[index],int(guard.bodies[index]));return J[:,:6]
        if kind=='self':
            point=points[j]-points[i];length=float(np.linalg.norm(point));return point,point/max(length,1e-12),jac(j)-jac(i),length-guard.radii[i]-guard.radii[j]
        if kind=='workspace':
            axis=j%3;n=np.eye(3)[axis]*(1 if j<3 else -1);gap=points[i,axis]-guard.workspace_lower[axis]-guard.radii[i] if j<3 else guard.workspace_upper[axis]-points[i,axis]-guard.radii[i]
            return points[i],n,jac(i),float(gap)
        return None
    def _goal_point_for_blocker(self):
        kind,i,j=self.blocker_id
        return self.goal_points[j]-self.goal_points[i] if kind=='self' else self.goal_points[i]
'''
suffix='''    def summary(self):
        out=super().summary();out.update(reserve_solver='six-variable convex piecewise quadratic with certified stationarity; same one-sided objective',stall_metric='actual 3+2 goal feature progress',blocker_dual='effective new goal-entry objective, not the original Cartesian-only objective')
        return out
'''
(ROOT/'goal_entry_policy_v2.py').write_text(prefix+solve+call+suffix);compile(prefix+solve+call+suffix,'goal_entry_policy_v2.py','exec')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='goal_entry':";new="        if job.get('policy_version')=='goal_entry_v2':\n            from goal_entry_policy_v2 import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'entry_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('entry_','entry_v2_',1);j['policy_version']='goal_entry_v2'
(ROOT/'entry_v2_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_v2';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'ENTRY_V2_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},changes=['algebraically eliminate reserve epigraph variables; retain identical convex cost and constraints','diagnose active blockers using the goal-entry objective duals','measure actual low-dimensional feature progress including target posture; support self/workspace geometric rows'],no_safety_relaxation=True,no_route=True),indent=2))
print(json.dumps(jobs))
