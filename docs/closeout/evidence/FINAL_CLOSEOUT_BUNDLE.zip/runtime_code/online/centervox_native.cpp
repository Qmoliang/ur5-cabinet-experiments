// Native kernels for the online CenterVox manager (incremental_proxy_manager.py).
//
// cv_containment: lambda_max(outer^-1/2 inner outer^-1/2) per row by the same
//   closed-form 3x3 Cholesky + analytic eigenvalue formula as the Python
//   _batch_containment_values; rows the Python code would hand to the exact
//   eigensolver are flagged (needs_exact = 1) and recomputed there, so every
//   containment decision is made by the same rule.
// cv_frame_uncertainty: the frame-local CenterVox U of the legacy Q+U path:
//   translated_i = minkowski_outer(U_i, d_i d_i^T) (trace-balanced Young bound),
//   then per group a common-frame diagonal-dominance Loewner bound.  Any
//   orthonormal frame gives a valid bound; the frame here comes from a 3x3
//   Jacobi eigensolver instead of LAPACK, so values agree to rounding only and
//   the caller still checks containment of every member.
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <vector>

extern "C" {

static inline double sq(double x) { return x * x; }

static void jacobi3(const double a_in[9], double values[3], double vectors[9]) {
  double a[9];
  std::memcpy(a, a_in, sizeof(a));
  double v[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  for (int sweep = 0; sweep < 50; ++sweep) {
    double off = sq(a[1]) + sq(a[2]) + sq(a[5]);
    if (off < 1e-300) break;
    for (int p = 0; p < 2; ++p) {
      for (int q = p + 1; q < 3; ++q) {
        double apq = a[3 * p + q];
        if (std::fabs(apq) < 1e-300) continue;
        double app = a[3 * p + p], aqq = a[3 * q + q];
        double theta = (aqq - app) / (2.0 * apq);
        double t = (theta >= 0 ? 1.0 : -1.0) / (std::fabs(theta) + std::sqrt(theta * theta + 1.0));
        double c = 1.0 / std::sqrt(t * t + 1.0), s = t * c;
        for (int k = 0; k < 3; ++k) {  // A <- A J (columns p, q)
          double akp = a[3 * k + p], akq = a[3 * k + q];
          a[3 * k + p] = c * akp - s * akq;
          a[3 * k + q] = s * akp + c * akq;
        }
        for (int k = 0; k < 3; ++k) {  // A <- J^T A (rows p, q)
          double apk = a[3 * p + k], aqk = a[3 * q + k];
          a[3 * p + k] = c * apk - s * aqk;
          a[3 * q + k] = s * apk + c * aqk;
        }
        for (int k = 0; k < 3; ++k) {  // V <- V J
          double vkp = v[3 * k + p], vkq = v[3 * k + q];
          v[3 * k + p] = c * vkp - s * vkq;
          v[3 * k + q] = s * vkp + c * vkq;
        }
      }
    }
  }
  for (int i = 0; i < 3; ++i) values[i] = a[4 * i];
  std::memcpy(vectors, v, sizeof(v));  // columns are eigenvectors
}

int32_t cv_containment(int64_t n, const double* inner, const double* outer, double* values,
                       uint8_t* needs_exact) {
#pragma omp parallel for schedule(static)
  for (int64_t r = 0; r < n; ++r) {
    const double* A = outer + 9 * r;
    const double* B = inner + 9 * r;
    double a00 = A[0], a10 = 0.5 * (A[3] + A[1]), a20 = 0.5 * (A[6] + A[2]);
    double a11 = A[4], a21 = 0.5 * (A[7] + A[5]), a22 = A[8];
    double l00 = std::sqrt(a00);
    double l10 = a10 / l00, l20 = a20 / l00;
    double l11 = std::sqrt(a11 - l10 * l10);
    double l21 = (a21 - l20 * l10) / l11;
    double l22 = std::sqrt(a22 - l20 * l20 - l21 * l21);
    double inv[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    inv[0] = 1.0 / l00;
    inv[4] = 1.0 / l11;
    inv[8] = 1.0 / l22;
    inv[3] = -l10 / (l00 * l11);
    inv[7] = -l21 / (l11 * l22);
    inv[6] = (l10 * l21 - l11 * l20) / (l00 * l11 * l22);
    double s[9];
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) s[3 * i + j] = 0.5 * (B[3 * i + j] + B[3 * j + i]);
    double t[9], m[9];
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) {
        double acc = 0;
        for (int k = 0; k < 3; ++k) acc += inv[3 * i + k] * s[3 * k + j];
        t[3 * i + j] = acc;
      }
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) {
        double acc = 0;
        for (int k = 0; k < 3; ++k) acc += t[3 * i + k] * inv[3 * j + k];
        m[3 * i + j] = acc;
      }
    for (int i = 0; i < 3; ++i)
      for (int j = i + 1; j < 3; ++j) {
        double sym = 0.5 * (m[3 * i + j] + m[3 * j + i]);
        m[3 * i + j] = m[3 * j + i] = sym;
      }
    double q = (m[0] + m[4] + m[8]) / 3.0;
    double p1 = sq(m[1]) + sq(m[2]) + sq(m[5]);
    double p2 = sq(m[0] - q) + sq(m[4] - q) + sq(m[8] - q) + 2.0 * p1;
    double p = std::sqrt(p2 / 6.0);
    double value;
    if (p > 0.0) {
      double b00 = (m[0] - q) / p, b11 = (m[4] - q) / p, b22 = (m[8] - q) / p;
      double b01 = m[1] / p, b02 = m[2] / p, b12 = m[5] / p;
      double det = b00 * (b11 * b22 - b12 * b12) - b01 * (b01 * b22 - b12 * b02) + b02 * (b01 * b12 - b11 * b02);
      double half = 0.5 * det;
      half = half < -1.0 ? -1.0 : (half > 1.0 ? 1.0 : half);
      double phi = std::acos(half) / 3.0;
      value = q + 2.0 * p * std::cos(phi);
    } else {
      value = q;
    }
    values[r] = value;
    bool exact = !std::isfinite(value) || std::fabs(value - 1.0) <= 1.0e-6 || !std::isfinite(l00) ||
                 !std::isfinite(l11) || !std::isfinite(l22) || l00 <= 0.0 || l11 <= 0.0 || l22 <= 0.0;
    needs_exact[r] = exact ? 1 : 0;
  }
  return 0;
}

int32_t cv_frame_uncertainty(int64_t n, int64_t groups, const double* shapes, const double* displacements,
                             const int64_t* group_of, double* translated, double* frame_out) {
  // translated = minkowski_outer(sym(U), d d^T)
#pragma omp parallel for schedule(static)
  for (int64_t r = 0; r < n; ++r) {
    const double* U = shapes + 9 * r;
    const double* d = displacements + 3 * r;
    double first[9], second[9];
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) {
        first[3 * i + j] = 0.5 * (U[3 * i + j] + U[3 * j + i]);
        second[3 * i + j] = d[i] * d[j];
      }
    double ft = std::fmax(first[0] + first[4] + first[8], 1.0e-18);
    double st = std::fmax(second[0] + second[4] + second[8], 1.0e-18);
    double beta = std::sqrt(st / ft);
    double* T = translated + 9 * r;
    for (int k = 0; k < 9; ++k) T[k] = (1.0 + beta) * first[k] + (1.0 + 1.0 / beta) * second[k];
  }
  // group mean of sym(translated) and a Jacobi frame per group
  std::vector<double> mean(9 * groups, 0.0);
  std::vector<int64_t> count(groups, 0);
  for (int64_t r = 0; r < n; ++r) {
    int64_t g = group_of[r];
    const double* T = translated + 9 * r;
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) mean[9 * g + 3 * i + j] += 0.5 * (T[3 * i + j] + T[3 * j + i]);
    count[g] += 1;
  }
  std::vector<double> frames(9 * groups);
#pragma omp parallel for schedule(static)
  for (int64_t g = 0; g < groups; ++g) {
    double ref[9], values[3];
    for (int k = 0; k < 9; ++k) ref[k] = mean[9 * g + k] / (double)(count[g] > 0 ? count[g] : 1);
    jacobi3(ref, values, &frames[9 * g]);
  }
  // per-member diagonal-dominance row bounds in the group frame, max per group
  std::vector<double> bounds(3 * groups, 0.0);
  std::vector<double> rows(3 * n);
#pragma omp parallel for schedule(static)
  for (int64_t r = 0; r < n; ++r) {
    const double* F = &frames[9 * group_of[r]];  // columns are frame axes
    const double* T = translated + 9 * r;
    double S[9], tmp[9], B[9];
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) S[3 * i + j] = 0.5 * (T[3 * i + j] + T[3 * j + i]);
    for (int i = 0; i < 3; ++i)
      for (int l = 0; l < 3; ++l) {
        double acc = 0;
        for (int k = 0; k < 3; ++k) acc += S[3 * i + k] * F[3 * k + l];
        tmp[3 * i + l] = acc;
      }
    for (int i = 0; i < 3; ++i)
      for (int l = 0; l < 3; ++l) {
        double acc = 0;
        for (int j = 0; j < 3; ++j) acc += F[3 * j + i] * tmp[3 * j + l];
        B[3 * i + l] = acc;  // F^T S F
      }
    for (int i = 0; i < 3; ++i)
      rows[3 * r + i] = B[4 * i] + (std::fabs(B[3 * i]) + std::fabs(B[3 * i + 1]) + std::fabs(B[3 * i + 2]) -
                                    std::fabs(B[4 * i]));
  }
  for (int64_t r = 0; r < n; ++r) {
    int64_t g = group_of[r];
    for (int i = 0; i < 3; ++i) bounds[3 * g + i] = std::fmax(bounds[3 * g + i], rows[3 * r + i]);
  }
#pragma omp parallel for schedule(static)
  for (int64_t g = 0; g < groups; ++g) {
    double* b = &bounds[3 * g];
    double largest = std::fmax(std::fmax(std::fmax(b[0], b[1]), b[2]), 1.0e-18);
    for (int i = 0; i < 3; ++i) b[i] += largest * 2.0e-14 + 1.0e-18;
    const double* F = &frames[9 * g];
    double* out = frame_out + 9 * g;
    for (int i = 0; i < 3; ++i)
      for (int k = 0; k < 3; ++k) {
        double acc = 0;
        for (int j = 0; j < 3; ++j) acc += F[3 * i + j] * b[j] * F[3 * k + j];
        out[3 * i + k] = acc;
      }
  }
  return 0;
}

// Two-stage variant with the group frames supplied by the caller (LAPACK eigh
// of the group means, exactly as the Python construction):
//   cv_translate_mean: translated shapes and the group means of their sym part;
//   cv_bounds_in_frames: diagonal-dominance bounds in the given frames.
int32_t cv_translate_mean(int64_t n, int64_t groups, const double* shapes, const double* displacements,
                          const int64_t* group_of, double* translated, double* means) {
#pragma omp parallel for schedule(static)
  for (int64_t r = 0; r < n; ++r) {
    const double* U = shapes + 9 * r;
    const double* d = displacements + 3 * r;
    double first[9], second[9];
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) {
        first[3 * i + j] = 0.5 * (U[3 * i + j] + U[3 * j + i]);
        second[3 * i + j] = d[i] * d[j];
      }
    double ft = std::fmax(first[0] + first[4] + first[8], 1.0e-18);
    double st = std::fmax(second[0] + second[4] + second[8], 1.0e-18);
    double beta = std::sqrt(st / ft);
    double* T = translated + 9 * r;
    for (int k = 0; k < 9; ++k) T[k] = (1.0 + beta) * first[k] + (1.0 + 1.0 / beta) * second[k];
  }
  std::vector<int64_t> count(groups, 0);
  std::memset(means, 0, sizeof(double) * 9 * groups);
  for (int64_t r = 0; r < n; ++r) {
    int64_t g = group_of[r];
    const double* T = translated + 9 * r;
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) means[9 * g + 3 * i + j] += 0.5 * (T[3 * i + j] + T[3 * j + i]);
    count[g] += 1;
  }
  for (int64_t g = 0; g < groups; ++g)
    for (int k = 0; k < 9; ++k) means[9 * g + k] /= (double)(count[g] > 0 ? count[g] : 1);
  return 0;
}

int32_t cv_bounds_in_frames(int64_t n, int64_t groups, const double* translated, const int64_t* group_of,
                            const double* frames, double* frame_out) {
  std::vector<double> bounds(3 * groups, 0.0);
  std::vector<double> rows(3 * n);
#pragma omp parallel for schedule(static)
  for (int64_t r = 0; r < n; ++r) {
    const double* F = frames + 9 * group_of[r];  // columns are frame axes
    const double* T = translated + 9 * r;
    double S[9], tmp[9], B[9];
    for (int i = 0; i < 3; ++i)
      for (int j = 0; j < 3; ++j) S[3 * i + j] = 0.5 * (T[3 * i + j] + T[3 * j + i]);
    for (int i = 0; i < 3; ++i)
      for (int l = 0; l < 3; ++l) {
        double acc = 0;
        for (int k = 0; k < 3; ++k) acc += S[3 * i + k] * F[3 * k + l];
        tmp[3 * i + l] = acc;
      }
    for (int i = 0; i < 3; ++i)
      for (int l = 0; l < 3; ++l) {
        double acc = 0;
        for (int j = 0; j < 3; ++j) acc += F[3 * j + i] * tmp[3 * j + l];
        B[3 * i + l] = acc;
      }
    for (int i = 0; i < 3; ++i)
      rows[3 * r + i] = B[4 * i] + (std::fabs(B[3 * i]) + std::fabs(B[3 * i + 1]) + std::fabs(B[3 * i + 2]) -
                                    std::fabs(B[4 * i]));
  }
  for (int64_t r = 0; r < n; ++r) {
    int64_t g = group_of[r];
    for (int i = 0; i < 3; ++i) bounds[3 * g + i] = std::fmax(bounds[3 * g + i], rows[3 * r + i]);
  }
#pragma omp parallel for schedule(static)
  for (int64_t g = 0; g < groups; ++g) {
    double* b = &bounds[3 * g];
    double largest = std::fmax(std::fmax(std::fmax(b[0], b[1]), b[2]), 1.0e-18);
    for (int i = 0; i < 3; ++i) b[i] += largest * 2.0e-14 + 1.0e-18;
    const double* F = frames + 9 * g;
    double* out = frame_out + 9 * g;
    for (int i = 0; i < 3; ++i)
      for (int k = 0; k < 3; ++k) {
        double acc = 0;
        for (int j = 0; j < 3; ++j) acc += F[3 * i + j] * b[j] * F[3 * k + j];
        out[3 * i + k] = acc;
      }
  }
  return 0;
}

}  // extern "C"
