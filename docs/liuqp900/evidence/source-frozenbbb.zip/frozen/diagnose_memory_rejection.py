from pathlib import Path
import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build,online
from goal_plane_acceptance_policy import LowDimPolicy
R=ROOT;f=R/'trials/goal_plane_regression_end_2';j=json.loads((f/'job.json').read_text());z=np.load(j['start_snapshot']);q=z['q'];ctx=build(j['task'],start=q,previous=np.zeros(6));c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target);p=LowDimPolicy(ctx,j,lambda **kw:None);p.observe(0,q,np.zeros(6));p.mode='CERT_PREP';p.future_state=p.continuation_witnesses(q);a=p._solve(c,c.pilot_nominal,c.last_qp_arrays);v=np.clip(a['velocity'],*c.joint_velocity_bounds());rows=[]
for m in p.memories:
 value=p._value(m,q);gradient=p._gradient(m,c.pilot_nominal);C=np.linalg.norm(np.array(m['normal'])[:3])*p.site_curvature;end=p._value(m,q+.02*v)
 rows.append(dict(value=value,linear_predicted_value=value+.02*float(gradient@v),actual_next_value=end,curvature_remainder_bound=.5*C*.02**2*np.sum(np.abs(v))**2))
out=dict(q=q.tolist(),raw_velocity=v.tolist(),memory_safe=p.memory_safe(q,v),physical_braking_safe=ctx.guard.braking_safe(ctx.proxy_guard,q,v),memories=rows,l1_speed=float(np.sum(np.abs(v))))
(R/'MEMORY_REJECTION_DIAGNOSIS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
