#!/bin/bash
# Obstacle-side reduction (tree deletion, plane reuse) on the 20 start poses.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
COMMON="UR5_KNOWN_INDEX=ball_tree UR5_PYTHON_PLANES=1"
./launch_seeds.sh $PWD/r_tree       ellipsoid 0.075 64  $COMMON UR5_OBSTACLE_REDUCTION=tree &
./launch_seeds.sh $PWD/r_reuse      ellipsoid 0.075 84  $COMMON UR5_OBSTACLE_REDUCTION=reuse &
./launch_seeds.sh $PWD/r_treereuse  ellipsoid 0.075 104 $COMMON UR5_OBSTACLE_REDUCTION=tree+reuse &
wait
./launch_seeds.sh $PWD/r_geo_reuse  ellipsoid 0.075 64  $COMMON UR5_OBSTACLE_REDUCTION=reuse UR5_ATTRACTION=geodesic &
wait
# Isolated timing: seeds 1 (easy) and 2 (trapped), one run at a time on the same cores.
for seed in 1 2; do
  ./known_seed_one.sh $PWD/rt_reuse     ellipsoid 0.075 $seed 120 $COMMON UR5_OBSTACLE_REDUCTION=reuse
  ./known_seed_one.sh $PWD/rt_treereuse ellipsoid 0.075 $seed 120 $COMMON UR5_OBSTACLE_REDUCTION=tree+reuse
  ./known_seed_one.sh $PWD/rt_geo_reuse ellipsoid 0.075 $seed 120 $COMMON UR5_OBSTACLE_REDUCTION=reuse UR5_ATTRACTION=geodesic
done
echo DONE > $PWD/R_DONE
