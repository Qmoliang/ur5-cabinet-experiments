"""Summarize v6 online runs: outcome, map age and perception cost per case."""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import numpy as np


def load_case(case_dir: Path) -> dict:
    summary = json.loads((case_dir / "summary.json").read_text())
    config = json.loads((case_dir / "case.json").read_text())
    run_dir = next(path for path in case_dir.iterdir() if path.is_dir())
    with (run_dir / "cycles.csv").open() as handle:
        ages = np.asarray([float(row["snapshot_age_ms"]) for row in csv.DictReader(handle)])
    with (run_dir / "perception_frames.csv").open() as handle:
        frames = list(csv.DictReader(handle))[1:]  # first row is the initial map

    def column(name: str) -> np.ndarray:
        return np.asarray([float(row[name]) for row in frames if row.get(name) not in (None, "")])

    pipeline = column("frame_pipeline_ms") if frames and "frame_pipeline_ms" in frames[0] else column("proxy_update_ms")
    publish_age = column("publish_snapshot_age_ms")
    return {
        "case": case_dir.name,
        "representation": config["representation"],
        "map": config["map"],
        "timing": config["timing"],
        "success": summary.get("success"),
        "final_error_mm": 1000.0 * float(summary["final_error_m"]),
        "first_success_time_s": summary.get("first_success_time_s"),
        "published_maps": summary.get("published_perception_frames"),
        "map_age_p50_ms": float(np.percentile(ages, 50)),
        "map_age_p95_ms": float(np.percentile(ages, 95)),
        "map_age_max_ms": float(np.max(ages)),
        "publish_age_p50_ms": float(np.median(publish_age)) if len(publish_age) else None,
        "pipeline_p50_ms": float(np.median(pipeline)) if len(pipeline) else None,
        "pipeline_first_ms": float(pipeline[0]) if len(pipeline) else None,
        "pipeline_last_ms": float(pipeline[-1]) if len(pipeline) else None,
        "final_proxy_count": summary.get("final_proxy_count"),
        "controller_ms_p99": summary.get("controller_ms_p99"),
        "penetrating_cycles": summary.get("exact_penetrating_cycles"),
        "coverage_checks_passed": summary.get("all_centervox_coverage_checks_passed"),
        "observability_late": summary.get("observability_late_samples"),
        "observability_never": summary.get("observability_never_observed_samples"),
    }


def main() -> None:
    root = Path(sys.argv[1])
    rows = [load_case(path) for path in sorted(root.iterdir())
            if path.is_dir() and (path / "summary.json").exists()]
    (root / "summary_table.json").write_text(json.dumps(rows, indent=2))
    for row in rows:
        print(json.dumps(row))


if __name__ == "__main__":
    main()
