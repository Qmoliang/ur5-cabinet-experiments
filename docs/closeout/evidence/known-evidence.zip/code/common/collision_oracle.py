"""One robot/constraint oracle for model and published-map proxy inputs."""
import time
import numpy as np,mujoco
from unified_policy import POLICY
from proxy_geometry import ExactProxyGuard
from static_safety import ExecutionGuard
from unified_self_rows import SelfCollisionRows
class SearchDeadline(RuntimeError):pass
class CollisionOracle:
 def __init__(self,model,robot,arrays,initial_q,margin=None):
  self.model=model;self.data=mujoco.MjData(model);self.robot=robot;self.body_ids=np.array([x.body_id for x in robot]);self.local=np.array([x.local_center for x in robot]);self.radii=np.array([x.radius for x in robot]);self.site=model.site("attachment_site").id
  self.lower=model.jnt_range[:6,0]+POLICY["joint_padding_rad"];self.upper=model.jnt_range[:6,1]-POLICY["joint_padding_rad"];self.margin=POLICY["goal_margin_m"] if margin is None else margin
  self.guard=ExactProxyGuard(arrays);self.checks=0;self.deadline=float("inf");self._q=None;self._free_cache={};self._segment_cache={}
  self.sphere_positions(initial_q);self.pairs=SelfCollisionRows(model,self.data,robot,POLICY["dt_s"],lambda data,rb:self.sphere_positions(initial_q)).pairs
  self.execution=ExecutionGuard(model,robot,POLICY["dt_s"],POLICY["environment_margin_m"],POLICY["acceleration_limit"]);self.execution.set_self_pairs(self.pairs);self.execution.max_depth=20;self.execution.deadline_check=self.check_deadline
 def sphere_positions(self,q):
  self.data.qpos[:6]=q;mujoco.mj_kinematics(self.model,self.data)
  return self.data.xpos[self.body_ids]+np.einsum("nij,nj->ni",self.data.xmat[self.body_ids].reshape(-1,3,3),self.local)
 def gripper_position(self,q):self.sphere_positions(q);return self.data.site_xpos[self.site].copy()
 def evaluate(self,q):
  if time.perf_counter()>self.deadline:raise SearchDeadline()
  if self._q is not None and np.array_equal(q,self._q):return self._cache
  self.checks+=1;p=self.sphere_positions(q);mujoco.mj_comPos(self.model,self.data);J=[]
  for i,pt in enumerate(p):
   jac=np.zeros((3,self.model.nv));mujoco.mj_jac(self.model,self.data,jac,None,pt,int(self.body_ids[i]));J.append(jac[:,:6])
  J=np.asarray(J);ej=np.zeros((3,self.model.nv));mujoco.mj_jacSite(self.model,self.data,ej,None,self.site)
  gaps,normals=self.guard.nearest(p,self.radii);gj=-np.einsum("ni,nij->nj",normals,J)
  low=np.array(POLICY["workspace_lower"]);high=np.array(POLICY["workspace_upper"]);work=np.c_[p-low-self.radii[:,None],high-p-self.radii[:,None]].ravel();wj=np.concatenate([J,-J],axis=1).reshape(-1,6)
  i,j=self.pairs.T;delta=p[j]-p[i];length=np.linalg.norm(delta,axis=1);selfgap=length-self.radii[i]-self.radii[j]-POLICY["self_margin_m"]
  sj=np.einsum("ni,nij->nj",delta/np.maximum(length[:,None],1e-30),J[j]-J[i])
  self._q=np.asarray(q).copy();self._cache=(self.data.site_xpos[self.site].copy(),ej[:,:6].copy(),gaps,gj,np.r_[work,selfgap],np.vstack([wj,sj]));return self._cache
 def exact_clearance(self,q,margin=None):
  if time.perf_counter()>self.deadline:raise SearchDeadline()
  if np.any(q<self.lower) or np.any(q>self.upper):return -float("inf")
  p=self.sphere_positions(q);m=self.margin if margin is None else margin;env=float(self.guard.nearest(p,self.radii)[0].min())-m;i,j=self.pairs.T
  selfgap=np.min(np.linalg.norm(p[j]-p[i],axis=1)-self.radii[i]-self.radii[j]-POLICY["self_margin_m"])
  work=np.min(np.c_[p-np.array(POLICY["workspace_lower"])-self.radii[:,None],np.array(POLICY["workspace_upper"])-p-self.radii[:,None]])
  return float(min(env,selfgap,work))
 def check_deadline(self):
  if time.perf_counter()>self.deadline:raise SearchDeadline()
 def free(self,q):
  self.check_deadline();q=np.asarray(q,dtype=float);key=(self.margin,q.tobytes())
  if key in self._free_cache:return self._free_cache[key]
  value=self._free_uncached(q)
  if len(self._free_cache)>30000:self._free_cache.clear()
  self._free_cache[key]=value;return value
 def _free_uncached(self,q):
  if np.any(q<self.lower) or np.any(q>self.upper):return False
  p=self.sphere_positions(q);i,j=self.pairs.T
  if np.min(np.linalg.norm(p[j]-p[i],axis=1)-self.radii[i]-self.radii[j])<POLICY["self_margin_m"]:return False
  if np.any(p-self.radii[:,None]<np.array(POLICY["workspace_lower"])) or np.any(p+self.radii[:,None]>np.array(POLICY["workspace_upper"])):return False
  return self.guard.certify(p,p,self.radii+self.margin).minimum_clearance_m>=0
 def segment_free(self,a,b,step=.02):
  # Exploration heuristic only. Every returned route is independently certified continuously.
  self.check_deadline();a=np.asarray(a);b=np.asarray(b);count=max(1,int(np.ceil(np.max(np.abs(b-a))/step)))
  return all(self.free(a+(b-a)*t) for t in np.linspace(0,1,count+1))
 def segment_certified(self,a,b):
  self.check_deadline()
  if np.any(a<self.lower) or np.any(a>self.upper) or np.any(b<self.lower) or np.any(b>self.upper):return False
  a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float);key=(self.margin,a.tobytes(),b.tobytes())
  if key in self._segment_cache:return self._segment_cache[key]
  old=self.execution.margin;self.execution.margin=self.margin
  try:value=self.execution.segment(self.guard,a,b)
  finally:self.execution.margin=old
  if len(self._segment_cache)>30000:self._segment_cache.clear()
  self._segment_cache[key]=value;return value
