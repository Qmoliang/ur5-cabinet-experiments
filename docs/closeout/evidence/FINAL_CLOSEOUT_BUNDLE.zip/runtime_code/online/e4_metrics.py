"""E4 per-run summary: task outcome, object contacts, perception delay, missed detections, coverage.

Per object (ground truth only for scoring):
  visible frames    detector frames with >= VISIBLE_PX true object pixels in the fixed cameras
  matched frames    of those, frames where some certificate touches the true object (at capture time)
  first_visible_s   capture time of the first visible frame
  detection_delay   (time the first matched result reached the controller) - first_visible_s
  missed            visible in >= 3 frames but never matched
  blind             launched but never visible to the fixed cameras
Pipeline latency: available time - capture time of every detector result.
Coverage: fraction of sample points of the true object geoms inside the
dynamic certificates, while the object is within 0.4 m of the arm.
"""
import numpy as np

VISIBLE_PX = 10


def e4_summary(e4, mode, count, objects, frames, coverage, duration_s):
    latency = [1000.0 * (f["available_t"] - f["capture_t"]) for f in frames]
    compute = [f["compute_ms"] for f in frames]
    per_object = []
    if objects is not None:
        for k, obj in enumerate(objects.objects):
            # From launch on ("sudden" objects sit visible and still before it).
            launched_at = obj.t0 if obj.t0 is not None else np.inf
            visible = [f for f in frames
                       if f["objects"][k]["visible_px"] >= VISIBLE_PX and f["capture_t"] >= launched_at]
            matched = [f for f in visible if f["objects"][k]["matched"]]
            first_visible = visible[0]["capture_t"] if visible else None
            first_matched_available = matched[0]["available_t"] if matched else None
            cov = [c for (_t, kk, _near, c) in coverage if kk == k]
            part_cov = {}
            for part in ("head", "handle"):
                values = [f["objects"][k].get("covered_at_capture", {}).get(part, 0.0) for f in visible]
                part_cov[part] = float(np.mean(values)) if values else None
            per_object.append(dict(
                capture_coverage_head=part_cov["head"], capture_coverage_handle=part_cov["handle"],
                behaviour=obj.behaviour, launched=obj.launched, t0=obj.t0,
                visible_frames=len(visible), matched_frames=len(matched),
                first_visible_s=first_visible, first_matched_available_s=first_matched_available,
                detection_delay_s=(None if first_visible is None or first_matched_available is None
                                   else first_matched_available - first_visible),
                missed=bool(obj.launched and len(visible) >= 3 and not matched),
                blind=bool(obj.launched and not visible),
                coverage_mean=float(np.mean(cov)) if cov else None,
                coverage_min=float(np.min(cov)) if cov else None,
                coverage_samples=len(cov)))
    false_track_frames = sum(1 for f in frames if f.get("unmatched_tracks", 0) > 0)
    out = dict(e4)
    if "delay" in out:  # UR5_COMPUTE_DELAY: counts only
        d = out["delay"]
        out["delay"] = dict(solves=d["solves"], held_cycles=d["held_cycles"])
    out.update(
        mode=mode, object_count=count,
        objects=None if objects is None else dict(
            progress=objects.progress, trigger_s=objects.trigger_s, not_launched=objects.not_launched,
            rejected_no_room=objects.rejected_no_room, all_done=bool(objects.all_done(duration_s)),
            described=objects.describe()),
        per_object=per_object,
        detector_frames=len(frames),
        detector_latency_ms_p50=float(np.percentile(latency, 50)) if latency else None,
        detector_latency_ms_p95=float(np.percentile(latency, 95)) if latency else None,
        detector_compute_ms_p50=float(np.percentile(compute, 50)) if compute else None,
        frames_with_unmatched_tracks=false_track_frames,
    )
    return out
