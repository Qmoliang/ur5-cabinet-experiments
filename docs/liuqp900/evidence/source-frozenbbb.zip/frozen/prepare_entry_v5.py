from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='goal_entry_v4':";new="        if job.get('policy_version')=='goal_entry_v5':\n            from goal_entry_policy_v5 import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_v4':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'entry_v4_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('entry_v4','entry_v5');j['policy_version']='goal_entry_v5'
(ROOT/'entry_v5_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_v5';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'ENTRY_V5_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},changes=['posture preparation in the null space of the current tracking frame','during bypass control safe blocked-point surface velocity instead of simultaneously pulling the end effector back to the final point','transport tangent orientation across nearest proxy changes','remove voluntary 40mm clearance hold; original physical safety remains','exit only after target-side compatibility, actual feature-distance decrease, and no-return braking certificate','explicit policy failure after its local movement family remains exhausted for 100 cycles'],no_future_configuration_search=True,hard_safety_unchanged=True,goal_unchanged=True),indent=2))
print(json.dumps(jobs))
