"""The repository's online NEO (external_neo_adaptive/neo_online.py) for the pilot, unchanged except for
what the moving-object experiment needs:

  * moving objects: one velocity-damper row per robot sphere / detected sphere certificate within
    the influence distance, with NEO's obstacle-velocity term,
        n^T J_i u <= (d - d_s) / (d_i - d_s) + n^T v_obstacle
    (detections and latency compensation from dynamic_channel.py, the same input LiuQP gets);
  * self-collision dampers (safety_rows.py), n^T (J_i - J_j) u <= gap / 0.05;
  * the acceleration limit (it reuses LiuQP's joint_velocity_bounds, which carries it);
  * when quadprog and SLSQP both fail (the original raises), the same least-violation fallback as
    the LiuQP variants (fallback.py).
The geometry (base ellipsoid Q + directional uncertainty U + offset, support-normal distances, its
own influence MVT) and the QP objective are the original's.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent / "external_neo_adaptive"))
from neo_online import OnlineNEO  # noqa: E402

from fallback import W_MOVING, W_STATIC, least_violation  # noqa: E402
from protocol_liuqp_controller import ProtocolStepMetrics  # noqa: E402


def make_e4_neo(influence):
    class E4NEO(OnlineNEO):
        pass

    E4NEO.influence = float(influence)
    return E4NEO


def _attach(self, channel, self_rows):
    self.e4_channel, self.e4_self_rows = channel, self_rows
    self.fallback_cycles = 0


OnlineNEO.attach_e4 = _attach
_original_assemble = OnlineNEO.assemble
_original_solve = OnlineNEO.solve


def _assemble(self, target):
    H, g, A, lo, hi, info = _original_assemble(self, target)
    from model import certificate_world_state

    positions, jac, radii = certificate_world_state(self.model, self.data, self.robot_spheres)
    jac = jac[:, :, : self.nv]
    n_static = int(info["active"])
    kinds = ["joint"] * self.nv + ["task"] * 3 + ["workspace"] * info["workspace_rows"] + ["static"] * n_static
    rows, lows, highs = [A], [lo], [hi]
    channel = getattr(self, "e4_channel", None)
    if channel is not None and len(channel.centers):
        delta = channel.centers[None, :, :] - positions[:, None, :]
        length = np.linalg.norm(delta, axis=2)
        d = length - radii[:, None] - channel.radii[None, :]
        moving_influence = float(os.environ.get("UR5_NEO_MOVING_INFLUENCE") or self.influence)
        pi, pj = np.nonzero(d < moving_influence)
        if len(pi):
            n = delta[pi, pj] / np.maximum(length[pi, pj], 1e-12)[:, None]
            rows.append(np.einsum("pi,pij->pj", n, jac[pi]))
            lows.append(np.full(len(pi), -np.inf))
            highs.append((d[pi, pj] - self.safety_margin) / (moving_influence - self.safety_margin)
                         + np.einsum("pi,pi->p", n, channel.velocities[pj]))
            kinds += ["moving"] * len(pi)
    self_rows = getattr(self, "e4_self_rows", None)
    if self_rows is not None:
        pairs = self_rows.geometry(positions, jac, radii)
        if pairs:
            rows.append(np.array([row for _a, _b, _gap, row in pairs]))
            lows.append(np.full(len(pairs), -np.inf))
            highs.append(np.array([gap / 0.05 for _a, _b, gap, _row in pairs]))
            kinds += ["self"] * len(pairs)
    info["kinds"] = np.array(kinds)
    return H, g, np.vstack(rows), np.concatenate(lows), np.concatenate(highs), info


def _solve(self, target):
    try:
        return _original_solve(self, target)
    except RuntimeError as error:
        if not hasattr(self, "e4_channel"):
            raise
        H, g, A, lo, hi, info = self.failed_qp_candidate
        kinds = info["kinds"]
        keep = kinds != "task"
        weights = np.where(kinds == "moving", W_MOVING, W_STATIC)
        u = least_violation(A[keep], lo[keep], hi[keep], (kinds == "joint")[keep], weights[keep])
        status = "fallback"
        if u is None:
            step = (self.acceleration_limit or 1e9) * self.dt
            u = self.applied_velocity - np.clip(self.applied_velocity, -step, step)
            status = "fallback failed"
        self.fallback_cycles += 1
        self.previous_velocity = np.asarray(u, float).copy()
        values = {f: 0 for f in ProtocolStepMetrics.__dataclass_fields__}
        values.update(status=status, representation=self.representation, qp_rho_mode="", qp_row_sha256="",
                      qdot_norm=float(np.linalg.norm(u)), min_clearance=float("inf"),
                      limiting_robot_index=-1, limiting_obstacle_index=-1, limiting_proxy_id=-1)
        print(f"NEO fallback ({status}): {str(error)[:100]}", flush=True)
        return u, ProtocolStepMetrics(**values)


OnlineNEO.assemble = _assemble
OnlineNEO.solve = _solve
