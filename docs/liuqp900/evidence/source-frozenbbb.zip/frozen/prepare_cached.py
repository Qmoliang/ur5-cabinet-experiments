from pathlib import Path
import json,shutil
ROOT=Path(__file__).resolve().parent
p=ROOT/'pilot_worker_continuation.py';s=p.read_text();s=s.replace("        if job.get('policy_version')=='continuation':","        if job.get('policy_version')=='continuation_cached':\n            from continuation_cached_policy import LowDimPolicy\n        elif job.get('policy_version')=='continuation':");p.write_text(s)
s=(ROOT/'launch_continuation.py').read_text().replace('[48,49,50,51]','[56,57,58,59]').replace('[52,53,54,55]','[60,61,62,63]');(ROOT/'launch_cached.py').write_text(s)
j=json.loads((ROOT/'development_jobs.json').read_text())
for x in j:x.update(name=x['name']+'_cached',policy_version='continuation_cached')
(ROOT/'cached_jobs.json').write_text(json.dumps(j,indent=2))
a=ROOT/'revisions/continuation_cached';a.mkdir()
for p in ROOT.glob('*.py'):shutil.copy2(p,a/p.name)
