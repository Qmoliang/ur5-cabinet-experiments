"""CenterVox certificates from a dense, noise-free point cloud of the known drawer.

Every box face is sampled on a square grid (spacing h); each sample is a ball of
radius h/sqrt(2), so the balls cover the face.  Measurement uncertainty is a negligible 0.1 mm (exactly zero makes the shapes singular)
(--uncertainty sets an isotropic standard deviation.  The cloud goes
through the same proxy manager the cameras feed, in one update, and the result
is saved for run_v6_case.py --frozen-map (no frontier cells).

Usage: build_dense_map.py OUT.pkl [--spacing 0.0025] [--uncertainty 0.0]
"""
import argparse
import os
import pickle
import sys
from pathlib import Path

import numpy as np

os.environ["UR5_FRONTIER"] = "0"
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_protocol_v3_async_online as online  # noqa: E402


def face_samples(box, spacing):
    c, h = np.asarray(box.center, float), np.asarray(box.half_size, float)
    points = []
    for axis in range(3):
        others = [a for a in range(3) if a != axis]
        grids = [np.arange(-h[a] + spacing / 2, h[a], spacing) for a in others]
        if any(len(g) == 0 for g in grids):
            grids = [g if len(g) else np.array([0.0]) for g in grids]
        u, v = np.meshgrid(*grids, indexing="ij")
        for sign in (-1.0, 1.0):
            p = np.zeros((u.size, 3))
            p[:, axis] = sign * h[axis]
            p[:, others[0]] = u.ravel()
            p[:, others[1]] = v.ravel()
            points.append(c + p)
    return np.concatenate(points)


parser = argparse.ArgumentParser()
parser.add_argument("out")
parser.add_argument("--spacing", type=float, default=0.0025)
parser.add_argument("--uncertainty", type=float, default=0.0001)
args = parser.parse_args()
worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=0.0075, maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm"), scene_version="camera_quarter")
points = np.concatenate([face_samples(b, args.spacing) for b in worker.scene.boxes])
keep = np.all(points >= online.PROXY_WORKSPACE_LOWER, axis=1) & np.all(points <= online.PROXY_WORKSPACE_UPPER, axis=1)
points = points[keep]
radii = np.full(len(points), args.spacing / np.sqrt(2.0))
shapes = np.repeat((args.uncertainty ** 2 * np.eye(3))[None], len(points), axis=0)
worker.proxy_manager.update(points, radii, shapes)
coverage = worker.proxy_manager.coverage_audit()
proxies = worker.proxy_manager.snapshot
with open(args.out, "wb") as handle:
    pickle.dump({"proxies": proxies, "frontier_cells": 0}, handle)
print(f"{len(points)} surface samples (spacing {1000*args.spacing:.1f} mm, sigma {1000*args.uncertainty:.1f} mm) "
      f"-> {len(proxies.centers)} CenterVox certificates; coverage ok: {coverage.all_raw_sample_balls_certified}")
worker.close()
