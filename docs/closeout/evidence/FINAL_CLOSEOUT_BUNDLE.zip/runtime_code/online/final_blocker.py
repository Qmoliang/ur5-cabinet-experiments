"""What limits LiuQP at the end of each run (frontier vs observed surface), and how far."""
import csv, json, sys
from pathlib import Path
import numpy as np
for root in sys.argv[1:]:
    for case in sorted(Path(root).glob("seed*")):
        if not case.is_dir():
            continue
        d = next(p for p in case.iterdir() if p.is_dir())
        cycles = list(csv.DictReader(open(d / "cycles.csv")))
        frames = list(csv.DictReader(open(d / "perception_frames.csv")))
        snaps = np.load(d / "causal_proxy_snapshots.npz")
        off = snaps["offsets"]; g = len(snaps["publish_cycles"]) - 1
        ids = snaps["proxy_ids"][off[g]:off[g + 1]]; centres = snaps["centers"][off[g]:off[g + 1]]
        nf = int(float(frames[-1].get("frontier_cells") or 0))
        front = set(ids[-nf:].tolist()) if nf else set()
        out = []
        for row in (cycles[-1],):
            lim = int(float(row["limiting_proxy_id"]))
            ee = np.array([float(row[k]) for k in ("ee_x", "ee_y", "ee_z")])
            where = centres[np.flatnonzero(ids == lim)[0]] if lim in set(ids.tolist()) else None
            kind = "frontier" if lim in front else ("surface" if where is not None else "none/other")
            out.append(f"limit={kind} at {None if where is None else where.round(3)} "
                       f"{'' if where is None else str(round(1000*np.linalg.norm(where-ee)))+'mm from gripper'} "
                       f"robot_sphere={row.get('limiting_robot_index')} gap={row.get('minimum_gap_m', row.get('min_clearance_m'))}")
        # how many frontier cells remain within 5 cm of the target
        target = np.array(json.load(open(d / "summary.json")).get("target_position", [np.nan] * 3), dtype=float)
        near = int(np.sum(np.linalg.norm(centres[-nf:] - target, axis=1) < 0.05)) if nf and np.all(np.isfinite(target)) else None
        print(f"{case.name}: err {1000*float(cycles[-1]['error_m']):.1f}mm gripper {ee.round(3)} {out[0]} frontier<5cm of target: {near}")
