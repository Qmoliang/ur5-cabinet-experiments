"""v3 integration corrections only: mode epochs and posture sign continuity."""
import numpy as np,mujoco
from lowdim_policy import LowDimPolicy as Base

class LowDimPolicy(Base):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.command_epoch=0;self.pose_activation_pending=False;self.synced_pose_entries=0

    def emit(self,name,**kwargs):
        if name in ('escape_triggered','plane_selected','task_trial_started','posture_phase','mixed_phase','posture_phase_finished','posture_unavailable','mixed_unavailable','task_capacity_restored','retreat_phase','release_candidate','recovered_original_controller','recovery_reentered'):
            self.command_epoch=getattr(self,'command_epoch',0)+1
        return super().emit(name,**kwargs)

    def observe(self,k,q,previous):
        super().observe(k,q,previous)
        if self.pose_activation_pending and np.max(np.abs(previous))<1e-8:
            if self.mode in ('POSTURE','MIXED_ESCAPE'):
                self.pose_q=np.asarray(q).copy();self.pose_p=self.ee.copy();self.pose_k=k
                self.pose_data=mujoco.MjData(self.ctx.model);self.synced_pose_entries+=1
                self.event(event='posture_reference_reset_after_stop',cycle=k,mode=self.mode,endpoint=self.pose_p.tolist())
            self.pose_activation_pending=False

    def _posture_candidates(self,s,A):
        candidates=super()._posture_candidates(s,A)
        if self.z_mem is None:return candidates
        result=[]
        # Preserve geometric priority, but align each +/- pair to the prior
        # posture direction. The opposite remains an explicit fallback.
        for i in range(0,len(candidates),2):
            pair=candidates[i:i+2]
            pair.sort(key=lambda z:-float(z@self.z_mem));result.extend(pair)
        return result

    def _posture(self,*args,**kwargs):
        choose=kwargs.get('choose',False) or (len(args)>=8 and bool(args[7]))
        answer=super()._posture(*args,**kwargs)
        if choose and answer is not None and np.max(np.abs(self.previous))>1e-8:
            self.brake_pending=True;self.pose_activation_pending=True
        return answer

    def _mixed(self,*args,**kwargs):
        old_mode=self.mode;answer=super()._mixed(*args,**kwargs)
        if answer is not None and old_mode!='MIXED_ESCAPE' and np.max(np.abs(self.previous))>1e-8:
            self.brake_pending=True;self.pose_activation_pending=True
        return answer

    def summary(self):
        data=super().summary();data.update(integration_revision='v3_mode_epoch_and_posture_sign',command_epoch=self.command_epoch,posture_entries_reset_after_stop=self.synced_pose_entries)
        return data
