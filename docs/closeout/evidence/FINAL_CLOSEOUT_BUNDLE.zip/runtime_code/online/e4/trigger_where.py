"""Where was the gripper when the objects were launched (E4 runs)?  Drawer opening plane x = 0.35."""
import json
from pathlib import Path

import numpy as np

inside = total = 0
depths = []
for f in sorted(Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e4").glob("*_k[123]_v*/seed*/summary.json")):
    s = json.load(open(f))
    o = s["e4"]["objects"]
    if not any(d["launched"] for d in o["described"]):
        continue
    t0 = min(d["t0"] for d in o["described"] if d["launched"])
    inner = next(f.parent.glob("A-CV-*"))
    ee = np.load(inner / "ee_history.npy")
    p = ee[min(len(ee) - 1, int(round(t0 / 0.02)))]
    total += 1
    depths.append(p[0] - 0.35)
    inside += p[0] > 0.35
print(f"launched runs {total}; gripper already past the drawer opening (x > 0.35) at launch: {inside}")
print("gripper x - 0.35 at launch (m): median %.3f, min %.3f, max %.3f" % (np.median(depths), min(depths), max(depths)))
