"""Shared certifier for supplied proxies. No scene/world geometry is consulted."""
from types import SimpleNamespace
import numpy as np
from scipy.spatial import cKDTree
from unified_native import NativeEllipsoidSupport
from unified_policy import POLICY
import os

def from_known_cover(cover):
 n=len(cover.centers)
 return dict(centers=np.asarray(cover.centers),shapes=np.asarray(cover.ellipsoid_shapes),radii=np.asarray(cover.sphere_radii),offsets=np.zeros(n),boxes=np.zeros((n,3)),representation=cover.representation)

def from_published(proxies,representation):
 extra=np.asarray(proxies.proxy_uncertainty_shapes)
 if np.any(extra!=0):raise ValueError("nonidentity fitted uncertainty cannot enter the shared planner")
 boxes=getattr(proxies,"box_half_extents",None)
 return dict(centers=np.asarray(proxies.centers),shapes=np.asarray(proxies.base_ellipsoid_shapes),radii=np.asarray(proxies.sphere_radii),offsets=np.asarray(proxies.proxy_offset_radii),boxes=np.zeros_like(proxies.centers) if boxes is None else np.asarray(boxes),representation=representation)

class ExactProxyGuard:
 def __init__(self,arrays):
  self.arrays=arrays;self.centers=np.asarray(arrays["centers"]);self.Q=np.asarray(arrays["shapes"]);self.sphere=np.asarray(arrays["radii"]);self.offset=np.asarray(arrays["offsets"]);self.box=np.asarray(arrays["boxes"]);self.representation=arrays["representation"]
  self.isbox=np.any(self.box>0,axis=1);self.values,self.rotations=np.linalg.eigh(self.Q);self.kernel=NativeEllipsoidSupport();self.kernel.set_pair_threads(1 if os.environ.get("UNIFIED_PLANNER_PROCESS")=="1" else POLICY["pair_threads"])
  self.cover=SimpleNamespace(centers=self.centers,ellipsoid_shapes=self.Q,sphere_radii=self.sphere,proxy_offset_radii=self.offset,box_half_extents=self.box)
  axis=np.sqrt(np.maximum(np.diagonal(self.Q,axis1=1,axis2=2),0)) if self.representation=="ellipsoid" else np.repeat(self.sphere[:,None],3,axis=1)
  self.half=np.where(self.isbox[:,None],self.box,axis)+self.offset[:,None];self.bound=float(np.max(np.linalg.norm(self.half,axis=1),initial=0));self.tree=cKDTree(self.centers)
 def pairs(self,a,b,r):
  ids=self.tree.query_ball_point((a+b)*.5,np.linalg.norm(b-a,axis=1)*.5+r+self.bound+1e-9)
  ri=np.repeat(np.arange(len(a)),[len(x) for x in ids]);oi=np.array([j for x in ids for j in x],dtype=int)
  if not len(oi):return ri,oi
  separation=np.maximum(np.abs(self.centers[oi]-(a[ri]+b[ri])*.5)-self.half[oi]-np.abs(b[ri]-a[ri])*.5,0.)
  # Distance between the segment AABB and the proxy AABB is a lower bound.
  ok=np.sum(separation*separation,axis=1)<=(r[ri]+1e-12)**2
  return ri[ok],oi[ok]
 def point_geometry(self,p,oi,optimizer=False):
  c=self.centers[oi];delta=c-p;dist=np.zeros(len(oi));normal=np.zeros_like(p);box=self.isbox[oi]
  if np.any(box):
   h=self.box[oi[box]];x=p[box];cc=c[box];near=np.clip(x,cc-h,cc+h);d=near-x;length=np.linalg.norm(d,axis=1);normal[box]=d/np.maximum(length[:,None],1e-30);dist[box]=length
   if optimizer:
    for local_idx in np.flatnonzero(length<1e-12):
     k=np.flatnonzero(box)[local_idx];depth=h[local_idx]-np.abs(x[local_idx]-cc[local_idx]);axis=int(np.argmin(depth));normal[k]=0;normal[k,axis]=-1. if x[local_idx,axis]>=cc[local_idx,axis] else 1.;dist[k]=-depth[axis]
  take=~box
  if np.any(take):
   ids=oi[take]
   if self.representation=="sphere":
    length=np.linalg.norm(delta[take],axis=1);normal[take]=delta[take]/np.maximum(length[:,None],1e-30);dist[take]=length-self.sphere[ids]
   else:
    result=self.kernel.closest_points_pairs_warm(p[take],c[take],self.values[ids],self.rotations[ids],np.full(len(ids),np.nan));d=result[1]-p[take];length=np.linalg.norm(d,axis=1);normal[take]=d/np.maximum(length[:,None],1e-30);dist[take]=length
    if optimizer:
     local=np.einsum("nji,nj->ni",self.rotations[ids],-delta[take]);values=np.maximum(self.values[ids],1e-18);rho=np.sqrt(np.sum(local*local/values,axis=1));inside=rho<1
     if np.any(inside):
      global_ids=np.flatnonzero(take)[inside];amin=np.sqrt(values[inside].min(axis=1));dist[global_ids]=amin*(rho[inside]-1)
      gradient=amin[:,None]*local[inside]/values[inside]/np.maximum(rho[inside,None],1e-12);normal[global_ids]=-np.einsum("nij,nj->ni",self.rotations[ids[inside]],gradient)
  return dist-self.offset[oi],normal
 def support(self,n,oi):
  result=np.empty(len(oi));box=self.isbox[oi]
  result[box]=np.sum(np.abs(n[box])*self.box[oi[box]],axis=1)
  if self.representation=="sphere":result[~box]=self.sphere[oi[~box]]
  else:result[~box]=np.sqrt(np.maximum(np.einsum("ni,nij,nj->n",n[~box],self.Q[oi[~box]],n[~box]),0))
  return result+self.offset[oi]
 def certify(self,starts,ends,radii):
  starts=np.asarray(starts);ends=np.asarray(ends);radii=np.asarray(radii);ri,oi=self.pairs(starts,ends,radii)
  if not len(oi):return SimpleNamespace(minimum_clearance_m=0.,safe=True)
  a=starts[ri];b=ends[ri];c=self.centers[oi];da,na=self.point_geometry(a,oi)
  if np.array_equal(starts,ends):
   value=min(0.,float(np.min(da-radii[ri])));return SimpleNamespace(minimum_clearance_m=value,safe=value>=0)
  db,nb=self.point_geometry(b,oi)
  lower=(da+db-np.linalg.norm(b-a,axis=1))*.5
  for normal in [na,nb]:
   plane=np.minimum(np.einsum("ni,ni->n",normal,c-a),np.einsum("ni,ni->n",normal,c-b))-self.support(normal,oi)
   lower=np.maximum(lower,plane)
  value=min(0.,float(np.min(lower-radii[ri])));return SimpleNamespace(minimum_clearance_m=value,safe=value>=0)
 def certify_curved(self,starts,ends,radii,curve):
  starts=np.asarray(starts);ends=np.asarray(ends);radii=np.asarray(radii);curve=np.asarray(curve);ri,oi=self.pairs(starts,ends,radii+curve)
  if not len(oi):return SimpleNamespace(minimum_clearance_m=0.,safe=True)
  a=starts[ri];b=ends[ri];center=self.centers[oi];da,na=self.point_geometry(a,oi);db,nb=self.point_geometry(b,oi);padding=curve[ri]
  lower=(da+db-np.linalg.norm(b-a,axis=1))*.5-padding
  B=4*padding
  for normal in [na,nb]:
   initial=np.einsum("ni,ni->n",normal,center-a)-self.support(normal,oi);slope=-np.einsum("ni,ni->n",normal,b-a)
   tau=np.clip((B-slope)/np.maximum(2*B,1e-30),0,1)
   bound=initial+tau*(slope-B)+B*tau*tau
   lower=np.maximum(lower,bound)
  value=min(0.,float(np.min(lower-radii[ri])));return SimpleNamespace(minimum_clearance_m=value,safe=value>=0)
 def nearest(self,positions,radii,reach=.030):
  ri,oi=self.pairs(positions,positions,radii+reach);gap=np.full(len(positions),reach);normal=np.zeros_like(positions)
  if not len(oi):return gap,normal
  distance,n=self.point_geometry(positions[ri],oi,optimizer=True);values=distance-radii[ri]
  for i in np.unique(ri):
   ids=np.flatnonzero(ri==i);k=ids[np.argmin(values[ids])]
   if values[k]<gap[i]:gap[i]=values[k];normal[i]=n[k]
  return gap,normal
