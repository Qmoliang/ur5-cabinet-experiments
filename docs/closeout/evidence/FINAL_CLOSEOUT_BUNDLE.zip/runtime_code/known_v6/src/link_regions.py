"""Per-link separating planes for LiuQP (IRIS-inspired certificate pruning).

LiuQP's erase-remove, for each of the 65 robot spheres separately, places a
plane at the nearest obstacle and deletes every obstacle lying fully behind
it.  That is IRIS's separating-hyperplane step with a single point as seed.
Here the seed is a whole capsule of the robot (one collision geometry): the
plane for an obstacle goes through the closest pair between the capsule's
axis segment and that obstacle, so it separates the obstacle from the entire
capsule and every sphere on the capsule can share it.  The same greedy prune
then removes everything behind each plane.  Each sphere still gets its own
clearance to each shared plane, and LiuQP's QP, NEAR/CONTACT handling and
safety condition are unchanged.

Box-shaped geometries (spheres on a grid, not along a segment) keep LiuQP's
own per-sphere planes.
"""
from __future__ import annotations

import time
from collections import defaultdict

import numpy as np

from controller import ProtocolLiuQPController, ProtocolSeparatingPlane


def closest_points_on_ellipsoid(points, center, rotation, axes):
    """Closest points on one ellipsoid surface (rotation columns = axes)."""
    local = (points - center) @ rotation
    sign = np.where(local < 0.0, -1.0, 1.0)
    y = np.abs(local)
    a2 = axes * axes
    inside = np.sum(y * y / a2, axis=1) <= 1.0
    low = np.zeros(len(y))
    high = np.linalg.norm(y, axis=1) * axes.max() + 1e-12
    for _ in range(60):
        t = 0.5 * (low + high)
        value = np.sum(a2 * y * y / (a2 + t[:, None]) ** 2, axis=1) - 1.0
        low = np.where(value > 0.0, t, low)
        high = np.where(value > 0.0, high, t)
    closest_local = sign * a2 * y / (a2 + high[:, None])
    closest = center + closest_local @ rotation.T
    distance = np.where(inside, -1.0, np.linalg.norm(points - closest, axis=1))
    return closest, distance


class LinkRegionLiuQPController(ProtocolLiuQPController):
    """LiuQP whose separating planes are shared by all spheres of a capsule."""

    SEGMENT_SAMPLES = 33

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Use the plain per-sphere plane path; shared planes replace it below.
        self.native_exact_pair_batch = False
        groups: dict[int, list[int]] = defaultdict(list)
        for index, sphere in enumerate(self.robot_spheres):
            groups[int(sphere.source_geom_id)].append(index)
        self.capsule_groups = []
        self.box_spheres: set[int] = set()
        for members in groups.values():
            radii = {round(float(self.robot_spheres[i].radius), 12) for i in members}
            locals_ = np.array([self.robot_spheres[i].local_center for i in members])
            # Capsule chains: equal radii and collinear centres.
            collinear = True
            if len(members) > 2:
                direction = locals_[-1] - locals_[0]
                direction /= max(np.linalg.norm(direction), 1e-12)
                offsets = locals_ - locals_[0]
                residual = offsets - np.outer(offsets @ direction, direction)
                collinear = float(np.max(np.linalg.norm(residual, axis=1))) < 1e-9
            if len(radii) == 1 and collinear and len(members) >= 2:
                self.capsule_groups.append(members)
            else:
                self.box_spheres.update(members)
        self.group_of = {i: g for g, members in enumerate(self.capsule_groups) for i in members}
        self._shared: dict[int, list[tuple]] = {}
        self.shared_plane_solves = 0
        self.per_sphere_plane_solves = 0

    # -- shared planes ---------------------------------------------------
    def _segment_obstacle_pair(self, a, b, obstacle):
        """Closest pair between segment [a, b] and one obstacle proxy."""
        center = self.obstacle_centers[obstacle]
        if self.representation == "sphere":
            direction = b - a
            t = np.clip(np.dot(center - a, direction) / max(np.dot(direction, direction), 1e-18), 0.0, 1.0)
            x = a + t * direction
            normal = center - x
            length = np.linalg.norm(normal)
            normal = normal / max(length, 1e-12)
            radius = float(self.obstacle_radii[obstacle]) + float(self.obstacle_offsets[obstacle])
            return x, center - radius * normal, normal
        rotation = self.obstacle_rotations[obstacle]
        axes = np.sqrt(np.maximum(self.obstacle_eigenvalues[obstacle], 0.0))
        lo, hi = 0.0, 1.0
        for _ in range(3):  # coarse-to-fine search; distance is convex along the segment
            ts = np.linspace(lo, hi, self.SEGMENT_SAMPLES)
            points = a + ts[:, None] * (b - a)
            _, distance = closest_points_on_ellipsoid(points, center, rotation, axes)
            best = int(np.argmin(np.where(distance < 0.0, -np.inf, distance)))
            width = (hi - lo) / (self.SEGMENT_SAMPLES - 1)
            lo, hi = max(0.0, ts[best] - width), min(1.0, ts[best] + width)
        t = 0.5 * (lo + hi)
        x = a + t * (b - a)
        y, distance = closest_points_on_ellipsoid(x[None, :], center, rotation, axes)
        y = y[0]
        normal = y - x
        length = np.linalg.norm(normal)
        if distance[0] < 0.0 or length < 1e-12:
            return None
        return x, y - float(self.obstacle_offsets[obstacle]) * normal / length, normal / length

    def _build_shared_planes(self, positions, radii):
        self._shared = {}
        tolerance = 1e-10
        for group, members in enumerate(self.capsule_groups):
            a, b = positions[members[0]], positions[members[-1]]
            radius = float(radii[members[0]])
            candidates = set()
            for i in members:
                candidates.update(int(c) for c in self._candidate_indices(positions[i], float(radii[i])))
            if not candidates:
                self._shared[group] = []
                continue
            candidates = np.array(sorted(candidates), dtype=np.int64)
            # Cheap lower bound to the capsule: best over its spheres.
            bounds = np.min([self._ordering_lower_bound(positions[i], radius, candidates) for i in members], axis=0)
            remaining = list(candidates[np.lexsort((candidates, bounds))])
            planes = []
            while remaining:
                kept = int(remaining[0])
                pair = self._segment_obstacle_pair(a, b, kept)
                self.shared_plane_solves += 1
                if pair is None:
                    # The capsule axis touches this proxy: no shared plane exists.
                    # Fall back to per-sphere planes for this whole capsule.
                    planes = None
                    break
                _, surface, normal = pair
                offset = float(normal @ surface)
                planes.append((kept, normal, surface, offset))
                indices = np.asarray(remaining, dtype=np.int64)
                behind = self._minimum_support(indices, normal) >= offset - tolerance
                remaining = [int(i) for i, drop in zip(indices, behind) if not bool(drop)]
            self._shared[group] = planes

    def solve(self, target):
        from robot import certificate_world_state
        positions, jacobians, radii = certificate_world_state(self.model, self.data, self.robot_spheres)
        started = time.perf_counter()
        self._build_shared_planes(positions, radii)
        # Fastest a sphere can move along any direction this cycle:
        # |n . J qdot| <= sum_i ||J_i|| |qdot_i|.  A plane farther than one step
        # of that is provably inactive, so its row can be left out.
        lower, upper = self.joint_velocity_bounds()
        limits = np.maximum(np.abs(lower), np.abs(upper))
        column_norms = np.linalg.norm(jacobians[:, :, : self.nv], axis=1)
        self._reach_per_step = (column_norms @ limits) * self.dt
        self._shared_ms = (time.perf_counter() - started) * 1000.0
        self.dropped_inactive_rows = 0
        return super().solve(target)

    def _row_can_bind(self, robot_index: int, clearance: float) -> bool:
        # Keep NEAR/CONTACT rows unconditionally: they also shape LiuQP's
        # objective.  Drop only NORMAL rows that one step cannot reach.
        if clearance + self.safety_margin < self.near_distance:
            return True
        return clearance <= self._reach_per_step[robot_index] + 1e-9

    def active_planes_for_robot_sphere(self, robot_index, center, radius, directional_batch=None, exact_batch=None):
        group = self.group_of.get(robot_index)
        planes = None if group is None else self._shared.get(group)
        if planes is None:
            started = time.perf_counter()
            result = super().active_planes_for_robot_sphere(robot_index, center, radius, directional_batch, exact_batch)
            self.per_sphere_plane_solves += len(result[0])
            return result
        active = []
        for obstacle, normal, surface, offset in planes:
            clearance = offset - float(normal @ center) - float(radius) - self.safety_margin
            if not self._row_can_bind(robot_index, clearance):
                self.dropped_inactive_rows += 1
                continue
            active.append(ProtocolSeparatingPlane(
                robot_index=robot_index, obstacle_index=obstacle, proxy_id=int(self.proxy_ids[obstacle]),
                normal_to_obstacle=normal, surface_point=surface, offset=offset, clearance=clearance))
        # Geometry time is charged once per capsule in solve(); report zero here.
        return active, len(planes), 0, 0.0, 0.0
