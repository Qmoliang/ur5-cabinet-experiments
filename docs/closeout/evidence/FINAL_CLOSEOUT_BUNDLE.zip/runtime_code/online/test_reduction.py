"""Offline check of tree deletion and plane reuse along a recorded trajectory."""
import sys
from pathlib import Path

import numpy as np

KNOWN = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
sys.path[:0] = [str(KNOWN / "src"), str(KNOWN / "src" / "core"), str(KNOWN), str(KNOWN.parent / "online_v6")]

import mujoco  # noqa: E402
from ball_tree import NativeBallTree  # noqa: E402
from known_volume import build_volume_cover  # noqa: E402
from obstacle_reduction import ObstacleReductionLiuQPController  # noqa: E402
from robot import build_model, build_robot_certificate, certificate_world_state, set_configuration  # noqa: E402
from run import MVT_OUTWARD_PADDING, NEAR_DISTANCE, SAFETY_MARGIN, load_scene  # noqa: E402

scene = load_scene()
SPAN = float(sys.argv[1]) if len(sys.argv) > 1 else 0.075
CYCLES = int(sys.argv[2]) if len(sys.argv) > 2 else 3001
cover = build_volume_cover(scene.boxes, "ellipsoid", SPAN)
print(f"cover: {len(cover.centers)} ellipsoids ({SPAN * 1000:.0f} mm cells)")
model = build_model(scene)
robot = build_robot_certificate(model)
radii = np.array([s.radius for s in robot])
padding = NEAR_DISTANCE + SAFETY_MARGIN + MVT_OUTWARD_PADDING


def controller(mode):
    data = mujoco.MjData(model)
    common = dict(model=model, data=data, scene=scene, robot_spheres=robot, obstacle_centers=cover.centers,
                  representation="ellipsoid", obstacle_offsets=np.zeros(len(cover.centers)),
                  proxy_ids=cover.proxy_ids, safety_margin=SAFETY_MARGIN, near_distance=NEAR_DISTANCE,
                  contact_distance=0.0,
                  obstacle_index=NativeBallTree(cover.centers, cover.aabb_half_extents + MVT_OUTWARD_PADDING,
                                                query_padding=padding),
                  redundant_plane_pruning=True, ellipsoid_pair_threads=8, ellipsoid_pair_affinity_mask=0)
    return ObstacleReductionLiuQPController(**common, obstacle_shapes=cover.ellipsoid_shapes, reduction=mode), data


# "plain" = LiuQP's own erase-remove, counted the same way (no tree, no reuse).
plain, data_plain = controller("tree")
plain.use_tree = False
tree, data_tree = controller("tree")
reuse, data_reuse = controller("tree+reuse")
q_history = np.load(RUNS / "e0/ellipsoid_075mm_seed01/q_history.npy")
mismatches = 0
worst_conservatism = 0.0
for q in q_history[:CYCLES:2]:  # every other 20 ms cycle
    for c, d in ((plain, data_plain), (tree, data_tree), (reuse, data_reuse)):
        set_configuration(model, d, q)
    positions, _, _ = certificate_world_state(model, data_plain, robot)
    for i, (p, r) in enumerate(zip(positions, radii)):
        a = plain.active_planes_for_robot_sphere(i, p, float(r))[0]
        b = tree.active_planes_for_robot_sphere(i, p, float(r))[0]
        c = reuse.active_planes_for_robot_sphere(i, p, float(r))[0]
        if [x.obstacle_index for x in a] != [x.obstacle_index for x in b] or \
           any(abs(x.offset - y.offset) > 1e-12 for x, y in zip(a, b)):
            mismatches += 1
        exact = {x.obstacle_index: x.clearance for x in a}
        for x in c:
            if x.obstacle_index in exact:
                worst_conservatism = max(worst_conservatism, exact[x.obstacle_index] - x.clearance)
cycles = len(q_history[:CYCLES:2])
print(f"cycles checked: {cycles}; tree-mode plane mismatches vs LiuQP: {mismatches}")
for name, c in (("LiuQP erase-remove", plain), ("tree deletion", tree), ("tree + reuse", reuse)):
    k = c.counts
    print(f"{name:20s} per cycle: exact planes {k['exact_planes'] / cycles:6.1f}  obstacle tests "
          f"{(k['leaf_tests'] + k['node_tests']) / cycles:7.1f} (leaf {k['leaf_tests'] / cycles:7.1f}, node "
          f"{k['node_tests'] / cycles:6.1f})  spheres reused {k['reused_spheres'] / cycles:5.1f} of 65")
print(f"reuse: worst gap understatement vs exact planes {worst_conservatism * 1000:.3f} mm (safe direction)")
