#!/bin/bash
# Whole-arm geodesic objective (UR5_WHOLE_ARM=1) on the known-map scenarios.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
OUT=$PWD/scenes_wholearm
mkdir -p $OUT
jobs=()
for seed in $(seq 1 20); do
  jobs+=("wall ellipsoid $seed" "wall sphere $seed" "cage ellipsoid $seed" "cage_wide ellipsoid $seed" "exit ellipsoid $seed")
done
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 40)); do
    set -- ${jobs[$i]}
    id=$1_$2_geodesic_native_seed$(printf "%02d" $3)
    [ -f $OUT/$id/summary.json ] && continue
    ./known_job.sh $OUT $1 $2 geodesic_native $3 $((w * 2)) UR5_WHOLE_ARM=1
  done
}
for w in $(seq 0 39); do worker $w & done
wait
echo DONE > $OUT/WHOLEARM_DONE
