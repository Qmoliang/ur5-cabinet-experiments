"""Escape mode for LiuQP against a moving obstacle, used only when its QP is infeasible.

LiuQP's last QP (controller.last_qp_arrays and its row identities) holds one
plane row a_i = n_i^T J_i per robot-sphere / obstacle pair, with n_i pointing
robot -> obstacle.  The escape QP keeps every row that does not belong to the
moving obstacle (joint velocity limits, workspace, static planes) as a hard
constraint and minimises

    (eps / 2) |qdot|^2  +  sum_i w_i a_i . qdot      (eps = 1: |qdot| ~ 1 rad/s; 1e-3 left OSQP at max iterations)

over the moving obstacle's rows: each term is the speed at which a robot
sphere approaches the obstacle, so the minimum moves the arm away from it as
fast as the remaining constraints allow.  w_i = 1 / max(clearance_i, 5 mm), so
the closest pairs dominate.  Static rows are relaxed only to "do not get any
closer" (a pinned arm cannot always meet LiuQP's push-out speed); they are
never dropped -- dropping them drove the arm through the drawer wall when the
racket squeezed it there.  If even that is infeasible: None, the arm stops.
"""
from __future__ import annotations

import numpy as np
import osqp
from scipy import sparse


def escape_velocity(controller, moving_ids, epsilon=1.0, dt=0.02):
    arrays = getattr(controller, "last_qp_arrays", None)
    identity = getattr(controller, "_previous_qp_full_row_identity", None)
    if arrays is None or identity is None:
        return None
    _hessian, _gradient, A, lower, upper = arrays
    kinds = [row[0] for row in identity]
    proxies = np.array([row[2] for row in identity])
    moving = np.isin(proxies, list(moving_ids)) & np.isin(kinds, ["collision", "contact_recovery"])
    if not np.any(moving):
        return None
    rows = A[moving]
    clearance = np.where(np.array(kinds)[moving] == "collision", upper[moving] * dt, 0.0)
    weights = 1.0 / np.maximum(clearance, 0.005)
    direction = (weights[:, None] * rows).sum(axis=0)
    scale = float(np.linalg.norm(direction))
    if scale < 1e-12:
        return None
    direction /= scale
    n = A.shape[1]

    def solve(keep):
        if not np.all(np.isfinite(A[keep])):
            return None
        try:
            solver = osqp.OSQP()
            solver.setup(P=sparse.csc_matrix(epsilon * np.eye(n)), q=direction, A=sparse.csc_matrix(A[keep]),
                         l=lower[keep], u=upper[keep], verbose=False, polishing=True, max_iter=4000,
                         eps_abs=1e-6, eps_rel=1e-6)
            result = solver.solve()
        except Exception:   # OSQP rejects the data (e.g. a degenerate row): no escape, the arm stops
            return None
        if result.x is None or not str(result.info.status).lower().startswith("solved"):
            return None
        return np.asarray(result.x, dtype=float)

    # Static obstacle rows in escape: never approach (upper >= 0) instead of
    # LiuQP's push-out speed, so qdot = 0 stays feasible and nothing goes deeper.
    static = ~moving & np.isin(kinds, ["collision", "contact_recovery"])
    upper = np.where(static, np.maximum(upper, 0.0), upper)
    upper = np.maximum(upper, lower)   # joint rows near a joint limit can cross
    return solve(~moving)
