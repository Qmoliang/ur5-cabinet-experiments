"""Supplementary workspace certificate, preserving the original -1e-10 m tolerance.

Fresh model/trajectory reconstruction; never trusts the online guard's flags.
Original audit.json is never rewritten. Uses per-point active-joint bounds,
a Lipschitz envelope and an endpoint-consistent parabolic chord bound.
"""
from pathlib import Path
import os,sys,json,time
os.sched_setaffinity(0,set(map(int,sys.argv[2].split(','))) if len(sys.argv)>2 else {60,61,62,63})
import numpy as np,mujoco
from pilot_adapter import ROOT,online
folder=Path(sys.argv[1]);started=time.monotonic();entry=json.loads((ROOT/'INPUTS.json').read_text())[0]
model=mujoco.MjModel.from_xml_path(entry['scene']);data=mujoco.MjData(model);robot=online.build_robot_certificate(model)
body=np.array([p.body_id for p in robot]);local=np.array([p.local_center for p in robot]);radii=np.array([p.radius for p in robot]);q=np.load(folder/'trajectory.npz')['q'];lower=np.array([-.95,-.95,0.]);upper=np.array([.95,.95,1.35]);tol=np.longdouble('-1e-10')
masks=[];levers=[]
for bi,point in zip(body,local):
    own=int(bi);invariant=set()
    if model.body_jntnum[own]==1:
        j=int(model.body_jntadr[own])
        # Exclude only exact local axis alignment, not approximate alignment.
        if np.array_equal(np.cross(model.jnt_axis[j],point-model.jnt_pos[j]),np.zeros(3)):invariant.add(j)
    length=float(np.linalg.norm(point));active=[];b=own
    while b:
        length+=float(np.linalg.norm(model.body_pos[b]));j0=int(model.body_jntadr[b])
        for j in range(j0,j0+int(model.body_jntnum[b])):
            assert model.jnt_type[j]==mujoco.mjtJoint.mjJNT_HINGE
            if j not in invariant and j<6:active.append(j)
            length+=2*float(np.linalg.norm(model.jnt_pos[j]))
        b=int(model.body_parentid[b])
    masks.append([j in active for j in range(6)]);levers.append(np.nextafter(length*(1+1e-12),np.inf))
masks=np.asarray(masks,dtype=np.longdouble);levers=np.asarray(levers,dtype=np.longdouble)
def position(qi):
    data.qpos[:6]=qi;mujoco.mj_kinematics(model,data)
    return data.xpos[body]+np.einsum('nij,nj->ni',data.xmat[body].reshape(-1,3,3),local)
def gaps(p):return np.asarray(np.c_[p-radii[:,None]-lower,upper-p-radii[:,None]],dtype=np.longdouble)
positions=np.asarray([position(qi) for qi in q]);minimum=float('inf');subdivisions=0;bad=[];endpoint_violations=[];lipschitz_certified=0;parabolic_certified=0
def interval(a,b,pa,pb,depth=0):
    global minimum,subdivisions,lipschitz_certified,parabolic_certified
    ga=gaps(pa);gb=gaps(pb);minimum=min(minimum,float(ga.min()),float(gb.min()))
    if min(ga.min(),gb.min())<tol:return False
    delta=np.abs(np.asarray(b,dtype=np.longdouble)-np.asarray(a,dtype=np.longdouble));delta=np.where(delta>0,np.nextafter(delta,np.longdouble('inf')),delta)
    amount=masks@delta;excursion=np.nextafter(levers*amount,np.longdouble('inf'))
    excursion=np.where(amount==0,0,excursion)
    lip=np.maximum(ga,gb)-excursion[:,None]
    # K_i=2*lever_i bounds directional second derivative. Add the old 1 pm
    # midpoint allowance as 4e-12*t*(1-t), rather than subtracting it even
    # at known endpoints. Exactly invariant points require no interpolation.
    B=levers*amount**2+np.where(amount>0,np.longdouble('4e-12'),0)
    slope=gb-ga;tau=np.clip((B[:,None]-slope)/np.maximum(2*B[:,None],np.longdouble('1e-60')),0,1)
    parabola=ga+tau*(slope-B[:,None])+B[:,None]*tau*tau
    bound=np.nextafter(np.maximum(lip,parabola),np.longdouble('-inf'))
    if bound.min()>=tol:
        if lip.min()>=tol:lipschitz_certified+=1
        else:parabolic_certified+=1
        return True
    if depth>=12:return False
    subdivisions+=1;mid=(a+b)/2;pm=position(mid)
    return interval(a,mid,pa,pm,depth+1) and interval(mid,b,pm,pb,depth+1)
for i in range(len(q)-1):
    if min(gaps(positions[i]).min(),gaps(positions[i+1]).min())<tol:endpoint_violations.append(i)
    if not interval(q[i],q[i+1],positions[i],positions[i+1]):bad.append(i)
out=dict(passed=not bad,tolerance_m=float(tol),tolerance_changed=False,failed_intervals=bad,endpoint_violations=endpoint_violations,minimum_sampled_slack_m=minimum,subdivisions=subdivisions,lipschitz_certified_intervals=lipschitz_certified,parabolic_certified_intervals=parabolic_certified,original_audit_preserved=True,arithmetic='extended precision for bound arithmetic; same compiled-model kinematics and endpoint tolerance as original audit',scope='supplementary workspace-only continuous certificate; not a hardware certificate or replacement for obstacle/self/joint audits',wall_s=time.monotonic()-started)
(folder/'workspace_refinement.json').write_text(json.dumps(out,indent=2));print(json.dumps({k:v for k,v in out.items() if k not in ('failed_intervals','endpoint_violations')},indent=2))
