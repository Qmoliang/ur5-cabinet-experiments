from pathlib import Path
import os,json
import numpy as np
from lowdim_policy_v4 import LowDimPolicy as Previous

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.candidate_records=[]

    def _accept(self,v,delta,desired_eff,pose=False):
        before=dict(self.rejections);accepted=super()._accept(v,delta,desired_eff,pose)
        reason='accepted'
        if not accepted:
            changed=[key for key,value in self.rejections.items() if value>before.get(key,0)]
            reason=changed[-1] if changed else 'unclassified'
        H,g,A,l,u=self.ctx.controller.last_qp_arrays
        self.candidate_records.append(dict(cycle=int(self.k),mode=self.mode,reason=reason,accepted=bool(accepted),pose=bool(pose),q=self.q.copy(),previous=self.previous.copy(),velocity=np.asarray(v).copy(),delta=np.asarray(delta).copy(),desired_eff=np.asarray(desired_eff).copy(),linear_violation=float(max(np.max(l-A@v),np.max(A@v-u),0)),goal_error=self.error,pose_reference=None if not pose else self.pose_p.copy()))
        return accepted

    def summary(self):
        report=super().summary();folder=Path(os.environ['UNIFIED_CASE_DIR']);items=self.candidate_records
        np.savez_compressed(folder/'candidate_values.npz',q=np.asarray([x['q'] for x in items]),previous=np.asarray([x['previous'] for x in items]),velocity=np.asarray([x['velocity'] for x in items]),delta=np.asarray([x['delta'] for x in items]),desired_eff=np.asarray([x['desired_eff'] for x in items]))
        metadata=[{k:v for k,v in x.items() if k not in ('q','previous','velocity','delta','desired_eff','pose_reference')} for x in items]
        (folder/'candidate_metadata.json').write_text(json.dumps(metadata,indent=2))
        report.update(candidate_count=len(items),trace_scope='all candidate admissions/rejections of this diagnostic rerun; arrays retained for independent rejection analysis')
        return report
