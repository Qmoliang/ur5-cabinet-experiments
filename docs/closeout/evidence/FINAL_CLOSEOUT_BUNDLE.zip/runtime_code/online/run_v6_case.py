"""Run one v6 online LiuQP case with the O01/O02 formal settings.

Differences from external_neo_adaptive/run_study.py are only the knobs under
study: the map history mode and sphere cover scope (environment variables read
by incremental_proxy_manager), the timing mode, and an explicit CPU slice so
several cases can run side by side on a large host without sharing cores.
"""
from __future__ import annotations

import argparse

# Fixed external depth cameras, name:position:look-at[:fovy].  The drawer
# opening spans x = 0.35, y 0.24-0.58, z 0.51-0.65; the arm cameras never see
# the undersides of its front edges or the space just in front of them.
STATIC_CAMERA_PRESETS = {
    # one camera low in front, looking up into the opening
    "low": "static_low:0.05,0.40,0.30:0.42,0.40,0.58",
    # plus one high at the side, looking down across the opening and its edges
    "low_side": "static_low:0.05,0.40,0.30:0.42,0.40,0.58;static_side:0.15,-0.20,0.85:0.40,0.40,0.58",
    # E4: plus an overview camera high behind the robot looking down over the workspace
    # in front of the cabinet (where moving objects come from).
    "low_side_top": ("static_low:0.05,0.40,0.30:0.42,0.40,0.58;static_side:0.15,-0.20,0.85:0.40,0.40,0.58;"
                     "static_top:-0.35,0.35,1.55:0.20,0.35,0.45:90"),
    # E4: map cameras as low_side; the overview camera feeds only the moving-object detector.
    "low_side_detect": ("static_low:0.05,0.40,0.30:0.42,0.40,0.58;static_side:0.15,-0.20,0.85:0.40,0.40,0.58;"
                        "detect_top:-0.35,0.35,1.55:0.20,0.35,0.45:90"),
}
STATIC_CAMERA_NAMES: tuple = ()


def _scene_cameras(scene_json, detect=True):
    """The drawer preset's fixed cameras, placed relative to another scene's opening face x0 and target."""
    import json as _json

    import numpy as _np

    scene = _json.loads(open(scene_json, encoding="utf-8").read())
    x0 = min(b["center"][0] - b["half_size"][0] for b in scene["boxes"])
    tx, ty, tz = scene["waypoints"][-1]

    def v(*p):
        return ",".join(f"{c:.4f}" for c in p)

    spec = (f"static_low:{v(x0 - 0.30, ty, tz - 0.28)}:{v(x0 + 0.07, ty, tz)};"
            f"static_side:{v(x0 - 0.20, ty - 0.606, tz + 0.27)}:{v(x0 + 0.05, ty, tz)}")
    if detect:
        spec += f";detect_top:{v(x0 - 0.70, ty - 0.056, 1.55)}:{v(x0 - 0.15, ty - 0.056, 0.45)}:90"
    return spec
import json
import os
from pathlib import Path
import sys
import traceback

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import numpy as np  # noqa: E402
import psutil  # noqa: E402

import run_protocol_v3_async_online as online  # noqa: E402
from mixed_geometry import install as install_mixed_geometry
install_mixed_geometry(online)

MAP_MODES = {
    # name: (history mode, sphere cover scope)
    "legacy": ("full_history", "global"),
    "incremental": ("running_bound", "bucket"),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("representation", choices=("sphere", "ellipsoid"))
    parser.add_argument("--map", choices=sorted(MAP_MODES), required=True)
    parser.add_argument("--timing", choices=("paced", "sync"), required=True)
    parser.add_argument("--cpus", required=True, help="first:count CPU slice")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=3000)
    parser.add_argument("--minimum-core-semi-axis", type=float, default=0.0)
    parser.add_argument("--sphere-budget-scale", type=float, default=1.0)
    parser.add_argument("--start-seed", type=int, default=0,
                        help="0 = formal start pose; otherwise a seeded joint offset")
    parser.add_argument("--start-sigma", type=float, default=0.05,
                        help="per-joint standard deviation of the offset, rad")
    parser.add_argument("--geodesic", action="store_true",
                        help="pull LiuQP along the geodesic field of each published map")
    parser.add_argument("--reuse", action="store_true",
                        help="reuse separating planes across cycles until the map changes")
    parser.add_argument("--static-cameras", default="", choices=["", *STATIC_CAMERA_PRESETS],
                        help="add fixed external depth cameras (a preset)")
    parser.add_argument("--frozen-map", default="",
                        help="publish this fixed map (from build_frozen_map.py) every frame")
    parser.add_argument("--drop-frontier", action="store_true",
                        help="with --frozen-map: leave out the unseen-space cells")
    parser.add_argument("--look", action="store_true",
                        help="move the wrist camera to look at unseen space that blocks LiuQP")
    parser.add_argument("--frontier", action="store_true",
                        help="treat unseen space inside the cabinet's box as obstacles")
    parser.add_argument("--objects", type=int, default=0, help="E4: moving objects (0 = paired baseline)")
    parser.add_argument("--object-speed", type=float, default=0.25)
    parser.add_argument("--e4-controller", default="", choices=["", "liuqp", "liuqphe", "combined", "neo_matched", "neo_paper"],
                        help="E4: rule for the detected moving objects (enables the fixed-camera detector)")
    parser.add_argument("--accel", type=float, default=0.0, help="joint acceleration limit, rad/s^2")
    parser.add_argument("--e4-seed", type=int, default=0)
    parser.add_argument("--scene", default="drawer", choices=["drawer", "cage", "cage_wide", "shelf"],
                        help="E4: online scene (cage / shelf: known_v6/assets/scenes/*.json)")
    parser.add_argument("--far-start", action="store_true",
                        help="E4: start ~40 cm in front of the cabinet (assets/far_start_q.npy)")
    args = parser.parse_args()
    if args.scene != "drawer":
        known = HERE.parent / "known_v6" / "assets" / "scenes"
        os.environ["UR5_E4_SCENE_JSON"] = str(known / {"cage": "cage.json", "cage_wide": "cage_wide.json", "shelf": "iris_ur3_shelf_t0.json"}[args.scene])
        if args.static_cameras:
            args.static_cameras = "scene"
            STATIC_CAMERA_PRESETS["scene"] = _scene_cameras(os.environ["UR5_E4_SCENE_JSON"],
                                                           detect=True)
            designed = HERE / "assets" / f"design_cameras_{args.scene}.txt"
            if designed.exists():
                # Map cameras chosen for coverage of the free space around the target (e4/camera_design.py).
                STATIC_CAMERA_PRESETS["scene"] += ";" + designed.read_text().strip()
    os.environ["UR5_START_SEED"] = str(args.start_seed)   # seeds the online escape's planner
    os.environ["UR5_OBJECTS"] = str(args.objects)
    os.environ["UR5_OBJECT_SPEED"] = repr(args.object_speed)
    os.environ["UR5_E4_CONTROLLER"] = args.e4_controller
    os.environ["UR5_ACCEL_LIMIT"] = repr(args.accel) if args.accel > 0 else ""
    os.environ["UR5_E4_SEED"] = str(args.e4_seed)
    os.environ["UR5_E4_CONFIRM"] = "1" if args.e4_controller and os.environ.get("UR5_E4_NO_CONFIRM") != "1" else "0"
    os.environ["UR5_ONLINE_GEODESIC"] = "1" if args.geodesic else "0"
    os.environ["UR5_FRONTIER"] = "1" if args.frontier else "0"
    os.environ["UR5_ACTIVE_LOOK"] = "1" if args.look else "0"
    global STATIC_CAMERA_NAMES
    if args.static_cameras:
        spec = STATIC_CAMERA_PRESETS[args.static_cameras]
        os.environ["UR5_STATIC_CAMERAS"] = spec
        STATIC_CAMERA_NAMES = tuple(item.split(":")[0] for item in spec.split(";")
                                    if not item.startswith("detect_"))
    if args.frozen_map:
        os.environ["UR5_FROZEN_MAP"] = str(Path(args.frozen_map).resolve())
        os.environ["UR5_FROZEN_DROP_FRONTIER"] = "1" if args.drop_frontier else "0"
    if args.reuse:
        from online_reuse import OnlineReuseLiuQPController
        original_factory = online._new_controller

        def reuse_factory(*factory_args, **factory_kwargs):
            controller = original_factory(*factory_args, **factory_kwargs)
            controller.__class__ = OnlineReuseLiuQPController
            controller.init_reuse()
            return controller

        online._new_controller = reuse_factory
    initial_configuration = None
    if args.start_seed:
        q0 = np.asarray(online._protocol_scene("camera_quarter").q0, dtype=float)
        if args.far_start:
            q0 = np.load(HERE / "assets" / ("far_start_q.npy" if args.scene == "drawer"
                                            else f"far_start_q_{args.scene}.npy"))
        offset = np.random.default_rng(args.start_seed).normal(0.0, args.start_sigma, 6)
        initial_configuration = q0 + offset

    history_mode, cover_scope = MAP_MODES[args.map]
    os.environ["UR5_MAP_HISTORY_MODE"] = history_mode
    os.environ["UR5_SPHERE_COVER_SCOPE"] = cover_scope
    os.environ["UR5_SPHERE_BUDGET_SCALE"] = repr(args.sphere_budget_scale)
    first, count = (int(value) for value in args.cpus.split(":"))
    if count < 8:
        raise ValueError("a case needs at least 8 CPUs")
    cpus = tuple(range(first, first + count))
    # Same proportions as the formal perception_heavy layout.
    control = cpus[: max(3, 3 * count // 8)]
    OWN_PUBLICATION_CPU = os.environ.get("UR5_PUBLICATION_OWN_CPU", "1") == "1"
    perception = cpus[len(control):]
    if args.e4_controller:
        # The fixed-camera detector gets the last CPU of the slice to itself.
        os.environ["UR5_E4_DETECTOR_CPU"] = str(perception[-1])
        perception = perception[:-1]

    args.out.mkdir(parents=True, exist_ok=False)
    config = dict(vars(args), out=str(args.out), history_mode=history_mode,
                  environment={k:v for k,v in os.environ.items() if k.startswith("UR5_") or k in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS")},
                  sphere_cover_scope=cover_scope, control_cpus=control,
                  perception_cpus=perception,
                  initial_configuration=(
                      None if initial_configuration is None
                      else initial_configuration.tolist()
                  ))
    (args.out / "case.json").write_text(json.dumps(config, indent=2))
    process = psutil.Process()
    process.cpu_affinity(list(control))
    try:
        summary = online.run_one(
            args.representation, "mvt_simd", args.out,
            maximum_cycles=args.cycles,
            initial_configuration=initial_configuration,
            unknown_policy="observed_only",
            realtime_pacing=args.timing == "paced",
            perception_sync=args.timing == "sync",
            perception_executor="process",
            centervox_size=float(os.environ.get("UR5_CENTERVOX", "0.0075")), maximum_uncertainty_union_inflation=1.05,
            certificate_radius_limit=float(os.environ.get("UR5_CERT_RADIUS","0.025")),
            uncertainty_fusion_mode=os.environ.get("UR5_FUSION_MODE", "raw_directional_uncertainty"),
            direct_thin_axis_inflation=1.0, direct_tangent_subdivisions=1,
            direct_partition_mode="grid",
            minimum_core_semi_axis=args.minimum_core_semi_axis,
            sphere_cover_mode="matched",
            ellipsoid_cover_mode="matched", radius_limit_representation="both",
            camera_width=320, camera_height=180, camera_pixel_stride=1,
            camera_names=("ur5_depth_wrist", "ur5_depth_forearm") + STATIC_CAMERA_NAMES,
            scene_version="camera_quarter",
            record_dense_map_snapshots=True, sweep_guard_mode="audit_only",
            success_tolerance=0.001, success_hold_cycles=50, stop_on_success=False,
            perception_cpu_affinity=perception, control_cpu_affinity=control,
            # Map preparation (native geodesic build, MVT handle) on the last
            # control CPU, the controller's compute threads on the others, so
            # preparing a map never competes with a control cycle.
            ellipsoid_pair_threads=4,
            control_compute_cpu_affinity=tuple(control[:-1]) if OWN_PUBLICATION_CPU else None,
            publication_cpu_affinity=(control[-1],) if OWN_PUBLICATION_CPU else None,
            task_gain=2.0, max_task_speed=0.18, osqp_adaptive_row_threshold=512,
            osqp_tolerance=1e-5, osqp_max_iterations=4000,
        )
        (args.out / "summary.json").write_text(json.dumps(summary, indent=2, default=str))
        print(json.dumps({k: summary.get(k) for k in (
            "success", "final_error_m", "first_sustained_success_time_s",
            "final_proxy_count", "published_perception_frames")}, default=str))
    except Exception:
        (args.out / "failure.json").write_text(traceback.format_exc())
        raise


if __name__ == "__main__":
    main()
