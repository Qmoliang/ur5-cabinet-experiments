"""RL hook for run.py: a policy on top of the combined rule (residual RL pilot).

The QP (LiuQP rows + combined rule + self rows + fallback) stays the safety
layer.  Every DECISION_EVERY cycles the policy picks

    a[0:3]  command offset   0.15 m * tanh(a)    (added to the attraction point, faded to 0
                                                  within 2 cm of the target)
    a[3]    reaction_s       0.2 * exp(0.7 tanh a)   in [0.10, 0.40]
    a[4]    buffer_s         0.1 * exp(0.9 tanh a)   in [0.04, 0.25]
    a[5]    yield_s          0.6 * exp(0.7 tanh a)   in [0.30, 1.21]

a = 0 is the default combined rule exactly, so a zero-initialised policy
starts at the baseline.  mode "fixed" applies constant parameters (grid
search), mode "passive" only ends episodes and records outcomes (baselines).

run.py calls take_hook() once per run; the worker sets CURRENT before run.run.
"""
from __future__ import annotations

import numpy as np

CURRENT = None

DECISION_EVERY = 5
OBS_DIM = 41
ACT_DIM = 6
OFFSET_M = 0.15
SLOTS = 2

R_PROGRESS = 5.0
R_STEP = -0.01
R_CONTACT = -5.0
R_SUCCESS = 5.0
R_FALLBACK = -0.02


def take_hook():
    global CURRENT
    hook, CURRENT = CURRENT, None
    return hook


def params_from_action(a):
    a = np.asarray(a, dtype=float)
    offset = OFFSET_M * np.tanh(a[0:3])
    reaction = 0.2 * np.exp(0.7 * np.tanh(a[3]))
    buffer = 0.1 * np.exp(0.9 * np.tanh(a[4]))
    yield_s = 0.6 * np.exp(0.7 * np.tanh(a[5]))
    return offset, reaction, buffer, yield_s


class NumpyPolicy:
    """tanh MLP mean + state-independent log std (weights from the trainer)."""

    def __init__(self, path):
        w = np.load(path)
        self.layers = [(w[f"W{i}"], w[f"b{i}"]) for i in range(3)]
        self.log_std = w["log_std"]
        self.obs_mean, self.obs_std = w["obs_mean"], w["obs_std"]

    def mean(self, obs):
        x = np.clip((obs - self.obs_mean) / self.obs_std, -10, 10)
        for i, (W, b) in enumerate(self.layers):
            x = x @ W.T + b
            if i < 2:
                x = np.tanh(x)
        return x


class RLHook:
    def __init__(self, mode, *, policy_path=None, deterministic=False, params=None, seed=0,
                 success_tol=0.005, hold_cycles=50, no_offset=False):
        assert mode in ("policy", "fixed", "passive")
        self.mode = mode
        self.no_offset = bool(no_offset)   # ablation: the policy sets only the 3 rule scalars
        self.policy = NumpyPolicy(policy_path) if mode == "policy" else None
        self.deterministic = deterministic
        self.fixed = params or {}
        self.rng = np.random.default_rng(seed)
        self.success_tol, self.hold_cycles = success_tol, hold_cycles
        self.obs, self.act, self.logp, self.rew = [], [], [], []
        self.offset = np.zeros(3)
        self.prev_action = np.zeros(ACT_DIM)
        self.pending_reward = 0.0
        self.prev_error = None
        self.hold = 0
        self.outcome = dict(success=False, contact=False, contact_kinds={}, success_s=None,
                            fallback_cycles=0, cycles=0, min_object_distance=None)
        self.last_object_distance = 1.0

    # ---- binding ----------------------------------------------------------
    def bind(self, *, rule, objects, target, scene_boxes, dt):
        self.rule, self.objects, self.target, self.dt = rule, objects, np.asarray(target, float), dt
        lo = np.min([np.asarray(b.center) - np.asarray(b.half_size) for b in scene_boxes], axis=0)
        hi = np.max([np.asarray(b.center) + np.asarray(b.half_size) for b in scene_boxes], axis=0)
        self.box_lo, self.box_hi = lo, hi
        if self.mode == "fixed" and rule is not None:
            rule.reaction_s = float(self.fixed.get("reaction_s", rule.reaction_s))
            rule.buffer_s = float(self.fixed.get("buffer_s", rule.buffer_s))
            rule.yield_s = float(self.fixed.get("yield_s", rule.yield_s))

    # ---- observation -------------------------------------------------------
    def observe(self, t, ee, q, qdot):
        to_box = np.clip(ee, self.box_lo, self.box_hi) - ee
        slots = []
        trig, since = 0.0, 0.0
        if self.objects is not None:
            ts = self.objects.trigger_s
            if ts is not None and ts >= 0:
                trig, since = 1.0, min(t - ts, 4.0)
            for obj in self.objects.objects:
                p = obj.position(t)
                if p is None:
                    continue
                slots.append((float(np.linalg.norm(p - ee)), np.r_[p - ee, obj.velocity(t), 1.0]))
        slots.sort(key=lambda s: s[0])
        feats = [s[1] for s in slots[:SLOTS]] + [np.zeros(7)] * (SLOTS - min(len(slots), SLOTS))
        return np.concatenate([
            ee - self.target, to_box, q, qdot, *feats, [trig, since, min(self.last_object_distance, 1.0)],
            self.prev_action,
        ]).astype(np.float64)

    # ---- per cycle ---------------------------------------------------------
    def before_solve(self, cycle, t, ee, q, qdot):
        """Returns the command offset; sets the rule's parameters at decision cycles."""
        # The offset fades out within 2 cm of the target, so the final approach is the plain rule
        # (an exploring policy's offset would otherwise keep the gripper off the 5 mm goal).
        gate = float(np.clip((np.linalg.norm(ee - self.target) - 0.02) / 0.13, 0.0, 1.0))
        if self.mode != "policy" or cycle % DECISION_EVERY:
            return self.offset * gate
        obs = self.observe(t, ee, q, qdot)
        mean = self.policy.mean(obs)
        std = np.exp(self.policy.log_std)
        a = mean if self.deterministic else mean + std * self.rng.standard_normal(ACT_DIM)
        logp = float(-0.5 * np.sum(((a - mean) / std) ** 2) - np.sum(self.policy.log_std)
                     - 0.5 * ACT_DIM * np.log(2 * np.pi))
        if self.obs:
            self.rew.append(self.pending_reward)
        self.pending_reward = 0.0
        self.obs.append(obs)
        self.act.append(a)
        self.logp.append(logp)
        self.prev_action = np.clip(a, -3, 3)
        if self.no_offset:
            self.prev_action[0:3] = 0.0
        offset, reaction, buffer, yield_s = params_from_action(a)
        self.offset = np.zeros(3) if self.no_offset else offset
        if self.rule is not None:
            self.rule.reaction_s, self.rule.buffer_s, self.rule.yield_s = reaction, buffer, yield_s
        return self.offset * gate

    def after_step(self, cycle, error, penetrating, protective, fallback_cycles, object_distance):
        """Accumulates reward; True ends the episode."""
        t = (cycle + 1) * self.dt
        if object_distance is not None:
            self.last_object_distance = float(object_distance)
            m = self.outcome["min_object_distance"]
            self.outcome["min_object_distance"] = object_distance if m is None else min(m, object_distance)
        if self.prev_error is not None:
            self.pending_reward += R_PROGRESS * (self.prev_error - error)
        self.prev_error = error
        if cycle % DECISION_EVERY == 0:
            self.pending_reward += R_STEP
        new_fallbacks = fallback_cycles - self.outcome["fallback_cycles"]
        self.pending_reward += R_FALLBACK * new_fallbacks
        self.outcome["fallback_cycles"] = fallback_cycles
        self.outcome["cycles"] = cycle + 1
        if protective["stopped"]:
            self.outcome["contact"] = True
            self.outcome["contact_kinds"] = dict(protective["kinds"])
            self.pending_reward += R_CONTACT
            return True
        objects_done = self.objects is None or self.objects.all_done(t)
        if error < self.success_tol and not penetrating and objects_done:
            self.hold += 1
        else:
            self.hold = 0
        if self.hold >= self.hold_cycles:
            self.outcome["success"] = True
            self.outcome["success_s"] = t - self.hold_cycles * self.dt
            self.pending_reward += R_SUCCESS
            return True
        return False

    def trajectory(self):
        rew = list(self.rew)
        if self.obs:
            rew.append(self.pending_reward)
        n = len(self.obs)
        return dict(obs=np.asarray(self.obs).reshape(n, OBS_DIM), act=np.asarray(self.act).reshape(n, ACT_DIM),
                    logp=np.asarray(self.logp), rew=np.asarray(rew[:n]))
