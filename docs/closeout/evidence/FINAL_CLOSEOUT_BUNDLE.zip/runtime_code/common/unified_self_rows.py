"""Self-collision rows for every E4 controller: the arm must not move into itself.

For robot certificate spheres i, j on bodies that are neither the same nor
parent/child, with gap d = |p_j - p_i| - r_i - r_j - SELF_MARGIN and n the unit
vector from i to j, the gap may not close faster than LiuQP allows for an
obstacle:  n^T (J_i - J_j) qdot <= d / dt  (LiuQP form)  or, for NEO,
<= xi (d - d_s) / (d_i - d_s)  (its velocity damper).  Pairs already closer than
SELF_MARGIN at the start pose are left out (permanent overlaps of the
conservative certificate spheres at the joints).  Only pairs within QUERY rows.
"""
from __future__ import annotations

import numpy as np

SELF_MARGIN = 0.005
QUERY = 0.05


class SelfCollisionRows:
    def __init__(self, model, data, robot, dt, certificate_world_positions):
        self.dt = float(dt)
        bodies = np.array([s.body_id for s in robot])
        parent = model.body_parentid
        positions = certificate_world_positions(data, robot)
        radii = np.array([s.radius for s in robot])
        pairs = []
        for i in range(len(robot)):
            for j in range(i + 1, len(robot)):
                a, b = int(bodies[i]), int(bodies[j])
                if a == b or parent[a] == b or parent[b] == a:
                    continue
                gap = np.linalg.norm(positions[j] - positions[i]) - radii[i] - radii[j]
                if gap < SELF_MARGIN:
                    continue
                pairs.append((i, j))
        self.pairs = np.array(pairs, dtype=np.int64).reshape(-1, 2)
        self.rows_last = 0

    def geometry(self, positions, jacobians, radii):
        """(i, j, gap, n, relative jacobian row) for pairs within QUERY."""
        if not len(self.pairs):
            return []
        i, j = self.pairs[:, 0], self.pairs[:, 1]
        delta = positions[j] - positions[i]
        length = np.linalg.norm(delta, axis=1)
        gap = length - radii[i] - radii[j] - SELF_MARGIN
        near = np.nonzero((gap < QUERY) & (length > 1e-9))[0]
        out = []
        for k in near:
            n = delta[k] / length[k]
            out.append((int(i[k]), int(j[k]), float(gap[k]), n @ (jacobians[i[k]] - jacobians[j[k]])))
        return out

    def rows(self, positions, jacobians, radii):
        out = [(row, gap / self.dt, ("self", a, b)) for a, b, gap, row in self.geometry(positions, jacobians, radii)]
        self.rows_last = len(out)
        return out
