#!/bin/bash
# One known-environment robustness run: representation span seed slot
cd /mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6
rep=$1 span=$2 seed=$3 slot=$4
OUT=/mnt/ssd2/hsjed/ur5_cabinet/v6runs/known_robust
id=${rep}_$(printf "%03d" $(python3 -c "print(round($span*1000))"))mm_seed$(printf "%02d" $seed)
cpu=$((48 + 2*slot))
UR5_KNOWN_CELL_SPAN=$span UR5_KNOWN_OUT=$OUT/$id UR5_START_SEED=$seed OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MUJOCO_GL=egl \
  taskset -c $cpu-$((cpu+1)) timeout 3600 ~/envs/ur5cab/bin/python -c "
import sys,json,time; sys.path[:0]=[\"src\",\"src/core\",\".\"]
import run; t=time.time(); s=run.run(\"$rep\", maximum_cycles=3000)
print(json.dumps({k:s.get(k) for k in (\"success\",\"final_error_m\",\"proxy_count\")}), \"wall_s\", round(time.time()-t,1))
" > $OUT/$id.log 2>&1
