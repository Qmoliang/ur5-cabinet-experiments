Incremental paired evidence archive. All sphere outcomes/audits and paired summaries are included.
The full ellipsoid frozen runtime is already public at the URL in BASELINE_ARCHIVE_REFERENCE.json.
To assemble the sphere runtime source: extract runtime_code/ from that baseline ZIP as code/, then overlay the code/ files from this archive. Verify against FROZEN_MANIFEST.json.
Input manifests retain original server paths; this is an evidence/source archive, not a validated portable one-command rerun package.
No experimental data or algorithms were changed for this packaging. The complete 13.9 MB paired archive remains in the original server and local delivery folder.
