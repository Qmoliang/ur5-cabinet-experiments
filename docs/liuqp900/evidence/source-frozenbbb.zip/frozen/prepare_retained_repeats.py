from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
original=json.loads((ROOT/'retained_jobs.json').read_text())[1]
jobs=[dict(original,name='retained_stall_repeat_'+str(i)) for i in [1,2]]
(ROOT/'retained_repeats.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'RETAINED_REPEAT_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},reason='repeat exact real-stall start with unchanged geometry/objective/thresholds, including measured compute delays; no scene or seed search',not_independent_generalization_test=True),indent=2))
print(json.dumps(jobs))
