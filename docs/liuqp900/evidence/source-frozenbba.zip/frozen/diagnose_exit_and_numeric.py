from pathlib import Path
import os,json
os.sched_setaffinity(0,{48,49,50,51})
import numpy as np
from pilot_adapter import ROOT,build,online
from reserve_objective import solve_reserve
from verified_qp import solve_verified

ctx=build('iris_4shelves_t2');c=ctx.controller;c.osqp_adaptive_row_threshold=10**9;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.osqp_max_iterations=3000;c.pilot_verified_fallback=True
low=ctx.model.jnt_range[:6,0]+.015;high=ctx.model.jnt_range[:6,1]-.015;out=[]
for name in ['release_from_real_stall','release_only_from_real_stall']:
    folder=ROOT/'trials'/name
    if not (folder/'result.json').exists():continue
    r=json.loads((folder/'result.json').read_text());tr=np.load(folder/'trajectory.npz');ps=r['policy_summary'];hit=next(x for x in ps['events'] if x['event']=='release_selected');j=hit['joint'];sign=hit['sign'];hitV=.5*hit['error_m']**2
    eligible=np.flatnonzero(.5*tr['goal_error']**2<hitV-.05*(hitV-.5e-6));points=sorted(set(([int(eligible[0])+1] if len(eligible) else [])+[len(tr['q'])-1]))
    for index in points:
        q=tr['q'][index].copy();prev=tr['velocity'][index-1].copy() if index else np.zeros(6)
        for _ in range(10):
            if np.max(np.abs(prev))<1e-8:break
            c.applied_velocity=prev.copy();online.set_configuration(ctx.model,ctx.data,q);lo,hi=c.joint_velocity_bounds();brake=prev-np.clip(prev,-.2,.2)
            brake=ctx.guard.filter(ctx.proxy_guard,q,prev,brake,lo,hi,index,ctx.metadata['generation']);q=q+.02*brake;prev=brake
        online.set_configuration(ctx.model,ctx.data,q);c.applied_velocity=prev.copy();c.solve(ctx.target);H,g,A,l,u=c.last_qp_arrays;s=c.pilot_nominal;p=online.attachment_position(ctx.model,ctx.data);e=float(np.linalg.norm(p-ctx.target));d=(ctx.target-p)/e
        nominal=solve_reserve(H,g,A,l,u,q,prev,low,high,c.task_weight,e,.02,10.) if name=='release_from_real_stall' else dict(velocity=s['x'])
        v=nominal['velocity'];reserve=float(q[j]-low[j] if sign>0 else high[j]-q[j]);release_rate=float(sign*v[j]);goal_rate=float(d@s['J']@v)
        goal_time=e/max(goal_rate,1e-7);limit_time=float('inf') if release_rate>=0 else reserve/(-release_rate)
        out.append(dict(name=name,index=index,time_s=index*.02,joint=j,release_sign=sign,q=q.tolist(),error_mm=e*1000,reserve_rad=reserve,nominal_goal_rate_mm_s=goal_rate*1000,nominal_release_rate=release_rate,estimated_goal_time=goal_time,estimated_limit_time=limit_time,credit_condition=.5*e*e<hitV-.05*(hitV-.5e-6),old_no_reconsume_condition=release_rate>=-1e-6,new_time_budget_condition=limit_time>=goal_time))
folder=ROOT/'trials/reserve_metric';r=json.loads((folder/'result.json').read_text());z=np.load(folder/(r['snapshots'][-1]+'.npz'));q=z['q'];online.set_configuration(ctx.model,ctx.data,q);p=online.attachment_position(ctx.model,ctx.data);e=float(np.linalg.norm(p-ctx.target));H,g,A,l,u=[z[k] for k in ['H','g','A','l','u']]
aux=solve_reserve(H,g,A,l,u,q,z['previous'],low,high,c.task_weight,e,.02,10.)
forward=solve_verified(H,g+aux['delta'],A,l,u)
numeric=dict(original_failure=r['maximum_auxiliary_forward_difference'],independent_forward_difference=float(np.max(np.abs(forward.x-aux['velocity']))),forward_kkt_relative=forward.info.relative_stationarity,forward_complementarity=forward.info.complementarity)
(ROOT/'EXIT_AND_NUMERIC_DIAGNOSIS.json').write_text(json.dumps(dict(exit_checks=out,numerical_check=numeric),indent=2));print(json.dumps(dict(exit_checks=out,numerical_check=numeric),indent=2))
