import json,os,copy
from pathlib import Path
import numpy as np
from goal_entry_policy_activated import LowDimPolicy as Previous

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.last_failed_heading=None
    def _surface_action(self,c,s,arrays,geometry):
        answer=super()._surface_action(c,s,arrays,geometry)
        if answer is None and self.circulation_tangent is not None and np.max(np.abs(self.previous))<1e-8:
            self.last_failed_heading=dict(cycle=self.k,q=self.q.tolist(),previous=self.previous.tolist(),mode=self.mode,blocker_id=list(self.blocker_id),stored_tangent=self.circulation_tangent.tolist(),projected_tangent=self._tangent(geometry).tolist(),reverse_used=self.reverse_used,feature_last_progress=self.feature_last_progress,pending_memory=copy.deepcopy(self.pending_memory),memories=copy.deepcopy(self.memories))
        return answer
    def summary(self):
        out=super().summary()
        if self.last_failed_heading is not None:(Path(os.environ['UNIFIED_CASE_DIR'])/'failed_heading_state.json').write_text(json.dumps(self.last_failed_heading,indent=2))
        out['heading_observation_only']=True;return out
