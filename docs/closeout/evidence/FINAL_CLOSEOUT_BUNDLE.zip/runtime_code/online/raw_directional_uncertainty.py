"""Causal directional leaves refit from all retained raw error sets.

Grouping is spatial/directional only; every raw center and full error matrix is
retained. Refit avoids compounding an earlier enclosing ellipsoid or freezing
its representative/frame. PSD checks cover all historical translated inputs.
"""
import numpy as np
from pointcloud_proxy import minkowski_outer_shapes

class RawDirectionalJoin:
    MAX_LEAVES_PER_VOXEL=49
    def __init__(self):
        self.cells={};self.total_samples=0;self.minimum_psd_slack=float('inf');self.generation=-1
    @staticmethod
    def bins(shapes):
        val,vec=np.linalg.eigh(shapes);axis=vec[:,:,-1];face=np.argmax(np.abs(axis),axis=1);dominant=axis[np.arange(len(axis)),face]
        canonical=axis/dominant[:,None];rest=np.array([[1,2],[0,2],[0,1]])[face];uv=np.take_along_axis(canonical,rest,axis=1)
        ij=np.clip(np.floor((uv+1)*2).astype(int),0,3);ids=face*16+ij[:,0]*4+ij[:,1];ids[val[:,-1]<=2*np.maximum(val[:,0],1e-18)]=48
        return ids
    def update(self,points,shapes,keys,inverse,representatives):
        self.generation+=1;codes=self.bins(shapes);unique,owners=np.unique(np.c_[inverse,codes],axis=0,return_inverse=True)
        if not len(unique):return [self.cells[key] for key in keys]
        order=np.argsort(owners,kind='stable');first=np.r_[0,np.flatnonzero(np.diff(owners[order]))+1];ends=np.r_[first[1:],len(order)]
        point_chunks=[];shape_chunks=[];generations=[]
        for i,(spatial,code) in enumerate(unique):
            key=keys[spatial];old=self.cells.get(key,{}).get(int(code));take=order[first[i]:ends[i]]
            raw_points=points[take].copy();raw_shapes=shapes[take].copy();seen=frozenset({self.generation})
            if old is not None:
                raw_points=np.concatenate([old['raw_points'],raw_points]);raw_shapes=np.concatenate([old['raw_shapes'],raw_shapes]);seen=old['generations']|seen
            point_chunks.append(raw_points);shape_chunks.append(raw_shapes);generations.append(seen)
        sizes=np.array([len(x) for x in point_chunks]);starts=np.r_[0,np.cumsum(sizes)[:-1]];owner=np.repeat(np.arange(len(sizes)),sizes)
        raw_points=np.concatenate(point_chunks);raw_shapes=np.concatenate(shape_chunks)
        centers=np.add.reduceat(raw_points,starts,axis=0)/sizes[:,None]
        delta=raw_points-centers[owner]
        translated=minkowski_outer_shapes(raw_shapes,np.einsum('ni,nj->nij',delta,delta))
        means=np.add.reduceat(translated,starts,axis=0)/sizes[:,None,None];_,R=np.linalg.eigh(means)
        frames=R[owner];B=np.einsum('nji,njk,nkl->nil',frames,translated,frames);diag=np.diagonal(B,axis1=1,axis2=2)
        bound=diag+np.sum(np.abs(B),axis=2)-np.abs(diag);D=np.maximum.reduceat(bound,starts,axis=0)
        D+=np.maximum(D.max(axis=1),1e-18)[:,None]*2e-14+1e-18;outer=np.einsum('nik,nk,njk->nij',R,D,R)
        slack=float(np.linalg.eigvalsh(outer[owner]-translated)[:,0].min())
        if slack < -1e-12:raise AssertionError('refitted directional leaf lost a historical raw support')
        for i,(spatial,code) in enumerate(unique):
            self.cells.setdefault(keys[spatial],{})[int(code)]=dict(center=centers[i].copy(),R=R[i].copy(),D=D[i].copy(),shape=outer[i].copy(),count=int(sizes[i]),generations=generations[i],raw_points=point_chunks[i],raw_shapes=shape_chunks[i])
        self.minimum_psd_slack=min(self.minimum_psd_slack,slack);self.total_samples+=len(points)
        return [self.cells[key] for key in keys]
