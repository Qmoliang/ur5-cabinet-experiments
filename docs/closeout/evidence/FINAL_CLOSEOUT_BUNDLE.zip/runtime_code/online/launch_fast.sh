#!/bin/bash
# Usage: launch_fast.sh OUTDIR "flags" seed... ; one run per 16-CPU slice, all in parallel.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4 UR5_EXTRA_ENV=${UR5_EXTRA_ENV:-}
OUT=$1; FLAGS=$2; shift 2
mkdir -p $OUT
slot=0
for seed in "$@"; do
  id=seed$(printf "%02d" $seed)
  systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_ACTIVE_LOOK \
    timeout 2400 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py ellipsoid --map incremental \
    --timing paced --cpus $(($slot * 16)):16 --start-seed $seed $FLAGS --out $OUT/$id > $OUT/$id.log 2>&1 &
  slot=$((slot + 1))
done
wait
echo DONE > $OUT/DONE
