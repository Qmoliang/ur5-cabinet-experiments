import os,json,sys
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy_v3 import LowDimPolicy
out=[]
for name in sys.argv[1:]:
    folder=ROOT/'trials'/name
    if not (folder/'result.json').exists():continue
    tr=np.load(folder/'trajectory.npz');q=tr['q'][-1];job=json.loads((folder/'job.json').read_text());result=json.loads((folder/'result.json').read_text());ctx=build('iris_4shelves_t2',start=q);c=ctx.controller
    c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
    p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,np.zeros(6));s=c.pilot_nominal;arrays=c.last_qp_arrays;H,g,A,l,u=arrays
    ps=result['policy_summary'];p.memories=json.loads((folder/'goalward_memories.json').read_text());p.blocker_id=ps.get('blocker_id')
    if p.blocker_id is not None:p.mode='OPEN'
    record=dict(name=name,error_mm=p.error*1000,q=q.tolist(),goal_q=p.qg.tolist(),posture_error=(p.P@(q-p.qg)).tolist(),rejections=ps.get('rejections'),proposals=[])
    def check(label,answer):
        if answer is None:record['proposals'].append(dict(label=label,solved=False));return
        v=np.clip(answer['velocity'],*c.joint_velocity_bounds());guard=ctx.guard;pg=ctx.proxy_guard
        accepted=[a for a in [1.,.75,.5,.25,.125,.0625,0.] if guard.braking_safe(pg,q,a*v)]
        current=q.copy();speed=v.copy();failed=None
        for step in range(10):
            nxt=current+.02*speed
            if not guard.braking_safe(pg,current,speed):
                margins=[]
                for t in [0.,.25,.5,.75,1.]:
                    pts=guard.positions(current+t*(nxt-current));gap,normal=pg.nearest(pts,guard.radii,reach=.04);i=int(np.argmin(gap))
                    margins.append(dict(fraction=t,proxy_gap_mm=1000*float(gap[i]),robot_sphere=i,self_gap_mm=1000*guard.self_gap(pts),workspace_mm=1000*float(min(np.min(pts-guard.radii[:,None]-guard.workspace_lower),np.min(guard.workspace_upper-pts-guard.radii[:,None])))))
                failed=dict(step=step,samples=margins);break
            current=nxt;speed-=np.clip(speed,-.2,.2)
            if np.max(np.abs(speed))<1e-12:break
        forces=np.abs(answer['original_dual'])*np.linalg.norm(A,axis=1);top=[dict(row=s['row_ids'][i],dual=float(answer['original_dual'][i]),upper=float(u[i])) for i in np.argsort(-forces)[:5]]
        record['proposals'].append(dict(label=label,solved=True,velocity=v.tolist(),safe_scales=accepted,first_failed_braking_check=failed,top=top))
    check('goal_objective',p._solve(c,s,arrays))
    if p.blocker_id is not None:
        geometry=p._geometry();point,n,J,gap=geometry;b=n@J;b/=np.linalg.norm(b);support=p._support(c,s,arrays,b);record['selected_blocker']=p.blocker_id;record['support']=support
        if support is not None:
            check('half_support_release',p._solve(c,s,arrays,release=(b,.5*support)))
            check('smallest_release',p._solve(c,s,arrays,release=(b,.5*support/2**11)))
    out.append(record);print(json.dumps(record),flush=True)
(ROOT/'ENTRY_ADMISSION_DIAGNOSIS.json').write_text(json.dumps(out,indent=2))
