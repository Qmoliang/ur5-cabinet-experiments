"""Use only CPU 48-51 while the older frozen batch completes on 52-55."""
from pathlib import Path
script=Path(__file__).with_name('launch_batch.py').read_text()
script=script.replace('cpu_slots.put([48,49,50,51]);cpu_slots.put([52,53,54,55])','cpu_slots.put([48,49,50,51])').replace('max_workers=2','max_workers=1')
exec(compile(script,str(Path(__file__).with_name('launch_batch.py')),'exec'))
