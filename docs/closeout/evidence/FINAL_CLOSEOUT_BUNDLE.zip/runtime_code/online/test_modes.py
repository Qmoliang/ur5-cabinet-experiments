"""One plan from the E0 seed-2 trapped pose in each subgoal mode, same random seed."""
import sys
from pathlib import Path

import numpy as np

KNOWN = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
sys.path[:0] = [str(KNOWN / "src"), str(KNOWN / "src" / "core"), str(KNOWN), str(KNOWN.parent / "online_v6")]

from ball_tree import NativeBallTree  # noqa: E402
from guidance import ConfigurationChecker, StallTriggeredGuidance  # noqa: E402
from known_volume import build_volume_cover  # noqa: E402
from robot import build_model, build_robot_certificate  # noqa: E402
from run import load_scene  # noqa: E402

scene = load_scene()
model = build_model(scene)
robot = build_robot_certificate(model)
cover = build_volume_cover(scene.boxes, "ellipsoid", 0.075)
history = np.load("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e0/ellipsoid_075mm_seed02/q_history.npy")
target = np.asarray(scene.waypoints[-1], dtype=float)
for mode in ("rrt", "rrt_dense", "iris"):
    checker = ConfigurationChecker(model, robot, cover.centers, "ellipsoid", shapes=cover.ellipsoid_shapes,
                                   margin=0.016, index=NativeBallTree(cover.centers, cover.aabb_half_extents))
    guidance = StallTriggeredGuidance(checker, target, seed=2, references=[history[0]], subgoal_mode=mode)
    guidance.plan(history[-1], cycle=0)
    event = guidance.stats.events[-1]
    print(mode, {k: event.get(k) for k in ("event", "path_vertices", "path_points", "regions", "subgoals", "plan_ms")})
