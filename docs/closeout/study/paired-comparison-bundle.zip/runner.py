from pathlib import Path
import sys,os,json,time,traceback,hashlib,argparse
U=Path(__file__).resolve().parents[2]
def main():
 parser=argparse.ArgumentParser();parser.add_argument("id");parser.add_argument("--out",required=True);parser.add_argument("--cpu-first",type=int,default=0);parser.add_argument("--planner-cpus",default="96,97");parser.add_argument("--code-dir",default=str(U/"code"));parser.add_argument("--cycles",type=int,default=None);args=parser.parse_args()
 CODE=Path(args.code_dir).resolve();source_path=U/'entries'/(args.id+'.json');e=json.loads(source_path.read_text());assert e['mode']=='online';e=dict(e,representation='sphere');out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
 for name in list(os.environ):
  if name.startswith('UR5_'):os.environ.pop(name)
 os.environ.update(OMP_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',MUJOCO_GL='egl',UNIFIED_CASE_DIR=str(out),UR5_GUIDANCE='escape_chain',UR5_ESCAPE_TRACK='joint',UR5_ACCEL_LIMIT='10',UR5_OBJECTS='0',UR5_RACKET='0',UR5_E4_SAFETY='1',UR5_SUCCESS_TOL='.001')
 sys.path.insert(0,str(CODE/'common'));from unified_policy import POLICY,POLICY_SHA256
 if args.cycles is None:args.cycles=POLICY['maximum_cycles']
 assert args.cycles==POLICY['maximum_cycles']
 import numpy as np,mujoco
 start=time.perf_counter();result=dict(id=e['id'],mode=e['mode'],task=e['task'],seed=e['seed'],policy_sha256=POLICY_SHA256,status='running',representation='sphere',paired_baseline='final_r17')
 commonhash={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (CODE/'common').iterdir() if p.is_file()}
 try:
  if e['mode']=='known':
   os.sched_setaffinity(0,set(range(args.cpu_first,args.cpu_first+8)))
   os.environ.update(UR5_SCENE_JSON=e['scene_json'],UR5_START_Q_FILE=e['starts'],UR5_START_SEED=str(e['seed']),UR5_KNOWN_OUT=str(out),UR5_CONTROLLER='liuqp',UR5_ATTRACTION='straight')
   sys.path.insert(0,str(CODE/'known/known_v6'));import run as kr
   scene=kr.load_scene();(out/'runtime_scene.xml').write_text(kr._robot_module.build_xml(scene))
   (out/'job.json').write_text(json.dumps(dict(entry=e,policy=POLICY,policy_sha256=POLICY_SHA256,common_hashes=commonhash,code_root=str(CODE),environment={k:v for k,v in os.environ.items() if k.startswith('UR5_')}),indent=2))
   d=kr.run('ellipsoid',maximum_cycles=args.cycles)
  else:
   os.environ.update(UR5_E4_SCENE_JSON=e['scene_json'],UR5_E4_CONTROLLER='liuqp',UR5_E4_SEED='0',UR5_E4_CONFIRM='1',UR5_CERT_RADIUS='.025',UR5_COMPUTE_DELAY='1',UR5_NO_RETURN_FREE='1',UR5_CENTERVOX=str(POLICY['measured_support_cell_span_m']),UR5_STATIC_DEDUP='1',UR5_FIT_WORKERS='8',UR5_FRONTIER_MERGE='0',UR5_FRONTIER_CELL_VOXELS='1',UR5_FUSION_MODE='raw_directional_uncertainty',UR5_CELL_CERTIFICATES='1',UR5_PLANNER_CPUS=args.planner_cpus,UR5_MAP_HISTORY_MODE='running_bound',UR5_SPHERE_COVER_SCOPE='bucket',UR5_FRONTIER='1',UR5_ACTIVE_LOOK='1')
   template=mujoco.MjModel.from_xml_path(str(CODE/'common/robot_only.xml'))
   from camera_rig import fixed_rig
   rig,records=fixed_rig(template,np.load(e['starts']),e['target']);os.environ['UR5_STATIC_CAMERAS']=rig
   sys.path.insert(0,str(CODE/'online'));import run_protocol_v3_async_online as online
   from mixed_geometry import install;install(online)
   cpus=list(range(args.cpu_first,args.cpu_first+16));control=tuple(cpus[:6]);perception=tuple(cpus[6:]);os.sched_setaffinity(0,set(control))
   config=dict(entry=e,source_entry_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),representation='sphere',initial_configuration=e['initial_q'],target=e['target'],environment={k:v for k,v in os.environ.items() if k.startswith('UR5_')},policy=POLICY,policy_sha256=POLICY_SHA256,common_hashes=commonhash,code_root=str(CODE),cameras=records,control_cpus=control,perception_cpus=perception)
   (out/'case.json').write_text(json.dumps(config,indent=2));(out/'job.json').write_text(json.dumps(config,indent=2))
   d=online.run_one('sphere','mvt_simd',out,maximum_cycles=args.cycles,initial_configuration=np.array(e['initial_q']),unknown_policy='observed_only',realtime_pacing=True,perception_sync=False,perception_executor='process',centervox_size=POLICY['measured_support_cell_span_m'],maximum_uncertainty_union_inflation=1.05,certificate_radius_limit=.025,uncertainty_fusion_mode='raw_directional_uncertainty',direct_thin_axis_inflation=1.,direct_tangent_subdivisions=1,direct_partition_mode='grid',minimum_core_semi_axis=0.,sphere_cover_mode='matched',ellipsoid_cover_mode='matched',radius_limit_representation='both',camera_width=320,camera_height=180,camera_pixel_stride=1,camera_names=('ur5_depth_wrist','ur5_depth_forearm')+tuple(x['name'] for x in records),scene_version='camera_quarter',record_dense_map_snapshots=True,sweep_guard_mode='audit_only',success_tolerance=.001,success_hold_cycles=50,stop_on_success=POLICY.get("stop_after_goal_hold",False),perception_cpu_affinity=perception,control_cpu_affinity=control,ellipsoid_pair_threads=POLICY['pair_threads'],control_compute_cpu_affinity=tuple(control[:-1]),publication_cpu_affinity=(control[-1],),task_gain=POLICY['task_gain'],max_task_speed=POLICY['max_task_speed'],osqp_adaptive_row_threshold=512,osqp_tolerance=POLICY['qp_tolerance'],osqp_max_iterations=POLICY['qp_max_iterations'])
   (out/'summary.json').write_text(json.dumps(d,indent=2,default=str))
  result.update(status='completed',cycles=d['cycles'],reported_goal=bool(d.get('ever_sustained_success',d['success'])),termination_reason=d.get('termination_reason'))
 except Exception as exc:
  result.update(status='execution_error',error=repr(exc));(out/'failure.txt').write_text(traceback.format_exc())
 finally:
  result['wall_s']=time.perf_counter()-start;(out/'run_result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
if __name__=='__main__':main()
