#!/bin/bash
# Pilot, known map: drawer / cage (20 cm) / wide cage (24 cm) / IRIS shelf t0
# x LiuQP-E, LiuQP-E + combined rule, NEO-E 0.30 m, NEO-E 0.046 m (ellipsoid covers)
# x no racket | 1 racket 0.25 m/s | 1 racket 0.5 m/s | 2 rackets 0.5 m/s
# x seeds 1-5 (far start + per-joint noise, start check) x straight and geodesic attraction.
# Every controller: acceleration limit 10 rad/s^2, self-collision rows, least-violation fallback,
# protective stop on any contact.  40 workers x 2 CPUs.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/pilot_known
A=/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/assets
jobs=()
for seed in 1 2 3 4 5; do
  for scene in drawer cage cage_wide iris_ur3_shelf_t0; do
    case $scene in
      drawer) far=$A/far_start_q.npy ;; cage) far=$A/far_start_q_cage.npy ;;
      cage_wide) far=$A/far_start_q_cage_wide.npy ;; *) far=$A/far_start_q_shelf.npy ;;
    esac
    for attr in straight geodesic_native; do
      for ctl in liuqp combined neo_paper neo_matched; do
        for cond in "0 0.0" "1 0.25" "1 0.5" "2 0.5"; do
          set -- $cond
          jobs+=("$P/${ctl}_${attr%_native}_k$1_v$2 $scene $attr $seed UR5_CONTROLLER=$ctl UR5_E4_SAFETY=1 UR5_E4_FAR_START_FILE=$far UR5_ACCEL_LIMIT=10 UR5_OBJECTS=$1 UR5_OBJECT_SPEED=$2")
        done
      done
    done
  done
done
echo "${#jobs[@]} jobs" > $P.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 40)); do
    set -- ${jobs[$i]}
    out=$1; scene=$2; attr=$3; seed=$4; shift 4
    id=${scene}_ellipsoid_${attr}_seed$(printf "%02d" $seed)
    [ -f $out/$id/summary.json ] && continue
    ./known_job.sh $out $scene ellipsoid $attr $seed $((w * 2)) "$@"
  done
}
for w in $(seq 0 39); do worker $w & done
wait
echo DONE > $P.done
