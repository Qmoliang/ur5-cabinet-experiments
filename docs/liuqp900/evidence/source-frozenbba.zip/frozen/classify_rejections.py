from pathlib import Path
import os,json,collections,time
os.sched_setaffinity(0,{52,53,54,55})
import numpy as np
from pilot_adapter import ROOT,build,online,POLICY
from unified_joint_braking import joint_velocity_bounds

folder=ROOT/'trials/diagnostic_v4_trace';meta=json.loads((folder/'candidate_metadata.json').read_text());z=np.load(folder/'candidate_values.npz')
indices=[i for i,x in enumerate(meta) if x['reason']=='continuous_certificate']
pose=[i for i in indices if meta[i]['mode'] in ('POSTURE','MIXED_ESCAPE')]
task=[i for i in indices if i not in set(pose)]
def sample(seq,n):return [seq[k] for k in np.unique(np.linspace(0,len(seq)-1,min(n,len(seq))).astype(int))] if seq else []
selected=sorted(set(sample(task,180)+sample(pose,120)))
ctx=build('iris_4shelves_t2');guard=ctx.guard;pg=ctx.proxy_guard;rad=guard.radii;low=guard.joint_min+guard.joint_padding;high=guard.joint_max-guard.joint_padding
records=[];started=time.monotonic()
def sampled_margins(qa,qb):
    result=dict(environment_gap_m=float('inf'),self_gap_m=float('inf'),workspace_gap_m=float('inf'),environment_kind=None)
    for t in np.linspace(0,1,9):
        p=guard.positions(qa+t*(qb-qa))
        ri,oi=pg.pairs(p,p,rad+.006001)
        if len(oi):
            distance,_=pg.point_geometry(p[ri],oi,optimizer=True);gap=distance-rad[ri];k=int(np.argmin(gap))
            if gap[k]<result['environment_gap_m']:
                result.update(environment_gap_m=float(gap[k]),environment_kind='unknown_frontier' if pg.isbox[oi[k]] else 'observed_proxy',robot_sphere=int(ri[k]),proxy_index=int(oi[k]))
        result['self_gap_m']=min(result['self_gap_m'],guard.self_gap(p))
        result['workspace_gap_m']=min(result['workspace_gap_m'],float(min(np.min(p-rad[:,None]-guard.workspace_lower),np.min(guard.workspace_upper-p-rad[:,None]))))
    return result

for count,index in enumerate(selected):
    q=z['q'][index];previous=z['previous'][index];v=z['velocity'][index]
    lo,hi=joint_velocity_bounds(q,previous,guard.joint_min,guard.joint_max,guard.velocity_limits,.02,10.,.015)
    clipped=np.clip(v,lo,hi);brake=np.clip(previous-np.clip(previous,-.2,.2),lo,hi)
    original_safe=guard.braking_safe(pg,q,v);scale=None;salvaged=None
    for a in [1.,.75,.5,.25,.125,.0625,0.]:
        candidate=clipped if a==1 else brake+a*(clipped-brake)
        if guard.braking_safe(pg,q,candidate):scale=a;salvaged=candidate;break
    current=q.copy();speed=v.copy();fail=None
    for step in range(10):
        nxt=current+.02*speed
        if np.any(nxt<low-1e-12) or np.any(nxt>high+1e-12):
            fail=dict(step=step,category='joint_position_braking');break
        if not guard.segment(pg,current,nxt):
            values=sampled_margins(current,nxt)
            if values['environment_gap_m']<.006-1e-7:category='sampled_'+str(values['environment_kind'])
            elif values['self_gap_m']<.005-1e-7:category='sampled_self_collision'
            elif values['workspace_gap_m']<-1e-10:category='sampled_workspace'
            elif values['environment_gap_m']<.0060002-1e-10:category='certificate_padding_or_unsampled_violation'
            else:category='not_certified_no_sampled_hard_violation'
            fail=dict(step=step,category=category,**values);break
        current=nxt;speed=speed-np.clip(speed,-.2,.2)
        if np.max(np.abs(speed))<1e-12:break
    records.append(dict(candidate_index=index,cycle=meta[index]['cycle'],mode=meta[index]['mode'],original_rejection_reproduced=not original_safe,original_linear_violation=meta[index]['linear_violation'],command_max_joint_speed=float(np.max(np.abs(v))),max_change_from_previous=float(np.max(np.abs(v-previous))),braking_steps=int(np.ceil(np.max(np.abs(v))/.2)),first_failure=fail,original_guard_safe_scale=scale,safe_scaled_motion_nonzero=bool(salvaged is not None and np.linalg.norm(salvaged)>1e-6),safe_scaled_motion_dot_proposal=None if salvaged is None else float(salvaged@v)))
    if count%25==0:print(json.dumps(dict(classified=count+1,total=len(selected),wall_s=time.monotonic()-started)),flush=True)
summary=dict(total_candidates=len(meta),total_continuous_rejections=len(indices),classified_count=len(records),sampling='up to180 evenly spaced task records plus up to120 evenly spaced posture/mixed records; raw data retained for all',reproduced=sum(x['original_rejection_reproduced'] for x in records),first_step_failures=sum(x['first_failure'] is not None and x['first_failure']['step']==0 for x in records),later_braking_failures=sum(x['first_failure'] is not None and x['first_failure']['step']>0 for x in records),categories=dict(collections.Counter('no_failure' if x['first_failure'] is None else x['first_failure']['category'] for x in records)),safe_nonzero_scaled_alternatives=sum(x['safe_scaled_motion_nonzero'] for x in records),positive_scale_alternatives=sum(x['original_guard_safe_scale'] is not None and x['original_guard_safe_scale']>0 and x['safe_scaled_motion_nonzero'] for x in records),records=records,scope='counterfactual certificate replay of actual rejected proposals; finite samples cannot prove an interval safe when certification failed')
(ROOT/'REJECTION_CLASSIFICATION.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='records'},indent=2))
