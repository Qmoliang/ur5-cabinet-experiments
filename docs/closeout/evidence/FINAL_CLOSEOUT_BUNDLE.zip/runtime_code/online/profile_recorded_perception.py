"""Replay a recorded online trajectory through the O01/O02 perception worker.

Deterministic: frames are taken every --every cycles of the recorded joint
history, so stage timings depend only on map content, not on wall-clock pacing.
"""

from __future__ import annotations

import argparse
import cProfile
import csv
import io
import os
import pstats
import sys
from pathlib import Path

import numpy as np

ONLINE = (
    Path(__file__).resolve().parent.parent
    / os.environ.get("UR5_RUNTIME", "online_v6")
)
sys.path.insert(0, str(ONLINE))
from run_protocol_v3_async_online import PerceptionWorker  # noqa: E402
import incremental_proxy_manager  # noqa: E402

# Record how many CenterVox cells each frame actually changes.
LAST_STATS: dict = {}
_original_update = incremental_proxy_manager.IncrementalMatchedProxyManager.update


def _recording_update(self, *args, **kwargs):
    stats = _original_update(self, *args, **kwargs)
    LAST_STATS["changed"] = stats.changed_center_voxels
    LAST_STATS["reuses"] = stats.contained_cell_reuses
    LAST_STATS["cells"] = len(self._cells)
    LAST_STATS["samples"] = sum(len(cell.samples) for cell in self._cells.values())
    return stats


incremental_proxy_manager.IncrementalMatchedProxyManager.update = _recording_update

TIMING_KEYS = (
    "capture_ms", "map_update_ms", "proxy_update_ms", "proxy_manager_update_ms",
    "proxy_coverage_audit_ms", "proxy_frame_centervox_ms", "proxy_history_union_ms",
    "proxy_cell_merge_ms", "proxy_bucket_fit_ms", "proxy_publish_ids_hash_ms",
    "mvt_update_ms", "frame_pipeline_ms",
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=("O01", "O02"))
    parser.add_argument("--every", type=int, default=25)
    parser.add_argument("--frames", type=int, default=0, help="0 = whole trajectory")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--profile-from", type=int, default=0,
                        help="only profile frames from this index on")
    args = parser.parse_args()
    representation = "sphere" if args.case == "O01" else "ellipsoid"
    q_history = np.load(ONLINE.parents[2] / "evidence" / args.case / "replay_q.npy")
    cycles = np.arange(0, len(q_history), args.every)
    if args.frames:
        cycles = cycles[: args.frames]
    # Same settings as external_neo_adaptive/run_study.py for liu_sphere / liu_ellipsoid.
    worker = PerceptionWorker(
        representation, "mvt_simd",
        centervox_size=0.0075, maximum_uncertainty_union_inflation=1.05,
        certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty",
        direct_thin_axis_inflation=1.0, direct_tangent_subdivisions=1,
        direct_partition_mode="grid",
        sphere_cover_mode="adaptive_irredundant" if representation == "sphere" else "matched",
        ellipsoid_cover_mode="matched", radius_limit_representation="both",
        camera_width=320, camera_height=180, camera_pixel_stride=1,
        camera_names=("ur5_depth_wrist", "ur5_depth_forearm"), scene_version="camera_quarter",
    )
    args.out.mkdir(parents=True, exist_ok=True)
    profiler = cProfile.Profile()
    rows = []
    try:
        for frame, cycle in enumerate(cycles):
            if frame >= args.profile_from:
                profiler.enable()
            packet = worker.process(
                q_history[cycle], requested_frame=frame, source_cycle=int(cycle),
                source_time_s=float(cycle) * 0.02, transferable=True,
                include_dense_snapshot=False,
            )
            profiler.disable()
            row = packet.frame_row
            rows.append({"cycle": int(cycle), **LAST_STATS,
                         "coverage_ok": row.get("coverage_ok"),
                         "proxy_count": row["proxy_count"],
                         "center_voxels": row["center_voxels"],
                         "occupied_voxels": row["occupied_voxels"],
                         **{k: row.get(k) for k in TIMING_KEYS}})
            print(frame, cycle, row["proxy_count"], LAST_STATS,
                  f"proxy={row['proxy_update_ms']:.0f}ms audit={row['proxy_coverage_audit_ms']:.0f}ms",
                  flush=True)
        # Final map, for soundness/tightness comparison between map modes.
        manager = worker.proxy_manager
        keys = sorted(manager._cells)
        snapshot = manager.snapshot
        np.savez_compressed(
            args.out / f"{args.case}_final_map.npz",
            keys=np.asarray(keys, dtype=np.int64),
            representatives=np.asarray([manager._cells[k].representative for k in keys]),
            cell_shapes=np.asarray([manager._cells[k].uncertainty_shape for k in keys]),
            proxy_centers=snapshot.centers,
            proxy_radii=snapshot.sphere_radii,
            proxy_outer_shapes=snapshot.ellipsoid_outer_shapes,
            proxy_base_shapes=snapshot.base_ellipsoid_shapes,
            proxy_uncertainty_shapes=snapshot.proxy_uncertainty_shapes,
        )
    finally:
        worker.close()
    with (args.out / f"{args.case}_frames.csv").open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    profiler.dump_stats(args.out / f"{args.case}.pstats")
    stream = io.StringIO()
    pstats.Stats(profiler, stream=stream).strip_dirs().sort_stats("tottime").print_stats(30)
    (args.out / f"{args.case}_tottime.txt").write_text(stream.getvalue())
    stream = io.StringIO()
    pstats.Stats(profiler, stream=stream).strip_dirs().sort_stats("cumulative").print_stats(45)
    (args.out / f"{args.case}_cumulative.txt").write_text(stream.getvalue())


if __name__ == "__main__":
    main()
