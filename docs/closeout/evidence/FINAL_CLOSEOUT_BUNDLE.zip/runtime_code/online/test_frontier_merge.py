"""Merged frontier: fewer spheres, and every fine frontier cell still inside one (all 8 corners)."""
import os
import sys
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
os.environ["UR5_FRONTIER"] = "0"
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
import run_protocol_v3_async_online as online  # noqa: E402
from frontier import IncrementalFrontier, region_of_interest  # noqa: E402

case = Path(sys.argv[1])
run = next(p for p in case.iterdir() if p.is_dir())
qs = np.load(run / "causal_source_configurations.npz")["q"][:12]
worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=0.005, maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm"), scene_version="camera_quarter")
for i, q in enumerate(qs):
    worker.process(q, i, i, 0.0, transferable=True, include_dense_snapshot=False)
keys, states = worker.occupancy.snapshot_arrays()
frontier = IncrementalFrontier(*region_of_interest(worker.scene.boxes), online.MAP_VOXEL_SIZE, cell_voxels=1)
frontier.apply(keys, states)
os.environ["UR5_FRONTIER_MERGE"] = "0"
fine_centres, fine_radius, _ = frontier.cells()
os.environ["UR5_FRONTIER_MERGE"] = "1"
import mujoco
online.set_configuration(worker.model, worker.data, qs[-1])
near = np.vstack([online.certificate_world_positions(worker.data, worker.robot), np.asarray(worker.scene.waypoints[-1])[None]])
centres, radii, _, shapes = frontier.cells(near_points=near)
inverse = np.linalg.inv(shapes)
h = 0.5 * online.MAP_VOXEL_SIZE
corners = (fine_centres[:, None, :] + h * np.array([[sx, sy, sz] for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)])[None])
tree = cKDTree(centres)
ok = np.ones(len(fine_centres), dtype=bool)
for k in range(8):
    near = tree.query_ball_point(corners[:, k], r=float(radii.max()) + 1e-12)
    for i, cand in enumerate(near):
        if ok[i]:
            cand = np.asarray(cand)
            d = corners[i, k] - centres[cand] if len(cand) else None
            ok[i] = len(cand) > 0 and np.any(np.einsum("ni,nij,nj->n", d, inverse[cand], d) <= 1 + 1e-9)
print(f"fine frontier {len(fine_centres)} spheres -> merged {len(centres)} "
      f"(block ellipsoids); every fine cell covered: {bool(ok.all())}")
worker.close()
