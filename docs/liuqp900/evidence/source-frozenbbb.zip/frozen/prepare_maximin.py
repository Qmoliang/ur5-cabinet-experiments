from pathlib import Path
import json,shutil
r=Path(__file__).resolve().parent;p=r/'pilot_worker_continuation.py';s=p.read_text();s=s.replace("        if job.get('policy_version')=='continuation_cached':","        if job.get('policy_version')=='continuation_maximin':\n            from continuation_maximin_policy import LowDimPolicy\n        elif job.get('policy_version')=='continuation_cached':");p.write_text(s)
s=(r/'launch_cached.py').read_text().replace('max_workers=2','max_workers=1');(r/'launch_maximin.py').write_text(s)
j=json.loads((r/'development_jobs.json').read_text())
for x in j:x.update(name=x['name']+'_maximin',policy_version='continuation_maximin')
(r/'maximin_jobs.json').write_text(json.dumps(j,indent=2))
a=r/'revisions/continuation_maximin';a.mkdir()
for p in r.glob('*.py'):shutil.copy2(p,a/p.name)
