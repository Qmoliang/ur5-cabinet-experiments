#!/bin/bash
# CenterVox voxel size study on the recorded online runs: rebuild each final map
# at 5.0 and 3.75 mm, then LiuQP + geodesic on it with unseen cells dropped.
# CPUs 80-127 (the wall2 batch uses 0-79).
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=5 CUDA_VISIBLE_DEVICES=5 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
OUT=v6runs/cvsize; ONLINE=repo/experiment/runtimes/online_v6
lim="systemd-run --user --scope -q -p MemoryMax=24G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_CENTERVOX"
mkdir -p $OUT/maps
jobs=()
for seed in $(seq 1 20); do for size in 0.005 0.00375; do jobs+=("$size $seed"); done; done
for ((start = 0; start < ${#jobs[@]}; start += 12)); do
  for slot in $(seq 0 11); do
    index=$((start + slot)); [ $index -lt ${#jobs[@]} ] || break
    set -- ${jobs[$index]}; id=cv$1_seed$(printf "%02d" $2)
    [ -f $OUT/maps/$id.pkl ] || UR5_CENTERVOX=$1 $lim taskset -c $((80 + slot * 4))-$((83 + slot * 4)) timeout 3600 \
      ~/envs/ur5cab/bin/python $ONLINE/build_frozen_map.py v6runs/online_long/look_seed$(printf "%02d" $2) $OUT/maps/$id.pkl >> $OUT/maps/build.log 2>&1 &
  done
  wait
done
for ((start = 0; start < ${#jobs[@]}; start += 4)); do
  for slot in 0 1 2 3; do
    index=$((start + slot)); [ $index -lt ${#jobs[@]} ] || break
    set -- ${jobs[$index]}; id=cv$1/seed$(printf "%02d" $2); mkdir -p $OUT/cv$1
    [ -f $OUT/$id/summary.json ] && continue
    $lim timeout 2400 ~/envs/ur5cab/bin/python $ONLINE/run_v6_case.py ellipsoid --map incremental --timing paced \
      --cpus $((80 + slot * 12)):12 --start-seed $2 --geodesic --frozen-map $OUT/maps/cv$1_seed$(printf "%02d" $2).pkl --drop-frontier \
      --out $OUT/$id > $OUT/$id.log 2>&1 &
  done
  wait
done
echo DONE > $OUT/CVSIZE_DONE
