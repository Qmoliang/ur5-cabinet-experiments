"""One frozen final regression matrix; ordinary method failures are outcomes."""
from pathlib import Path
import os,sys,json,time,hashlib,subprocess,threading,queue,concurrent.futures,signal,argparse,datetime
V=Path(__file__).resolve().parent;U=V.parents[1];PY='/home/hsjed/envs/ur5cab/bin/python'
parser=argparse.ArgumentParser();parser.add_argument('--phase',choices=['smoke','matrix'],required=True);args=parser.parse_args();phase=args.phase
spec=json.loads((V/'EVALUATION_SPEC.json').read_text());frozen=json.loads((V/'FROZEN_MANIFEST.json').read_text());inputs=json.loads((V/'INPUT_MANIFEST.json').read_text());cases=spec['smoke_cases'] if phase=='smoke' else spec['matrix_cases'];assert len(cases)==(3 if phase=='smoke' else 300)
if phase=='matrix':assert json.loads((V/'SMOKE_GATE.json').read_text())['validity_passed'],'smoke validity gate not passed'
halt=threading.Event();lock=threading.Lock();jobs=queue.Queue();active={};started=time.time();outcomes=V/'outcomes';outcomes.mkdir(exist_ok=True);(V/'audits').mkdir(exist_ok=True)
def read(p):
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return None
def verify():
 for name,digest in frozen.items():assert hashlib.sha256((V/name).read_bytes()).hexdigest()==digest,'frozen artifact changed: '+name
 for name,digest in inputs.items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,'input changed: '+name

def snapshot(final=False):
 records=[read(outcomes/(k+'.json')) for k in cases];present=[r for r in records if r];ordinary=[r for r in present if r.get('continue_evaluation') and not r['strict_pass']];invalid=[r for r in present if not r.get('continue_evaluation')];complete=len(present)==len(cases);blocker=(V/(phase.upper()+'_BLOCKER.json')).exists();groups={}
 for key,r in zip(cases,records):
  task=key.split('__')[1];g=groups.setdefault(task,dict(expected=0,completed=0,safe_arrivals=0,ordinary_nonarrivals=0,validity_or_safety_errors=0));g['expected']+=1
  if r:
   g['completed']+=1;g['safe_arrivals']+=int(r.get('strict_pass',False));g['ordinary_nonarrivals']+=int(r.get('continue_evaluation',False) and not r.get('strict_pass',False));g['validity_or_safety_errors']+=int(not r.get('continue_evaluation',False))
 d=dict(phase=phase,expected=len(cases),completed=len(present),safe_arrivals=sum(r.get('strict_pass',False) for r in present),ordinary_nonarrivals=len(ordinary),validity_or_safety_errors=len(invalid),active=dict(active),halted=halt.is_set(),complete=complete,validity_passed=complete and not invalid and not blocker,all_tasks_succeeded=complete and all(r['strict_pass'] for r in present),final=final,elapsed_wall_s=time.time()-started,updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),by_task=groups,failures=[dict(id=r['id'],outcome=r['outcome'],termination_reason=r.get('termination_reason'),continue_evaluation=r.get('continue_evaluation')) for r in present if not r.get('strict_pass')],criteria='safe arrival; timing reported separately',data_role='development/regression matrix, not held-out generalization',known_reruns_started=False)
 p=V/(phase.upper()+'_PROGRESS.json');tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(d,indent=2));tmp.replace(p)
 if final:
  target=V/('SMOKE_GATE.json' if phase=='smoke' else 'FINAL_EVALUATION.json');target.write_text(json.dumps(d,indent=2))
 return d
verify()
for key in cases:
 old=read(outcomes/(key+'.json'))
 if old is not None:
  if not old.get('continue_evaluation'):halt.set()
 else:jobs.put(key)

def worker(slot):
 while not halt.is_set():
  if (V/'STOP_REQUESTED').exists():
   with lock:halt.set();snapshot()
   return
  try:key=jobs.get_nowait()
  except queue.Empty:return
  try:
   verify();case=V/'runs'/key;env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MUJOCO_GL='egl',CUDA_VISIBLE_DEVICES='4',MUJOCO_EGL_DEVICE_ID='4')
   if not (case/'run_result.json').exists():
    assert not case.exists(),'incomplete output retained; not overwritten: '+key
    with (V/(key+'.log')).open('w') as log:
     child=subprocess.Popen([PY,'-u',str(V/'runner.py'),key,'--out',str(case),'--cpu-first',str(slot*16),'--planner-cpus',f'{48+slot*2},{49+slot*2}','--code-dir',str(V/'code')],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
     with lock:active[key]=dict(stage='run',pid=child.pid);snapshot()
     try:child.wait(timeout=spec['process_watchdog_s'])
     except subprocess.TimeoutExpired:
      if os.getpgid(child.pid)==child.pid:os.killpg(child.pid,signal.SIGTERM)
      child.wait(timeout=30);raise RuntimeError('process watchdog; incomplete evidence')
   with lock:active[key]=dict(stage='independent_audit');snapshot()
   env['AUDIT_CPU']=str(60+slot)
   with (V/'audits'/(key+'_driver.log')).open('w') as log:subprocess.run([PY,'-u',str(V/'audit_tools/audit_entry.py'),str(V),key],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=spec['audit_watchdog_s'],check=True)
   result=read(outcomes/(key+'.json'));assert result is not None
   with lock:
    active.pop(key,None)
    if not result.get('continue_evaluation'):halt.set()
    snapshot();print(json.dumps(dict(id=key,outcome=result['outcome'],valid_attempt=result.get('attempt_valid'),safe=result.get('safety_verified'),continue_evaluation=result.get('continue_evaluation'),charged_s=result.get('completion_charged_s'))),flush=True)
  except Exception as exc:
   with lock:
    halt.set();active.pop(key,None);(V/(phase.upper()+'_BLOCKER.json')).write_text(json.dumps(dict(id=key,error=repr(exc)),indent=2));snapshot();print(json.dumps(dict(id=key,error=repr(exc))),flush=True)
   return
with lock:snapshot()
with concurrent.futures.ThreadPoolExecutor(max_workers=spec['workers']) as pool:
 futures=[pool.submit(worker,i) for i in range(spec['workers'])]
 for f in futures:f.result()
verify();final=snapshot(final=True);print(json.dumps(final),flush=True)
