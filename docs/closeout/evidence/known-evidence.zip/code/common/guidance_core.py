"""One target/escape state machine; only job scheduling differs by adapter."""
import time,json
from types import SimpleNamespace
import numpy as np
from unified_policy import POLICY,POLICY_SHA256
from collision_oracle import CollisionOracle
from planner_core import search
class UnifiedGuidance:
 def __init__(self,model,robot,controller,target,initial_q,arrays,generation,executor=None,blocking=False):
  from robot_model import planning_model
  model=planning_model(model)
  self.model=model;self.robot=robot;self.controller=controller;self.target=np.asarray(target);self.initial_q=np.asarray(initial_q);self.arrays=arrays;self.generation=generation;self.executor=executor;self.blocking=blocking
  self.oracle=CollisionOracle(model,robot,arrays,initial_q,margin=POLICY["operating_margin_m"])
  self.history=[];self.chain=[];self.track_history=[];self.future=None;self.retry_after=100;self.last_q=self.initial_q.copy();self.command=self.target.copy();self.last_cycle=-1
  self.stats=SimpleNamespace(calls=0,failures=0,plan_ms=[],events=[],subgoals=[],regions=[])
  self.subgoal_mode="unified_certified_chain";self.trigger="shared_stall_or_proactive";self.pre_step=True;self.pending_time=None
 @property
 def active(self):return bool(self.chain)
 def current_target(self):return self.command
 def clear(self):
  self.chain=[];self.track_history=[];self.controller.extra_joint_goal=None;self.controller.extra_task_frames=();self.command=self.target.copy()
 def connect(self,a,b):
  old=self.oracle.margin
  self.oracle.margin=POLICY["environment_margin_m"]
  try:return self.oracle.segment_free(a,b) and self.oracle.segment_certified(a,b)
  finally:self.oracle.margin=old
 def on_map(self,arrays,generation,cycle):
  self.arrays=arrays;self.generation=generation;self.oracle=CollisionOracle(self.model,self.robot,arrays,self.initial_q,margin=POLICY["operating_margin_m"])
  if self.chain and (self.oracle.exact_clearance(self.chain[-1],POLICY["goal_margin_m"])<0 or not self.connect(self.last_q,self.chain[0])):
   self.stats.events.append(dict(event="path_invalidated",cycle=cycle,generation=generation));self.clear();self.retry_after=cycle+10
 def accept(self,result,q,cycle):
  self.stats.plan_ms.append(1000*result.get("seconds",0));self.stats.events.append(dict(event="search_finished",cycle=cycle,**result))
  path=[np.asarray(p) for p in result.get("path",[])]
  if result.get("status")=="path" and path and self.oracle.exact_clearance(path[-1],POLICY["goal_margin_m"])>=0:
   if self.oracle.exact_clearance(q,POLICY["operating_margin_m"])>=0 and self.connect(q,path[-1]):path=[path[-1]]
   elif not self.connect(q,path[0]):path=[]
   if path:self.chain=path;self.track_history=[];self.stats.subgoals.append([p.tolist() for p in path]);self.stats.events.append(dict(event="path_accepted",cycle=cycle,points=len(path)))
  if not self.chain:self.stats.failures+=1
  self.retry_after=cycle+POLICY["retry_cycles"]
 def update(self,q,gripper,cycle):
  q=np.asarray(q);gripper=np.asarray(gripper);self.last_q=q.copy();error=float(np.linalg.norm(gripper-self.target))
  if cycle!=self.last_cycle:self.history.append(error);self.history=self.history[-101:];self.last_cycle=cycle
  if self.future is not None and self.future.done():
   try:result=self.future.result()
   except Exception as ex:result=dict(status="worker_error",error=repr(ex),seconds=time.perf_counter()-self.pending_time)
   self.future=None;self.accept(result,q,cycle)
  if self.chain:
   while len(self.chain)>1 and np.max(np.abs(q-self.chain[0]))<POLICY["waypoint_tolerance_rad"] and self.connect(q,self.chain[1]):self.chain.pop(0);self.track_history=[]
   distance=float(np.linalg.norm(q-self.chain[0]));self.track_history.append(distance);self.track_history=self.track_history[-201:]
   if len(self.chain)==1 and np.max(np.abs(q-self.chain[0]))<POLICY["final_joint_tolerance_rad"] and error<POLICY["goal_tolerance_m"]:
    self.stats.events.append(dict(event="path_completed",cycle=cycle));self.clear()
   elif len(self.track_history)==201 and self.track_history[0]-min(self.track_history[-200:])<1e-5 and error>=POLICY["goal_tolerance_m"]:
    self.stats.events.append(dict(event="tracking_stall",cycle=cycle,joint_gap=distance));self.clear();self.retry_after=cycle+10
   else:
    self.controller.extra_joint_goal=self.chain[0].copy();self.command=self.oracle.gripper_position(self.chain[0]);return self.command
  self.controller.extra_joint_goal=None
  stalled=len(self.history)>POLICY["stall_window"] and self.history[-51]-min(self.history[-50:])<POLICY["minimum_progress_m"]
  proactive=error<POLICY["proactive_error_m"] and cycle>=POLICY["proactive_after_cycle"]
  charged=cycle*POLICY["dt_s"]+(sum(self.stats.plan_ms)/1000 if self.blocking else 0.)
  remaining=120.-charged
  if self.future is None and cycle>=self.retry_after and error>POLICY["goal_tolerance_m"] and (stalled or proactive) and remaining>1.:
   self.stats.calls+=1;self.pending_time=time.perf_counter();args=(self.model,self.robot,self.arrays,self.initial_q,q.copy(),self.target.copy(),int(self.generation),self.stats.calls,min(POLICY["planner_budget_s"],remaining))
   self.stats.events.append(dict(event="search_started",cycle=cycle,generation=self.generation))
   if self.executor is None:self.accept(search(*args),q,cycle)
   elif self.blocking:
    self.future=self.executor.submit(search,*args);result=self.future.result();result["compute_seconds"]=result.get("seconds");result["seconds"]=time.perf_counter()-self.pending_time;self.accept(result,q,cycle);self.future=None
   else:self.future=self.executor.submit(search,*args)
   self.retry_after=cycle+POLICY["retry_cycles"]
  self.command=self.target.copy();return self.command
 def holding(self):return False
 def finish(self,run_dir):
  if self.future is not None:self.future.cancel()
  if self.executor is not None:self.executor.shutdown(wait=True,cancel_futures=True)
  (run_dir/"guidance.json").write_text(json.dumps(dict(policy_sha256=POLICY_SHA256,events=self.stats.events,subgoals=self.stats.subgoals),default=float))
  return dict(mode="unified_certified_chain",policy_sha256=POLICY_SHA256,escapes=self.stats.calls,chains=sum(e["event"]=="path_accepted" for e in self.stats.events),search_s=[x/1000 for x in self.stats.plan_ms],pause_s=0.)
