"""Worst-protruding certificates near the limiting one: members, member spread vs core axes."""
import json, os, sys, csv
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("UR5_NATIVE_FIT", "0")
from pointcloud_proxy import fit_matched_voxel_proxies
run, scene_json = Path(sys.argv[1]), sys.argv[2]
inner = next(run.glob("A-CV-*"))
p = np.load(inner / "final_causal_proxies.npz")
boxes = json.load(open(scene_json))["boxes"]
bc = np.array([b["center"] for b in boxes]); bh = np.array([b["half_size"] for b in boxes])
rows = list(csv.DictReader(open(inner / "cycles.csv")))
ids = list(p["proxy_ids"]); focus = p["centers"][ids.index(int(float(rows[-1]["limiting_proxy_id"])))]
pts, off, U = p["filtered_points"], p["filtered_point_offsets"], p["filtered_uncertainty_shapes"]
fit = fit_matched_voxel_proxies(pts, filter_size=0.005, cluster_size=0.10, maximum_aabb_overshoot=0.025,
                                already_filtered=True, filtered_point_offsets=off, filtered_point_uncertainty_shapes=U,
                                cluster_origin=np.array([-0.25, -0.15, -0.02]), maximum_uncertainty_union_inflation=1.05,
                                certificate_radius_limit=0.070)
rng = np.random.default_rng(0); n = rng.normal(size=(2000, 3)); n /= np.linalg.norm(n, axis=1, keepdims=True)
box_h = (n @ bc.T) + np.abs(n) @ bh.T
res = []
for k in np.where(np.linalg.norm(fit.centers - focus, axis=1) < 0.08)[0]:
    core = np.sqrt(np.maximum(np.einsum("ni,ij,nj->n", n, fit.ellipsoid_outer_shapes[k], n), 0))
    h_core = n @ fit.centers[k] + core
    exc = (h_core[:, None] - box_h).max(axis=0); i = int(np.argmin(exc))
    res.append((exc[i], k, i))
res.sort(reverse=True)
for e, k, i in res[:6]:
    m = np.where(fit.filtered_cluster_indices == k)[0]
    c = pts[m]; ev, evec = np.linalg.eigh(np.cov(c.T)) if len(m) > 2 else (np.zeros(3), np.eye(3))
    span = np.ptp((c - c.mean(0)) @ evec, axis=0)
    axes = np.sqrt(np.linalg.eigvalsh(fit.ellipsoid_outer_shapes[k]))
    base = np.sqrt(np.linalg.eigvalsh(fit.base_ellipsoid_shapes[k]))
    j = np.argmax(n @ fit.centers[k] + np.sqrt(np.einsum("ni,ij,nj->n", n, fit.ellipsoid_outer_shapes[k], n)) - box_h[:, i])
    print(f"cert {k}: core-only protrusion {e*1e3:5.1f} mm beyond {boxes[i]['name']}, {len(m)} points, point span {np.round(span*1e3,1)} mm,"
          f" outer axes {np.round(axes*1e3,1)}, base axes {np.round(base*1e3,1)}, dir {np.round(n[j],2)}")
