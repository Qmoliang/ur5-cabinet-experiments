"""Experiment A summary: per swept target, goal-pose clearance (mm beyond the 6 mm margin; < 0 = no valid
goal pose), success of original LiuQP (sphere) and LiuQP-E (ellipsoid) over 20 starts, median final
distance, and for failures the robot part / scene box on the tightest row over the last 5 s."""
import collections
import csv
import json
import sys
from pathlib import Path

import mujoco
import numpy as np

K = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
sys.path[:0] = [str(K / "src"), str(K / "src/core")]
from robot import build_robot_certificate  # noqa: E402

V = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
clear = {}
for line in open(V / "depth_sweep_clearance.jsonl"):
    d = json.loads(line)
    clear[d["scene"]] = d
robot_cache = {}


def blocker(run, names):
    model = mujoco.MjModel.from_xml_path(str(run / "scene.xml"))
    robot = robot_cache.setdefault(model.nbody, build_robot_certificate(model))
    proxies = np.load(run / "proxies.npz")
    box_of = dict(zip(proxies["proxy_ids"].tolist(), proxies["box_indices"].tolist()))
    pairs = collections.Counter()
    for r in list(csv.DictReader(open(run / "cycles.csv")))[-250:]:
        ri, pid = int(r["limiting_robot_index"]), int(r["limiting_proxy_id"])
        if ri >= 0 and pid in box_of:
            pairs[(robot[ri].body_name.replace("_link", ""), names[box_of[pid]])] += 1
    return pairs.most_common(1)[0][0] if pairs else None


for scene in open(V / "depth_sweep.scenes").read().split():
    payload = json.load(open(K / "assets/scenes" / f"{scene}.json"))
    names = [b.get("name", str(i)) for i, b in enumerate(payload["boxes"])]
    c = clear.get(scene, {})
    cells = []
    for rep in ("sphere", "ellipsoid"):
        runs = [p for p in sorted((V / "depth_sweep/liuqp").glob(f"{scene}_{rep}_straight_seed*")) if p.is_dir()]
        ss = [json.load(open(r / "summary.json")) for r in runs if (r / "summary.json").exists()]
        ok = sum(bool(s["success"]) for s in ss)
        err = np.median([s["final_error_m"] for s in ss]) if ss else np.nan
        stops = sum(bool((s.get("protective_stop") or {}).get("stopped")) for s in ss)
        blocks = collections.Counter(blocker(r, names) for r, s in zip(runs, ss) if not s["success"])
        top = ", ".join(f"{a}/{b} x{n}" for (a, b), n in blocks.most_common(2) if a) if blocks else ""
        cells.append(f"{rep[:3]} {ok:2d}/{len(ss):<2d} err {1000*err:4.0f} mm stops {stops}  {top}")
    print(f"{scene:24s} goal clr ell {c.get('ellipsoid_mm', float('nan')):6.1f} sph {c.get('sphere_mm', float('nan')):6.1f} | "
          + " | ".join(cells))
