from pathlib import Path
import time,sys
ROOT=Path(__file__).resolve().parent
while not all((ROOT/'trials'/name/'result.json').exists() for name in ['retained_stall_repeat_1','retained_stall_repeat_2']):time.sleep(15)
script=(ROOT/'launch_audits.py').read_text().replace("'56,57,58,59'","'48,49,50,51'").replace("'60,61,62,63'","'52,53,54,55'").replace('AUDIT_STATUS.json','RETAINED_AUDIT_STATUS.json')
sys.argv=[str(ROOT/'launch_audits.py'),'retained*']
exec(compile(script,str(ROOT/'launch_audits.py'),'exec'))
