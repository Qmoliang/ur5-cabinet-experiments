#!/bin/bash
# Dodge test: racket at 0.3 s while the arm is still in open space; ellipsoid covers;
# LiuQP / NEO-matched / NEO-paper (NEO with the racket velocity in its dampers);
# 2 scenes x 2 directions x 4 speeds x 20 start poses.  40 workers x 2 CPUs.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
D=$PWD/dodge
jobs=()
for seed in $(seq 1 20); do
  for scene in drawer cage_wide; do
    for dir in side above; do
      vec="0,-1,0"; [ $dir = above ] && vec="0,0,-1"
      for speed in 0.15 0.25 0.5 1.0; do
        for ctl in liuqp neo_matched neo_paper; do
          jobs+=("$D/${ctl}_${dir}_v$speed $scene ellipsoid geodesic_native $seed UR5_CONTROLLER=$ctl UR5_RACKET=1 UR5_RACKET_DIR=$vec UR5_RACKET_TRIGGER=0.3 UR5_RACKET_SPEED=$speed")
        done
      done
    done
  done
done
echo "${#jobs[@]} jobs" > $D.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 40)); do
    set -- ${jobs[$i]}
    out=$1; scene=$2; rep=$3; attr=$4; seed=$5; shift 5
    id=${scene}_${rep}_${attr}_seed$(printf "%02d" $seed)
    [ -f $out/$id/summary.json ] && continue
    ./known_job.sh $out $scene $rep $attr $seed $((w * 2)) "$@"
  done
}
for w in $(seq 0 39); do worker $w & done
wait
echo DONE > $D.done
