from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
archive=ROOT/'revisions/blocker_v2';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='blocker_v2':";new="        if job.get('policy_version')=='blocker_v3':\n            from blocker_policy_v3 import LowDimPolicy\n        elif job.get('policy_version')=='blocker_v2':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'blocker_v2_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('blocker_v2','blocker_v3_joint_only');j['policy_version']='blocker_v3';j['spatial_metric']=False
(ROOT/'blocker_v3_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'BLOCKER_V3_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='isolate geometric release with joint reserve cost; omit spatial epigraph cost; verify the proposed effective original-QP solution before publishing, refine with independent solver on numerical rejection; same thresholds and safety'),indent=2))
print(json.dumps(jobs))
