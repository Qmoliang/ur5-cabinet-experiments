#!/bin/bash
# Reviewer batch, online (approved 2026-10-27).  Every controller with its real compute time
# (UR5_COMPUTE_DELAY=1: a command is applied ceil(T/20 ms) cycles after its solve started).
#  R1  liuqp / combined / neo_split (NEO 0.046 static + 0.30 moving) / neo_matched / neo_paper
#      x drawer (geodesic), cage_wide, shelf x no racket | 1@0.25 | 1@0.5 | 2@0.5 x seeds 1-20
#      (neo_matched / neo_paper seeds 1-5 reused from pilot_online/*_delay).
#  R2  spheres (3 scenes) and straight attraction (drawer) for liuqp / combined, no racket, seeds 1-20.
#  R3  camera: 5% pixel dropout (handled as no return) | uniform +-3 mm depth error, liuqp / combined,
#      3 scenes, no racket, seeds 1-10.
# Map as in the pilot (CenterVox 5 mm, frontier, no-return carving).  16-CPU slots 0-96 taken as free.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/review_online
export UR5_NO_RETURN_FREE=1 UR5_COMPUTE_DELAY=1
jobs=()
for cond in "0 0.0" "1 0.25" "1 0.5" "2 0.5"; do
  for seed in $(seq 1 20); do
    for scene in drawer cage_wide shelf; do
      for ctl in liuqp combined neo_split neo_matched neo_paper; do
        case $ctl in neo_matched|neo_paper) [ $seed -le 5 ] && continue ;; esac
        jobs+=("${ctl}_delay $scene $seed $cond -")
      done
    done
  done
done
for seed in $(seq 1 20); do
  for scene in drawer cage_wide shelf; do
    for ctl in liuqp combined; do jobs+=("${ctl}_delay_sphere $scene $seed 0 0.0 E4_REP=sphere"); done
  done
  for ctl in liuqp combined; do jobs+=("${ctl}_delay_straight drawer $seed 0 0.0 E4_STRAIGHT=1"); done
done
for seed in $(seq 1 10); do
  for scene in drawer cage_wide shelf; do
    for ctl in liuqp combined; do
      jobs+=("${ctl}_delay_dropout5 $scene $seed 0 0.0 UR5_DEPTH_DROPOUT=0.05")
      jobs+=("${ctl}_delay_noise3 $scene $seed 0 0.0 UR5_DEPTH_NOISE_UNIFORM=0.003")
    done
  done
done
echo "${#jobs[@]} jobs" > review_online.jobs
n=0
for job in "${jobs[@]}"; do
  set -- $job
  name=$1; scene=$2; seed=$3; k=$4; v=$5; extra=$6
  out=$P/${name}_k${k}_v$v/${scene}_s$seed
  [ -f $out/case.json ] && continue
  base=${name%%_delay*}; ctl=$base; neo_moving=
  [ $base = neo_split ] && { ctl=neo_matched; neo_moving=0.30; }
  geo=; [ $scene = drawer ] && geo=1
  case "$extra" in E4_STRAIGHT=1) geo=; extra=- ;; esac
  while :; do
    for c in 0 16 32 48 64 80 96; do
      ps -eo args | grep -v grep | grep -q -- "--cpus $c:16" || { slot=$c; break 2; }
    done
    sleep 20
  done
  ( [ "$extra" != - ] && export "$extra"
    UR5_NEO_MOVING_INFLUENCE=$neo_moving E4_GEODESIC=$geo E4_SCENE=$scene ./e4_map.sh $out $seed $slot $ctl $k $v ) &
  n=$((n + 1)); echo "$n $(date +%T) $name $scene s$seed k$k v$v slot $slot" >> review_online.log
  sleep 15
done
wait
echo DONE > review_online.done
