from pathlib import Path
import json,hashlib,numpy as np
R=Path(__file__).resolve().parent
freezes={}
for n in ['FINAL_FREEZE.json','EXECUTION_PROGRESS_FREEZE.json','PERSISTENT_PROGRESS_FREEZE.json']:
 d=json.loads((R/n).read_text());changed=[p for p,h in d['source_hashes'].items() if hashlib.sha256((R/p).read_bytes()).hexdigest()!=h];assert not changed,(n,changed);freezes[n]=dict(checked=len(d['source_hashes']),changed=changed)
old=json.loads((R/'PROTECTED_PREVIOUS_STUDY.json').read_text());changed=[p for p,h in old.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=h];assert not changed
repeat={}
for a,b,key in [('exact_failure_trace','old_cycle_schedule','cycle_schedule_exact'),('final_original_cycle_1','final_original_cycle_repeat','frozen_failure_repeat')]:
 qa=np.load(R/'trials'/a/'trajectory.npz')['q'];qb=np.load(R/'trials'/b/'trajectory.npz')['q'];repeat[key]=dict(same_shape=qa.shape==qb.shape,max_q_difference=None if qa.shape!=qb.shape else float(np.max(np.abs(qa-qb))));assert repeat[key]['max_q_difference']==0
(R/'INTEGRITY_AND_REPEAT.json').write_text(json.dumps(dict(freezes=freezes,previous_files_checked=len(old),previous_changed=changed,repeats=repeat),indent=2));print(json.dumps(dict(freezes=freezes,previous_files=len(old),repeats=repeat),indent=2))
