"""Freeze the tested sphere switch, then launch the predeclared 300-case evaluation."""
from pathlib import Path
import json,hashlib,subprocess,os,datetime,py_compile
U=Path('/mnt/ssd2/hsjed/ur5_cabinet/v6runs/unified_static_20261102');V=U/'closeout/sphere_r17_pair_20261104';B=V.parent/'final_r17'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((V/'REPRESENTATION_PREFLIGHT.json').read_text())['passed']
assert not (V/'FROZEN_MANIFEST.json').exists(),'already frozen; do not relaunch'
for p,h in json.loads((V/'BASELINE_REUSE_MANIFEST.json').read_text()).items():assert sha(Path(p))==h,p
for p,h in json.loads((V/'INPUT_MANIFEST.json').read_text()).items():assert sha(Path(p))==h,p
for name in ['planner_core.py','guidance_core.py','collision_oracle.py','proxy_geometry.py','static_safety.py','taskspace_search.py','policy.json']:
 assert sha(V/'code/common'/name)==sha(B/'code/common'/name),name
assert sha(V/'code/online/protocol_liuqp_controller.py')==sha(B/'code/online/protocol_liuqp_controller.py')
for p in [V/'runner.py',V/'evaluate.py',V/'supervise_pair.py',V/'test_sphere_contract.py']+list((V/'audit_tools').glob('*.py')):py_compile.compile(str(p),doraise=True)
protocol=json.loads((V/'PROTOCOL.json').read_text());protocol['status']='frozen_before_any_case';protocol['frozen_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(V/'PROTOCOL.json').write_text(json.dumps(protocol,indent=2))
manifest={str(p.relative_to(V)):sha(p) for p in V.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
(V/'FROZEN_MANIFEST.json').write_text(json.dumps(manifest,indent=2));(V/'FREEZE_RECORD.json').write_text(json.dumps(dict(frozen_at=protocol['frozen_at'],files=len(manifest),sha256=sha(V/'FROZEN_MANIFEST.json'),baseline_reused=True,preflight_passed=True),indent=2))
with (V/'supervisor.log').open('a') as log:
 child=subprocess.Popen(['/home/hsjed/envs/ur5cab/bin/python','-u',str(V/'supervise_pair.py')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
record=dict(pid=child.pid,launched_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),version=str(V),user_authorized_sphere_only_300=True,baseline=str(B));(V/'SUPERVISOR_LAUNCH.json').write_text(json.dumps(record,indent=2))
p=U/'closeout/WORK_STATE.json';d=json.loads(p.read_text());d.update(active_ablation=str(V),active_ablation_representation='sphere',new_sphere_ablation_authorized=True,previous_ellipsoid_study_closed=True,ellipsoid_reruns_started=False,known_reruns_started=False,new_experiments_running=True);p.write_text(json.dumps(d,indent=2))
print(json.dumps(record,indent=2))
