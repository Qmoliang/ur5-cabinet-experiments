"""Independent continuous bounds for robot spheres against boxes and each other."""
import numpy as np

def audit_motion(q,positions,radii,centers,half,pairs,K,position_fn,environment_margin=.006,self_margin=.005,tol=1e-7,max_depth=12):
 aa,bb=np.asarray(pairs,dtype=int).T;radii=np.asarray(radii);centers=np.asarray(centers);half=np.asarray(half);bad=[];witnesses=[];sub=0;minimum_environment=float('inf');minimum_self=float('inf')
 def gap(p):
  nonlocal minimum_environment,minimum_self
  ge=float(np.min(np.linalg.norm(np.maximum(np.abs(p[:,None]-centers)-half,0),axis=2)-radii[:,None]));gs=float(np.min(np.linalg.norm(p[bb]-p[aa],axis=1)-radii[aa]-radii[bb]));minimum_environment=min(minimum_environment,ge);minimum_self=min(minimum_self,gs);return ge,gs
 def environment_lower(pa,pb):
  ca=np.clip(pa[:,None],centers-half,centers+half);cb=np.clip(pb[:,None],centers-half,centers+half);da=np.linalg.norm(ca-pa[:,None],axis=2);db=np.linalg.norm(cb-pb[:,None],axis=2);na=(ca-pa[:,None])/np.maximum(da[:,:,None],1e-30);nb=(cb-pb[:,None])/np.maximum(db[:,:,None],1e-30)
  def plane(n):return np.minimum(np.sum(n*(centers-pa[:,None]),axis=2),np.sum(n*(centers-pb[:,None]),axis=2))-np.sum(np.abs(n)*half,axis=2)
  lower=np.maximum((da+db-np.linalg.norm(pb-pa,axis=1)[:,None])*.5,np.maximum(plane(na),plane(nb)))-radii[:,None];return float(np.min(lower))
 def self_lower(pa,pb):
  x=pa[bb]-pa[aa];y=pb[bb]-pb[aa];delta=y-x;den=np.sum(delta*delta,axis=1);t=np.clip(-np.sum(x*delta,axis=1)/np.maximum(den,1e-30),0,1);return float(np.min(np.linalg.norm(x+t[:,None]*delta,axis=1)-radii[aa]-radii[bb]))
 def record(i,reason,ga,gb,lower_e=None,lower_s=None):
  if len(witnesses)<100:witnesses.append(dict(cycle=i,reason=reason,environment_endpoint_min_mm=min(ga[0],gb[0])*1000,self_endpoint_min_mm=min(ga[1],gb[1])*1000,environment_lower_mm=None if lower_e is None else lower_e*1000,self_lower_mm=None if lower_s is None else lower_s*1000))
 def interval(i,a,b,pa,pb,ga,gb,depth=0,check_environment=True,check_self=True):
  nonlocal sub
  env=True if not check_environment else None;self_ok=True if not check_self else None
  if check_environment and min(ga[0],gb[0])<environment_margin-tol:record(i,'sampled_environment_margin_violation',ga,gb);env=False
  if check_self and min(ga[1],gb[1])<self_margin-tol:record(i,'sampled_self_margin_violation',ga,gb);self_ok=False
  pad=K*np.sum(np.abs(b-a))**2/8+1e-12;le=None;ls=None
  if env is None:
   le=environment_lower(pa,pb)-pad
   if le>=environment_margin-tol:env=True
  if self_ok is None:
   ls=self_lower(pa,pb)-2*pad
   if ls>=self_margin-tol:self_ok=True
  if env is not None and self_ok is not None:return env,self_ok
  if depth>=max_depth:
   record(i,'interval_not_certified',ga,gb,le,ls);return False if env is None else env,False if self_ok is None else self_ok
  sub+=1;m=(a+b)*.5;pm=position_fn(m);gm=gap(pm)
  left=interval(i,a,m,pa,pm,ga,gm,depth+1,env is None,self_ok is None);right=interval(i,m,b,pm,pb,gm,gb,depth+1,env is None,self_ok is None)
  return (left[0] and right[0]) if env is None else env,(left[1] and right[1]) if self_ok is None else self_ok
 values=[gap(p) for p in positions]
 environment_bad=[];self_bad=[]
 for i in range(len(q)-1):
  env_ok,self_ok=interval(i,q[i],q[i+1],positions[i],positions[i+1],values[i],values[i+1])
  if not env_ok:environment_bad.append(i)
  if not self_ok:self_bad.append(i)
  if not env_ok or not self_ok:bad.append(i)
 return dict(passed=not bad,environment_passed=not environment_bad,self_passed=not self_bad,environment_bad_intervals=environment_bad,self_bad_intervals=self_bad,bad_intervals=bad,witnesses=witnesses,minimum_environment_m=minimum_environment,minimum_self_m=minimum_self,subdivisions=sub,method='box_support_planes_and_exact_relative_sphere_segments_with_joint_arc_remainder')
