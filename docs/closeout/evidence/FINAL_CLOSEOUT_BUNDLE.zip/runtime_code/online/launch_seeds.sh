#!/bin/bash
# Run seeds 1..20 of one configuration, 10 at a time.
# Usage: launch_seeds.sh <out_dir> <representation> <span> <first_cpu> [KEY=VALUE ...]
OUT=$1; rep=$2; span=$3; base=$4; shift 4
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
mkdir -p $OUT
for wave in 0 1; do
  for slot in $(seq 0 9); do
    seed=$((wave * 10 + slot + 1))
    ./known_seed_one.sh $OUT $rep $span $seed $((base + 2 * slot)) "$@" &
  done
  wait
done
echo DONE > $OUT/ALL_DONE
