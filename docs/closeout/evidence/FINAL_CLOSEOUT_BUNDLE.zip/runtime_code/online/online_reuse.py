"""Plane reuse for the online LiuQP (directional ellipsoid path).

Same rule as the known-cabinet version: a robot sphere that moved less than
`reuse_distance` since its planes were computed, and whose newly arrived
candidates all lie behind those planes, keeps its planes with gaps measured to
the planes.  Other spheres go through LiuQP's unchanged native batch.  Every
map publication calls update_obstacles, which clears the reuse state, because
planes are only valid for the proxy set they were built on.
"""
from __future__ import annotations

import numpy as np

from protocol_liuqp_controller import ProtocolLiuQPController, ProtocolSeparatingPlane

TOLERANCE = 1e-10


class OnlineReuseLiuQPController(ProtocolLiuQPController):
    def init_reuse(self, reuse_distance: float = 0.002) -> None:
        self.reuse_distance = float(reuse_distance)
        self._state: dict[int, dict] = {}
        self._reused: set[int] = set()
        self._candidates_now: dict[int, np.ndarray] = {}
        self.reuse_counts = {"reused_spheres": 0, "recomputed_spheres": 0, "map_resets": 0}

    def update_obstacles(self, *args, **kwargs):
        if hasattr(self, "_state"):
            self._state.clear()
            self.reuse_counts["map_resets"] += 1
        return super().update_obstacles(*args, **kwargs)

    def _prefetch_directional_pairs(self, positions, radii):
        positions = np.asarray(positions, dtype=float)
        radii = np.asarray(radii, dtype=float)
        self._reused = set()
        recompute = []
        for i, (center, radius) in enumerate(zip(positions, radii)):
            candidates = np.unique(np.asarray(self._candidate_indices(center, float(radius)), dtype=np.int64))
            self._candidates_now[i] = candidates
            state = self._state.get(i)
            if state is not None and np.linalg.norm(center - state["center"]) <= self.reuse_distance:
                survivors = np.setdiff1d(candidates, state["candidates"], assume_unique=True)
                for plane in state["planes"]:
                    if not len(survivors):
                        break
                    behind = self._minimum_support(survivors, plane.normal_to_obstacle) >= plane.offset - TOLERANCE
                    survivors = survivors[~behind]
                if not len(survivors):
                    self._reused.add(i)
                    continue
            recompute.append(i)
        self.reuse_counts["reused_spheres"] += len(self._reused)
        self.reuse_counts["recomputed_spheres"] += len(recompute)
        batches: dict[int, tuple | None] = {}
        geometry_ms = 0.0
        if recompute:
            index = np.asarray(recompute, dtype=np.int64)
            full = self._normal_dense
            # Warm-start normals are keyed by row position in the native call.
            self._normal_dense = np.ascontiguousarray(full[index])
            try:
                sub_batches, geometry_ms = super()._prefetch_directional_pairs(positions[index], radii[index])
                full[index] = self._normal_dense
            finally:
                self._normal_dense = full
            for local, original in enumerate(recompute):
                batches[original] = sub_batches[local]
        for i in self._reused:
            batches[i] = None
        return batches, geometry_ms

    def active_planes_for_robot_sphere(self, robot_index, center, radius, directional_batch=None, exact_batch=None):
        if robot_index in getattr(self, "_reused", ()):
            current = set(self._candidates_now[robot_index].tolist())
            planes = []
            for plane in self._state[robot_index]["planes"]:
                if plane.obstacle_index not in current:
                    continue
                clearance = plane.offset - float(plane.normal_to_obstacle @ center) - float(radius) - self.safety_margin
                planes.append(ProtocolSeparatingPlane(
                    robot_index=robot_index, obstacle_index=plane.obstacle_index, proxy_id=plane.proxy_id,
                    normal_to_obstacle=plane.normal_to_obstacle, surface_point=plane.surface_point,
                    offset=plane.offset, clearance=clearance, directional_support=True))
            self._last_support_batch_stats = (0, 0.0, 0)
            self._last_closest_batch_stats = (0, 0, 0.0, 0, False)
            return planes, len(current), len(current) - len(planes), 0.0, 0.0
        result = super().active_planes_for_robot_sphere(robot_index, center, radius, directional_batch, exact_batch)
        if hasattr(self, "_state") and robot_index in self._candidates_now:
            self._state[robot_index] = {"center": np.array(center, dtype=float),
                                        "candidates": np.sort(self._candidates_now[robot_index]),
                                        "planes": result[0]}
        return result
