"""Profile _prepare_publication (runs in the control process) on recorded frames."""
import cProfile
import os
import pstats
import sys
import time
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
import run_v6_case  # noqa: E402

os.environ["UR5_STATIC_CAMERAS"] = run_v6_case.STATIC_CAMERA_PRESETS["low_side"]
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
os.environ["UR5_FRONTIER"] = "1"
os.environ["UR5_FRONTIER_CELL_VOXELS"] = "1"
import run_protocol_v3_async_online as online  # noqa: E402

case = Path(sys.argv[1])
run = next(p for p in case.iterdir() if p.is_dir())
qs = np.load(run / "causal_source_configurations.npz")["q"][:6]
worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=0.005, maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm", "static_low", "static_side"),
    scene_version="camera_quarter")
packets = [worker.process(q, i, i, 0.0, transferable=True, include_dense_snapshot=False) for i, q in enumerate(qs)]
online._GEODESIC.update(enabled=True, target=np.array([0.63, 0.40633091, 0.58]), build_ms=[])
profiler = cProfile.Profile()
for packet in packets[1:]:
    t = time.perf_counter()
    profiler.enable()
    prepared, guard, observed = online._prepare_publication(packet, "ellipsoid", "mvt_simd", worker.robot_radii, 0.005)
    profiler.disable()
    print(f"prepare {1000*(time.perf_counter()-t):.0f} ms (geodesic {online._GEODESIC['build_ms'][-1]:.0f} ms), "
          f"{len(prepared.proxies.centers)} proxies")
pass
worker.close()
