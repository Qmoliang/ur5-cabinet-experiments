"""Pilot summary (known map): per scene x attraction x controller x condition.

clean   = reached within 5 mm (held 1 s) [after every racket has gone], no collision (no protective stop)
hit     = protective stop caused by a racket;  scene / floor / self = stop caused by those contacts
reach t = median time to the sustained 5 mm reach of the clean runs
Racket conditions count only runs where a racket was actually launched (launches depend on each
controller's own approach); the "launched" column shows how many."""
import collections
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/pilot_known")
rows = collections.defaultdict(list)
for f in ROOT.glob("*/*_seed*/summary.json"):
    ctl_attr, k, v = f.parent.parent.name.rsplit("_", 2)
    ctl, attr = ctl_attr.rsplit("_", 1)
    scene = f.parent.name.split("_ellipsoid_")[0]
    rows[(scene, attr, ctl, k + "@" + v[1:])].append(json.load(open(f)))


def outcome(s):
    o = s.get("objects") or {}
    p = s.get("protective_stop") or {}
    launched = any(d["launched"] for d in o.get("described", []))
    stopped = bool(p.get("stopped"))
    kinds = p.get("kinds") or {}
    if (o.get("count") or 0) > 0:
        reached = bool(o.get("success_after"))
    else:
        reached = bool(s.get("success"))
    cause = None
    if stopped:
        cause = "hit" if "object" in kinds else ("scene" if "scene" in kinds else ("floor" if "floor" in kinds else "self"))
    return dict(launched=launched, clean=reached and not stopped, cause=cause,
                t=s.get("first_sustained_success_time_s"), fallback=s.get("fallback_cycles", 0),
                k=(o.get("count") or 0), peak=s.get("peak_joint_speed_ratio", 0.0), p99=s.get("controller_ms_p99", 0.0))


controllers = ["liuqp", "combined", "neo_paper", "neo_matched"]
conditions = ["k0@0.0", "k1@0.25", "k1@0.5", "k2@0.5"]
print(f"{ROOT}: {sum(len(v) for v in rows.values())} runs")
for attr in ("straight", "geodesic"):
    print(f"\n=== attraction: {attr}.  cell: clean/counted [hit scene floor self]  (counted = all runs for k0, launched runs otherwise)")
    for scene in ("drawer", "cage", "cage_wide", "iris_ur3_shelf_t0"):
        print(f"  {scene}")
        for ctl in controllers:
            cells = []
            for cond in conditions:
                out = [outcome(s) for s in rows.get((scene, attr, ctl, cond), [])]
                if cond != "k0@0.0":
                    out = [o for o in out if o["launched"]]
                c = collections.Counter(o["cause"] for o in out if o["cause"])
                cells.append(f"{sum(o['clean'] for o in out)}/{len(out)} [{c['hit']} {c['scene']} {c['floor']} {c['self']}]")
            base = [outcome(s) for s in rows.get((scene, attr, ctl, "k0@0.0"), [])]
            times = [o["t"] for o in base if o["clean"] and o["t"] is not None]
            t = f"{np.median(times):5.1f}s" if times else "   -  "
            print(f"    {ctl:12s} " + "   ".join(f"{cond}: {cell:17s}" for cond, cell in zip(conditions, cells)) + f"  reach t {t}")
print("\nall runs: peak joint speed / limit (max), controller p99 ms (median) per controller:")
for ctl in controllers:
    out = [outcome(s) for key, ss in rows.items() if key[2] == ctl for s in ss]
    print(f"  {ctl:12s} peak {max(o['peak'] for o in out):.2f}  p99 {np.median([o['p99'] for o in out]):.1f}  "
          f"fallback runs {sum(o['fallback'] > 0 for o in out)}/{len(out)}")
