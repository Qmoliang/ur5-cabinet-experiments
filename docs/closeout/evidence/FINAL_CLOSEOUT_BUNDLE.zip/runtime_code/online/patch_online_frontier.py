"""Add frontier proxies (UR5_FRONTIER=1) to the perception worker (idempotent).

Default off: the worker publishes exactly the CenterVox proxies as before.
"""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/run_protocol_v3_async_online.py")
source = path.read_text()
if "UR5_FRONTIER" in source:
    print("already patched")
    raise SystemExit
edits = [
    (
        "        proxies = self.proxy_manager.snapshot\n"
        "        effective_sphere_radii = (\n",
        "        proxies = self.proxy_manager.snapshot\n"
        "        # Frontier proxies: unseen space inside the cabinet's bounding box\n"
        "        # becomes an obstacle (added after the CenterVox coverage proof).\n"
        "        frontier_count = 0\n"
        "        frontier_ms = 0.0\n"
        "        if os.environ.get(\"UR5_FRONTIER\", \"0\") == \"1\":\n"
        "            from frontier import frontier_cells, merge_frontier, region_of_interest\n"
        "            frontier_started = time.perf_counter()\n"
        "            known_keys, known_states = self.occupancy.snapshot_arrays()\n"
        "            roi_lower, roi_upper = region_of_interest(self.scene.boxes)\n"
        "            centres, radius, cells = frontier_cells(\n"
        "                known_keys, known_states, MAP_VOXEL_SIZE, roi_lower, roi_upper\n"
        "            )\n"
        "            proxies = merge_frontier(proxies, centres, radius, cells)\n"
        "            frontier_count = int(len(centres))\n"
        "            frontier_ms = (time.perf_counter() - frontier_started) * 1000.0\n"
        "        effective_sphere_radii = (\n",
    ),
    (
        "            \"proxy_update_ms\": proxy_update_ms,\n",
        "            \"proxy_update_ms\": proxy_update_ms,\n"
        "            \"frontier_cells\": frontier_count,\n"
        "            \"frontier_ms\": frontier_ms,\n",
    ),
]
for old, new in edits:
    assert source.count(old) == 1, old[:80]
    source = source.replace(old, new)
path.write_text(source)
print("patched")
