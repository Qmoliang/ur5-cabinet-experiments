from pathlib import Path
import json,hashlib,shutil
import numpy as np
ROOT=Path(__file__).resolve().parent
trace=ROOT/'trials/entry_v7_memory_stall_2/trajectory.npz'
with np.load(trace) as z:ticks=np.maximum(1,np.ceil((z['controller_ms']/1000)/.02-1e-9)).astype(np.int64)
np.save(ROOT/'FAILED_DELAY_TICKS.npy',ticks)
(ROOT/'FAILED_DELAY_SOURCE.json').write_text(json.dumps(dict(source=str(trace),source_sha256=hashlib.sha256(trace.read_bytes()).hexdigest(),loaded_key='controller_ms only',ticks=len(ticks),p99_ticks=float(np.percentile(ticks,99)),tail='hold last recorded tick if the sequence is exhausted',scope='offline delay-schedule stress replay; actual solver time is still measured but does not determine simulated command latency in this diagnostic'),indent=2))
s=(ROOT/'pilot_worker_recovery.py').read_text();old="        if job.get('policy_version')=='goal_entry_final':";new="        if job.get('policy_version')=='goal_entry_activated':\n            from goal_entry_policy_activated import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_final':";assert old in s;s=s.replace(old,new)
old="qp_braking=False;qp_brake_steps=0;qp_failure_events=[]";new="qp_braking=False;qp_brake_steps=0;qp_failure_events=[]\nlatency_ticks=np.load(job['latency_ticks_file']) if job.get('latency_ticks_file') else None\nlatency_tail_uses=0";assert old in s;s=s.replace(old,new)
old="            ticks=max(1,int(np.ceil(elapsed/dt-1e-9))) if job.get('compute_delay',True) else 1"
new="""            ticks=max(1,int(np.ceil(elapsed/dt-1e-9))) if job.get('compute_delay',True) else 1
            if latency_ticks is not None:
                latency_tail_uses+=int(fresh_calls-1>=len(latency_ticks))
                ticks=int(latency_ticks[min(fresh_calls-1,len(latency_ticks)-1)])"""
assert old in s;s=s.replace(old,new)
s=s.replace("    result['qp_failure_events']=qp_failure_events","    result['qp_failure_events']=qp_failure_events\n    result['latency_model']='measured_control_compute' if latency_ticks is None else 'recorded_failed_schedule_diagnostic'\n    result['latency_trace_tail_uses']=latency_tail_uses")
compile(s,'pilot_worker_integration.py','exec');(ROOT/'pilot_worker_integration.py').write_text(s)
s=(ROOT/'launch_batch.py').read_text().replace("ROOT/'pilot_worker.py'","ROOT/'pilot_worker_integration.py'");(ROOT/'launch_integration_batch.py').write_text(s)
previous=json.loads((ROOT/'entry_final_jobs.json').read_text());initial=next(j for j in previous if not j.get('start_snapshot'));snapshot=next(j for j in previous if j.get('start_snapshot'))
jobs=[dict(initial,name='online_activation_reset_'+str(i),policy_version='goal_entry_activated') for i in [1,2,3]]
jobs.append(dict(snapshot,name='failed_latency_schedule_replay',policy_version='goal_entry_activated',latency_ticks_file=str(ROOT/'FAILED_DELAY_TICKS.npy')))
(ROOT/'integration_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/integration_validation';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'INTEGRATION_VALIDATION_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},delay_trace_sha256=hashlib.sha256((ROOT/'FAILED_DELAY_TICKS.npy').read_bytes()).hexdigest(),changes=['reset only the escape module progress references when it is activated; snapshot-active control branch is unchanged'],checks=['three unmodified-public-start online repetitions','one adverse scheduling replay from a previously failed same-state run; no trajectory is supplied as a control reference'],hard_safety_and_goal_unchanged=True,no_new_escape_strategy=True),indent=2))
print(json.dumps(jobs))
