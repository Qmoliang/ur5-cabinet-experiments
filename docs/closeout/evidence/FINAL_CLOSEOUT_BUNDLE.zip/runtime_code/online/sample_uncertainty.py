"""Per-sample camera uncertainty along a recorded run: size vs range, per camera.

Uncertainty size = sqrt of the largest eigenvalue of each sample's directional
uncertainty shape.  Frames are the run's published camera poses.
"""
import os
import sys
from pathlib import Path

import numpy as np

os.environ["UR5_FRONTIER"] = "0"
sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
import run_protocol_v3_async_online as online  # noqa: E402
from depth_camera_perception import UR5MountedDepthCamera  # noqa: E402
import mujoco  # noqa: E402

case = Path(sys.argv[1])
run = next(p for p in case.iterdir() if p.is_dir())
sources = np.load(run / "causal_source_configurations.npz")
scene = online._protocol_scene("camera_quarter")
model = online.build_model(scene)
data = mujoco.MjData(model)
camera = UR5MountedDepthCamera(model, width=320, height=180, pixel_stride=1,
                               camera_names=("ur5_depth_wrist", "ur5_depth_forearm"),
                               minimum_range=online.CAMERA_MINIMUM_RANGE, optical_depth_error_bound=0.003,
                               occluding_self_filter=True)
sizes, ranges, names = [], [], []
for q in sources["q"][::10]:
    online.set_configuration(model, data, q)
    for obs in camera.capture(data):
        if obs.sample_uncertainty_shapes is None or not len(obs.points):
            continue
        s = np.sqrt(np.maximum(np.linalg.eigvalsh(np.asarray(obs.sample_uncertainty_shapes))[:, -1], 0))
        position = data.cam_xpos[model.camera(obs.camera_name).id]
        sizes.append(s)
        ranges.append(np.linalg.norm(np.asarray(obs.points) - position, axis=1))
        names.append(np.full(len(s), obs.camera_name))
sizes, ranges, names = map(np.concatenate, (sizes, ranges, names))
print(f"{len(sizes)} samples: uncertainty median {1000*np.median(sizes):.1f} mm, p90 {1000*np.percentile(sizes, 90):.1f}, "
      f"p99 {1000*np.percentile(sizes, 99):.1f}")
for lo_r, hi_r in ((0, 0.15), (0.15, 0.3), (0.3, 0.5), (0.5, 1.6)):
    m = (ranges >= lo_r) & (ranges < hi_r)
    if m.any():
        print(f"  range {lo_r:.2f}-{hi_r:.2f} m: {m.mean()*100:4.1f}% of samples, uncertainty median "
              f"{1000*np.median(sizes[m]):.1f} mm, p90 {1000*np.percentile(sizes[m], 90):.1f}")
for n in np.unique(names):
    m = names == n
    print(f"  {n}: median {1000*np.median(sizes[m]):.1f} mm")
camera.close()
