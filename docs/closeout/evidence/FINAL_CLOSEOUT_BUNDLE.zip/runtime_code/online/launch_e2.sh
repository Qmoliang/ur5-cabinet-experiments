#!/bin/bash
# E2: subgoal source x trigger, 20 start poses each (E1 = stall + iris already exists).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
COMMON="UR5_KNOWN_INDEX=ball_tree UR5_GUIDANCE=iris_zo"
./launch_seeds.sh $PWD/e2_stall_rrt      ellipsoid 0.075 64 $COMMON UR5_GUIDANCE_SUBGOALS=rrt       UR5_GUIDANCE_TRIGGER=stall &
./launch_seeds.sh $PWD/e2_stall_rrtdense ellipsoid 0.075 96 $COMMON UR5_GUIDANCE_SUBGOALS=rrt_dense UR5_GUIDANCE_TRIGGER=stall &
wait
./launch_seeds.sh $PWD/e2_always_iris    ellipsoid 0.075 64 $COMMON UR5_GUIDANCE_SUBGOALS=iris      UR5_GUIDANCE_TRIGGER=always &
./launch_seeds.sh $PWD/e2_always_rrt     ellipsoid 0.075 96 $COMMON UR5_GUIDANCE_SUBGOALS=rrt       UR5_GUIDANCE_TRIGGER=always &
wait
echo DONE > $PWD/E2_DONE
