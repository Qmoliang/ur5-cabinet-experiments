"""Actual progress acceptance and a trust region for held continuation commands."""
import numpy as np
from continuation_certified_policy import LowDimPolicy as Previous

def values(policy,q,rows):
 g=policy.future_guard;pg=policy.ctx.proxy_guard;out=[]
 for s in sorted({r['fraction'] for r in rows}):
  rs=[r for r in rows if r['fraction']==s];p=g.positions((1-s)*q+s*policy.qg);env=[r for r in rs if r['kind']=='environment']
  if env:
   ri=np.array([r['id'][0] for r in env]);oi=np.array([r['id'][1] for r in env]);dist,_=pg.point_geometry(p[ri],oi,optimizer=True);out.extend((dist-g.radii[ri]-policy.ctx.controller.safety_margin).tolist())
  for r in rs:
   if r['kind']=='environment':continue
   i,j=r['id']
   if r['kind']=='workspace':out.append(float(p[i,j%3]-g.radii[i]-g.workspace_lower[j%3] if j<3 else g.workspace_upper[j%3]-p[i,j%3]-g.radii[i]))
   else:out.append(float(np.linalg.norm(p[i]-p[j])-g.radii[i]-g.radii[j]-g.self_margin))
 return min(out,default=0.)

class LowDimPolicy(Previous):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.trust_radius=.04;self.last_delay_ticks=1;self.progress_stage=None;self.acceptance_events=[];self.nonlinear_rejections=0;self.execution_contract_rejections=0;self.stage_rejections=0;self.stage_acceptances=0;self.proposal_contract=None;self.call_horizon=self.dt;self.progress_stagnations=0
 def continuation_witnesses(self,q):
  force=self.progress_stage is None or self.k-self.progress_stage['cycle']>=100 or np.max(np.abs(q-self.progress_stage['q']))>=self.trust_radius
  if force:self.witness_anchor=None
  before=self.refreshes;state=super().continuation_witnesses(q)
  if self.refreshes>before:
   m=-state['deficit'];old=self.progress_stage
   if old is not None:
    predicted=min([r['slack']+r['b']@(q-old['q']) for r in old['rows']],default=0.)-old['margin'];actual=m-old['margin'];accepted=actual>=.0002
    bad=actual<-.0002 or (predicted>.0002 and actual<.25*predicted)
    if bad:
     self.stage_rejections+=1;self.trust_radius=max(.04/4096,self.trust_radius/2);self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8
    elif accepted:
     self.stage_acceptances+=1
     if actual>=.75*max(predicted,0):self.trust_radius=min(.04,self.trust_radius*2)
    else:self.progress_stagnations+=1
    event=dict(cycle=self.k,start_cycle=old['cycle'],before_m=old['margin'],after_m=m,predicted_gain_m=float(predicted),actual_gain_m=float(actual),accepted=accepted,rejected=bad,trust_radius_rad=self.trust_radius)
    self.acceptance_events.append(event)
    if len(self.acceptance_events)<=400:self.emit('actual_progress_assessed',**{k:v for k,v in event.items() if k!='cycle'})
   self.progress_stage=dict(cycle=self.k,q=q.copy(),margin=m,rows=[dict(r,b=r['b'].copy()) for r in state['rows']])
  return state
 def _extras(self,c,s):
  rows,bounds=super()._extras(c,s)
  if self.mode=='CERT_PREP':
   speed=self.trust_radius/self.call_horizon;rows=np.vstack([rows,np.eye(6),-np.eye(6)]);bounds=np.r_[bounds,np.full(12,speed)]
  return rows,bounds
 def _admit(self,c,arrays,answer,coordinate=None):
  admitted=super()._admit(c,arrays,answer,coordinate)
  if admitted is None or self.mode!='CERT_PREP' or self.future_state is None or not self.future_state['rows']:return admitted
  v=admitted[0];rows=self.future_state['rows'];m=min(r['slack'] for r in rows);pred=min(r['slack']+self.call_horizon*(r['b']@v) for r in rows)-m
  if pred>2e-9:
   realized=values(self,self.q+self.call_horizon*v,rows)-m
   if realized<.5*pred-2e-7:self.nonlinear_rejections+=1;return None
  return admitted
 def __call__(self,c,s,arrays):
  self.proposal_contract=None;self.call_horizon=self.dt*max(1,min(100,int(self.last_delay_ticks)));before=self.nonlinear_rejections;delta=super().__call__(c,s,arrays)
  if self.brake_pending:
   self.expected=None;self.last_delta=np.zeros(6);c.pilot_supplied_solution=None
   if self.nonlinear_rejections>before:self.trust_radius=max(.04/4096,self.trust_radius/2)
   return np.zeros(6)
  if self.expected is not None and self.mode=='CERT_PREP':self.proposal_contract=dict(q=self.q.copy(),radius=self.trust_radius,cycle=self.k,mode=self.mode)
  return delta
 def filter_progress(self,q,previous,command,lo,hi,contract):
  if contract is None or contract['mode']!='CERT_PREP':return command
  if np.max(np.abs(q-contract['q']))<=contract['radius']+1e-12:return command
  self.execution_contract_rejections+=1;self.command_epoch+=1;self.brake_pending=True;self.witness_anchor=None
  if self.execution_contract_rejections<=100:self.emit('held_command_outside_validated_region',source_cycle=contract['cycle'],displacement_rad=float(np.max(np.abs(q-contract['q']))),radius_rad=contract['radius'])
  return np.clip(previous-np.clip(previous,-self.acceleration*self.dt,self.acceleration*self.dt),lo,hi)
 def summary(self):
  out=super().summary();out.update(actual_progress_events=self.acceptance_events,actual_progress_accepted=self.stage_acceptances,actual_progress_rejected=self.stage_rejections,actual_progress_stagnations=self.progress_stagnations,nonlinear_progress_rejections=self.nonlinear_rejections,held_command_progress_rejections=self.execution_contract_rejections,final_trust_radius_rad=self.trust_radius,progress_rule='full-map witness refresh checks actual stage progress; candidate nonlinear agreement over previously observed delay; invalidate held commands outside their validated state region; never delete physical or inherited no-return constraints')
  return out
