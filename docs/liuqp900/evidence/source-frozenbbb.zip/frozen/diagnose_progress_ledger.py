from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent;out=[]
for name in ['final_original_cycle_1','final_original_measured_1','regression_end_2','progress_original_cycle_v5']:
 f=R/'trials'/name;r=json.loads((f/'result.json').read_text());p=r['policy_summary'];stages=p.get('actual_progress_events',[]);best=-float('inf');local_only=0;frontier=0;worst_loss=0.;examples=[]
 for a in stages:
  if 'after_m' not in a:continue
  m=a['after_m'];prior=best;best=max(best,a['before_m'],m);loss=max(0.,best-m);worst_loss=max(worst_loss,loss)
  if a.get('accepted'):
   if m<prior+.0002:
    local_only+=1
    if len(examples)<5:examples.append(dict(cycle=a['cycle'],stage_gain_m=a['actual_gain_m'],current_m=m,earlier_best_m=prior))
   else:frontier+=1
 out.append(dict(name=name,accepted_stage_count=p.get('actual_progress_accepted'),accepted_stages_without_new_best_margin=local_only,accepted_stages_with_new_best_margin=frontier,worst_observed_drop_below_previous_best_mm=worst_loss*1000,examples=examples,scope='stage records only; valid local progress is not a proof of accumulated progress or a globally non-returning trajectory'))
(R/'PROGRESS_LEDGER_DIAGNOSIS.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
