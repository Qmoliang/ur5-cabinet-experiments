#!/bin/bash
# Wall layout sweep: 8 searches at a time on CPUs 120-127.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
: > wall_sweep.jsonl
combos=()
for top in 0.40 0.45 0.50; do for x in 0.25 0.30; do for b in 0.15 0.20 0.25; do for d in 0.10 0.15 0.20; do combos+=("$top $x $b $d"); done; done; done; done
run() { UR5_SCENE_JSON=x OMP_NUM_THREADS=1 taskset -c $2 timeout 3000 ~/envs/ur5cab/bin/python wall_sweep_one.py $1 2>/dev/null | grep "^{" >> wall_sweep.jsonl; }
cpus=(120 121 122 123 124 125 126 127)
for ((i = 0; i < ${#combos[@]}; i += 8)); do
  for k in $(seq 0 7); do j=$((i + k)); [ $j -lt ${#combos[@]} ] || break; run "${combos[$j]}" ${cpus[$k]} & done
  wait
done
echo DONE > WALL_SWEEP_DONE
