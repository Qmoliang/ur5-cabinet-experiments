from pathlib import Path
import os,sys,json,queue,subprocess,concurrent.futures
ROOT=Path(__file__).resolve().parent;PY='/home/hsjed/envs/ur5cab/bin/python';patterns=sys.argv[1:] or ['entry*']
folders=[p for p in sorted({p for pattern in patterns for p in (ROOT/'trials').glob(pattern)}) if (p/'result.json').exists() and (not (p/'audit.json').exists() or not (p/'memory_audit.json').exists())]
slots=queue.Queue();slots.put('40,41,42,43');slots.put('44,45,46,47')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libstdc++.so.6')
def run(folder):
    cpus=slots.get()
    try:
        for script,artifact,log in [('audit_pilot.py','audit.json','audit.log'),('audit_continuation_memory.py','memory_audit.json','memory_audit.log')]:
            if (folder/artifact).exists():continue
            with (folder/log).open('w') as output:
                try:subprocess.run([PY,'-u',str(ROOT/script),str(folder),cpus],env=env,stdout=output,stderr=subprocess.STDOUT,timeout=900,check=True)
                except (subprocess.CalledProcessError,subprocess.TimeoutExpired) as error:print(json.dumps(dict(name=folder.name,audit=script,error=str(error))),flush=True)
        a=json.loads((folder/'audit.json').read_text()) if (folder/'audit.json').exists() else {}
        m=json.loads((folder/'memory_audit.json').read_text()) if (folder/'memory_audit.json').exists() else {}
        out=dict(name=folder.name,safety=a.get('safety_passed'),arrival=a.get('safe_arrival'),memory=m.get('passed'),memories=m.get('memory_count'));print(json.dumps(out),flush=True);return out
    finally:slots.put(cpus)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:out=list(pool.map(run,folders))
(ROOT/'ENTRY_AUDIT_LATEST.json').write_text(json.dumps(out,indent=2))
