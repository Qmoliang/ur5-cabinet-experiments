"""Add UR5_ATTRACTION, UR5_LINK_REGIONS and UR5_PYTHON_PLANES to known_v6/run.py (idempotent).

All default off; with none set the runner behaves exactly as before.
"""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
source = path.read_text()
if "UR5_LINK_REGIONS" in source:
    print("already patched")
    raise SystemExit

edits = [
    (
        "    if representation == \"sphere\":\n"
        "        controller = ProtocolLiuQPController(**common, obstacle_radii=cover.sphere_radii)\n"
        "    else:\n"
        "        controller = ProtocolLiuQPController(**common, obstacle_shapes=cover.ellipsoid_shapes)\n",
        "    controller_class = ProtocolLiuQPController\n"
        "    if os.environ.get(\"UR5_LINK_REGIONS\", \"0\") == \"1\":\n"
        "        from link_regions import LinkRegionLiuQPController\n"
        "        controller_class = LinkRegionLiuQPController\n"
        "    if representation == \"sphere\":\n"
        "        controller = controller_class(**common, obstacle_radii=cover.sphere_radii)\n"
        "    else:\n"
        "        controller = controller_class(**common, obstacle_shapes=cover.ellipsoid_shapes)\n"
        "    if os.environ.get(\"UR5_PYTHON_PLANES\", \"0\") == \"1\":\n"
        "        # Same per-sphere plane path as the link-region controller uses for\n"
        "        # its fallback, so plane-solve counts compare like for like.\n"
        "        controller.native_exact_pair_batch = False\n"
        "    attractor = None\n"
        "    attraction_mode = os.environ.get(\"UR5_ATTRACTION\", \"straight\")\n"
        "    if attraction_mode == \"geodesic\":\n"
        "        sys.path.insert(0, str(ROOT.parent / \"online_v6\"))\n"
        "        from geodesic import GeodesicAttractor\n"
        "        attractor_started = time.perf_counter()\n"
        "        attractor = GeodesicAttractor(\n"
        "            cover.centers, target, representation,\n"
        "            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,\n"
        "        )\n"
        "        attractor_build_ms = (time.perf_counter() - attractor_started) * 1000.0\n"
        "    elif attraction_mode != \"straight\":\n"
        "        raise ValueError(\"UR5_ATTRACTION must be straight or geodesic\")\n",
    ),
    (
        "            command = target if guidance is None else guidance.current_target()\n",
        "            command = target if guidance is None else guidance.current_target()\n"
        "            if attractor is not None:\n"
        "                command = attractor.command(ee_history[-1])\n",
    ),
    (
        "        \"guidance_mode\": guidance_mode,\n",
        "        \"guidance_mode\": guidance_mode,\n"
        "        \"attraction_mode\": attraction_mode,\n"
        "        \"attractor_build_ms\": attractor_build_ms if attractor is not None else None,\n"
        "        \"link_regions\": controller_class.__name__ != \"ProtocolLiuQPController\",\n"
        "        \"python_planes\": os.environ.get(\"UR5_PYTHON_PLANES\", \"0\") == \"1\",\n"
        "        \"shared_plane_solves\": getattr(controller, \"shared_plane_solves\", None),\n"
        "        \"per_sphere_plane_solves\": getattr(controller, \"per_sphere_plane_solves\", None),\n"
        "        \"active_obstacle_rows_total\": int(sum(row[\"active_obstacle_rows\"] for row in cycles)),\n"
        "        \"active_obstacle_rows_p50\": float(np.median([row[\"active_obstacle_rows\"] for row in cycles])),\n"
        "        \"geometry_ms_p50\": float(np.median([row[\"geometry_ms\"] for row in cycles])),\n",
    ),
]
for old, new in edits:
    assert source.count(old) == 1, old[:80]
    source = source.replace(old, new)
path.write_text(source)
print("patched")
