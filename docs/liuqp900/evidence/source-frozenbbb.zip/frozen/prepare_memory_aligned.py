from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;s=(R/'pilot_worker_goal_plane_acceptance.py').read_text().replace("        if job.get('policy_version')=='goal_plane_acceptance':","        if job.get('policy_version')=='goal_plane_memory':\n            from goal_plane_memory_policy import LowDimPolicy\n        elif job.get('policy_version')=='goal_plane_acceptance':");(R/'pilot_worker_goal_plane_memory.py').write_text(s)
s=(R/'launch_goal_plane_final.py').read_text().replace("ROOT/'pilot_worker_goal_plane_acceptance.py'","ROOT/'pilot_worker_goal_plane_memory.py'").replace('[32,33,34,35]','[48,49,50,51]').replace('[36,37,38,39]','[52,53,54,55]');(R/'launch_goal_plane_memory.py').write_text(s)
j=json.loads((R/'goal_plane_final_jobs.json').read_text())
# Evaluate the exact rejected snapshot first, then all remaining frozen cases.
j.sort(key=lambda x:x['name']!='goal_plane_regression_end_2')
for x in j:x['name']=x['name'].replace('goal_plane_','memory_aligned_',1);x['policy_version']='goal_plane_memory'
(R/'memory_aligned_jobs.json').write_text(json.dumps(j,indent=2));a=R/'revisions/goal_plane_memory';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
(R/'MEMORY_ALIGNED_FREEZE.json').write_text(json.dumps(dict(jobs=j,sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['goal_plane_memory_policy.py','goal_plane_acceptance_policy.py','goal_side_plane_policy.py','diagnostic_exact_pruned_policy.py','pilot_worker_goal_plane_memory.py','code/online/protocol_liuqp_controller.py','code/common/policy.json','GOAL_BRANCH_PORTS.json','INPUTS.json']},scope='same twelve cases, same objective and thresholds, only sharper existing no-return interval certificate; all outcomes retained'),indent=2));print('frozen',len(j),'memory-aligned trials')
