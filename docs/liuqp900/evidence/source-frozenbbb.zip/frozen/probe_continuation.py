from pathlib import Path
import os,json,time
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np,mujoco
from pilot_adapter import ROOT,build
from continuation_policy import LowDimPolicy
OLD=ROOT.parent/'liuqp_reheading_study_20261107'
job=json.loads((ROOT/'development_jobs.json').read_text())[0]
ctx=build(job['task']);c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7
out=[]
for name,path in [('original_stall',Path(job['start_snapshot']))]+[(n,next((OLD/'trials'/n).glob('snapshot_final_*.npz'))) for n in ['reheading_v2_measured_1','reheading_v2_measured_2','reheading_v2_original_start']]:
 z=np.load(path);q=z['q'];previous=z['previous'];ctx.data.qpos[:6]=q;c.applied_velocity=previous.copy();c.pilot_objective_hook=None;c.solve(ctx.target)
 p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,previous)
 if name!='original_stall':p.memories=json.loads((OLD/'trials'/name/'goalward_memories.json').read_text())
 st=p.continuation_witnesses(q);p.future_state=st;p.mode='CERT_PREP';p.brake_pending=False
 a=p._solve(c,c.pilot_nominal,c.last_qp_arrays);ad=None if a is None else p._admit(c,c.last_qp_arrays,a)
 worst=sorted(st['rows'],key=lambda x:x['slack'])[0] if st['rows'] else None
 errors=[]
 if worst is not None:
  def value(qq):
   g=p.future_guard;fraction=worst['fraction'];points=g.positions((1-fraction)*qq+fraction*p.qg);kind=worst['kind'];i,j=worst['id']
   if kind=='environment':return float(ctx.proxy_guard.point_geometry(points[i][None,:],np.array([j]),optimizer=True)[0][0]-g.radii[i]-c.safety_margin)
   if kind=='workspace':return float(points[i,j%3]-g.radii[i]-g.workspace_lower[j%3] if j<3 else g.workspace_upper[j%3]-points[i,j%3]-g.radii[i])
   return float(np.linalg.norm(points[i]-points[j])-g.radii[i]-g.radii[j]-g.self_margin)
  for j in range(6):
   e=np.eye(6)[j]*1e-6;numeric=(value(q+e)-value(q-e))/2e-6;errors.append(float(abs(numeric-worst['b'][j])))
 record=dict(name=name,deficit_m=st['deficit'],witnesses=len(st['rows']),query_s=st['seconds'],worst=None if worst is None else {k:(v.tolist() if hasattr(v,'tolist') else v) for k,v in worst.items()},gradient_max_error=max(errors,default=0),proposal=None if a is None else a['velocity'].tolist(),admitted=None if ad is None else ad[0].tolist(),inherited_memories=len(p.memories))
 if ad is not None:record['executed_one_step_deficit_m']=p.continuation_witnesses(q+.02*ad[0])['deficit']
 out.append(record);print(json.dumps(record),flush=True)
p.q=p.qg.copy();cert=p.continuation_certificate();assert cert
(ROOT/'SNAPSHOT_PROBE.json').write_text(json.dumps(dict(cases=out,terminal_fixed_point_certificate=cert),indent=2))
assert max(x['gradient_max_error'] for x in out)<1e-4
