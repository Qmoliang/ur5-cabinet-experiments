// Ball-tree broad phase over proxy AABBs, as a drop-in alternative to the
// native multilevel voxel table.  Leaves apply exactly the same float32
// sphere-vs-AABB predicate as BruteForceAABBIndex, so the candidate set is
// identical; only the way candidates are found differs.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <numeric>
#include <vector>

#ifdef _WIN32
#define BT_API extern "C" __declspec(dllexport)
#else
#define BT_API extern "C"
#endif

namespace {

struct Node {
    float center[3];
    float radius;
    int32_t begin;  // range into order[] for leaves
    int32_t end;
    int32_t left;   // -1 for leaves
    int32_t right;
};

struct BallTree {
    std::vector<float> lo;      // n x 3
    std::vector<float> hi;      // n x 3
    std::vector<float> center;  // n x 3, AABB centers
    std::vector<float> bound;   // n, radius of the sphere around each AABB
    std::vector<int32_t> order;
    std::vector<Node> nodes;
    float padding = 0.0f;
    int32_t leaf_size = 8;
};

int32_t build(BallTree& tree, int32_t begin, int32_t end) {
    Node node{};
    double mean[3] = {0.0, 0.0, 0.0};
    for (int32_t k = begin; k < end; ++k) {
        const int32_t i = tree.order[k];
        for (int a = 0; a < 3; ++a) mean[a] += tree.center[3 * i + a];
    }
    for (int a = 0; a < 3; ++a) node.center[a] = static_cast<float>(mean[a] / (end - begin));
    float radius = 0.0f;
    float lower[3] = {INFINITY, INFINITY, INFINITY};
    float upper[3] = {-INFINITY, -INFINITY, -INFINITY};
    for (int32_t k = begin; k < end; ++k) {
        const int32_t i = tree.order[k];
        float d2 = 0.0f;
        for (int a = 0; a < 3; ++a) {
            const float d = tree.center[3 * i + a] - node.center[a];
            d2 += d * d;
            lower[a] = std::min(lower[a], tree.center[3 * i + a]);
            upper[a] = std::max(upper[a], tree.center[3 * i + a]);
        }
        radius = std::max(radius, std::sqrt(d2) + tree.bound[i]);
    }
    // Small relative inflation keeps float rounding from pruning a true hit.
    node.radius = radius * 1.0001f + 1.0e-6f;
    node.begin = begin;
    node.end = end;
    node.left = node.right = -1;
    const int32_t index = static_cast<int32_t>(tree.nodes.size());
    tree.nodes.push_back(node);
    if (end - begin > tree.leaf_size) {
        int axis = 0;
        for (int a = 1; a < 3; ++a)
            if (upper[a] - lower[a] > upper[axis] - lower[axis]) axis = a;
        const int32_t middle = begin + (end - begin) / 2;
        std::nth_element(tree.order.begin() + begin, tree.order.begin() + middle,
                         tree.order.begin() + end, [&](int32_t x, int32_t y) {
                             return tree.center[3 * x + axis] < tree.center[3 * y + axis];
                         });
        const int32_t left = build(tree, begin, middle);
        const int32_t right = build(tree, middle, end);
        tree.nodes[index].left = left;
        tree.nodes[index].right = right;
    }
    return index;
}

}  // namespace

BT_API void* bt_create(const float* centers, const float* half_extents, int32_t count,
                       float query_padding, int32_t leaf_size) {
    if (count <= 0) return nullptr;
    auto* tree = new BallTree();
    tree->padding = query_padding;
    tree->leaf_size = std::max(1, leaf_size);
    tree->lo.resize(3 * count);
    tree->hi.resize(3 * count);
    tree->center.resize(3 * count);
    tree->bound.resize(count);
    for (int32_t i = 0; i < count; ++i) {
        float b2 = 0.0f;
        for (int a = 0; a < 3; ++a) {
            // Same float32 bounds as the brute-force reference.
            tree->lo[3 * i + a] = centers[3 * i + a] - half_extents[3 * i + a];
            tree->hi[3 * i + a] = centers[3 * i + a] + half_extents[3 * i + a];
            tree->center[3 * i + a] = centers[3 * i + a];
            b2 += half_extents[3 * i + a] * half_extents[3 * i + a];
        }
        tree->bound[i] = std::sqrt(b2) * 1.0001f + 1.0e-6f;
    }
    tree->order.resize(count);
    std::iota(tree->order.begin(), tree->order.end(), 0);
    tree->nodes.reserve(2 * count / tree->leaf_size + 2);
    build(*tree, 0, count);
    return tree;
}

BT_API void bt_destroy(void* handle) { delete static_cast<BallTree*>(handle); }

BT_API int32_t bt_node_count(void* handle) {
    return static_cast<int32_t>(static_cast<BallTree*>(handle)->nodes.size());
}

// Batched form for planners: every (query sphere, proxy) pair whose AABB test
// passes, written as two parallel arrays.  Returns the pair count, or -1 if the
// output buffers are too small.  Unlike bt_query_sphere, radii are used as given.
BT_API int32_t bt_query_pairs(void* handle, const float* centers, const float* radii,
                              int32_t count, int32_t* out_query, int32_t* out_proxy,
                              int32_t capacity) {
    const auto& tree = *static_cast<BallTree*>(handle);
    int32_t written = 0;
    int32_t stack[128];
    for (int32_t q = 0; q < count; ++q) {
        const float* c = centers + 3 * q;
        const float r = radii[q];
        const float r2 = r * r;
        int32_t top = 0;
        stack[top++] = 0;
        while (top) {
            const Node& node = tree.nodes[stack[--top]];
            float d2 = 0.0f;
            for (int a = 0; a < 3; ++a) {
                const float d = c[a] - node.center[a];
                d2 += d * d;
            }
            const float reach = r + node.radius;
            if (d2 > reach * reach) continue;
            if (node.left >= 0) {
                stack[top++] = node.left;
                stack[top++] = node.right;
                continue;
            }
            for (int32_t k = node.begin; k < node.end; ++k) {
                const int32_t i = tree.order[k];
                float s = 0.0f;
                for (int a = 0; a < 3; ++a) {
                    const float below = std::max(tree.lo[3 * i + a] - c[a], 0.0f);
                    const float above = std::max(c[a] - tree.hi[3 * i + a], 0.0f);
                    const float d = std::max(below, above);
                    s += d * d;
                }
                if (s <= r2) {
                    if (written >= capacity) return -1;
                    out_query[written] = q;
                    out_proxy[written] = i;
                    ++written;
                }
            }
        }
    }
    return written;
}

// Returns the number of candidates written (sorted ascending), or -1 if the
// output buffer is too small.
BT_API int32_t bt_query_sphere(void* handle, const float* query_center, float radius,
                               int32_t* output, int32_t capacity) {
    const auto& tree = *static_cast<BallTree*>(handle);
    const float r = radius + tree.padding;
    const float r2 = r * r;
    int32_t written = 0;
    int32_t stack[128];
    int32_t top = 0;
    stack[top++] = 0;
    while (top) {
        const Node& node = tree.nodes[stack[--top]];
        float d2 = 0.0f;
        for (int a = 0; a < 3; ++a) {
            const float d = query_center[a] - node.center[a];
            d2 += d * d;
        }
        const float reach = r + node.radius;
        if (d2 > reach * reach) continue;
        if (node.left >= 0) {
            stack[top++] = node.left;
            stack[top++] = node.right;
            continue;
        }
        for (int32_t k = node.begin; k < node.end; ++k) {
            const int32_t i = tree.order[k];
            float s = 0.0f;
            for (int a = 0; a < 3; ++a) {
                const float below = std::max(tree.lo[3 * i + a] - query_center[a], 0.0f);
                const float above = std::max(query_center[a] - tree.hi[3 * i + a], 0.0f);
                const float d = std::max(below, above);
                s += d * d;
            }
            if (s <= r2) {
                if (written >= capacity) return -1;
                output[written++] = i;
            }
        }
    }
    std::sort(output, output + written);
    return written;
}
