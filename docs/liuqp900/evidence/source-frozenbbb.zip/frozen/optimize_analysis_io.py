from pathlib import Path
import os,signal,shutil
R=Path(__file__).resolve().parent
for proc in Path('/proc').iterdir():
 if not proc.name.isdigit():continue
 try:args=(proc/'cmdline').read_bytes().decode().split('\0');cwd=(proc/'cwd').resolve()
 except (OSError,UnicodeDecodeError):continue
 if cwd==R and any(x in args for x in ['diagnose_failure.py','quick_attribution.py']):os.kill(int(proc.name),signal.SIGTERM);print('stopped read-only analysis',proc.name)
a=R/'revisions/analysis_io';a.mkdir(parents=True,exist_ok=True)
for n in ['diagnose_failure.py','quick_attribution.py']:
 p=R/n;shutil.copy2(p,a/n);s=p.read_text()
 for expr in ["f/'decision_trace.npz'","f/'trajectory.npz'","R/'trials/exact_failure_trace/decision_trace.npz'","R/'trials/exact_failure_trace/trajectory.npz'"]:s=s.replace('np.load('+expr+')','dict(np.load('+expr+'))')
 p.write_text(s)
