"""bucket_fit_native.cpp: Jacobi for basis-independent eigen uses, LAPACK where the basis matters."""
from pathlib import Path
import sys
p = Path(sys.argv[1]); s = p.read_text()

def sub(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:70], s.count(old))
    s = s.replace(old, new)

sub('''M3 sym(const double* a) {''', '''// Cyclic Jacobi for a symmetric 3x3 matrix: ascending values, V[3*i+j] =
// component i of eigenvector j.  Used only where the result does not depend on
// the eigenvector basis (eigenvalues, V f(w) V^T matrix functions); LAPACK
// (eigh3) stays where the basis itself enters the fit.
void eigh3_fast(const double* s_in, V3& w, M3& v_out) {
  double a[9];
  std::memcpy(a, s_in, sizeof(a));
  double v[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  for (int sweep = 0; sweep < 60; ++sweep) {
    double off = a[1] * a[1] + a[2] * a[2] + a[5] * a[5];
    double diag = a[0] * a[0] + a[4] * a[4] + a[8] * a[8];
    if (off <= 1e-34 * diag || off < 1e-300) break;
    for (int p = 0; p < 2; ++p)
      for (int q = p + 1; q < 3; ++q) {
        double apq = a[3 * p + q];
        if (apq == 0.0) continue;
        double app = a[3 * p + p], aqq = a[3 * q + q];
        double theta = (aqq - app) / (2.0 * apq);
        double t = (theta >= 0 ? 1.0 : -1.0) / (std::fabs(theta) + std::sqrt(theta * theta + 1.0));
        double c = 1.0 / std::sqrt(t * t + 1.0), sn = t * c;
        for (int k = 0; k < 3; ++k) {
          double akp = a[3 * k + p], akq = a[3 * k + q];
          a[3 * k + p] = c * akp - sn * akq;
          a[3 * k + q] = sn * akp + c * akq;
        }
        for (int k = 0; k < 3; ++k) {
          double apk = a[3 * p + k], aqk = a[3 * q + k];
          a[3 * p + k] = c * apk - sn * aqk;
          a[3 * q + k] = sn * apk + c * aqk;
        }
        for (int k = 0; k < 3; ++k) {
          double vkp = v[3 * k + p], vkq = v[3 * k + q];
          v[3 * k + p] = c * vkp - sn * vkq;
          v[3 * k + q] = sn * vkp + c * vkq;
        }
      }
  }
  int order[3] = {0, 1, 2};
  std::sort(order, order + 3, [&](int x, int y) { return a[4 * x] < a[4 * y]; });
  for (int j = 0; j < 3; ++j) {
    w[j] = a[4 * order[j]];
    for (int i = 0; i < 3; ++i) v_out[3 * i + j] = v[3 * i + order[j]];
  }
}

V3 eigvalsh3_fast(const M3& s) {
  V3 w;
  M3 v;
  eigh3_fast(s.data(), w, v);
  return w;
}

M3 sym(const double* a) {''')
# grouped union: positive part, slack, reference inverse root, whitened scale -> basis independent
sub('''      V3 w;
      M3 v;
      eigh3(diff, w, v);
      V3 wp{std::max(w[0], 0.0), std::max(w[1], 0.0), std::max(w[2], 0.0)};''', '''      V3 w;
      M3 v;
      eigh3_fast(diff.data(), w, v);
      V3 wp{std::max(w[0], 0.0), std::max(w[1], 0.0), std::max(w[2], 0.0)};''')
sub('''      minimum = std::min(minimum, eigvalsh3(d)[0]);''', '''      minimum = std::min(minimum, eigvalsh3_fast(d)[0]);''')
sub('''    V3 rw;
    M3 rv;
    eigh3(ref, rw, rv);''', '''    V3 rw;
    M3 rv;
    eigh3_fast(ref.data(), rw, rv);''')
sub('''      scale = std::max(scale, eigvalsh3(ws)[2]);''', '''      scale = std::max(scale, eigvalsh3_fast(ws)[2]);''')
# value-only uses in requirements, outputs and surface radius
s = s.replace('eigvalsh3(un)[2]', 'eigvalsh3_fast(un)[2]').replace('eigvalsh3(outer)[2]', 'eigvalsh3_fast(outer)[2]')
sub('''eigvalsh3(sym(uncertainty + 9 * i))[2]''', '''eigvalsh3_fast(sym(uncertainty + 9 * i))[2]''')
p.write_text(s); print('patched; remaining LAPACK eigh3 calls:', s.count('eigh3(') - s.count('void eigh3('), 'eigvalsh3( calls:', s.count('eigvalsh3(') - s.count('V3 eigvalsh3('))
