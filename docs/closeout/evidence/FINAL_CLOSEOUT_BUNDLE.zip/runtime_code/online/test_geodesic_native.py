"""Native vs Python geodesic field on the known cabinet."""
import sys
import time
from pathlib import Path

import numpy as np

KNOWN = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
sys.path[:0] = [str(KNOWN / "src"), str(KNOWN / "src" / "core"), str(KNOWN), str(KNOWN.parent / "online_v6")]

from geodesic import GeodesicAttractor  # noqa: E402
from geodesic_fast import NativeGeodesicAttractor  # noqa: E402
from known_volume import build_volume_cover  # noqa: E402
from run import load_scene  # noqa: E402

scene = load_scene()
target = np.asarray(scene.waypoints[-1], dtype=float)
for span in (0.075, 0.018):
    cover = build_volume_cover(scene.boxes, "ellipsoid", span)
    t = time.perf_counter()
    python = GeodesicAttractor(cover.centers, target, "ellipsoid", shapes=cover.ellipsoid_shapes)
    python_s = time.perf_counter() - t
    native = NativeGeodesicAttractor(cover.centers, target, "ellipsoid", shapes=cover.ellipsoid_shapes)
    print(f"{len(cover.centers)} ellipsoids: build python {python_s:.1f} s, native {native.build_ms:.1f} ms; "
          f"reachable cells python {python.reachable_cells}, native {native.reachable_cells}")
    angles = []
    for run in ("e0/ellipsoid_075mm_seed02", "e0/ellipsoid_075mm_seed01"):
        for p in np.load(RUNS / run / "ee_history.npy")[::50]:
            a, b = python.command(p) - p, native.command(p) - p
            if np.linalg.norm(a) > 1e-9 and np.linalg.norm(b) > 1e-9:
                angles.append(np.degrees(np.arccos(np.clip(a @ b / np.linalg.norm(a) / np.linalg.norm(b), -1, 1))))
    print(f"  direction difference along recorded paths: median {np.median(angles):.1f} deg, max {np.max(angles):.1f} deg")
    t = time.perf_counter()
    for _ in range(1000):
        native.command(target + np.array([-0.4, 0.0, -0.15]))
    print(f"  native command: {1000 * (time.perf_counter() - t) / 1000:.3f} ms each")
    for name, run in (("trapped seed 2", "e0/ellipsoid_075mm_seed02"), ("easy seed 1", "e0/ellipsoid_075mm_seed01")):
        for label, start in (("start", np.load(RUNS / run / "ee_history.npy")[0]),
                             ("final", np.load(RUNS / run / "ee_history.npy")[-1])):
            p = start.copy()
            for step in range(3000):
                d = native.command(p) - p
                n = np.linalg.norm(d)
                if np.linalg.norm(p - target) < 1e-3 or n < 1e-9:
                    break
                p = p + d / n * min(0.004, n)
            print(f"  {name} from {label}: point reaches target with native field: {np.linalg.norm(p - target) < 1e-3}")
