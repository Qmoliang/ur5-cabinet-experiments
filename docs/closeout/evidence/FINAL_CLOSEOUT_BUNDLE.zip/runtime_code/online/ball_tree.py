"""ctypes wrapper for the native ball-tree broad phase (ball_tree.cpp).

Same query interface and float32 sphere-vs-AABB predicate as
native_mvt.BruteForceAABBIndex, so candidate sets are identical.
"""
from __future__ import annotations

import ctypes
from dataclasses import dataclass
import sys
from pathlib import Path

import numpy as np

LIBRARY = Path(__file__).resolve().parent / (
    "ball_tree_native.dll" if sys.platform == "win32" else "ball_tree_native.so"
)


@dataclass(frozen=True)
class BallTreeStats:
    """The bookkeeping fields the runners record for the MVT."""

    level_count: int
    index_references: int
    cell_lookups_per_query: int


class NativeBallTree:
    def __init__(self, centers, half_extents, *, query_padding=0.0, leaf_size=8):
        self._lib = ctypes.CDLL(str(LIBRARY))
        fp = ctypes.POINTER(ctypes.c_float)
        self._lib.bt_create.argtypes = [fp, fp, ctypes.c_int32, ctypes.c_float, ctypes.c_int32]
        self._lib.bt_create.restype = ctypes.c_void_p
        self._lib.bt_destroy.argtypes = [ctypes.c_void_p]
        self._lib.bt_query_sphere.argtypes = [
            ctypes.c_void_p, fp, ctypes.c_float, ctypes.POINTER(ctypes.c_int32), ctypes.c_int32]
        self._lib.bt_query_sphere.restype = ctypes.c_int32
        self._lib.bt_query_pairs.argtypes = [
            ctypes.c_void_p, fp, fp, ctypes.c_int32, ctypes.POINTER(ctypes.c_int32),
            ctypes.POINTER(ctypes.c_int32), ctypes.c_int32]
        self._lib.bt_query_pairs.restype = ctypes.c_int32
        self._lib.bt_node_count.argtypes = [ctypes.c_void_p]
        self._lib.bt_node_count.restype = ctypes.c_int32
        centers = np.ascontiguousarray(centers, dtype=np.float32).reshape(-1, 3)
        half = np.ascontiguousarray(half_extents, dtype=np.float32).reshape(-1, 3)
        self._count = len(centers)
        # The padding is added in Python exactly as the brute-force reference
        # does, then the native side receives the final float32 radius.
        self.query_padding = float(query_padding)
        self._handle = self._lib.bt_create(
            centers.ctypes.data_as(fp), half.ctypes.data_as(fp), self._count, 0.0, int(leaf_size))
        self._output = np.empty(self._count, dtype=np.int32)
        self.node_count = self._lib.bt_node_count(self._handle)
        # Tree depth stands in for "levels"; lookups per query vary with the
        # query, so -1 marks it as not applicable.
        self.stats = BallTreeStats(
            level_count=int(np.ceil(np.log2(max(self.node_count, 1) + 1))),
            index_references=self._count,
            cell_lookups_per_query=-1,
        )

    def query_sphere(self, center, radius) -> np.ndarray:
        center = np.ascontiguousarray(center, dtype=np.float32).reshape(3)
        effective = np.float32(float(radius) + self.query_padding)
        count = self._lib.bt_query_sphere(
            self._handle, center.ctypes.data_as(ctypes.POINTER(ctypes.c_float)), effective,
            self._output.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)), self._count)
        if count < 0:
            raise RuntimeError("ball tree output buffer overflow")
        return self._output[:count].astype(np.int64)

    def query_spheres(self, centers, radii):
        return tuple(self.query_sphere(c, r) for c, r in zip(np.asarray(centers), np.asarray(radii)))

    def query_pairs(self, centers, radii) -> tuple[np.ndarray, np.ndarray]:
        """All (sphere, proxy) AABB-overlap pairs for a batch of spheres, in one
        native call; radii are used as given (no query padding)."""
        centers = np.ascontiguousarray(centers, dtype=np.float32).reshape(-1, 3)
        radii = np.ascontiguousarray(radii, dtype=np.float32).reshape(-1)
        fp = ctypes.POINTER(ctypes.c_float)
        ip = ctypes.POINTER(ctypes.c_int32)
        capacity = max(4096, 64 * len(centers))
        while True:
            spheres = np.empty(capacity, dtype=np.int32)
            proxies = np.empty(capacity, dtype=np.int32)
            count = self._lib.bt_query_pairs(
                self._handle, centers.ctypes.data_as(fp), radii.ctypes.data_as(fp), len(centers),
                spheres.ctypes.data_as(ip), proxies.ctypes.data_as(ip), capacity)
            if count >= 0:
                return spheres[:count].astype(np.int64), proxies[:count].astype(np.int64)
            capacity *= 4

    def close(self):
        if self._handle:
            self._lib.bt_destroy(self._handle)
            self._handle = None

    def __del__(self):
        self.close()


class UnfusedIndex:
    """Expose only query_sphere(s) of another index, so LiuQP takes its plain
    (non-fused) candidate path; used to compare indexes on equal terms."""

    def __init__(self, index):
        self._index = index
        self.query_padding = index.query_padding
        self.stats = index.stats

    def close(self):
        self._index.close()

    def query_sphere(self, center, radius):
        return np.asarray(self._index.query_sphere(center, radius), dtype=np.int64)

    def query_spheres(self, centers, radii):
        return tuple(self.query_sphere(c, r) for c, r in zip(np.asarray(centers), np.asarray(radii)))
