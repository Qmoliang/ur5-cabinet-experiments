"""Bounded robot-only position/posture exploration; final certification stays in planner_core."""
import numpy as np
import mujoco
from scipy.optimize import least_squares

def position_ik(oracle, posture, target, seed, max_nfev=40):
    def residual(x):
        oracle.check_deadline()
        qi=posture.copy();qi[:3]=x
        return oracle.gripper_position(qi)-target
    def jacobian(x):
        oracle.check_deadline()
        qi=posture.copy();qi[:3]=x;oracle.gripper_position(qi)
        mujoco.mj_comPos(oracle.model,oracle.data)
        J=np.zeros((3,oracle.model.nv))
        mujoco.mj_jacSite(oracle.model,oracle.data,J,None,oracle.site)
        return J[:,:3]
    result=least_squares(residual,seed[:3],jac=jacobian,bounds=(oracle.lower[:3],oracle.upper[:3]),max_nfev=max_nfev,ftol=1e-8,xtol=1e-8,gtol=1e-8)
    qi=posture.copy();qi[:3]=result.x
    return qi,float(np.linalg.norm(residual(result.x)))

def add_posture_goals(oracle,q0,target,goals,state):
    reference=state.setdefault('posture_reference',np.asarray(q0).copy())
    offsets=sorted([(x,y) for x in np.linspace(-.8,.8,9) for y in np.linspace(-.6,.6,13)],key=lambda x:x[0]**2+x[1]**2)
    cursor=state.get('posture_cursor',0)
    while cursor<len(offsets):
        oracle.check_deadline();dx,dy=offsets[cursor]
        posture=reference.copy();posture[3]+=dx;posture[4]+=dy
        if np.all(posture>=oracle.lower) and np.all(posture<=oracle.upper):
            goal,error=position_ik(oracle,posture,target,reference)
            if error<.0007 and oracle.free(goal):
                state['posture_feasible_count']=state.get('posture_feasible_count',0)+1
                if not any(np.max(np.abs(goal-g))<.05 for g in goals):goals.append(goal.copy())
        cursor+=1;state['posture_cursor']=cursor

class TaskspaceBiTree:
    def __init__(self,oracle,start,goals,rng):
        self.oracle=oracle;self.rng=rng;self.swapped=False;self.iterations=0
        self.trees=[([np.asarray(start).copy()],[-1]),([np.asarray(g).copy() for g in goals],[-1]*len(goals))]
        self.features=[[self.feature(start)],[self.feature(g) for g in goals]]
        self.roots=[[0],list(range(len(goals)))];self.goal_keys={np.asarray(g).tobytes() for g in goals}
        f0=self.features[0][0];fg=np.asarray(self.features[1])
        self.lower=np.minimum(f0,fg.min(axis=0))-.7;self.upper=np.maximum(f0,fg.max(axis=0))+.7
    def feature(self,q):return np.r_[self.oracle.gripper_position(q)/.15,q[3:5]]
    def add_goals(self,goals):
        side=0 if self.swapped else 1
        for goal in goals:
            key=np.asarray(goal).tobytes()
            if key in self.goal_keys:continue
            self.goal_keys.add(key);f=self.feature(goal)
            self.roots[side].append(len(self.trees[side][0]));self.trees[side][0].append(np.asarray(goal).copy());self.trees[side][1].append(-1);self.features[side].append(f)
            self.lower=np.minimum(self.lower,f-.7);self.upper=np.maximum(self.upper,f+.7)
    def extend(self,side,target):
        points,parents=self.trees[side];features=self.features[side]
        idx=int(np.argmin(np.linalg.norm(np.asarray(features)-target,axis=1)))
        base=points[idx];f=features[idx];delta=target-f;distance=np.linalg.norm(delta)
        nextf=target if distance<=.12 else f+.12*delta/distance
        posture=base.copy();posture[3:5]=nextf[3:]
        if np.any(posture<self.oracle.lower) or np.any(posture>self.oracle.upper):return None
        new,error=position_ik(self.oracle,posture,nextf[:3]*.15,base,max_nfev=12)
        if error>1e-5 or not self.oracle.free(new) or not self.oracle.segment_free(base,new):return None
        points.append(new.copy());parents.append(idx);features.append(self.feature(new));return len(points)-1
    def branch(self,side,index):
        points,parents=self.trees[side];path=[]
        while index>=0:path.append(points[index]);index=parents[index]
        return path[::-1]
    def advance(self,count=8):
        for _ in range(count):
            self.oracle.check_deadline();self.iterations+=1
            sample=self.features[1][self.rng.choice(self.roots[1])] if self.iterations%5==0 else self.rng.uniform(self.lower,self.upper)
            i=self.extend(0,sample)
            if i is not None:
                target=self.features[0][i]
                while True:
                    j=self.extend(1,target)
                    if j is None:break
                    if np.linalg.norm(self.features[1][j]-target)<1e-5:
                        if self.oracle.segment_free(self.trees[0][0][i],self.trees[1][0][j]):
                            path=self.branch(0,i)+self.branch(1,j)[::-1]
                            return path[::-1] if self.swapped else path
                        break
            self.trees.reverse();self.features.reverse();self.roots.reverse();self.swapped=not self.swapped
        return None
