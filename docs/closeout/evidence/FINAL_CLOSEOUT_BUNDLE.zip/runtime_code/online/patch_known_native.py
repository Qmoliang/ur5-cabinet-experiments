"""Add UR5_NATIVE_REUSE and UR5_ATTRACTION=geodesic_native to known_v6/run.py (idempotent)."""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
source = path.read_text()
if "UR5_NATIVE_REUSE" in source:
    print("already patched")
    raise SystemExit
edits = [
    (
        "    reduction = os.environ.get(\"UR5_OBSTACLE_REDUCTION\", \"\")\n",
        "    if os.environ.get(\"UR5_NATIVE_REUSE\", \"0\") == \"1\":\n"
        "        from native_reuse import NativeReuseLiuQPController\n"
        "        controller_class = NativeReuseLiuQPController\n"
        "    reduction = os.environ.get(\"UR5_OBSTACLE_REDUCTION\", \"\")\n",
    ),
    (
        "    elif attraction_mode != \"straight\":\n",
        "    elif attraction_mode == \"geodesic_native\":\n"
        "        sys.path.insert(0, str(ROOT.parent / \"online_v6\"))\n"
        "        from geodesic_fast import NativeGeodesicAttractor\n"
        "        attractor = NativeGeodesicAttractor(\n"
        "            cover.centers, target, representation,\n"
        "            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,\n"
        "        )\n"
        "        attractor_build_ms = attractor.build_ms\n"
        "    elif attraction_mode != \"straight\":\n",
    ),
]
for old, new in edits:
    assert source.count(old) == 1, old[:80]
    source = source.replace(old, new)
path.write_text(source)
print("patched")
