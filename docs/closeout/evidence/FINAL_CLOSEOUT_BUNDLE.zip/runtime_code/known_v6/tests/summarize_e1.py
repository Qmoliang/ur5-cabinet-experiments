"""E1/E2 summary: dodge-then-reach with 0-3 unlabeled moving objects (v6runs/e1, v6runs/e2).

Clean success = reached the target (5 mm, held 1 s) after every object has
gone, no object contact, no static penetration, joint speeds within limits.
Paired with the same controller, scene and start pose without objects (k = 0).
E3: every pair that reaches without objects but fails with them gets a cause.
"""
import collections
import csv
import glob
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e1")
runs = {}
for f in glob.glob(str(ROOT / "*" / "*_seed*" / "summary.json")):
    p = Path(f)
    variant, count, speed = p.parent.parent.name.rsplit("_", 2)   # <controller>_k<count>_v<speed>
    scene = p.parent.name.split("_ellipsoid_")[0]
    seed = int(p.parent.name.rsplit("_seed", 1)[1])
    runs[(variant, scene, int(count[1:]), float(speed[1:]), seed)] = (json.load(open(f)), p.parent)


def clean(s):
    o = s.get("objects") or {}
    ok_speed = s.get("peak_joint_speed_ratio", 0.0) <= 1.0 + 1e-6
    if o.get("count", 0) == 0:
        return bool(s.get("success")) and s.get("static_penetrating_cycles", 0) == 0 and ok_speed
    return (bool(o.get("success_after")) and o.get("contact_cycles", 0) == 0
            and s.get("static_penetrating_cycles", 0) == 0 and ok_speed)


def cause(s, run_dir):
    o = s["objects"]
    if o.get("contact_cycles", 0):
        bodies = o.get("contact_bodies") or {}
        part = max(bodies, key=bodies.get) if bodies else "?"
        return f"hit ({part})"
    if s.get("static_penetrating_cycles", 0):
        return "static penetration"
    if s.get("peak_joint_speed_ratio", 0) > 1 + 1e-6:
        return "speed limit"
    if not o.get("all_done"):
        return "objects never finished"
    rows = list(csv.DictReader(open(run_dir / "cycles.csv")))
    tail = rows[-50:]
    failed = sum(not r["status"].lower().startswith(("solved", "quadprog")) for r in tail)
    if failed > 25:
        return "QP infeasible at end"
    if float(tail[-1]["error_m"]) < 0.02:
        return "stalled within 2 cm"
    return "stalled (local minimum after the dodge)"


variants = sorted({k[0] for k in runs})
print(f"{ROOT}: {len(runs)} runs")
print("\nclean success (objects avoided, then target reached), per controller, all scenes:")
header = "  controller          k=0     " + "  ".join(f"k{c}@{v:4.2f}" for c in (1, 2, 3) for v in (0.25, 0.5, 1.0))
print(header)
for var in variants:
    cells = []
    base = [clean(s) for (vv, sc, k, sp, sd), (s, _) in runs.items() if vv == var and k == 0]
    cells.append(f"{sum(base):3d}/{len(base):<3d}")
    for c in (1, 2, 3):
        for v in (0.25, 0.5, 1.0):
            sel = [clean(s) for (vv, sc, k, sp, sd), (s, _) in runs.items() if vv == var and k == c and sp == v]
            cells.append(f"{sum(sel):3d}/{len(sel):<3d}" if sel else "   -   ")
    print(f"  {var:16s} " + "  ".join(cells))

print("\nper scene (clean / runs, all object counts and speeds):")
for var in variants:
    per = collections.defaultdict(lambda: [0, 0])
    for (vv, sc, k, sp, sd), (s, _) in runs.items():
        if vv == var and k > 0:
            per[sc][0] += clean(s)
            per[sc][1] += 1
    print(f"  {var:16s} " + "  ".join(f"{sc} {a}/{n}" for sc, (a, n) in sorted(per.items())))

print("\nhit-free / reached-after / peak joint speed ratio (max) / peak TCP m/s (max) / controller p99 ms (median):")
for var in variants:
    sel = [s for (vv, sc, k, sp, sd), (s, _) in runs.items() if vv == var and k > 0]
    if not sel:
        continue
    hit_free = sum((s["objects"] or {}).get("contact_cycles", 0) == 0 for s in sel)
    reached = sum(bool((s["objects"] or {}).get("success_after")) for s in sel)
    import statistics
    print(f"  {var:16s} hit-free {hit_free}/{len(sel)}  reached {reached}/{len(sel)}  "
          f"peakJ {max(s.get('peak_joint_speed_ratio', 0) for s in sel):.2f}  "
          f"TCP {max(s.get('peak_tcp_speed_mps', 0) for s in sel):.2f}  "
          f"p99 {statistics.median(s.get('controller_ms_p99', 0) for s in sel):.1f}  "
          f"static-pen runs {sum(s.get('static_penetrating_cycles', 0) > 0 for s in sel)}")

print("\nE3: reaches without objects, fails with them -> cause:")
for var in variants:
    causes = collections.Counter()
    for (vv, sc, k, sp, sd), (s, d) in runs.items():
        if vv != var or k == 0:
            continue
        base = runs.get((vv, sc, 0, 0.0, sd))
        if base is None or not clean(base[0]) or clean(s):
            continue
        causes[cause(s, d)] += 1
    print(f"  {var:16s} " + ", ".join(f"{c}: {n}" for c, n in causes.most_common()))

print("\ntime lost vs no objects (median s, clean pairs):")
for var in variants:
    lost = []
    for (vv, sc, k, sp, sd), (s, _) in runs.items():
        if vv != var or k == 0 or not clean(s):
            continue
        base = runs.get((vv, sc, 0, 0.0, sd))
        if base is None or not clean(base[0]) or base[0].get("first_sustained_success_time_s") is None:
            continue
        lost.append(s["objects"]["success_after_s"] - base[0]["first_sustained_success_time_s"])
    if lost:
        lost.sort()
        print(f"  {var:16s} {lost[len(lost) // 2]:5.2f} s over {len(lost)} pairs")
