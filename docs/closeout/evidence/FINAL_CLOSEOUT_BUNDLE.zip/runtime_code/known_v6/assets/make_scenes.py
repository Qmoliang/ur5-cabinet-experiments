"""Scene files for the three new known-map scenarios (robot base at the origin).

cage       : a bar cage in front of the robot; the target is 15 cm inside it,
             reachable only through a 12 cm x 15 cm window between bars.
             Tests shortcoming 1 (thin bars: sphere covers bulge ~31 mm into
             the window, ellipsoid covers ~4 mm).
exit       : the drawer cabinet, starting from a reached pose inside the
             drawer; the target is outside, beside the cabinet, so the straight
             line runs through the cabinet's side wall.  Tests shortcoming 2.
bin        : an open-top bin with 36 cm walls; the target is 20 cm below the
             rim, so the arm must reach over the near wall.  Tests shortcoming 2
             for the gripper and the links that follow it.
Each file has the drawer scene's format: boxes, q0 (start pose), waypoints[-1]
(target).
"""
import json
import sys
from pathlib import Path

import numpy as np

ASSETS = Path(__file__).resolve().parent
drawer = json.loads((ASSETS / "scene.json").read_text())
BAR = 0.006  # half thickness of a 12 mm bar


def box(name, center, half):
    return {"name": name, "center": [float(v) for v in center], "half_size": [float(v) for v in half],
            "material": "shelf"}


def cage(gap=0.12, window_height=0.148):
    x0, x1, y0, y1, z0, z1 = 0.48, 0.78, 0.256, 0.556, 0.40, 0.76
    yc, zc = 0.406, 0.58
    boxes = [box("cage_floor", ((x0 + x1) / 2, yc, z0 - BAR), ((x1 - x0) / 2, (y1 - y0) / 2, BAR)),
             box("cage_roof", ((x0 + x1) / 2, yc, z1 + BAR), ((x1 - x0) / 2, (y1 - y0) / 2, BAR))]
    half_h = (z1 - z0) / 2
    zm = (z0 + z1) / 2
    front_x = x0 + BAR
    # Front: corner posts, the two bars that bound the window, and one bar in
    # each side gap (6.6 cm gaps: too narrow for any arm link).
    for y in (y0 + BAR, yc - gap / 2 - BAR, yc + gap / 2 + BAR, y1 - BAR,
              (y0 + yc - gap / 2) / 2, (y1 + yc + gap / 2) / 2):
        boxes.append(box(f"front_bar_{y:.3f}", (front_x, y, zm), (BAR, BAR, half_h)))
    # Front rails above and below the window.
    for z in (zc - window_height / 2 - BAR, zc + window_height / 2 + BAR):
        boxes.append(box(f"front_rail_{z:.3f}", (front_x, yc, z), (BAR, (y1 - y0) / 2, BAR)))
    # Sides and back: bars every 6 cm.
    for x in np.arange(x0 + 0.066, x1, 0.06):
        for y in (y0 + BAR, y1 - BAR):
            boxes.append(box(f"side_bar_{x:.3f}_{y:.3f}", (x, y, zm), (BAR, BAR, half_h)))
    for y in np.arange(y0 + 0.066, y1 - 0.01, 0.06):
        boxes.append(box(f"back_bar_{y:.3f}", (x1 - BAR, y, zm), (BAR, BAR, half_h)))
    return dict(name=f"cage_gap{round(gap * 1000)}mm", description=cage.__doc__ or "bar cage",
                boxes=boxes, q0=drawer["q0"], waypoints=[[0.63, yc, zc]], duration=45.0)


def cabinet_exit(inside_q):
    return dict(name="cabinet_exit", description="drawer cabinet, start inside the drawer, target outside beside it",
                boxes=drawer["boxes"], q0=[float(v) for v in inside_q],
                waypoints=[[0.25, -0.15, 0.60]], duration=45.0)


def bin_scene(rim=0.66, x0=0.45, y0=0.256, size=0.30, depth=0.20):
    x1, y1, floor = x0 + size, y0 + size, 0.30
    half_h = (rim - floor) / 2
    zm = (rim + floor) / 2
    boxes = [box("bin_floor", ((x0 + x1) / 2, (y0 + y1) / 2, floor - BAR), ((x1 - x0) / 2, (y1 - y0) / 2, BAR)),
             box("bin_near_wall", (x0 + BAR, (y0 + y1) / 2, zm), (BAR, (y1 - y0) / 2, half_h)),
             box("bin_far_wall", (x1 - BAR, (y0 + y1) / 2, zm), (BAR, (y1 - y0) / 2, half_h)),
             box("bin_left_wall", ((x0 + x1) / 2, y0 + BAR, zm), ((x1 - x0) / 2, BAR, half_h)),
             box("bin_right_wall", ((x0 + x1) / 2, y1 - BAR, zm), ((x1 - x0) / 2, BAR, half_h))]
    return dict(name="bin_over_wall",
                description=f"open-top bin, {round((rim - floor) * 100)} cm walls, target {round(depth * 100)} cm below the rim",
                boxes=boxes, q0=drawer["q0"], waypoints=[[(x0 + x1) / 2, (y0 + y1) / 2, rim - depth]], duration=45.0)


def wall_scene(top=0.65, depth=0.10, wall_x=0.40, behind=0.15):
    """One tall 12 mm wall across the robot's front; the target is `behind` m
    beyond it and `depth` below its top, so the arm must reach over and down."""
    boxes = [box("high_wall", (wall_x + BAR, 0.406, top / 2), (BAR, 0.50, top / 2))]
    return dict(name="over_high_wall", description=f"{round(top * 100)} cm wall, target {round(depth * 100)} cm below its top",
                boxes=boxes, q0=drawer["q0"], waypoints=[[wall_x + behind, 0.406, top - depth]], duration=45.0)


if __name__ == "__main__":
    out = ASSETS / "scenes"
    out.mkdir(exist_ok=True)
    inside_q = np.load(sys.argv[1])[-1]
    # Sizes from the goal-pose feasibility sweeps (v6runs/feasibility*.py, goal_search*.py):
    # 12-16 cm cage windows admit no goal pose for either representation; a
    # 20 x 14.8 cm window admits ellipsoid goals only, 24 x 20 cm both.  The
    # bins admitted no goal pose that the search could find; a 50 cm wall at
    # x = 0.30 with the target 20 cm behind and 20 cm below its top did
    # (ellipsoid +3.2 mm, sphere -7.1 mm).
    for name, scene in (("cage", cage(0.20, 0.148)), ("cage_wide", cage(0.24, 0.20)),
                        ("exit", cabinet_exit(inside_q)), ("wall", wall_scene(0.50, 0.20, 0.30, 0.20)),
                        # Best of the 54-layout sweep (v6runs/wall_sweep.jsonl): goal
                        # clearance ellipsoid 7.9 mm, sphere 12.1 mm; none reached 15 mm.
                        ("wall2", wall_scene(0.45, 0.20, 0.25, 0.25))):
        (out / f"{name}.json").write_text(json.dumps(scene, indent=1))
        print(name, len(scene["boxes"]), "boxes, target", scene["waypoints"][-1])
