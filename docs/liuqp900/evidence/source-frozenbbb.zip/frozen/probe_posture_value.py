"""One-step local mobility diagnostics; never supplies a route to a controller."""
from pathlib import Path
import os,json
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
from scipy.optimize import linprog
from pilot_adapter import ROOT,build,online
from reserve_objective import solve_reserve

ctx=build('iris_4shelves_t2');probe=build('iris_4shelves_t2')
for cc in [ctx.controller,probe.controller]:cc.osqp_adaptive_row_threshold=10**9;cc.osqp_absolute_tolerance=1e-7;cc.osqp_relative_tolerance=1e-7;cc.osqp_max_iterations=3000;cc.pilot_verified_fallback=True
low=ctx.model.jnt_range[:6,0]+.015;high=ctx.model.jnt_range[:6,1]-.015

def state(context,q):
    online.set_configuration(context.model,context.data,q);cc=context.controller;cc.applied_velocity=np.zeros(6);cc.previous_velocity=np.zeros(6);cc.solve(context.target)
    H,g,A,l,u=cc.last_qp_arrays;s=cc.pilot_nominal;p=online.attachment_position(context.model,context.data).copy();e=np.linalg.norm(p-context.target);d=(context.target-p)/e
    return H,g,A,l,u,s,p,e,d

def capacity(data,retained=None):
    H,g,A,l,u,s,p,e,d=data;up=np.isfinite(u);lo=np.isfinite(l);AA=np.vstack([A[up],-A[lo]]);bb=np.r_[u[up],-l[lo]]
    lp=linprog(-d@s['J'],A_ub=AA,b_ub=bb,bounds=[(None,None)]*6,method='highs')
    if not lp.success:return dict(goal_capacity=None,no_close_capacity=None,rows=[])
    if retained is None:
        force=np.abs(s['y'])*np.linalg.norm(A,axis=1)
        retained=[tuple(s['row_ids'][i]) for i in np.argsort(-force) if s['row_ids'][i][0] in ('collision','self','frontier','workspace') and force[i]>max(1e-6,.05*force.max()) and u[i]*.02<.0036][:8]
    lookup={tuple(r):i for i,r in enumerate(s['row_ids'])};extra=[A[lookup[r]] for r in retained if r in lookup and u[lookup[r]]*.02<.0036]
    nc=linprog(-d@s['J'],A_ub=np.vstack([AA,extra]) if extra else AA,b_ub=np.r_[bb,np.zeros(len(extra))],bounds=[(None,None)]*6,method='highs')
    return dict(goal_capacity=float(-lp.fun),no_close_capacity=None if not nc.success else float(-nc.fun),rows=retained)

success=np.load(ROOT/'trials/reserve_release/trajectory.npz');stuck=np.load(ROOT/'trials/metric_v2_initial/trajectory.npz')
states=[('before_successful_elbow_change',success['q'][546]),('metric_stalled_near_goal',stuck['q'][-1])]
out=[]
for label,q in states:
    original=state(ctx,q);H,g,A,l,u,s,p,e,d=original;before=capacity(original)
    nominal=solve_reserve(H,g,A,l,u,q,np.zeros(6),low,high,ctx.controller.task_weight,e,.02,10.)
    record=dict(label=label,q=q.tolist(),joint_lower_reserve=(q-low).tolist(),joint_upper_reserve=(high-q).tolist(),error_mm=float(e)*1000,jacobian_singular_values=np.linalg.svd(s['J'],compute_uv=False).tolist(),nominal_velocity=nominal['velocity'].tolist(),nominal_goal_rate=float(d@s['J']@nominal['velocity']),before=before,candidates=[])
    up=np.isfinite(u);lo=np.isfinite(l);AA=np.vstack([A[up],-A[lo]]);bb=np.r_[u[up],-l[lo]]
    for j in range(6):
        for sign in [1.,-1.]:
            b=np.eye(6)[j]*sign;support=linprog(-b,A_ub=AA,b_ub=bb,bounds=[(None,None)]*6,method='highs')
            if not support.success or -support.fun<1e-5:continue
            candidate=solve_reserve(H,g,A,l,u,q,np.zeros(6),low,high,ctx.controller.task_weight,e,.02,10.,release=(b,.5*-support.fun))
            if candidate is None:continue
            v=np.clip(candidate['velocity'],*ctx.controller.joint_velocity_bounds());accepted=None
            for scale in [1,.75,.5,.25,.125,.0625]:
                if ctx.guard.braking_safe(ctx.proxy_guard,q,scale*v):accepted=scale*v;break
            if accepted is None:continue
            qnext=q+.02*accepted;after_state=state(probe,qnext);after=capacity(after_state,before['rows'])
            record['candidates'].append(dict(joint=j,sign=sign,safe_scale=scale,error_change_mm=float(after_state[7]-e)*1000,goal_rate=float(d@s['J']@accepted),goal_capacity=after['goal_capacity'],no_close_capacity=after['no_close_capacity'],original_cost=candidate['original_cost'],consumption_cost=candidate['consumption_cost']))
    out.append(record);print(json.dumps(record,indent=2),flush=True)
(ROOT/'POSTURE_VALUE_PROBES.json').write_text(json.dumps(out,indent=2))
