"""Checks for guidance.py: the distance function, and one plan from a real trapped pose."""
import sys
import time
from pathlib import Path

import numpy as np

KNOWN = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
sys.path[:0] = [str(KNOWN / "src"), str(KNOWN / "src" / "core"), str(KNOWN), str(KNOWN.parent / "online_v6")]

import mujoco  # noqa: E402
from ball_tree import NativeBallTree  # noqa: E402
from guidance import ConfigurationChecker, StallTriggeredGuidance, point_axis_ellipsoid_distance  # noqa: E402
from known_volume import build_volume_cover  # noqa: E402
from robot import build_model, build_robot_certificate  # noqa: E402
from run import load_scene  # noqa: E402

# 1. Distance to an axis-aligned ellipsoid vs dense surface sampling.
rng = np.random.default_rng(0)
axes = rng.uniform(0.01, 0.08, (200, 3))
centers = rng.uniform(-0.1, 0.1, (200, 3))
points = centers + rng.normal(0, 0.15, (200, 3))
exact = point_axis_ellipsoid_distance(points, centers, axes)
u = rng.normal(size=(20000, 3))
u /= np.linalg.norm(u, axis=1, keepdims=True)
worst = 0.0
for p, c, a, d in zip(points, centers, axes, exact):
    if d < 0:
        assert np.sum(((p - c) / a) ** 2) <= 1.0
        continue
    sampled = np.min(np.linalg.norm(c + u * a - p, axis=1))
    assert d <= sampled + 1e-9, (d, sampled)  # sampling can only overestimate
    worst = max(worst, sampled - d)
print(f"distance check passed; sampling gap at most {worst * 1000:.3f} mm")

# 2. One plan from the E0 seed-2 trapped pose.
scene = load_scene()
model = build_model(scene)
robot = build_robot_certificate(model)
cover = build_volume_cover(scene.boxes, "ellipsoid", 0.075)
checker = ConfigurationChecker(model, robot, cover.centers, "ellipsoid", shapes=cover.ellipsoid_shapes,
                               margin=0.016, index=NativeBallTree(cover.centers, cover.aabb_half_extents))
q_history = np.load("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e0/ellipsoid_075mm_seed02/q_history.npy")
q_trapped = q_history[-1]
print("trapped gripper", np.round(checker.gripper_position(q_trapped), 3),
      "clearance at 16 mm margin (m)", round(checker.clearance(q_trapped), 4))
t = time.perf_counter()
for _ in range(200):
    checker.free(q_trapped)
print(f"collision check: {1000 * (time.perf_counter() - t) / 200:.3f} ms each")
target = np.asarray(scene.waypoints[-1], dtype=float)
guidance = StallTriggeredGuidance(checker, target, seed=2, references=[q_history[0]])
ok = guidance.plan(q_trapped, cycle=0)
print("plan ok:", ok, guidance.stats.events[-1])
for s in guidance.subgoals:
    print("  subgoal", np.round(s, 3))
