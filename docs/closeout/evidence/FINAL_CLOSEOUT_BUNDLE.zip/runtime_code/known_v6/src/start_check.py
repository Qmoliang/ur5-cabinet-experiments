"""Is a start pose clear of both the sphere and the ellipsoid covers by a margin?

Sphere covers are checked exactly.  Ellipsoid covers are checked against
boundary samples, which over-estimates the gap by at most the sample spacing
(~1 mm here); the extra 2 mm in the margin absorbs it.
"""
import numpy as np
from scipy.spatial import cKDTree

from known_volume import build_volume_cover
from robot import build_robot_certificate, certificate_world_positions, set_configuration


class StartChecker:
    def __init__(self, boxes, cell_span: float, margin: float, sphere_too: bool = True):
        self.sphere_too = bool(sphere_too)
        sphere = build_volume_cover(boxes, "sphere", cell_span)
        ellipsoid = build_volume_cover(boxes, "ellipsoid", cell_span)
        self.sphere_centers = sphere.centers
        self.sphere_radii = sphere.sphere_radii
        u = np.random.default_rng(0).normal(size=(3000, 3))
        u /= np.linalg.norm(u, axis=1, keepdims=True)
        points = []
        for c, S in zip(ellipsoid.centers, ellipsoid.ellipsoid_shapes):
            w, v = np.linalg.eigh(S)
            points.append(c + u @ (v @ np.diag(np.sqrt(np.maximum(w, 0))) @ v.T).T)
        self.tree = cKDTree(np.concatenate(points))
        self.ellipsoid_centers = ellipsoid.centers
        self.ellipsoid_inverses = np.linalg.inv(ellipsoid.ellipsoid_shapes)
        self.margin = float(margin)
        self.robot = None

    def valid(self, model, data, q) -> bool:
        if self.robot is None:
            self.robot = build_robot_certificate(model)
            self.radii = np.array([s.radius for s in self.robot])
        set_configuration(model, data, q)
        p = certificate_world_positions(data, self.robot)
        d = np.linalg.norm(p[:, None] - self.sphere_centers[None], axis=2) - self.sphere_radii[None]
        if self.sphere_too and np.min(d - self.radii[:, None]) < self.margin:
            return False
        # Boundary samples miss a robot sphere centre that lies inside an
        # ellipsoid, so test that directly.
        offsets = p[:, None] - self.ellipsoid_centers[None]
        inside = np.einsum("rni,nij,rnj->rn", offsets, self.ellipsoid_inverses, offsets) < 1.0
        if inside.any():
            return False
        gap = self.tree.query(p)[0] - self.radii
        return bool(np.min(gap) >= self.margin)
