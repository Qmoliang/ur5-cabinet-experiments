"""Experiment B: escape point with backtracking memory for LiuQP's whole-arm local minima.

LiuQP is unchanged except that, while escaping, it tracks extra frames (Liu & Yim's Eq. 17 stacks
one tracking equation per goal frame; controller.extra_task_frames).  The constraints never change.

When LiuQP stalls (gripper < 2 mm closer over 1 s, not at the target):
  1. the stuck configuration joins a tabu list (backtracking memory);
  2. an escape configuration q_e is chosen
       mode "random": collision-free joint samples around the stuck configuration (RRT-like single step);
       mode "iris":   samples inside an IRIS-ZO region grown around the stuck configuration
                      (zero-order: sample, find collisions, bisect, cut with a hyperplane, repeat);
     scored by joint distance to the nearest collision-free goal configuration (IK of the target),
     excluding candidates within the tabu radius of earlier stuck configurations;
  3. LiuQP tracks the gripper, elbow (forearm_link origin) and wrist (wrist_1_link origin) positions
     of q_e until they are reached, the escape stalls, or 3 s pass; then the final target resumes.
The interface matches StallTriggeredGuidance (current_target / update / stats) so run.py needs no
new hooks.  Every collision check uses LiuQP's own certificates (guidance.ConfigurationChecker).
"""
from __future__ import annotations

import os
import time

import numpy as np

from scipy.optimize import least_squares
from scipy.spatial import cKDTree

from guidance import GuidanceStats, densify, iris_zo_region, rrt_connect, shortcut

FRAMES = ("forearm_link", "wrist_1_link")
# What LiuQP enforces besides obstacles (src/core/controller.py workspace rows, src/safety_rows.py).
WORKSPACE_A = np.array([[-1, 0, 0], [1, 0, 0], [0, -1, 0], [0, 1, 0], [0, 0, -1], [0, 0, 1]], dtype=float)
WORKSPACE_B = np.array([0.95, 0.95, 0.95, 0.95, 0.0, 1.35])
SELF_MARGIN = 0.005
WORKSPACE_MARGIN = 0.0   # as LiuQP's workspace rows (a shoulder sphere rests 1 mm above the floor)


def with_arm_limits(checker, start_q):
    """Make the planner's clearance also cover the workspace box (incl. the floor) and self-collision,
    with the same sphere pairs LiuQP's self rows use (pairs not on the same / parent-child bodies and
    clear at the start pose).  Without this, routes went through the floor and the arm itself."""
    import types

    model = checker.model
    parent = model.body_parentid
    positions = checker.sphere_positions(np.asarray(start_q, dtype=float))
    pairs = []
    for i in range(len(checker.radii)):
        for j in range(i + 1, len(checker.radii)):
            a, b = int(checker.body_ids[i]), int(checker.body_ids[j])
            if a == b or parent[a] == b or parent[b] == a:
                continue
            if np.linalg.norm(positions[j] - positions[i]) - checker.radii[i] - checker.radii[j] >= SELF_MARGIN:
                pairs.append((i, j))
    pairs = np.array(pairs, dtype=np.int64).reshape(-1, 2)
    obstacle_clearance = checker.clearance

    def clearance(self, q):
        value = obstacle_clearance(q)
        if not np.isfinite(value) and value < 0:
            return value
        p = self.sphere_positions(q)
        work = float(np.min(WORKSPACE_B[None, :] - p @ WORKSPACE_A.T - self.radii[:, None])) - WORKSPACE_MARGIN
        if len(pairs):
            gaps = (np.linalg.norm(p[pairs[:, 1]] - p[pairs[:, 0]], axis=1)
                    - self.radii[pairs[:, 0]] - self.radii[pairs[:, 1]] - SELF_MARGIN)
            work = min(work, float(np.min(gaps)))
        return min(value, work)

    checker.clearance = types.MethodType(clearance, checker)
    checker.self_pairs = len(pairs)
    return checker


def corridor(checker, path, rng, lower, upper, *, samples: int, iterations: int, maximum_regions: int = 80):
    """guidance.iris_corridor with the IRIS-ZO sampling effort as parameters: overlapping regions along
    the route, each seeded where the previous one stops containing it; junctions are the chain points."""
    regions, junctions = [], []
    start = 0
    while start < len(path) - 1 and len(regions) < maximum_regions:
        region = iris_zo_region(checker, path[start], rng, lower, upper, samples=samples, iterations=iterations)
        regions.append(region)
        last = start
        while last + 1 < len(path) and region.contains(path[last + 1]):
            last += 1
        if last == start:
            last = start + 1
        junctions.append(path[last])
        start = last
    return regions, junctions


def goal_configurations(checker, target, rng, *, attempts: int = 80, keep: int = 6, max_nfev: int = 400):
    """Collision-free IK solutions for the gripper target (v6runs/goal_search.py's method): stage 1 pushes
    every robot sphere out of a dense sampling of the cover (soft residuals) while pulling the gripper to
    the target; stage 2 puts the gripper exactly on the target near stage 1; the exact checker verifies."""
    u = rng.normal(size=(600, 3))
    u /= np.linalg.norm(u, axis=1, keepdims=True)
    if checker.representation == "sphere":
        roots = np.repeat(checker.proxy_radii[:, None], 3, axis=1)
    else:
        roots = checker.axes
    points = np.concatenate([c + k * u * r for c, r in zip(checker.centers, roots) for k in (0.4, 0.8, 1.0)])
    tree = cKDTree(points)
    need = checker.radii + checker.margin + 0.004

    def residual(q):
        d = tree.query(checker.sphere_positions(q))[0]
        return np.concatenate([1000.0 * (checker.gripper_position(q) - target), 30.0 * np.maximum(0.0, need - d)])

    lower = np.maximum(checker.lower, -2 * np.pi)
    upper = np.minimum(checker.upper, 2 * np.pi)
    found = []
    for _ in range(attempts):
        r = least_squares(residual, rng.uniform(lower, upper), bounds=(checker.lower, checker.upper), max_nfev=max_nfev)
        anchor = r.x
        r = least_squares(lambda x: np.concatenate([checker.gripper_position(x) - target, 1e-3 * (x - anchor)]),
                          anchor, bounds=(checker.lower, checker.upper), xtol=1e-12, ftol=1e-12)
        q = r.x
        if np.linalg.norm(checker.gripper_position(q) - target) > 2e-4 or not checker.free(q):
            continue
        if any(np.max(np.abs(q - other)) <= 0.1 for other in found):
            continue
        found.append(q)
        if len(found) >= keep:
            break
    return found


def plain_goal_configurations(checker, target, rng, *, keep: int = 6, seeds: int = 300, references=()):
    """Collision-free goal postures from plain position IK (random and reference seeds), checked after:
    10-25x faster than the push-out search on the stuck scenes, and enough distinct postures."""
    lower = np.maximum(checker.lower, -2 * np.pi)
    upper = np.minimum(checker.upper, 2 * np.pi)
    anchors = [np.asarray(r, dtype=float) for r in references]
    found = []
    for k in range(seeds):
        seed = anchors[k] if k < len(anchors) else rng.uniform(lower, upper)
        r = least_squares(lambda x: np.concatenate([checker.gripper_position(x) - target, 1e-3 * (x - seed)]),
                          seed, bounds=(checker.lower, checker.upper), max_nfev=60)
        q = r.x
        if np.linalg.norm(checker.gripper_position(q) - target) > 2e-4 or not checker.free(q):
            continue
        if any(np.max(np.abs(q - other)) <= 0.1 for other in found):
            continue
        found.append(q)
        if len(found) >= keep:
            break
    return found


def refined_goal_configurations(checker, target, rng, *, keep: int = 6, seeds: int = 300):
    """Plain position IK (fast), then a short push-out solve started from each posture (stage 1 of
    goal_configurations, few evaluations) so the goal postures sit away from walls, then the exact
    re-projection onto the target and the checker.  Distinct postures, at most `keep`."""
    candidates = plain_goal_configurations(checker, target, rng, keep=2 * keep, seeds=seeds)
    if not candidates:
        return []
    u = rng.normal(size=(600, 3))
    u /= np.linalg.norm(u, axis=1, keepdims=True)
    roots = np.repeat(checker.proxy_radii[:, None], 3, axis=1) if checker.representation == "sphere" else checker.axes
    tree = cKDTree(np.concatenate([c + k * u * r for c, r in zip(checker.centers, roots) for k in (0.4, 0.8, 1.0)]))
    need = checker.radii + checker.margin + 0.008

    def residual(q):
        d = tree.query(checker.sphere_positions(q))[0]
        return np.concatenate([1000.0 * (checker.gripper_position(q) - target), 30.0 * np.maximum(0.0, need - d)])

    found = []
    for q0 in candidates:
        anchor = least_squares(residual, q0, bounds=(checker.lower, checker.upper), max_nfev=40).x
        q = least_squares(lambda x: np.concatenate([checker.gripper_position(x) - target, 1e-3 * (x - anchor)]),
                          anchor, bounds=(checker.lower, checker.upper), xtol=1e-12, ftol=1e-12).x
        if np.linalg.norm(checker.gripper_position(q) - target) > 2e-4 or not checker.free(q):
            q = q0
        if any(np.max(np.abs(q - other)) <= 0.1 for other in found):
            continue
        found.append(q)
    found.sort(key=lambda q: -checker.clearance(q))
    return found[:keep]


class _BiTree:
    """guidance.rrt_connect's bidirectional search for one (goal, box), resumable in chunks."""

    def __init__(self, checker, start, goal, box, rng, step):
        self.checker, self.rng, self.step = checker, rng, step
        self.lower = np.maximum(np.minimum(start, goal) - box, checker.lower)
        self.upper = np.minimum(np.maximum(start, goal) + box, checker.upper)
        self.trees = [([np.asarray(start, dtype=float)], [-1]), ([np.asarray(goal, dtype=float)], [-1])]
        self.swapped = False
        self.iteration = 0

    def _extend(self, tree, target):
        nodes, parents = tree
        nearest = int(np.argmin(np.linalg.norm(np.asarray(nodes) - target, axis=1)))
        direction = target - nodes[nearest]
        distance = float(np.linalg.norm(direction))
        new = target if distance <= self.step else nodes[nearest] + direction * (self.step / distance)
        if not self.checker.segment_free(nodes[nearest], new):
            return None
        nodes.append(new)
        parents.append(nearest)
        return len(nodes) - 1

    @staticmethod
    def _branch(tree, index):
        nodes, parents = tree
        out = []
        while index >= 0:
            out.append(nodes[index])
            index = parents[index]
        return out[::-1]

    def run(self, iterations):
        for _ in range(iterations):
            self.iteration += 1
            sample = self.rng.uniform(self.lower, self.upper) if self.iteration % 10 else self.trees[1][0][0]
            grown = self._extend(self.trees[0], sample)
            if grown is not None:
                reached = self.trees[0][0][grown]
                while True:
                    connected = self._extend(self.trees[1], reached)
                    if connected is None:
                        break
                    if np.linalg.norm(self.trees[1][0][connected] - reached) < 1e-9:
                        path = self._branch(self.trees[0], grown) + self._branch(self.trees[1], connected)[::-1][1:]
                        return path[::-1] if self.swapped else path
            self.trees.reverse()
            self.swapped = not self.swapped
        return None


def rrt_round_robin(checker, start, goals, rng, *, boxes=(1.0, 2.0, 3.5), chunk: int = 150,
                    budget: int = 40000, step: float = 0.08):
    """One resumable bidirectional search per (goal posture, box), advanced in turns of `chunk`
    iterations, so an easy goal is found early and no tree is thrown away.  Returns (path, iterations)."""
    searches = [_BiTree(checker, start, g, box, rng, step) for g in goals for box in boxes]
    used = 0
    while searches and used < budget:
        for search in searches:
            path = search.run(chunk)
            used += chunk
            if path is not None:
                return path, used
            if used >= budget:
                break
    return None, used


_PARALLEL_JOB = None


# Worker pools of the parallel searches.  Forked by default (the known-map runner).  A process that
# already runs threads (the online runner: camera pipeline, OpenMP certificate kernels) must not fork:
# the child can inherit a lock another thread holds and wait on it forever.  Such a caller sets POOL to
# a factory (job, workers) -> Pool whose freshly started workers rebuild the job themselves.
POOL = None


def _make_pool(job, workers):
    global _PARALLEL_JOB
    if POOL is not None:
        return POOL(job, workers)
    import multiprocessing as mp

    _PARALLEL_JOB = job
    return mp.get_context("fork").Pool(processes=workers)


def _parallel_route_task(task):
    goal_index, box, seed = task
    checker, start, goals = _PARALLEL_JOB
    path = rrt_connect(checker, start, goals[goal_index], np.random.default_rng(seed), iterations=8000, margin=box)
    return goal_index, box, path


def rrt_parallel(checker, start, goals, seed, *, boxes=(1.0, 2.0, 3.5), workers=None):
    """The independent per-(goal posture, box) searches of the original route search, run on separate
    CPU cores (forked processes share the checker); the first route found wins and the rest stop.
    Returns (path, tasks finished before it)."""
    import multiprocessing as mp

    global _PARALLEL_JOB
    job = (checker, np.asarray(start, dtype=float), [np.asarray(g, dtype=float) for g in goals])
    order = sorted(range(len(goals)), key=lambda k: float(np.linalg.norm(goals[k] - start)))
    tasks = [(k, box, seed * 1000 + 17 * k + int(10 * box)) for box in boxes for k in order]
    workers = workers or max(1, len(os.sched_getaffinity(0)))
    finished = 0
    pool = _make_pool(job, min(workers, len(tasks)))
    try:
        for _k, _box, path in pool.imap_unordered(_parallel_route_task, tasks):
            finished += 1
            if path is not None:
                return path, finished
        return None, finished
    finally:
        pool.terminate()
        _PARALLEL_JOB = None


def _parallel_goal_task(task):
    seed, seeds, push = task
    checker, target = _PARALLEL_JOB
    if push:
        return goal_configurations(checker, target, np.random.default_rng(seed), attempts=seeds, keep=6, max_nfev=400)
    return refined_goal_configurations(checker, target, np.random.default_rng(seed), keep=6, seeds=seeds)


def parallel_goal_configurations(checker, target, seed, *, keep: int = 6, seeds: int = 300, workers=None,
                                 push: bool = False):
    """refined_goal_configurations with the IK seeds split over CPU cores; the merged postures are
    de-duplicated and the `keep` with the most clearance returned.  push=True runs the slow push-out
    search (goal_configurations, `seeds` attempts) instead: it finds goal postures only millimetres
    wide (the drawer: +1.3 mm beyond the margin) that plain IK never lands in."""
    import multiprocessing as mp

    global _PARALLEL_JOB
    workers = workers or max(1, len(os.sched_getaffinity(0)))
    try:
        with _make_pool((checker, np.asarray(target, dtype=float)), workers) as pool:
            parts = pool.map(_parallel_goal_task, [(seed * 100 + w, max(1, seeds // workers), push)
                                                     for w in range(workers)])
    finally:
        _PARALLEL_JOB = None
    found = []
    for q in (q for part in parts for q in part):
        if not any(np.max(np.abs(q - other)) <= 0.1 for other in found):
            found.append(q)
    found.sort(key=lambda q: -checker.clearance(q))
    return found[:keep]


def rrt_connect_multi(checker, start, goals, rng, *, step: float = 0.08, iterations: int = 6000,
                      pads=(0.5, 1.5)):
    """One bidirectional RRT from `start` to whichever goal posture connects first: the goal tree is
    rooted at every goal posture, so no per-goal restarts.  The sampling box is the hull of start and
    goals, padded; widened once if the first attempt fails.  Returns a list of configurations or None."""
    points = np.vstack([start] + list(goals))
    for pad in pads:
        lower = np.maximum(points.min(axis=0) - pad, checker.lower)
        upper = np.minimum(points.max(axis=0) + pad, checker.upper)
        trees = [([np.asarray(start, dtype=float)], [-1]), ([np.asarray(g, dtype=float) for g in goals], [-1] * len(goals))]

        def extend(tree, target):
            nodes, parents = tree
            nearest = int(np.argmin(np.linalg.norm(np.asarray(nodes) - target, axis=1)))
            direction = target - nodes[nearest]
            distance = float(np.linalg.norm(direction))
            new = target if distance <= step else nodes[nearest] + direction * (step / distance)
            if not checker.free(new) or not checker.segment_free(nodes[nearest], new):
                return None
            nodes.append(new)
            parents.append(nearest)
            return len(nodes) - 1

        def branch(tree, index):
            nodes, parents = tree
            out = []
            while index >= 0:
                out.append(nodes[index])
                index = parents[index]
            return out[::-1]

        swapped = False
        for _ in range(iterations):
            grown = extend(trees[0], rng.uniform(lower, upper))
            if grown is not None:
                reached = trees[0][0][grown]
                while True:
                    connected = extend(trees[1], reached)
                    if connected is None:
                        break
                    if np.linalg.norm(trees[1][0][connected] - reached) < 1e-9:
                        first = branch(trees[0], grown)
                        second = branch(trees[1], connected)[::-1]
                        path = first + second[1:]
                        return path[::-1] if swapped else path
            trees.reverse()
            swapped = not swapped
    return None


class EscapePointGuidance:
    def __init__(self, checker, controller, target, *, mode: str, seed: int = 0, minimum_margin: float = 0.006,
                 references=(), window: int = 50, minimum_progress: float = 0.002, converged: float = 0.005,
                 maximum_escapes: int = 6, tabu_radius: float = 0.25, escape_timeout: int = 150,
                 frame_tolerance: float = 0.01, candidates: int = 300, spread: float = 0.5):
        if mode not in {"random", "iris", "chain", "graph"}:
            raise ValueError("escape mode must be random, iris, chain or graph")
        # graph: the IRIS-ZO region graph and goal postures are built once before motion
        # (region_graph.py); an escape (still only on a stall) is then a graph search.
        # chain: a joint-space route from the stuck posture to a goal posture (RRT-Connect finds that one
        # exists), covered by IRIS-ZO regions; the region junctions, densified to 0.1 rad, are the chain of
        # escape points, each tracked with the whole-arm frames before the final target resumes.
        self.chain: list[np.ndarray] = []
        self.chain_index = 0
        self.point_started = 0
        self.point_timeout = 100
        self.pass_tolerance = 0.04
        self.lookahead = 3
        # Planning effort.  UR5_ESCAPE_FAST=1: 2 goal postures from shorter IK solves, lighter IRIS-ZO
        # regions (60 samples x 3 rounds instead of 120 x 6) and fewer shortcut rounds.
        # UR5_ESCAPE_FAST=2: all 6 goal postures but shorter IK solves, and the lighter regions.
        fast = os.environ.get("UR5_ESCAPE_FAST", "0")
        self.goal_keep, self.goal_nfev = {"1": (2, 100), "2": (6, 100)}.get(fast, (6, 400))
        # UR5_ESCAPE_FAST=3: goal postures from plain IK + a short push-out, and the route searches,
        # spread over the run's CPU cores (first route wins); lighter regions as in 2.
        self.parallel = fast == "3"
        self.seed = int(seed)
        self.region_samples, self.region_iterations = (60, 3) if fast in ("1", "2", "3") else (120, 6)
        self.shortcut_rounds = 60 if fast in ("1", "2", "3") else 150
        self.mode = mode
        self.subgoal_mode = f"escape_{mode}"
        self.trigger = "stall"
        self.checker = with_arm_limits(checker, references[0]) if references else checker
        self.controller = controller
        self.target = np.asarray(target, dtype=float)
        self.rng = np.random.default_rng(seed)
        self.minimum_margin = minimum_margin
        self.references = [np.asarray(r, dtype=float) for r in references]
        self.window, self.minimum_progress, self.converged = window, minimum_progress, converged
        self.maximum_escapes, self.tabu_radius = maximum_escapes, tabu_radius
        self.escape_timeout, self.frame_tolerance = escape_timeout, frame_tolerance
        self.candidates, self.spread = candidates, spread
        self.frame_ids = [controller.model.body(name).id for name in FRAMES]
        self.tabu: list[np.ndarray] = []
        self.goals = None
        self.escape_q = None
        self.escape_gripper = None
        self.escape_started = 0
        self.history: list[float] = []
        self.stats = GuidanceStats()
        self.graph = None
        if mode == "graph":
            from region_graph import build_graph

            started = time.perf_counter()
            self.checker.margin = self.minimum_margin + 0.003   # routes LiuQP can follow (see _plan_chain)
            self.goals = goal_configurations(self.checker, self.target, self.rng, keep=6, max_nfev=100)
            goal_ms = 1000 * (time.perf_counter() - started)
            quality = (120, 6) if os.environ.get("UR5_GRAPH_REGIONS", "light") == "full" else (60, 3)
            self.graph = build_graph(self.checker, self.references[0], self.goals, self.rng,
                                     samples=quality[0], iterations=quality[1])
            self.checker.margin = self.minimum_margin
            self.stats.events.append({"cycle": -1, "event": "graph_built", "goals": len(self.goals),
                                      "goal_ik_ms": goal_ms, **self.graph.stats,
                                      "setup_ms": 1000 * (time.perf_counter() - started)})

    # ---- interface used by run.py ------------------------------------------------------------
    def current_target(self) -> np.ndarray:
        return self.target if self.escape_q is None else self.escape_gripper

    def update(self, q_now: np.ndarray, gripper: np.ndarray, cycle: int) -> np.ndarray:
        if self.mode in ("chain", "graph") and self.escape_q is not None:
            # Look-ahead: LiuQP tracks the point `lookahead` steps beyond the first unpassed one, and a
            # point counts as passed once every tracked frame is within `pass_tolerance` of it, so the
            # pull never fades out mid-route; only the final goal posture must be reached exactly.
            # The arm may cut a corner and never come near the first unpassed point while it does reach a
            # later one (the look-ahead target it is pulled to): any point up to the look-ahead target that
            # the arm is near counts as passed, with all points before it.
            last_index = len(self.chain) - 1
            advanced = False
            while self.chain_index < last_index:
                reach = min(self.chain_index + self.lookahead, last_index - 1)
                near = [j for j in range(reach, self.chain_index - 1, -1)
                        if self._frames_near(q_now, self.chain[j], self.pass_tolerance)]
                if not near:
                    break
                self.chain_index = near[0] + 1
                advanced = True
            if advanced:
                self.point_started = cycle
                self._track(self.chain[min(self.chain_index + self.lookahead, last_index)], cycle)
            if self.chain_index >= last_index and self._frames_reached(q_now, gripper, self.frame_tolerance):
                self.stats.events.append({"cycle": cycle, "event": "chain_done", "points": len(self.chain)})
                self.chain = []
                self._clear_escape()
            elif cycle - self.point_started >= self.point_timeout:
                self.tabu.append(np.asarray(q_now, dtype=float).copy())
                self.stats.events.append({"cycle": cycle, "event": "chain_abort", "left": last_index - self.chain_index,
                                          "points": len(self.chain),
                                          "joint_gap_rad": float(np.max(np.abs(q_now - self.chain[self.chain_index])))})
                self.chain = []
                self._clear_escape()
            return self.current_target()
        if self.escape_q is not None:
            done = self._frames_reached(q_now, gripper)
            timed_out = cycle - self.escape_started >= self.escape_timeout
            stalled = self._stalled(float(np.linalg.norm(gripper - self.escape_gripper)))
            if done or timed_out or stalled:
                self.stats.events.append({"cycle": cycle, "event": "escape_end",
                                          "reason": "reached" if done else "timeout" if timed_out else "stalled",
                                          "joint_gap_rad": float(np.max(np.abs(q_now - self.escape_q)))})
                self._clear_escape()
            return self.current_target()
        error = float(np.linalg.norm(gripper - self.target))
        if self._stalled(error) and self.stats.calls < self.maximum_escapes:
            self.stats.events.append({"cycle": cycle, "event": "stall", "error_m": error,
                                      "q": np.asarray(q_now).tolist()})
            self._escape(np.asarray(q_now, dtype=float), cycle)
        return self.current_target()

    # ---- internals ----------------------------------------------------------------------------
    def _stalled(self, error: float) -> bool:
        self.history.append(error)
        if len(self.history) <= self.window or error < self.converged:
            return False
        return self.history[-self.window - 1] - min(self.history[-self.window:]) < self.minimum_progress

    def _frames_reached(self, q_now, gripper, tolerance=None) -> bool:
        tolerance = self.frame_tolerance if tolerance is None else tolerance
        return self._frames_near(q_now, self.escape_q, tolerance)

    def _frames_near(self, q_now, q_point, tolerance) -> bool:
        now = [self.checker.gripper_position(q_now)] + self._frame_positions(q_now)
        point = [self.checker.gripper_position(q_point)] + self._frame_positions(q_point)
        return all(float(np.linalg.norm(a - b)) <= tolerance for a, b in zip(now, point))

    def _track(self, q, cycle):
        """Make q the current escape point: LiuQP tracks its gripper, elbow and wrist positions."""
        self.escape_q = np.asarray(q, dtype=float)
        self.escape_gripper = self.checker.gripper_position(self.escape_q)
        if os.environ.get("UR5_ESCAPE_TRACK") == "joint":   # diagnostic: track the joint configuration
            self.controller.extra_joint_goal = self.escape_q.copy()
        else:
            self.controller.extra_task_frames = tuple(zip(self.frame_ids, self._frame_positions(self.escape_q)))
        self.escape_started = cycle
        self.history.clear()

    def _nearest_equivalent(self, q, reference):
        out = np.asarray(q, dtype=float).copy()
        for j in range(len(out)):
            for shift in (-2 * np.pi, 2 * np.pi):
                alt = out[j] + shift
                if self.checker.lower[j] <= alt <= self.checker.upper[j] and abs(alt - reference[j]) < abs(out[j] - reference[j]):
                    out[j] = alt
        return out

    def _clear_start(self, q_stuck, stuck_margin):
        """q_stuck if it has the checker's (planning) clearance, else the nearest nearby posture that has
        it and is reachable in a straight step checked at the stuck pose's own clearance; or None."""
        if self.checker.free(q_stuck):
            return q_stuck
        plan_margin = self.checker.margin
        for sigma in (0.02, 0.05, 0.1, 0.2):
            tries = [q for q in (q_stuck + self.rng.normal(0.0, sigma, 6) for _ in range(40)) if self.checker.free(q)]
            if tries:
                best = min(tries, key=lambda q: float(np.linalg.norm(q - q_stuck)))
                self.checker.margin = stuck_margin
                ok = self.checker.segment_free(q_stuck, best, step=0.01)
                self.checker.margin = plan_margin
                if ok:
                    return best
        return None

    def _plan_chain(self, q_stuck, cycle, event):
        """Route from the stuck posture to the nearest connectable goal posture, as IRIS-ZO junctions.

        The route keeps LiuQP's margin plus 3 mm, so LiuQP (which enforces 6 mm and slows near walls)
        can follow it.  A stuck arm rests at the margin, so the route starts from a nearby posture that
        has that clearance (the short step to it is checked at the stuck pose's own clearance)."""
        stuck_margin = self.checker.margin
        plan_margin = self.minimum_margin + 0.003
        self.checker.margin = plan_margin
        start = q_stuck
        if not self.checker.free(q_stuck):
            start = None
            for sigma in (0.02, 0.05, 0.1, 0.2):
                tries = [q_stuck + self.rng.normal(0.0, sigma, 6) for _ in range(40)]
                tries = [q for q in tries if self.checker.free(q)]
                if tries:
                    best = min(tries, key=lambda q: float(np.linalg.norm(q - q_stuck)))
                    self.checker.margin = stuck_margin
                    ok = self.checker.segment_free(q_stuck, best, step=0.01)
                    self.checker.margin = plan_margin
                    if ok:
                        start = best
                        break
            if start is None:
                event["route_note"] = "no clear start near the stuck posture"
                return None
        goals = [g for g in self.goals if self.checker.free(g)] or self.goals
        event.update(plan_margin_m=plan_margin, clear_goals=len([g for g in self.goals if self.checker.free(g)]))
        # The same physical posture has joint angles 2*pi apart; route to the equivalent nearest the start
        # (within the joint limits), otherwise the route must "travel" full turns that do not exist.
        goals = [self._nearest_equivalent(g, start) for g in goals]
        path = None
        phase = time.perf_counter()
        if self.parallel:
            open_goals = [g for g in goals if not any(float(np.linalg.norm(g - t)) < self.tabu_radius for t in self.tabu[:-1])]
            if open_goals:
                path, event["rrt_tasks"] = rrt_parallel(self.checker, start, open_goals, self.seed * 100 + self.stats.calls)
        else:
            for goal in sorted(goals, key=lambda g: float(np.linalg.norm(g - start))):
                if any(float(np.linalg.norm(goal - t)) < self.tabu_radius for t in self.tabu[:-1]):
                    continue
                for box in (1.0, 2.0, 3.5):
                    path = rrt_connect(self.checker, start, goal, self.rng, iterations=8000, margin=box)
                    if path is not None:
                        break
                if path is not None:
                    break
        event["rrt_ms"] = 1000 * (time.perf_counter() - phase)
        if path is None:
            return None
        phase = time.perf_counter()
        vertices = shortcut(self.checker, path, self.rng, rounds=self.shortcut_rounds)
        dense = densify(vertices)
        event["shortcut_ms"] = 1000 * (time.perf_counter() - phase)
        phase = time.perf_counter()
        lower = np.maximum(dense.min(axis=0) - 0.5, self.checker.lower)
        upper = np.minimum(dense.max(axis=0) + 0.5, self.checker.upper)
        regions, junctions = corridor(self.checker, dense, self.rng, lower, upper,
                                      samples=self.region_samples, iterations=self.region_iterations)
        event["corridor_ms"] = 1000 * (time.perf_counter() - phase)
        head = [q_stuck] if start is q_stuck else [q_stuck, start]
        # Light IRIS-ZO regions are certified only by sampling, so a straight leg between two junctions
        # can cut a wall (drawer: down to -33 mm).  Check every leg as the RRT checks its edges; where one
        # fails, use that stretch of the (already checked) route instead.
        phase = time.perf_counter()
        marks = [0] + [int(np.argmin(np.max(np.abs(dense - j), axis=1))) for j in junctions]
        points, patched = [], 0
        for a, b in zip(marks[:-1], marks[1:]):
            if b <= a:
                continue
            if self.checker.segment_free(dense[a], dense[b], step=0.01):
                points.append(dense[b])
            else:
                points.extend(dense[a + 1:b + 1])
                patched += 1
        event.update(legs_patched=patched, leg_check_ms=1000 * (time.perf_counter() - phase))
        chain = list(densify(head + points, step=0.1)[1:])
        event.update(path_vertices=len(vertices), regions=len(regions), junctions=len(junctions),
                     chain_points=len(chain), route_rad=float(sum(np.linalg.norm(b - a) for a, b in zip(vertices[:-1], vertices[1:]))))
        return chain

    def _frame_positions(self, q):
        self.checker.data.qpos[:6] = q
        import mujoco
        mujoco.mj_kinematics(self.checker.model, self.checker.data)
        return [self.checker.data.xpos[b].copy() for b in self.frame_ids]

    def _clear_escape(self):
        self.escape_q = None
        self.escape_gripper = None
        self.controller.extra_task_frames = ()
        self.controller.extra_joint_goal = None
        self.history.clear()

    def _score(self, q):
        goal_gap = min(float(np.linalg.norm(q - g)) for g in self.goals) if self.goals else \
            float(np.linalg.norm(self.checker.gripper_position(q) - self.target))
        # Backtracking memory: earlier stuck configurations (the current one is where we start from).
        tabu = any(float(np.linalg.norm(q - t)) < self.tabu_radius for t in self.tabu[:-1])
        return goal_gap + (100.0 if tabu else 0.0)

    def _escape(self, q_stuck: np.ndarray, cycle: int) -> None:
        started = time.perf_counter()
        checks_before = self.checker.checks
        self.stats.calls += 1
        self.tabu.append(q_stuck.copy())
        # A stalled arm rests at LiuQP's margin: search with that margin, raised by up to 4 mm when
        # the stuck pose has room, or lowered just enough that the stuck pose itself counts as free
        # (the region must start from it).  LiuQP still enforces its full margin while moving.
        self.checker.margin = self.minimum_margin
        room = self.checker.clearance(q_stuck)
        goal_ms = 0.0
        if self.goals is None:   # goal configurations at LiuQP's own margin, once per run
            goal_started = time.perf_counter()
            if self.parallel:
                self.goals = parallel_goal_configurations(self.checker, self.target, self.seed)
                if not self.goals:   # thin goal sets: fall back to the push-out search, once per run
                    self.goals = parallel_goal_configurations(self.checker, self.target, self.seed, seeds=200, push=True)
                    self.goal_fallback = True
            else:
                self.goals = goal_configurations(self.checker, self.target, self.rng, keep=self.goal_keep,
                                                 max_nfev=self.goal_nfev)
            goal_ms = 1000 * (time.perf_counter() - goal_started)
        self.checker.margin = self.minimum_margin + float(np.clip(room - 0.0005, -self.minimum_margin, 0.004))
        if self.mode == "graph":
            event = {"cycle": cycle, "event": "escape_search", "mode": "graph", "goals": len(self.goals),
                     "regions_containing_stuck": len(self.graph.containing(q_stuck))}
            stuck_margin = self.checker.margin
            self.checker.margin = self.minimum_margin + 0.003
            start = self._clear_start(q_stuck, stuck_margin)
            way = None
            if start is not None:
                if not self.graph.containing(start):
                    # The prebuilt regions follow routes from the start posture; LiuQP may get stuck
                    # elsewhere, so grow one region where it stopped and join it (one IRIS-ZO region).
                    phase = time.perf_counter()
                    self.graph.attach(start, np.maximum(start - 1.0, self.checker.lower),
                                      np.minimum(start + 1.0, self.checker.upper))
                    event["attach_ms"] = 1000 * (time.perf_counter() - phase)
                way, banned = self.graph.verified_route(start, self.goals)
                event["banned_edges"] = banned
                if way is not None and start is not q_stuck:
                    way = [start] + way
            elapsed = 1000 * (time.perf_counter() - started)
            self.stats.plan_ms.append(elapsed)
            event.update(search_ms=elapsed, collision_checks=self.checker.checks - checks_before)
            self.checker.margin = self.minimum_margin
            if way is None:
                self.stats.failures += 1
                event["result"] = "no_route_found"
                self.stats.events.append(event)
                self.history.clear()
                return
            chain = list(densify([q_stuck] + way, step=0.1)[1:])
            event.update(result="chain", waypoints=len(way), chain_points=len(chain))
            self.stats.events.append(event)
            self.stats.subgoals.append([q.tolist() for q in chain])
            self.chain, self.chain_index, self.point_started = chain, 0, cycle
            self._track(self.chain[min(self.lookahead, len(chain) - 1)], cycle)
            return
        if self.mode == "chain":
            event = {"cycle": cycle, "event": "escape_search", "mode": "chain", "goals": len(self.goals),
                     "goal_ik_ms": goal_ms, "margin_m": self.checker.margin,
                     "goal_fallback": getattr(self, "goal_fallback", False)}
            chain = self._plan_chain(q_stuck, cycle, event) if self.goals else None
            elapsed = 1000 * (time.perf_counter() - started)
            self.stats.plan_ms.append(elapsed)
            event.update(search_ms=elapsed, collision_checks=self.checker.checks - checks_before)
            self.checker.margin = self.minimum_margin
            if not chain:
                self.stats.failures += 1
                event["result"] = "no_route_found"
                self.stats.events.append(event)
                self.history.clear()
                return
            event["result"] = "chain"
            self.stats.events.append(event)
            self.stats.subgoals.append([q.tolist() for q in chain])
            self.chain = chain
            self.chain_index = 0
            self.point_started = cycle
            self._track(self.chain[min(self.lookahead, len(chain) - 1)], cycle)
            return
        lower = np.maximum(q_stuck - 1.0, self.checker.lower)
        upper = np.minimum(q_stuck + 1.0, self.checker.upper)
        region_faces = None
        if self.mode == "iris":
            region = iris_zo_region(self.checker, q_stuck, self.rng, lower, upper)
            region_faces = len(region.b)
            samples = self._sample_region(region, q_stuck)
        else:
            samples = [np.clip(q_stuck + self.rng.normal(0.0, self.spread, 6), lower, upper)
                       for _ in range(self.candidates)]
        moved = [q for q in samples if np.max(np.abs(q - q_stuck)) >= 0.05]
        ranked = sorted(moved, key=self._score)
        chosen = None
        tried = 0
        for q in ranked:
            if self._score(q) >= 100.0:
                break   # only tabu candidates left
            tried += 1
            if self.checker.free(q) and self.checker.segment_free(q_stuck, q, step=0.02):
                chosen = q
                break
            if tried >= 150:
                break
        elapsed = 1000 * (time.perf_counter() - started)
        self.stats.plan_ms.append(elapsed)
        event = {"cycle": cycle, "event": "escape_search", "mode": self.mode, "goals": len(self.goals),
                 "samples": len(samples), "tried": tried, "region_faces": region_faces,
                 "search_ms": elapsed, "goal_ik_ms": goal_ms,
                 "collision_checks": self.checker.checks - checks_before,
                 "margin_m": self.checker.margin}
        self.checker.margin = self.minimum_margin
        if chosen is None:
            self.stats.failures += 1
            event["result"] = "no_escape_found"
            self.stats.events.append(event)
            self.history.clear()
            return
        event.update(result="escape", q_escape=chosen.tolist(), score=self._score(chosen),
                     joint_step_rad=float(np.max(np.abs(chosen - q_stuck))))
        self.stats.events.append(event)
        self.stats.subgoals.append([float(x) for x in chosen])
        self.escape_q = chosen
        self.escape_gripper = self.checker.gripper_position(chosen)
        self.controller.extra_task_frames = tuple(zip(self.frame_ids, self._frame_positions(chosen)))
        self.escape_started = cycle
        self.history.clear()

    def _sample_region(self, region, seed):
        """Hit-and-run inside the IRIS-ZO polytope (the region is free by construction, up to sampling)."""
        points, x = [], seed.copy()
        for _ in range(self.candidates):
            direction = self.rng.normal(size=6)
            direction /= np.linalg.norm(direction)
            denominators = region.A @ direction
            slack = region.b - region.A @ x
            with np.errstate(divide="ignore", invalid="ignore"):
                ratios = slack / denominators
            t_max = np.min(ratios[denominators > 1e-12], initial=1.0)
            t_min = np.max(ratios[denominators < -1e-12], initial=-1.0)
            if t_max > t_min:
                x = x + direction * self.rng.uniform(0.999 * t_min, 0.999 * t_max)
            else:
                x = seed.copy()
            points.append(x.copy())
        return points
