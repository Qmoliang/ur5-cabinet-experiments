from pathlib import Path
import os,signal,time,json,datetime,shutil
ROOT=Path(__file__).resolve().parent
targets={2846228:('launcher','entry_v3_jobs.json'),2847456:('entry_v3_memory_stall_2','entry_v3_memory_stall_2'),2848280:('entry_v3_memory_stall_3','entry_v3_memory_stall_3')}
records=[]
for pid,(name,expected) in targets.items():
    proc=Path('/proc')/str(pid)/'cmdline'
    if not proc.exists():records.append(dict(pid=pid,name=name,already_exited=True));continue
    command=proc.read_bytes().replace(b'\0',b' ').decode()
    assert str(ROOT) in command and expected in command,command
    if name=='launcher':assert 'launch_batch.py' in command;os.kill(pid,signal.SIGTERM)
    elif not (ROOT/'trials'/name/'result.json').exists():
        assert 'pilot_worker.py' in command;os.kill(pid,signal.SIGINT)
    records.append(dict(pid=pid,name=name,command=command))
deadline=time.monotonic()+60
while time.monotonic()<deadline:
    if all(name=='launcher' or (ROOT/'trials'/name/'result.json').exists() for name,expected in targets.values()):break
    time.sleep(.5)
for item in records:
    name=item['name']
    if name=='launcher' or item.get('already_exited'):continue
    folder=ROOT/'trials'/name;p=folder/'result.json'
    if not p.exists():item['result_pending']=True;continue
    shutil.copy2(p,folder/'result_before_interruption_annotation.json');r=json.loads(p.read_text());r['status']='interrupted_defective_certificate';r['development_interruption']='Verified missing self-certificate reserve; preserve prefix and rerun frozen corrected version. Not a completed 300 s trial.';p.write_text(json.dumps(r,indent=2));item['saved_cycles']=r['cycles']
out=dict(reason='Systematic self-distance proposal/certificate inconsistency verified by exact replay; no safety thresholds relaxed',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),records=records,unstarted=[j['name'] for j in json.loads((ROOT/'entry_v3_jobs.json').read_text()) if not (ROOT/'trials'/j['name']).exists()])
(ROOT/'V3_DEVELOPMENT_INTERRUPTION.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
