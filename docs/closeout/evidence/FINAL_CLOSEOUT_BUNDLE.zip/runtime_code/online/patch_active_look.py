"""Hook ActiveLook (UR5_ACTIVE_LOOK=1) into the online control loop."""
from pathlib import Path
p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/run_protocol_v3_async_online.py")
s = p.read_text()

def sub(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)

sub("""    try:
        for cycle in range(cycle_limit):
""", """    look = None
    if os.environ.get("UR5_ACTIVE_LOOK", "0") == "1":
        from active_look import ActiveLook
        look = ActiveLook(model)
    try:
        for cycle in range(cycle_limit):
""")
sub("""            command = target if attractor is None else attractor.command(attachment_position(model, data))
            qdot_proposed, metrics = controller.solve(command)
""", """            command = target if attractor is None else attractor.command(attachment_position(model, data))
            if look is not None:
                command = look.command(cycle, attachment_position(model, data), data, active_packet, command)
            qdot_proposed, metrics = controller.solve(command)
            if look is not None:
                look.observe(metrics)
""")
sub("""        "online_geodesic": _GEODESIC["enabled"],
""", """        "online_geodesic": _GEODESIC["enabled"],
        "active_look_events": None if look is None else look.events,
""")
p.write_text(s)
print("patched")
