from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent
jobs=json.loads((ROOT/'contract_jobs.json').read_text())[2:]
for j in jobs:
    j['operating_gate']=False;j['name']=j['name'].replace('joint_spatial_contract','joint_spatial_hard_gate').replace('joint_spatial_from_stall','joint_spatial_hard_from_stall')
freeze=dict(reason='Isolate the spatial objective from the stronger normal-operation stop gate; original 6mm hard safety remains mandatory',jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')})
(ROOT/'final_ablations.json').write_text(json.dumps(jobs,indent=2));(ROOT/'FINAL_ABLATIONS_FREEZE.json').write_text(json.dumps(freeze,indent=2))
print(json.dumps(jobs))
