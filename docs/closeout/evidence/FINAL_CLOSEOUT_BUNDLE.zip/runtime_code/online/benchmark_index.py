"""How much of LiuQP's 20 ms cycle does the broad-phase index cost?

For real final maps and the robot's recorded poses, time one control cycle's
worth of candidate queries (one per certificate sphere, with LiuQP's query
padding) for: a full scan, the current 5-level native MVT, and a kd-tree over
proxy centers (the sphere-tree style lookup).  Every index must return exactly
the full-scan candidate set.
"""
from __future__ import annotations

import glob
import json
import sys
import time
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
KNOWN = ONLINE.parent / "known_v6"
RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
sys.path.insert(0, str(ONLINE))

import mujoco  # noqa: E402
import run_protocol_v3_async_online as online  # noqa: E402
import run_protocol_v3_online_ablation as ablation  # noqa: E402
from model import build_model, build_robot_certificate, certificate_world_positions, set_configuration  # noqa: E402
from native_mvt import BruteForceAABBIndex, NativeMultilevelMVT  # noqa: E402
from ball_tree import NativeBallTree  # noqa: E402

QUERY_PADDING = (ablation.NEAR_DISTANCE + ablation.SAFETY_MARGIN
                 + ablation.MOTION_BROADPHASE_PADDING + ablation.MVT_NUMERICAL_OUTWARD_PADDING)


def robot_positions(q_history: np.ndarray, every: int):
    scene = online._protocol_scene("camera_quarter")
    model = build_model(scene)
    data = mujoco.MjData(model)
    robot = build_robot_certificate(model)
    radii = np.array([sphere.radius for sphere in robot])
    poses = []
    for q in q_history[::every]:
        set_configuration(model, data, q)
        poses.append(certificate_world_positions(data, robot).copy())
    return np.array(poses), radii


def online_map(case: str, representation: str):
    path = glob.glob(str(RUNS / case / "A-CV*" / "final_causal_proxies.npz"))[0]
    data = np.load(path)
    proxies = type("P", (), {})()
    proxies.proxy_offset_radii = data["uncertainty_offsets"]
    proxies.sphere_radii = data["sphere_radii"]
    proxies.ellipsoid_outer_shapes = data["ellipsoid_outer_shapes"]
    proxies.proxy_uncertainty_shapes = data["proxy_uncertainty_shapes"]
    proxies.base_ellipsoid_shapes = data["ellipsoid_shapes"]
    half = ablation._environment_half_extents(proxies, representation)
    q = np.load(glob.glob(str(RUNS / case / "A-CV*" / "q_history.npy"))[0])
    return data["centers"], half, q


def known_map(representation: str, span: float, run: str):
    sys.path[:0] = [str(KNOWN / "src"), str(KNOWN / "src" / "core")]
    from known_volume import build_volume_cover
    scene = online._protocol_scene("camera_quarter")
    cover = build_volume_cover(scene.boxes, representation, span)
    q = np.load(RUNS / "known_sweep" / run / "q_history.npy")
    return cover.centers, cover.aabb_half_extents, q


def bench(name, centers, half, q_history, every=25):
    poses, radii = robot_positions(q_history, every)
    indexed_half = half + ablation.MVT_NUMERICAL_OUTWARD_PADDING
    t = time.perf_counter()
    mvt = NativeMultilevelMVT(centers, indexed_half, base_voxel_size=ablation.MVT_BASE_VOXEL_SIZE,
                              maximum_query_half_extent=float(radii.max() + QUERY_PADDING),
                              query_padding=QUERY_PADDING, simd=True)
    mvt_build = time.perf_counter() - t
    scan = BruteForceAABBIndex(centers, indexed_half, query_padding=QUERY_PADDING)
    t = time.perf_counter()
    tree = NativeBallTree(centers, indexed_half, query_padding=QUERY_PADDING)
    tree_build = time.perf_counter() - t

    times = {"full scan (numpy)": [], "5-level MVT (native)": [], "ball tree (native)": []}
    candidates = []
    for pose in poses:
        for label, fn in (("full scan (numpy)", scan.query_sphere), ("5-level MVT (native)", mvt.query_sphere),
                          ("ball tree (native)", tree.query_sphere)):
            t = time.perf_counter()
            result = [np.sort(fn(c, r)) for c, r in zip(pose, radii)]
            times[label].append(1000 * (time.perf_counter() - t))
            if label == "full scan (numpy)":
                reference = result
            elif any(not np.array_equal(a, b) for a, b in zip(reference, result)):
                raise AssertionError(f"{label} missed or added candidates in {name}")
        candidates.append(sum(len(r) for r in reference))
    stats = mvt.stats
    row = {"map": name, "proxies": len(centers), "poses": len(poses), "spheres_per_cycle": len(radii),
           "candidates_per_cycle_median": float(np.median(candidates)),
           "mvt_build_ms": 1000 * mvt_build, "ball_tree_build_ms": 1000 * tree_build,
           "ball_tree_nodes": tree.node_count,
           "mvt_level_proxy_counts": list(stats.level_proxy_counts),
           **{f"{k} ms/cycle median": float(np.median(v)) for k, v in times.items()},
           **{f"{k} ms/cycle p99": float(np.percentile(v, 99)) for k, v in times.items()}}
    mvt.close()
    tree.close()
    print(json.dumps(row), flush=True)
    return row


def main():
    rows = []
    for case, rep in (("realtime/R1_ell_incr_paced", "ellipsoid"), ("realtime/R2_sph_incr_paced", "sphere")):
        rows.append(bench(f"online {rep} ({case.split('/')[1]})", *online_map(case, rep)))
    for rep, span, run in (("ellipsoid", 0.075, "ellipsoid_075mm"), ("sphere", 0.035, "sphere_035mm"),
                           ("sphere", 0.012, "sphere_012mm")):
        rows.append(bench(f"known {rep} {round(span*1000)} mm", *known_map(rep, span, run)))
    Path(RUNS / "index_benchmark.json").write_text(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
