import os,json
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
from pilot_adapter import ROOT,build
from retained_blocker_policy import LowDimPolicy
q=np.load(ROOT/'trials/release_only_v2_from_stall/trajectory.npz')['q'][-1]
ctx=build('iris_4shelves_t2',start=q);c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.osqp_max_iterations=3000;c.solve(ctx.target)
s=c.pilot_nominal;arrays=c.last_qp_arrays;policy=LowDimPolicy(ctx,dict(method='release',joint_metric=True,spatial_metric=False,operating_gate=False),lambda **kw:None);policy.observe(0,q,np.zeros(6))
force=np.abs(s['y'])*np.linalg.norm(arrays[2],axis=1);indices=[i for i,row in enumerate(s['row_ids']) if row[0]=='collision'];i=max(indices,key=lambda j:force[j]);policy.blocker_id=tuple(s['row_ids'][i])
b,norm,gap=policy._retained_geometry(c,s,arrays);analytic=b*norm;fd=[]
for j in range(6):
    policy.q=q+1e-6*np.eye(6)[j];plus=policy._retained_geometry(c,s,arrays)[2]
    policy.q=q-1e-6*np.eye(6)[j];minus=policy._retained_geometry(c,s,arrays)[2]
    fd.append((plus-minus)/2e-6)
policy.q=q.copy();pruned=dict(s,row_ids=[row for row in s['row_ids'] if tuple(row)!=policy.blocker_id]);after=policy._retained_geometry(c,pruned,arrays)
record=dict(row_id=policy.blocker_id,measured_gap_above_nominal_m=gap,original_row_gap_m=float(arrays[4][i]*c.dt),row_gap_difference_m=gap-float(arrays[4][i]*c.dt),analytic_gradient=analytic.tolist(),finite_difference_gradient=fd,maximum_gradient_error=float(np.max(np.abs(analytic-fd))),pruning_geometry_difference=float(max(np.max(np.abs(b-after[0])),abs(gap-after[2]))))
assert record['maximum_gradient_error']<1e-6 and abs(record['row_gap_difference_m'])<1e-7 and record['pruning_geometry_difference']<1e-12
(ROOT/'RETAINED_GEOMETRY_VALIDATION.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
