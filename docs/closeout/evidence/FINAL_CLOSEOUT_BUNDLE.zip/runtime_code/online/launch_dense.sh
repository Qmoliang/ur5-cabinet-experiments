#!/bin/bash
# CenterVox from dense known clouds: LiuQP + geodesic on each fixed map, 20 start poses.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
OUT=v6runs/dense; ONLINE=repo/experiment/runtimes/online_v6
lim="systemd-run --user --scope -q -p MemoryMax=24G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS"
[ -f $OUT/maps/sigma2mm.pkl ] || ~/envs/ur5cab/bin/python $ONLINE/build_dense_map.py $OUT/maps/sigma2mm.pkl --uncertainty 0.002 > $OUT/maps/sigma2mm.log 2>&1
jobs=()
for seed in $(seq 1 20); do for m in exact sigma2mm; do jobs+=("$m $seed"); done; done
for ((start = 0; start < ${#jobs[@]}; start += 10)); do
  for slot in $(seq 0 9); do
    index=$((start + slot)); [ $index -lt ${#jobs[@]} ] || break
    set -- ${jobs[$index]}; id=$1/seed$(printf "%02d" $2); mkdir -p $OUT/$1
    [ -f $OUT/$id/summary.json ] && continue
    $lim timeout 2400 ~/envs/ur5cab/bin/python $ONLINE/run_v6_case.py ellipsoid --map incremental --timing paced \
      --cpus $(($slot*12)):12 --start-seed $2 --geodesic --frozen-map $OUT/maps/$1.pkl --out $OUT/$id > $OUT/$id.log 2>&1 &
  done
  wait
done
echo DONE > $OUT/DENSE_DONE
