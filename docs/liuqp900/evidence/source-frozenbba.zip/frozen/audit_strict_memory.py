from pathlib import Path
import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np,mujoco
R=Path(__file__).resolve().parent;entry=json.loads((R/'INPUTS.json').read_text())[0];model=mujoco.MjModel.from_xml_path(entry['scene']);data=mujoco.MjData(model);site=model.site('attachment_site').id
body=int(model.site_bodyid[site]);length=float(np.linalg.norm(model.site_pos[site]))
while body:
 length+=float(np.linalg.norm(model.body_pos[body]));j0=int(model.body_jntadr[body])
 for j in range(j0,j0+int(model.body_jntnum[body])):length+=2*float(np.linalg.norm(model.jnt_pos[j]))
 body=int(model.body_parentid[body])
K=2*length;outputs=[]
for job in json.loads((R/'memory_aligned_jobs.json').read_text()):
 f=R/'trials'/job['name'];result=json.loads((f/'result.json').read_text());memories=json.loads((f/'goalward_memories.json').read_text());port=result['policy_summary']['goal_port'];P=np.array(port['posture_matrix']);qg=np.array(port['goal_q']);tr=dict(np.load(f/'trajectory.npz'));q=tr['q'];tol=np.longdouble(float(-1e-10));bad=[];minimum=float('inf');subdivisions=0
 def feature(qi):
  data.qpos[:6]=qi;mujoco.mj_kinematics(model,data);return np.r_[data.site_xpos[site].copy(),P@(qi-qg)]
 def interval(a,b,fa,fb,m,depth=0):
  nonlocal_dummy=None
  global minimum,subdivisions
  normal=np.array(m['normal']);va=float(normal@fa-m['offset']);vb=float(normal@fb-m['offset']);minimum=min(minimum,va,vb)
  if min(np.longdouble(va),np.longdouble(vb))<tol:return False
  B=np.longdouble(.5*np.linalg.norm(normal[:3])*K)*np.longdouble(np.sum(np.abs(b-a)))**2;slope=np.longdouble(vb)-np.longdouble(va)
  t=np.clip((B-slope)/max(2*B,np.longdouble('1e-60')),0,1);lower=np.longdouble(va)+t*(slope-B)+B*t*t
  if lower>=tol:return True
  if depth>=12:return False
  subdivisions+=1;mid=(a+b)/2;fm=feature(mid);return interval(a,mid,fa,fm,m,depth+1) and interval(mid,b,fm,fb,m,depth+1)
 if memories:
  features=np.array([feature(x) for x in q]);inherited=[]
  if job.get('initial_memories'):inherited=json.loads(Path(job['initial_memories']).read_text());assert memories[:len(inherited)]==inherited
  for i,m in enumerate(memories):
   start=0 if i<len(inherited) else m['activation_cycle']
   for k in range(start,len(q)-1):
    if not interval(q[k],q[k+1],features[k],features[k+1],m):bad.append([i,k])
 entering=np.flatnonzero(tr['control_mode']=='CERT_ENTER');suffix_bad=[]
 if memories and len(entering):
  begin=q[int(entering[0])];N=max(1,int(np.ceil(np.max(np.abs(qg-begin))/.04)));qs=[begin+(qg-begin)*t for t in np.linspace(0,1,N+1)];fs=[feature(x) for x in qs]
  for i,m in enumerate(memories):
   for k in range(N):
    if not interval(qs[k],qs[k+1],fs[k],fs[k+1],m):suffix_bad.append([i,k])
 out=dict(passed=not bad and not suffix_bad,memory_count=len(memories),tolerance_m=float(tol),inherited_memories_checked_from_zero=True,failed_actual_intervals=bad,failed_terminal_suffix_intervals=suffix_bad,minimum_reconstructed_value=None if not memories else minimum,subdivisions=subdivisions,scope='fresh MuJoCo reconstruction and endpoint-dependent curvature bounds at the unchanged runtime 1e-10 tolerance; original memory_audit.json remains untouched; empty memory set does not exercise this mechanism')
 (f/'strict_memory_audit.json').write_text(json.dumps(out,indent=2));outputs.append(dict(name=f.name,**out));print(f.name,out['passed'],out['memory_count'],out['minimum_reconstructed_value'],flush=True)
(R/'STRICT_MEMORY_AUDIT_SUMMARY.json').write_text(json.dumps(outputs,indent=2));assert all(x['passed'] for x in outputs)
