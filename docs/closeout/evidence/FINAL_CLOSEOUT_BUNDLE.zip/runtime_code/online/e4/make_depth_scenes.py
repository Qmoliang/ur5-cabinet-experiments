"""Experiment A: copies of the four always-failing scenes with the target moved out step by step
(geometry and start pose unchanged).  Writes assets/scenes/<scene>_<tag>.json and prints the list."""
import json
from pathlib import Path

S = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/assets/scenes")
# scene -> (axis, values, tag); depth tags in cm relative to the opening / rim / wall top
SWEEPS = {
    # shelf front face at x = 0.33; target 9 cm inside -> 3 cm outside
    "iris_4shelves_t0": (0, [0.42, 0.39, 0.36, 0.33, 0.30], lambda v: f"in{round((v - 0.33) * 100):+d}"),
    # upper compartment; 12 cm inside -> 3 cm outside
    "iris_4shelves_t2": (0, [0.45, 0.41, 0.37, 0.33, 0.30], lambda v: f"in{round((v - 0.33) * 100):+d}"),
    # bin rim at z = 0.21; 5 cm below -> 6 cm above
    "iris_bins_t1": (2, [0.16, 0.185, 0.21, 0.24, 0.27], lambda v: f"rim{round((v - 0.21) * 100):+d}"),
    # wall top at z = 0.45; 20 cm below -> level with the top
    "wall2": (2, [0.25, 0.30, 0.35, 0.40, 0.45], lambda v: f"top{round((v - 0.45) * 100):+d}"),
}
names = []
for scene, (axis, values, tag) in SWEEPS.items():
    payload = json.load(open(S / f"{scene}.json"))
    for v in values:
        p = json.loads(json.dumps(payload))
        target = list(p["waypoints"][-1])
        target[axis] = v
        p["waypoints"] = [target]
        p.pop("goal_clearance_mm", None)
        name = f"{scene}_{tag(v)}".replace("+", "p").replace("-", "m")
        p["description"] = f"{payload.get('description', '')} | Exp A target {target}"
        json.dump(p, open(S / f"{name}.json", "w"), indent=1)
        names.append(name)
print(" ".join(names))
