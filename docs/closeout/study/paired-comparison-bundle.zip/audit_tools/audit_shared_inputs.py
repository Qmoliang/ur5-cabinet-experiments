from pathlib import Path
import json,itertools
import numpy as np

def audit_workspace(q,p,r,K,position_fn):
 low=np.array([-.95,-.95,0.]);high=np.array([.95,.95,1.35]);bad=[];sub=0;minimum=float("inf")
 def gap(x):
  nonlocal minimum
  v=float(np.min(np.c_[x-r[:,None]-low,high-x-r[:,None]]));minimum=min(minimum,v);return v
 def interval(a,b,pa,pb,depth=0):
  nonlocal sub
  ga=gap(pa);gb=gap(pb)
  if min(ga,gb)<-1e-10:return False
  pad=K*np.sum(np.abs(b-a))**2/8+1e-12
  if min(ga,gb)-pad>=-1e-10:return True
  if depth>=12:return False
  sub+=1;m=(a+b)*.5;pm=position_fn(m)
  return interval(a,m,pa,pm,depth+1) and interval(m,b,pm,pb,depth+1)
 for i in range(len(q)-1):
  if not interval(q[i],q[i+1],p[i],p[i+1]):bad.append(i)
 return dict(passed=not bad,bad_intervals=bad,minimum_sampled_slack_m=minimum,subdivisions=sub)

def audit_partition(case,entry):
 z=np.load(Path(case)/"proxies.npz");C=z["centers"];H=z["cell_half_extents"];ids=z["box_indices"];Q=z["ellipsoid_shapes"]
 boxes=json.loads(Path(entry["scene_json"]).read_text())["boxes"];errors=[];overhang=0.;volume=0.
 for k,b in enumerate(boxes):
  c=np.asarray(b["center"]);h=np.asarray(b["half_size"]);take=ids==k;cc=C[take];hh=H[take];qq=Q[take]
  if not len(cc):errors.append([k,"missing_box"]);continue
  axes=[];ranks=[]
  for axis in range(3):
   intervals=np.round(np.c_[cc[:,axis]-hh[:,axis],cc[:,axis]+hh[:,axis]],13)
   unique,inverse=np.unique(intervals,axis=0,return_inverse=True);axes.append(unique);ranks.append(inverse)
   if abs(unique[0,0]-(c[axis]-h[axis]))>1e-11 or abs(unique[-1,1]-(c[axis]+h[axis]))>1e-11 or np.any(np.abs(unique[:-1,1]-unique[1:,0])>1e-11):errors.append([k,axis,"noncontiguous_intervals"])
  tuples=np.stack(ranks,axis=1)
  if len(cc)!=np.prod([len(x) for x in axes]) or len(np.unique(tuples,axis=0))!=len(cc):errors.append([k,"cartesian_partition_not_complete"])
  # Exact convexity proof: all corners of every solid cell lie in its ellipsoid.
  inv=np.linalg.inv(qq)
  for sign in itertools.product([-1,1],repeat=3):
   v=hh*np.array(sign);measure=np.einsum("ni,nij,nj->n",v,inv,v)
   if np.any(measure>1+1e-10):errors.append([k,"uncovered_corner"])
  extent=np.sqrt(np.diagonal(qq,axis1=1,axis2=2));overhang=max(overhang,float(np.max(np.abs(cc-c)+extent-h)))
  volume+=float(np.sum(np.prod(2*hh,axis=1)))
 expected=sum(np.prod(2*np.asarray(x["half_size"])) for x in boxes)
 if abs(volume-expected)>1e-10:errors.append(["solid_volume_mismatch"])
 if overhang>.0005+1e-12:errors.append(["axis_overhang_budget_exceeded"])
 return dict(passed=not errors,errors=errors,solid_cells=len(C),source_boxes=len(boxes),solid_volume_m3=volume,source_volume_m3=expected,maximum_axis_overhang_m=overhang)
