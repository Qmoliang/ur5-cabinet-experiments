from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;s=(R/'pilot_worker_exact_diagnostic.py').read_text().replace("        if job.get('policy_version')=='diagnostic_exact_pruned':","        if job.get('policy_version')=='goal_side_plane':\n            from goal_side_plane_policy import LowDimPolicy\n        elif job.get('policy_version')=='diagnostic_exact_pruned':");(R/'pilot_worker_goal_plane.py').write_text(s)
s=(R/'launch_execution_progress.py').read_text().replace("ROOT/'pilot_worker_execution_progress.py'","ROOT/'pilot_worker_goal_plane.py'");(R/'launch_goal_plane.py').write_text(s)
j=json.loads((R/'execution_progress_jobs.json').read_text())
for x in j:x['name']=x['name'].replace('_v5','_goal_plane');x['policy_version']='goal_side_plane'
(R/'goal_plane_jobs.json').write_text(json.dumps(j,indent=2));a=R/'revisions/goal_side_plane';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
(R/'GOAL_PLANE_FREEZE.json').write_text(json.dumps(dict(jobs=j,sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['goal_side_plane_policy.py','diagnostic_exact_pruned_policy.py','pilot_worker_goal_plane.py']},scope='same fixed terminal feedback; replace only virtual collision objective normals with terminal-side separating planes; original safety unchanged'),indent=2))
