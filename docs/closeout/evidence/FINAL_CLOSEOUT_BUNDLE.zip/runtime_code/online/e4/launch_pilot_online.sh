#!/bin/bash
# Online pilot (approved 2026-10-27): drawer (geodesic) / wide cage / IRIS shelf t0 (straight), far start,
# seeds 1-5; LiuQP-E, +combined, NEO-E 0.30 (neo_paper), NEO-E 0.046 (neo_matched); no racket | 1@0.25 |
# 1@0.5 | 2@0.5.  Part A: as is.  Part B: NEO with its real compute time (UR5_COMPUTE_DELAY=1).
# Map: CenterVox 5 mm, unseen space as obstacles, no-return carving.  6 workers x 16 CPUs (CPUs 0-95).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/pilot_online
export UR5_NO_RETURN_FREE=1
jobs=()
for cond in "0 0.0" "1 0.25" "1 0.5" "2 0.5"; do
  for seed in 1 2 3 4 5; do
    for scene in drawer cage_wide shelf; do
      for ctl in liuqp combined neo_paper neo_matched neo_paper_delay neo_matched_delay; do
        jobs+=("$ctl $scene $seed $cond")
      done
    done
  done
done
echo "${#jobs[@]} jobs" > pilot_online.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 6)); do
    set -- ${jobs[$i]}
    ctl=$1; scene=$2; seed=$3; k=$4; v=$5
    out=$P/${ctl}_k${k}_v$v/${scene}_s$seed
    [ -f $out/case.json ] && continue
    delay=0; base=$ctl
    case $ctl in *_delay) delay=1; base=${ctl%_delay} ;; esac
    geo=; [ $scene = drawer ] && geo=1
    UR5_COMPUTE_DELAY=$delay E4_GEODESIC=$geo E4_SCENE=$scene ./e4_map.sh $out $seed $((w * 16)) $base $k $v
  done
}
for w in 0 1 2 3 4 5; do worker $w & done
wait
echo DONE > pilot_online.done
