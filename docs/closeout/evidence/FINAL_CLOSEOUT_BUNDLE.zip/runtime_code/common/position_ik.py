"""Position-only IK for this audited UR5 chain, verified against MuJoCo."""
import numpy as np,mujoco
def candidates(model,target,parameters,reference):
    data=mujoco.MjData(model);data.qpos[:6]=0;mujoco.mj_kinematics(model,data);S=data.xpos[model.body('shoulder_link').id].copy();B=data.xmat[model.body('shoulder_link').id].reshape(3,3).copy();t=B.T@(np.asarray(target)-S)
    assert np.allclose(model.body_pos[model.body('forearm_link').id],[0,-.131,.425])
    assert np.allclose(model.body_pos[model.body('wrist_1_link').id],[0,0,.392])
    assert np.allclose(model.body_pos[model.body('wrist_2_link').id],[0,.127,0])
    assert np.allclose(model.body_pos[model.body('wrist_3_link').id],[0,0,.1])
    assert np.allclose(model.site_pos[model.site('attachment_site').id],[0,.07,0])
    parameters=np.asarray(parameters);u,v=parameters[:,:2].T;q6=parameters[:,2] if parameters.shape[1]>2 else np.full(len(parameters),reference[5]);theta=np.pi/2+v;tx=np.cos(u)*t[0]+np.sin(u)*t[1];ty=-np.sin(u)*t[0]+np.cos(u)*t[1];tz=np.full_like(u,t[2]);dy=ty-.134;cost=dy/.07
    dx=tx-.425*np.sin(theta);dz=tz-.425*np.cos(theta);d=np.hypot(dx,dz);h2=.1**2+.07**2-dy**2
    cb=(d*d+.392**2-h2)/(2*.392*np.maximum(d,1e-30));mask=(np.abs(cost)<=1)&(np.abs(cb)<=1)&(d>1e-12)
    u,v,theta,tx,ty,tz,dx,dz,cost,cb,q6=[x[mask] for x in [u,v,theta,tx,ty,tz,dx,dz,cost,cb,q6]]
    result=[]
    for elbow in [-1,1]:
      alpha=np.arctan2(dx,dz)+elbow*np.arccos(cb);q3=alpha-theta;wx=.425*np.sin(theta)+.392*np.sin(alpha);wz=.425*np.cos(theta)+.392*np.cos(alpha)
      gx=tx-wx;gz=tz-wz;gamma=alpha+np.pi/2;vx=np.cos(gamma)*gx-np.sin(gamma)*gz;vz=np.sin(gamma)*gx+np.cos(gamma)*gz
      for wrist in [-1,1]:
       q5=wrist*np.arccos(cost);q4=np.arctan2(vx,vz)-np.arctan2(-.07*np.sin(q5),.1);q=np.c_[u,v,q3,q4,q5,q6];q[:,:5]=(q[:,:5]+np.pi)%(2*np.pi)-np.pi
       for j in range(6):
        options=np.stack([q[:,j]-2*np.pi,q[:,j],q[:,j]+2*np.pi],axis=1);valid=(options>=model.jnt_range[j,0]+.015)&(options<=model.jnt_range[j,1]-.015);rank=np.where(valid,np.abs(options-reference[j]),np.inf);ix=np.argmin(rank,axis=1);q[:,j]=options[np.arange(len(q)),ix]
       result.append(q)
    return np.vstack(result) if result else np.empty((0,6))
