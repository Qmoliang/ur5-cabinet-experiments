"""Native fit_matched_voxel_proxies (bucket_fit_native.cpp) with the Python coverage proof.

fit(points, **kwargs) accepts the same arguments as
pointcloud_proxy.fit_matched_voxel_proxies.  The native path covers the online
manager's mode (already filtered cells with offsets and directional
uncertainty, separate_uncertainty, fixed cluster origin, radius limit and union
inflation); anything else, or UR5_NATIVE_FIT=0, uses the Python fitter.
Either way assert_proxy_coverage proves the result before it is returned.
"""
from __future__ import annotations

import ctypes
import os
from pathlib import Path

import numpy as np

from pointcloud_proxy import PointCloudProxySet, assert_proxy_coverage, fit_matched_voxel_proxies

_LIB = None


def _lib():
    global _LIB
    if _LIB is None:
        import numpy.linalg  # noqa: F401  (loads NumPy's OpenBLAS, which provides dsyevd_64_)
        lib = ctypes.CDLL(str(Path(__file__).resolve().parent / "bucket_fit_kernels.so"))
        dp, lp = ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_int64)
        lib.bf_fit.argtypes = [ctypes.c_int64, dp, dp, dp, dp, ctypes.c_double, ctypes.c_double, ctypes.c_double,
                               ctypes.c_double, ctypes.c_double, ctypes.c_int32, ctypes.c_double,
                               lp, dp, dp, dp, dp, dp, dp, dp, dp, dp]
        lib.bf_fit.restype = ctypes.c_int64
        _LIB = lib
    return _LIB


def _native_applicable(kwargs) -> bool:
    return (
        os.environ.get("UR5_NATIVE_FIT", "1") == "1"
        and kwargs.get("already_filtered", False)
        and kwargs.get("filtered_point_offsets") is not None
        and kwargs.get("filtered_point_uncertainty_shapes") is not None
        and kwargs.get("uncertainty_fusion_mode", "separate_uncertainty") == "separate_uncertainty"
        and kwargs.get("cluster_origin") is not None
        and kwargs.get("maximum_uncertainty_union_inflation") is not None
        and kwargs.get("certificate_radius_limit") is not None
    )


def fit(points, **kwargs) -> PointCloudProxySet:
    if not _native_applicable(kwargs):
        return fit_matched_voxel_proxies(points, **kwargs)
    filter_size = float(kwargs.get("filter_size", 0.012))
    cluster_size = float(kwargs.get("cluster_size", 0.040))
    maximum_aabb_overshoot = float(kwargs.get("maximum_aabb_overshoot", 0.020))
    connection = kwargs.get("normal_connection_distance")
    connection = 1.75 * filter_size if connection is None else float(connection)
    limit = float(kwargs["certificate_radius_limit"])
    mode = {"both": 0, "sphere": 1, "ellipsoid": 2}[kwargs.get("radius_limit_representation", "both")]
    surface_uncertainty = float(kwargs.get("surface_uncertainty", 0.003))
    p = np.ascontiguousarray(points, dtype=np.float64).reshape(-1, 3)
    off = np.ascontiguousarray(kwargs["filtered_point_offsets"], dtype=np.float64).reshape(-1)
    u = np.ascontiguousarray(kwargs["filtered_point_uncertainty_shapes"], dtype=np.float64).reshape(-1, 3, 3)
    origin = np.ascontiguousarray(kwargs["cluster_origin"], dtype=np.float64).reshape(3)
    n = len(p)
    if n == 0:
        raise ValueError("Cannot fit proxies to an empty point cloud")
    inverse = np.empty(n, dtype=np.int64)
    centers, radii, base_radii, offsets = (np.empty((n, 3)), np.empty(n), np.empty(n), np.empty(n))
    shapes, rotations, unc, outer = (np.empty((n, 3, 3)) for _ in range(4))
    scalars = np.empty(3)
    ptr = lambda a, kind=ctypes.c_double: a.ctypes.data_as(ctypes.POINTER(kind))
    count = _lib().bf_fit(n, ptr(p), ptr(off), ptr(u), ptr(origin), cluster_size, connection, maximum_aabb_overshoot,
                          float(kwargs["maximum_uncertainty_union_inflation"]), limit, mode,
                          float(kwargs.get("minimum_core_semi_axis", 0.0)), ptr(inverse, ctypes.c_int64),
                          ptr(centers), ptr(radii), ptr(shapes), ptr(rotations), ptr(offsets), ptr(unc),
                          ptr(base_radii), ptr(outer), ptr(scalars))
    if count == -1:
        raise ValueError("certificate radius limit is smaller than an indivisible proxy requirement")
    if count == -2:
        raise AssertionError("refined proxy exceeded certificate radius limit")
    if count < 0:
        raise RuntimeError(f"native bucket fit failed with code {count}")
    result = PointCloudProxySet(
        raw_points=np.asarray(points, dtype=float),
        filtered_points=p,
        centers=centers[:count].copy(),
        sphere_radii=radii[:count].copy(),
        ellipsoid_shapes=shapes[:count].copy(),
        rotations=rotations[:count].copy(),
        cluster_keys=np.arange(count, dtype=int)[:, None],
        filtered_cluster_indices=inverse,
        maximum_ellipsoid_overshoot=float(scalars[0]),
        proxy_offset_radii=offsets[:count].copy(),
        filtered_uncertainty_shapes=u.copy(),
        filtered_point_offsets=off.copy(),
        proxy_uncertainty_shapes=unc[:count].copy(),
        base_sphere_radii=base_radii[:count].copy(),
        base_ellipsoid_shapes=shapes[:count].copy(),
        ellipsoid_outer_shapes=outer[:count].copy(),
        surface_cover_radius=float(scalars[2]),
        maximum_uncertainty_union_inflation=float(scalars[1]),
        certificate_radius_limit=limit,
        uncertainty_fusion_mode="separate_uncertainty",
    )
    assert_proxy_coverage(result, surface_uncertainty)
    return result
