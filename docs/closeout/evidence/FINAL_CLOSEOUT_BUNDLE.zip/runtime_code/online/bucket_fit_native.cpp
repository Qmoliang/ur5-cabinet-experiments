// Native port of pointcloud_proxy.fit_matched_voxel_proxies for the online
// mode used by incremental_proxy_manager: already-filtered CenterVox cells with
// cover offsets and directional uncertainty, "separate_uncertainty" fusion, a
// fixed world cluster origin, a certificate radius limit and a maximum
// uncertainty-union inflation.  It follows the Python step by step (bucket
// order, k-NN normals, normal-similarity union-find, level-by-level recursive
// splits, grouped Loewner joins with the same member ordering, per-proxy
// outputs).  Every symmetric 3x3 eigenproblem is solved by LAPACK dsyevd from
// NumPy's own OpenBLAS (the routine numpy.linalg.eigh/eigvalsh call), so frames
// match NumPy up to summation-order rounding.  The caller still runs the
// Python coverage proof on every result.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <numeric>
#include <unordered_map>
#include <vector>

extern "C" void dsyevd_64_(const char* jobz, const char* uplo, const int64_t* n, double* a, const int64_t* lda,
                           double* w, double* work, const int64_t* lwork, int64_t* iwork, const int64_t* liwork,
                           int64_t* info, size_t jobz_len, size_t uplo_len);

namespace {

using M3 = std::array<double, 9>;  // row-major
using V3 = std::array<double, 3>;

bool g_lapack_failed = false;

// eigh: ascending values, V[3*i+j] = component i of eigenvector j (NumPy layout).
void eigh3(const M3& s, V3& w, M3& v) {
  double a[9];
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) a[i + 3 * j] = s[3 * i + j];  // column-major copy
  const int64_t n = 3, lda = 3, lwork = 37, liwork = 18;
  double work[37];
  int64_t iwork[18], info = 0;
  dsyevd_64_("V", "L", &n, a, &lda, w.data(), work, &lwork, iwork, &liwork, &info, 1, 1);
  if (info != 0) g_lapack_failed = true;
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) v[3 * i + j] = a[i + 3 * j];
}

V3 eigvalsh3(const M3& s) {
  double a[9];
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) a[i + 3 * j] = s[3 * i + j];
  const int64_t n = 3, lda = 3, lwork = 7, liwork = 1;
  double work[7];
  int64_t iwork[1], info = 0;
  V3 w{};
  dsyevd_64_("N", "L", &n, a, &lda, w.data(), work, &lwork, iwork, &liwork, &info, 1, 1);
  if (info != 0) g_lapack_failed = true;
  return w;
}

// Cyclic Jacobi for a symmetric 3x3 matrix: ascending values, V[3*i+j] =
// component i of eigenvector j.  Used only where the result does not depend on
// the eigenvector basis (eigenvalues, V f(w) V^T matrix functions); LAPACK
// (eigh3) stays where the basis itself enters the fit.
void eigh3_fast(const double* s_in, V3& w, M3& v_out) {
  double a[9];
  std::memcpy(a, s_in, sizeof(a));
  double v[9] = {1, 0, 0, 0, 1, 0, 0, 0, 1};
  for (int sweep = 0; sweep < 60; ++sweep) {
    double off = a[1] * a[1] + a[2] * a[2] + a[5] * a[5];
    double diag = a[0] * a[0] + a[4] * a[4] + a[8] * a[8];
    if (off <= 1e-34 * diag || off < 1e-300) break;
    for (int p = 0; p < 2; ++p)
      for (int q = p + 1; q < 3; ++q) {
        double apq = a[3 * p + q];
        if (apq == 0.0) continue;
        double app = a[3 * p + p], aqq = a[3 * q + q];
        double theta = (aqq - app) / (2.0 * apq);
        double t = (theta >= 0 ? 1.0 : -1.0) / (std::fabs(theta) + std::sqrt(theta * theta + 1.0));
        double c = 1.0 / std::sqrt(t * t + 1.0), sn = t * c;
        for (int k = 0; k < 3; ++k) {
          double akp = a[3 * k + p], akq = a[3 * k + q];
          a[3 * k + p] = c * akp - sn * akq;
          a[3 * k + q] = sn * akp + c * akq;
        }
        for (int k = 0; k < 3; ++k) {
          double apk = a[3 * p + k], aqk = a[3 * q + k];
          a[3 * p + k] = c * apk - sn * aqk;
          a[3 * q + k] = sn * apk + c * aqk;
        }
        for (int k = 0; k < 3; ++k) {
          double vkp = v[3 * k + p], vkq = v[3 * k + q];
          v[3 * k + p] = c * vkp - sn * vkq;
          v[3 * k + q] = sn * vkp + c * vkq;
        }
      }
  }
  int order[3] = {0, 1, 2};
  std::sort(order, order + 3, [&](int x, int y) { return a[4 * x] < a[4 * y]; });
  for (int j = 0; j < 3; ++j) {
    w[j] = a[4 * order[j]];
    for (int i = 0; i < 3; ++i) v_out[3 * i + j] = v[3 * i + order[j]];
  }
}

V3 eigvalsh3_fast(const M3& s) {
  V3 w;
  M3 v;
  eigh3_fast(s.data(), w, v);
  return w;
}

M3 sym(const double* a) {
  M3 s;
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) s[3 * i + j] = 0.5 * (a[3 * i + j] + a[3 * j + i]);
  return s;
}
double trace(const M3& a) { return a[0] + a[4] + a[8]; }

// V diag(d) V^T with the NumPy einsum index pattern "ij,j,kj->ik".
M3 vdvt(const M3& v, const V3& d) {
  M3 r{};
  for (int i = 0; i < 3; ++i)
    for (int k = 0; k < 3; ++k) {
      double acc = 0;
      for (int j = 0; j < 3; ++j) acc += v[3 * i + j] * d[j] * v[3 * k + j];
      r[3 * i + k] = acc;
    }
  return r;
}

M3 minkowski(const M3& first_in, const M3& second_in) {
  M3 f = sym(first_in.data()), s = sym(second_in.data());
  double ft = std::max(trace(f), 1.0e-18), st = std::max(trace(s), 1.0e-18);
  double beta = std::sqrt(st / ft);
  M3 r;
  for (int k = 0; k < 9; ++k) r[k] = (1.0 + beta) * f[k] + (1.0 + 1.0 / beta) * s[k];
  return r;
}

struct Fit {
  V3 center;
  double radius;
  M3 shape;
  M3 rotation;
  double overshoot;
};

struct Ctx {
  int64_t n;
  const double* p;   // n x 3
  const double* off; // n
  const double* u;   // n x 9
  double min_core;
};

V3 mean_of(const Ctx& c, const std::vector<int64_t>& idx) {
  V3 m{0, 0, 0};
  for (int64_t i : idx)
    for (int a = 0; a < 3; ++a) m[a] += c.p[3 * i + a];
  for (int a = 0; a < 3; ++a) m[a] /= (double)idx.size();
  return m;
}

M3 principal_frame(const Ctx& c, const std::vector<int64_t>& idx) {
  V3 m = mean_of(c, idx);
  M3 cov{};
  for (int64_t i : idx) {
    double d[3] = {c.p[3 * i] - m[0], c.p[3 * i + 1] - m[1], c.p[3 * i + 2] - m[2]};
    for (int a = 0; a < 3; ++a)
      for (int b = 0; b < 3; ++b) cov[3 * a + b] += d[a] * d[b];
  }
  double denom = (double)std::max<int64_t>(1, (int64_t)idx.size() - 1);
  for (double& x : cov) x /= denom;
  V3 w;
  M3 v;
  eigh3(cov, w, v);
  // np.argsort(values)[::-1]
  std::array<int, 3> order = {0, 1, 2};
  std::stable_sort(order.begin(), order.end(), [&](int a, int b) { return w[a] < w[b]; });
  std::reverse(order.begin(), order.end());
  M3 r;
  for (int i = 0; i < 3; ++i)
    for (int j = 0; j < 3; ++j) r[3 * i + j] = v[3 * i + order[j]];
  double det = r[0] * (r[4] * r[8] - r[5] * r[7]) - r[1] * (r[3] * r[8] - r[5] * r[6]) +
               r[2] * (r[3] * r[7] - r[4] * r[6]);
  if (det < 0.0)
    for (int i = 0; i < 3; ++i) r[3 * i + 2] *= -1.0;
  return r;
}

Fit fit_group(const Ctx& c, const std::vector<int64_t>& idx) {
  Fit f;
  f.rotation = principal_frame(c, idx);
  const M3& r = f.rotation;
  V3 m = mean_of(c, idx);
  size_t k = idx.size();
  std::vector<V3> local(k);
  V3 lo{1e300, 1e300, 1e300}, hi{-1e300, -1e300, -1e300};
  for (size_t t = 0; t < k; ++t) {
    double d[3] = {c.p[3 * idx[t]] - m[0], c.p[3 * idx[t] + 1] - m[1], c.p[3 * idx[t] + 2] - m[2]};
    for (int j = 0; j < 3; ++j) {
      double acc = 0;
      for (int a = 0; a < 3; ++a) acc += d[a] * r[3 * a + j];  // (cluster - mean) @ rotation
      local[t][j] = acc;
      lo[j] = std::min(lo[j], acc);
      hi[j] = std::max(hi[j], acc);
    }
  }
  V3 lc, half;
  for (int j = 0; j < 3; ++j) {
    lc[j] = 0.5 * (lo[j] + hi[j]);
    half[j] = 0.5 * (hi[j] - lo[j]);
  }
  for (int a = 0; a < 3; ++a) {
    double acc = 0;
    for (int j = 0; j < 3; ++j) acc += r[3 * a + j] * lc[j];
    f.center[a] = m[a] + acc;
  }
  double floor_axis = std::max(1.0e-4, c.min_core);
  V3 seed;
  for (int j = 0; j < 3; ++j) seed[j] = std::max(half[j], floor_axis);
  double maximum_mahalanobis = 0;
  for (size_t t = 0; t < k; ++t) {
    double s2 = 0;
    for (int j = 0; j < 3; ++j) {
      double x = (local[t][j] - lc[j]) / seed[j];
      s2 += x * x;
    }
    maximum_mahalanobis = std::max(maximum_mahalanobis, std::sqrt(s2));
  }
  V3 axes, axes2;
  double scale = std::max(maximum_mahalanobis, 1.0);
  for (int j = 0; j < 3; ++j) {
    axes[j] = seed[j] * scale;
    axes2[j] = axes[j] * axes[j];
  }
  // rotation @ diag(axes**2) @ rotation.T
  for (int a = 0; a < 3; ++a)
    for (int b = 0; b < 3; ++b) {
      double acc = 0;
      for (int j = 0; j < 3; ++j) acc += r[3 * a + j] * axes2[j] * r[3 * b + j];
      f.shape[3 * a + b] = acc;
    }
  double radius = 0;
  V3 point_support{0, 0, 0};
  for (size_t t = 0; t < k; ++t) {
    double s2 = 0;
    for (int a = 0; a < 3; ++a) {
      double d = c.p[3 * idx[t] + a] - f.center[a];
      s2 += d * d;
      point_support[a] = std::max(point_support[a], std::fabs(d));
    }
    radius = std::max(radius, std::sqrt(s2));
  }
  f.radius = radius;
  double overshoot = -1e300;
  for (int a = 0; a < 3; ++a) {
    double acc = 0;
    for (int j = 0; j < 3; ++j) acc += r[3 * a + j] * r[3 * a + j] * axes2[j];
    overshoot = std::max(overshoot, std::sqrt(acc) - point_support[a]);
  }
  f.overshoot = overshoot;
  return f;
}

// loewner_union_outer_shapes_grouped over groups of member indices (into u).
std::vector<M3> grouped_union(const Ctx& c, const std::vector<std::vector<int64_t>>& groups, bool single_repair) {
  size_t count = groups.size();
  std::vector<M3> result(count);
#pragma omp parallel for schedule(dynamic, 8)
  for (int64_t gi = 0; gi < (int64_t)count; ++gi) {
    const size_t g = (size_t)gi;
    const auto& members = groups[g];
    size_t m = members.size();
    std::vector<M3> s(m);
    std::vector<double> tr(m);
    for (size_t t = 0; t < m; ++t) {
      s[t] = sym(c.u + 9 * members[t]);
      tr[t] = trace(s[t]);
    }
    // lexsort order: -trace, then flat[0..8], then original position (stable)
    std::vector<size_t> order(m);
    std::iota(order.begin(), order.end(), 0);
    std::stable_sort(order.begin(), order.end(), [&](size_t a, size_t b) {
      if (-tr[a] != -tr[b]) return -tr[a] < -tr[b];
      for (int k = 0; k < 9; ++k)
        if (s[a][k] != s[b][k]) return s[a][k] < s[b][k];
      return false;
    });
    M3 joined = s[order[0]];
    for (size_t rank = 1; rank < m; ++rank) {
      const M3& member = s[order[rank]];
      M3 diff;
      for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
          diff[3 * i + j] = 0.5 * (member[3 * i + j] - joined[3 * i + j] + (member[3 * j + i] - joined[3 * j + i]));
      V3 w;
      M3 v;
      eigh3_fast(diff.data(), w, v);
      V3 wp{std::max(w[0], 0.0), std::max(w[1], 0.0), std::max(w[2], 0.0)};
      M3 positive = vdvt(v, wp);
      M3 next;
      for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 3; ++j)
          next[3 * i + j] = 0.5 * (joined[3 * i + j] + positive[3 * i + j] + (joined[3 * j + i] + positive[3 * j + i]));
      joined = next;
    }
    double minimum = std::numeric_limits<double>::infinity();
    for (size_t t = 0; t < m; ++t) {
      M3 d;
      for (int k = 0; k < 9; ++k) d[k] = joined[k] - s[t][k];
      minimum = std::min(minimum, eigvalsh3_fast(d)[0]);
    }
    double repair = single_repair ? (minimum < 0.0 ? -minimum + 1.0e-18 : 0.0) : std::max(-minimum, 0.0) + 1.0e-18;
    for (int i = 0; i < 3; ++i) joined[4 * i] += repair;
    M3 ref{};
    for (size_t t = 0; t < m; ++t)
      for (int k = 0; k < 9; ++k) ref[k] += s[t][k];
    for (int k = 0; k < 9; ++k) ref[k] /= (double)m;
    for (int i = 0; i < 3; ++i) ref[4 * i] += 1.0e-18;
    V3 rw;
    M3 rv;
    eigh3_fast(ref.data(), rw, rv);
    V3 inv_sqrt;
    for (int j = 0; j < 3; ++j) inv_sqrt[j] = 1.0 / std::sqrt(std::max(rw[j], 1.0e-18));
    M3 ir = vdvt(rv, inv_sqrt);
    double scale = 1.0;
    for (size_t t = 0; t < m; ++t) {
      M3 tmp{}, wht{};
      for (int i = 0; i < 3; ++i)
        for (int l = 0; l < 3; ++l) {
          double acc = 0;
          for (int k = 0; k < 3; ++k) acc += s[t][3 * i + k] * ir[3 * k + l];
          tmp[3 * i + l] = acc;
        }
      for (int i = 0; i < 3; ++i)
        for (int l = 0; l < 3; ++l) {
          double acc = 0;
          for (int j = 0; j < 3; ++j) acc += ir[3 * i + j] * tmp[3 * j + l];
          wht[3 * i + l] = acc;
        }
      M3 ws = sym(wht.data());
      scale = std::max(scale, eigvalsh3_fast(ws)[2]);
    }
    M3 scaled;
    for (int k = 0; k < 9; ++k) scaled[k] = scale * ref[k];
    result[g] = trace(joined) < trace(scaled) ? joined : scaled;
  }
  return result;
}

std::vector<V3> estimate_normals(const Ctx& c) {
  int64_t n = c.n;
  std::vector<V3> normals(n, V3{0, 0, 1});
  if (n <= 2) return normals;
  int64_t k = std::min<int64_t>(12, n);
  const double h = 0.01;
  std::unordered_map<int64_t, std::vector<int64_t>> grid;
  auto key = [](int64_t x, int64_t y, int64_t z) { return (x * 73856093) ^ (y * 19349663) ^ (z * 83492791); };
  std::vector<std::array<int64_t, 3>> cell(n);
  for (int64_t i = 0; i < n; ++i) {
    for (int a = 0; a < 3; ++a) cell[i][a] = (int64_t)std::floor(c.p[3 * i + a] / h);
    grid[key(cell[i][0], cell[i][1], cell[i][2])].push_back(i);
  }
#pragma omp parallel
  {
  std::vector<std::pair<double, int64_t>> cand;
#pragma omp for schedule(dynamic, 64)
  for (int64_t i = 0; i < n; ++i) {
    for (int s = 1;; ++s) {
      cand.clear();
      for (int64_t dx = -s; dx <= s; ++dx)
        for (int64_t dy = -s; dy <= s; ++dy)
          for (int64_t dz = -s; dz <= s; ++dz) {
            auto it = grid.find(key(cell[i][0] + dx, cell[i][1] + dy, cell[i][2] + dz));
            if (it == grid.end()) continue;
            for (int64_t j : it->second) {
              if (cell[j][0] != cell[i][0] + dx || cell[j][1] != cell[i][1] + dy || cell[j][2] != cell[i][2] + dz)
                continue;  // hash collision
              double d2 = 0;
              for (int a = 0; a < 3; ++a) d2 += (c.p[3 * j + a] - c.p[3 * i + a]) * (c.p[3 * j + a] - c.p[3 * i + a]);
              cand.emplace_back(d2, j);
            }
          }
      if ((int64_t)cand.size() >= k) {
        std::partial_sort(cand.begin(), cand.begin() + k, cand.end());
        // complete once the k-th neighbour lies inside the searched cube
        if (std::sqrt(cand[k - 1].first) <= s * h || (int64_t)cand.size() == n) break;
      }
      if (s > 1000) break;
    }
    V3 m{0, 0, 0};
    for (int64_t t = 0; t < k; ++t)
      for (int a = 0; a < 3; ++a) m[a] += c.p[3 * cand[t].second + a];
    for (int a = 0; a < 3; ++a) m[a] /= (double)k;
    M3 cov{};
    for (int64_t t = 0; t < k; ++t) {
      double d[3];
      for (int a = 0; a < 3; ++a) d[a] = c.p[3 * cand[t].second + a] - m[a];
      for (int a = 0; a < 3; ++a)
        for (int b = 0; b < 3; ++b) cov[3 * a + b] += d[a] * d[b];
    }
    V3 w;
    M3 v;
    eigh3(cov, w, v);
    V3 nrm{v[0], v[3], v[6]};
    double len = std::max(std::sqrt(nrm[0] * nrm[0] + nrm[1] * nrm[1] + nrm[2] * nrm[2]), 1.0e-12);
    for (int a = 0; a < 3; ++a) nrm[a] /= len;
    normals[i] = nrm;
  }
  }
  return normals;
}

std::vector<std::vector<int64_t>> split_by_normals(const Ctx& c, const std::vector<int64_t>& idx,
                                                   const std::vector<V3>& normals, double distance) {
  const double threshold = std::cos(25.0 * M_PI / 180.0);
  size_t m = idx.size();
  std::vector<int64_t> parent(m);
  std::iota(parent.begin(), parent.end(), 0);
  auto find = [&](int64_t i) {
    while (parent[i] != i) {
      parent[i] = parent[parent[i]];
      i = parent[i];
    }
    return i;
  };
  auto dot = [&](int64_t a, int64_t b) {
    const V3 &x = normals[idx[a]], &y = normals[idx[b]];
    return std::fabs(x[0] * y[0] + x[1] * y[1] + x[2] * y[2]);
  };
  double d2max = distance * distance;
  for (size_t a = 0; a < m; ++a)
    for (size_t b = a + 1; b < m; ++b) {
      double d2 = 0;
      for (int t = 0; t < 3; ++t) {
        double d = c.p[3 * idx[a] + t] - c.p[3 * idx[b] + t];
        d2 += d * d;
      }
      if (d2 > d2max) continue;  // cKDTree.query_pairs keeps d^2 <= r^2
      if (dot(a, b) < threshold) continue;
      int64_t ra = find(a), rb = find(b);
      if (ra == rb) continue;
      if (dot(ra, rb) < threshold) continue;
      if (ra < rb) parent[rb] = ra; else parent[ra] = rb;
    }
  std::vector<std::vector<int64_t>> components;
  std::unordered_map<int64_t, size_t> slot;
  for (size_t a = 0; a < m; ++a) {
    int64_t root = find(a);
    auto it = slot.find(root);
    if (it == slot.end()) {
      slot[root] = components.size();
      components.push_back({idx[a]});
    } else {
      components[it->second].push_back(idx[a]);
    }
  }
  return components;
}

}  // namespace

extern "C" {

// Returns the proxy count (>= 1) or a negative code:
//   -1 radius limit smaller than an indivisible proxy requirement (Python ValueError)
//   -2 refined proxy exceeded certificate radius limit (Python AssertionError)
//   -3 LAPACK failure
int64_t bf_fit(int64_t n, const double* points, const double* offsets, const double* uncertainty,
               const double* origin, double cluster_size, double connection_distance, double maximum_aabb_overshoot,
               double maximum_union_inflation, double radius_limit, int32_t limit_mode /*0 both,1 sphere,2 ellipsoid*/,
               double minimum_core, int64_t* refined_inverse, double* centers, double* sphere_radii,
               double* shapes, double* rotations, double* proxy_offsets, double* proxy_uncertainty,
               double* base_radii, double* outer_shapes, double* scalars /*overshoot, inflation, surface radius*/) {
  g_lapack_failed = false;
  Ctx c{n, points, offsets, uncertainty, minimum_core};
  // spatial buckets in lexicographic key order, members in input order
  std::vector<std::array<int64_t, 3>> keys(n);
  for (int64_t i = 0; i < n; ++i)
    for (int a = 0; a < 3; ++a) keys[i][a] = (int64_t)std::floor((points[3 * i + a] - origin[a]) / cluster_size);
  std::vector<int64_t> order(n);
  std::iota(order.begin(), order.end(), 0);
  std::stable_sort(order.begin(), order.end(), [&](int64_t a, int64_t b) { return keys[a] < keys[b]; });
  std::vector<V3> normals = estimate_normals(c);
  std::vector<std::vector<int64_t>> initial;
  for (int64_t s = 0; s < n;) {
    int64_t e = s + 1;
    while (e < n && keys[order[e]] == keys[order[s]]) ++e;
    std::vector<int64_t> group(order.begin() + s, order.begin() + e);
    for (auto& comp : split_by_normals(c, group, normals, connection_distance)) initial.push_back(std::move(comp));
    s = e;
  }
  struct Node {
    std::vector<int64_t> idx;
    int depth;
    std::vector<int64_t> path;
  };
  std::vector<Node> pending;
  for (size_t g = 0; g < initial.size(); ++g) pending.push_back({initial[g], 0, {(int64_t)g}});
  struct Accepted {
    std::vector<int64_t> path, idx;
    Fit fit;
  };
  std::vector<Accepted> accepted;
  auto trace_of = [&](int64_t i) { return uncertainty[9 * i] + uncertainty[9 * i + 4] + uncertainty[9 * i + 8]; };
  auto uncertainty_split = [&](const std::vector<int64_t>& idx, std::vector<int64_t>& left,
                               std::vector<int64_t>& right) -> bool {
    if (idx.size() < 2) return false;
    size_t m = idx.size();
    std::vector<std::array<double, 9>> f(m);
    for (size_t t = 0; t < m; ++t) {
      double tr = std::max(trace_of(idx[t]), 1.0e-18);
      for (int k = 0; k < 9; ++k) f[t][k] = uncertainty[9 * idx[t] + k] / tr;
    }
    auto dist = [&](size_t a, size_t b) {
      double s = 0;
      for (int k = 0; k < 9; ++k) s += (f[a][k] - f[b][k]) * (f[a][k] - f[b][k]);
      return std::sqrt(s);
    };
    size_t second = 0, third = 0;
    double best = -1;
    for (size_t t = 0; t < m; ++t)
      if (dist(t, 0) > best) { best = dist(t, 0); second = t; }
    best = -1;
    for (size_t t = 0; t < m; ++t)
      if (dist(t, second) > best) { best = dist(t, second); third = t; }
    left.clear();
    right.clear();
    for (size_t t = 0; t < m; ++t) (dist(t, second) <= dist(t, third) ? left : right).push_back(idx[t]);
    return !left.empty() && !right.empty();
  };
  while (!pending.empty()) {
    std::vector<std::vector<int64_t>> node_groups;
    for (auto& node : pending) node_groups.push_back(node.idx);
    std::vector<M3> unions = grouped_union(c, node_groups, true);
    std::vector<Node> next;
    std::vector<Fit> fits(pending.size());
#pragma omp parallel for schedule(dynamic, 4)
    for (int64_t ni = 0; ni < (int64_t)pending.size(); ++ni) fits[ni] = fit_group(c, pending[ni].idx);
    for (size_t ni = 0; ni < pending.size(); ++ni) {
      Node& node = pending[ni];
      const Fit& fit = fits[ni];
      const M3& un = unions[ni];
      std::vector<int64_t> left, right;
      bool split = false;
      double max_trace = 1.0e-18;
      for (int64_t i : node.idx) max_trace = std::max(max_trace, trace_of(i));
      if (node.depth < 16 && trace(un) / max_trace > maximum_union_inflation)
        split = uncertainty_split(node.idx, left, right);
      if (!split) {
        double offset = 0;
        for (int64_t i : node.idx) offset = std::max(offset, offsets[i]);
        M3 outer = minkowski(fit.shape, un);
        double ur = std::sqrt(std::max(eigvalsh3_fast(un)[2], 0.0));
        double sphere_required = fit.radius + ur + offset;
        double ellipsoid_required = std::sqrt(std::max(eigvalsh3_fast(outer)[2], 0.0)) + offset;
        double limited = limit_mode == 0 ? std::max(sphere_required, ellipsoid_required)
                         : limit_mode == 1 ? sphere_required : ellipsoid_required;
        if (limited > radius_limit + 1.0e-12) {
          // certificate_split
          bool ok = false;
          if (node.idx.size() >= 2) {
            V3 lo{1e300, 1e300, 1e300}, hi{-1e300, -1e300, -1e300};
            for (int64_t i : node.idx)
              for (int a = 0; a < 3; ++a) {
                lo[a] = std::min(lo[a], points[3 * i + a]);
                hi[a] = std::max(hi[a], points[3 * i + a]);
              }
            double spread_max = std::max(std::max(hi[0] - lo[0], hi[1] - lo[1]), hi[2] - lo[2]);
            std::vector<int64_t> ord;
            bool done = false;
            if (spread_max <= 1.0e-15) {
              if (uncertainty_split(node.idx, left, right)) { ok = true; done = true; }
              else { ord = node.idx; std::sort(ord.begin(), ord.end()); }
            } else {
              int axis = 0;
              for (int a = 1; a < 3; ++a)
                if (hi[a] - lo[a] > hi[axis] - lo[axis]) axis = a;
              ord = node.idx;
              std::stable_sort(ord.begin(), ord.end(),
                               [&](int64_t a, int64_t b) { return points[3 * a + axis] < points[3 * b + axis]; });
            }
            if (!done) {
              size_t mid = ord.size() / 2;
              if (0 < mid && mid < ord.size()) {
                left.assign(ord.begin(), ord.begin() + mid);
                right.assign(ord.begin() + mid, ord.end());
                ok = true;
              }
            }
          }
          if (!ok || node.depth >= 32) return -1;
          split = true;
        }
      }
      if (!split && fit.overshoot > maximum_aabb_overshoot && node.depth < 16 && node.idx.size() >= 4) {
        V3 lo{1e300, 1e300, 1e300}, hi{-1e300, -1e300, -1e300};
        for (int64_t i : node.idx)
          for (int a = 0; a < 3; ++a) {
            lo[a] = std::min(lo[a], points[3 * i + a]);
            hi[a] = std::max(hi[a], points[3 * i + a]);
          }
        int axis = 0;
        for (int a = 1; a < 3; ++a)
          if (hi[a] - lo[a] > hi[axis] - lo[axis]) axis = a;
        std::vector<int64_t> ord = node.idx;
        std::stable_sort(ord.begin(), ord.end(),
                         [&](int64_t a, int64_t b) { return points[3 * a + axis] < points[3 * b + axis]; });
        size_t mid = ord.size() / 2;
        if (0 < mid && mid < ord.size()) {
          left.assign(ord.begin(), ord.begin() + mid);
          right.assign(ord.begin() + mid, ord.end());
          split = true;
        }
      }
      if (split) {
        auto pl = node.path, pr = node.path;
        pl.push_back(0);
        pr.push_back(1);
        next.push_back({left, node.depth + 1, pl});
        next.push_back({right, node.depth + 1, pr});
      } else {
        accepted.push_back({node.path, node.idx, fit});
      }
    }
    pending.swap(next);
  }
  std::stable_sort(accepted.begin(), accepted.end(),
                   [](const Accepted& a, const Accepted& b) { return a.path < b.path; });
  int64_t count = (int64_t)accepted.size();
  std::vector<std::vector<int64_t>> members(count);
  for (int64_t pi = 0; pi < count; ++pi) {
    for (int64_t i : accepted[pi].idx) refined_inverse[i] = pi;
  }
  // grouped union over all points by refined_inverse (members in input order)
  for (int64_t i = 0; i < n; ++i) members[refined_inverse[i]].push_back(i);
  std::vector<M3> proxy_u = grouped_union(c, members, false);
  double maximum_overshoot = 0.0, maximum_inflation = 1.0;
  for (int64_t pi = 0; pi < count; ++pi) {
    double mt = 0.0;
    for (int64_t i : members[pi]) mt = std::max(mt, trace_of(i));
    maximum_inflation = std::max(maximum_inflation, trace(proxy_u[pi]) / std::max(mt, 1.0e-18));
  }
  int limit_failures = 0;
#pragma omp parallel for schedule(dynamic, 16) reduction(+:limit_failures)
  for (int64_t pi = 0; pi < count; ++pi) {
    const Fit& f = accepted[pi].fit;
    const M3& un = proxy_u[pi];
    double effective = f.radius + std::sqrt(std::max(eigvalsh3_fast(un)[2], 0.0));
    M3 outer = minkowski(f.shape, un);
    double offset = 0;
    for (int64_t i : accepted[pi].idx) offset = std::max(offset, offsets[i]);
    double sphere_required = effective + offset;
    double ellipsoid_required = std::sqrt(std::max(eigvalsh3_fast(outer)[2], 0.0)) + offset;
    bool failed = limit_mode == 0 ? std::max(sphere_required, ellipsoid_required) > radius_limit + 1.0e-9
                  : limit_mode == 1 ? sphere_required > radius_limit + 1.0e-9
                                    : ellipsoid_required > radius_limit + 1.0e-9;
    if (failed) { limit_failures += 1; continue; }
    if (limit_mode == 0 || limit_mode == 1) effective = radius_limit - offset;
    for (int a = 0; a < 3; ++a) centers[3 * pi + a] = f.center[a];
    sphere_radii[pi] = effective;
    base_radii[pi] = f.radius;
    proxy_offsets[pi] = offset;
    for (int k = 0; k < 9; ++k) {
      shapes[9 * pi + k] = f.shape[k];
      rotations[9 * pi + k] = f.rotation[k];
      proxy_uncertainty[9 * pi + k] = un[k];
      outer_shapes[9 * pi + k] = outer[k];
    }
  }
  if (limit_failures) return -2;
  for (int64_t pi = 0; pi < count; ++pi) maximum_overshoot = std::max(maximum_overshoot, accepted[pi].fit.overshoot);
  double surface = 0.0;
#pragma omp parallel for reduction(max:surface)
  for (int64_t i = 0; i < n; ++i) surface = std::max(surface, eigvalsh3_fast(sym(uncertainty + 9 * i))[2]);
  scalars[0] = maximum_overshoot;
  scalars[1] = maximum_inflation;
  scalars[2] = std::sqrt(std::max(surface, 0.0));
  if (g_lapack_failed) return -3;
  return count;
}

}  // extern "C"
