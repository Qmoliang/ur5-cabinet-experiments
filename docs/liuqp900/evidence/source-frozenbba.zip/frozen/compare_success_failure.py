"""Offline diagnosis only. Successful joint trajectories are not exported to control."""
from pathlib import Path
import os,json
os.sched_setaffinity(0,{48,49,50,51})
import numpy as np
from scipy.optimize import linprog
from pilot_adapter import ROOT,U,build,online

OLD=ROOT.parent/'liuqp_lowdim_pilot_20261106'
sources={
 'successful_guided':U/'analysis/liuqp_execution_ablation_20261105/trials/iris_4shelves_t2_liuqp',
 'original_failed':OLD/'trials/confirm_original_shelf_t2_baseline_300s',
 'lowdim_failed':OLD/'trials/pilot_v4_original_shelf_t2_full'}
ctx=build('iris_4shelves_t2');ctl=ctx.controller;ctl.osqp_adaptive_row_threshold=10**9;ctl.osqp_absolute_tolerance=1e-7;ctl.osqp_relative_tolerance=1e-7;ctl.osqp_max_iterations=3000;ctl.pilot_verified_fallback=True
low=ctx.model.jnt_range[:6,0]+.015;high=ctx.model.jnt_range[:6,1]-.015
results=[]
for label,folder in sources.items():
    tr=np.load(folder/'trajectory.npz');q=tr['q'];v=tr['velocity'];ee=tr['ee'];error=np.linalg.norm(ee-ctx.target,axis=1)
    assert np.max(np.abs(q[0]-ctx.q0))<1e-12
    samples=[]
    for k in sorted(set([0,min(100,len(v)-1),min(250,len(v)-1),min(500,len(v)-1),min(1000,len(v)-1),min(2000,len(v)-1),len(v)-1])):
        qi=q[k];previous=np.zeros(6) if k==0 else v[k-1]
        online.set_configuration(ctx.model,ctx.data,qi);ctl.applied_velocity=previous.copy();ctl.previous_velocity=previous.copy()
        nominal,metrics=ctl.solve(ctx.target);H,g,A,l,u=ctl.last_qp_arrays;s=ctl.pilot_nominal;J=s['J'];p=online.attachment_position(ctx.model,ctx.data);d=(ctx.target-p)/np.linalg.norm(ctx.target-p)
        force=np.abs(s['y'])*np.linalg.norm(A,axis=1);indices=np.argsort(-force)[:5]
        finite_up=np.isfinite(u);finite_lo=np.isfinite(l);AA=np.vstack([A[finite_up],-A[finite_lo]]);bb=np.r_[u[finite_up],-l[finite_lo]]
        lp=linprog(-d@J,A_ub=AA,b_ub=bb,bounds=[(None,None)]*6,method='highs')
        actual=v[k]
        samples.append(dict(cycle=k,time_s=k*.02,q=qi.tolist(),joint_lower_reserve=(qi-low).tolist(),joint_upper_reserve=(high-qi).tolist(),goal_error_mm=float(np.linalg.norm(p-ctx.target))*1000,actual_velocity=actual.tolist(),nominal_velocity=nominal.tolist(),actual_goal_rate_mm_s=float(d@J@actual)*1000,nominal_goal_rate_mm_s=float(d@J@nominal)*1000,max_goal_rate_mm_s=None if not lp.success else float(-lp.fun)*1000,actual_original_constraint_violation=float(max(np.max(l-A@actual),np.max(A@actual-u),0)),nominal_status=metrics.status,actual_original_objective=float(.5*actual@H@actual+g@actual),nominal_original_objective=float(.5*nominal@H@nominal+g@nominal),top_rows=[dict(id=s['row_ids'][i],dual=float(s['y'][i]),force=float(force[i]),bound_lower=float(l[i]),bound_upper=float(u[i])) for i in indices]))
    audit=json.loads((folder/'audit.json').read_text())
    results.append(dict(label=label,source=str(folder),duration_s=len(v)*.02,initial_q=q[0].tolist(),final_q=q[-1].tolist(),joint_net_change=(q[-1]-q[0]).tolist(),minimum_joint_lower_reserve=np.min(q-low,axis=0).tolist(),minimum_joint_upper_reserve=np.min(high-q,axis=0).tolist(),first_error_mm=float(error[0])*1000,final_error_mm=float(error[-1])*1000,peak_error_mm=float(error.max())*1000,cumulative_error_increase_mm=float(np.maximum(np.diff(error),0).sum())*1000,minimum_proxy_gap_mm=audit['minimum_proxy_gap_mm'],safety_passed=audit['safety_passed'],goal_passed=audit['goal_passed'],samples=samples))
    print(json.dumps({k:x for k,x in results[-1].items() if k!='samples'},indent=2),flush=True)
initial=results[0]['samples'][0]
summary=dict(task='iris_4shelves_t2',seed=1,all_initial_states_equal=True,records=results,offline_witness_only=True,controller_may_read_success_path=False)
(ROOT/'SUCCESS_FAILURE_COMPARISON.json').write_text(json.dumps(summary,indent=2))
