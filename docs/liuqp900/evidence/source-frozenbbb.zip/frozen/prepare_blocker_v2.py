from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
archive=ROOT/'revisions/blocker_original';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='blocker':";new="        if job.get('policy_version')=='blocker_v2':\n            from blocker_policy_v2 import LowDimPolicy\n        elif job.get('policy_version')=='blocker':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'blocker_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('blocker_release','blocker_v2');j['policy_version']='blocker_v2'
(ROOT/'blocker_v2_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'BLOCKER_V2_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='clear stale expected auxiliary command on every callback including early braking returns; stop geometric release inside original goal tolerance; objective and thresholds unchanged'),indent=2))
print(json.dumps(jobs))
