"""Compact failed-feature exclusions preserve the original Cartesian goal fiber."""
import numpy as np
from goal_fiber_policy import LowDimPolicy as Previous
from goal_entry_policy_v6 import LowDimPolicy as GoalSolver
class LowDimPolicy(Previous):
 def __init__(self,*a,**kw):
  self.ball_interval_checks=0;self.ball_subdivisions=0;super().__init__(*a,**kw)
 def _is_ball(self,m):return m.get('memory_kind')=='local_feature_exclusion'
 def _memory_stamp(self):
  return tuple(('ball',tuple(m['hit_feature']),float(m['radius_m'])) if self._is_ball(m) else ('plane',tuple(m['normal']),float(m['offset'])) for m in self.memories)
 def _value(self,m,q):
  if self._is_ball(m):return float(np.linalg.norm(self.feature(q)-np.asarray(m['hit_feature']))-m['radius_m'])
  return super()._value(m,q)
 def _gradient(self,m,s):
  if not self._is_ball(m):return super()._gradient(m,s)
  d=self.feature(self.q)-np.asarray(m['hit_feature']);n=d/max(np.linalg.norm(d),1e-30);return n[:3]@s['J']+n[3:]@self.P
 def _extra_violation(self,q,v,arrays,ids,J):
  all_memories=self.memories;balls=[m for m in all_memories if self._is_ball(m)];self.memories=[m for m in all_memories if not self._is_ball(m)]
  try:value=super()._extra_violation(q,v,arrays,ids,J)
  finally:self.memories=all_memories
  feature=self.feature(q)
  for m in balls:
   d=feature-np.asarray(m['hit_feature']);norm=np.linalg.norm(d);n=d/max(norm,1e-30);value=max(value,float(-(n[:3]@J+n[3:]@self.P)@v-self.ctx.controller.task_gain*(norm-m['radius_m'])))
  return value
 def _memory_segment(self,a,b,memories,depth=0):
  planes=[m for m in memories if not self._is_ball(m)]
  if not super()._memory_segment(a,b,planes,depth):return False
  balls=[m for m in memories if self._is_ball(m)]
  if not balls:return True
  fa=self.feature(a);fb=self.feature(b);curve=self.site_curvature*np.sum(np.abs(b-a))**2/8
  for m in balls:
   self.ball_interval_checks+=1;x=fa-np.asarray(m['hit_feature']);y=fb-np.asarray(m['hit_feature']);d=y-x;t=np.clip(-x@d/max(d@d,1e-30),0,1);lower=float(np.linalg.norm(x+t*d)-curve)
   for endpoint in [x,y]:
    n=endpoint/max(np.linalg.norm(endpoint),1e-30);va=float(n@x);vb=float(n@y);B=4*curve*np.linalg.norm(n[:3]);slope=vb-va;t=np.clip((B-slope)/max(2*B,1e-30),0,1);lower=max(lower,float(va+t*(slope-B)+B*t*t))
   if np.nextafter(lower,-np.inf)>=m['radius_m']-1e-10:continue
   if min(np.linalg.norm(x),np.linalg.norm(y))<m['radius_m']-1e-9 or depth>=8:return False
   self.ball_subdivisions+=1;mid=(a+b)/2
   if not self._memory_segment(a,mid,[m],depth+1) or not self._memory_segment(mid,b,[m],depth+1):return False
  return True
 def select_terminal(self):
  memories=self.memories;balls=[m for m in memories if self._is_ball(m)]
  for rank,port in enumerate(self.terminal_options):
   if rank not in self.option_tried and any(self._value(m,np.asarray(port['goal_q']))<-1e-10 for m in balls):self.option_tried.add(rank);self.emit('terminal_pose_rejected_by_compact_memory',rank=rank)
  self.memories=[m for m in memories if not self._is_ball(m)]
  try:return super().select_terminal()
  finally:self.memories=memories
 def start_surface(self,*args,**kwargs):
  accepted=super().start_surface(*args,**kwargs)
  if accepted:
   hit=self.feature(self.q);radius=min(self.radius/2,self.error/4);self.surface_pending=dict(memory_kind='local_feature_exclusion',hit_feature=hit.tolist(),radius_m=radius,progress_buffer_m=radius,goal_value=self.error-radius,hit_distance=self.error,selected_row=list(self.blocker_id),hit_cycle=self.k);self.ee_escape_hit=self.error
  return accepted
 def _try_rejoin(self,c,s,arrays):
  m=self.surface_pending
  if m is None:return None
  if not self._is_ball(m):return super()._try_rejoin(c,s,arrays)
  if self._value(m,self.q)<m['radius_m']:return None
  if np.max(abs(self.previous))>1e-8:
   self.command_epoch+=1;self.brake_pending=True;self.expected=None;c.pilot_supplied_solution=None;return np.zeros(6)
  old_mode=self.mode;old_memories=self.memories;old_cache=self.solve_cache;self.mode='GOAL_REJOIN';self.memories=old_memories+[m];self.rejoin_testing=True;self.solve_cache={};answer=None;chosen=None;rate=0.
  try:
   stop=self._certify(self.q,self.previous,np.zeros(6))
   if stop is not None:
    answer=GoalSolver._solve(self,c,s,arrays);chosen=None if answer is None else self._admit(c,arrays,answer)
    if chosen is not None:rate=float(-(self.ee-self.ctx.target)@s['J']@chosen[0]/max(self.error,1e-12))
  finally:self.mode=old_mode;self.memories=old_memories;self.rejoin_testing=False;self.solve_cache=old_cache
  if chosen is None or rate<=1e-4:return None
  self.memories.append(dict(m,activation_cycle=self.k));self.surface_pending=None;self.surface_visited.extend(self.surface_nodes);self.surface_escape=False;self.goal_rejoin=True;self.mode='GOAL_REJOIN';self.goal_best=self.error;self.goal_progress_cycle=self.k;self.goal_first_execution=False;self.actual_checkpoint=None;self.command_epoch+=1;self.solve_cache={}
  event=dict(cycle=self.k,hit_error_m=self.ee_escape_hit,error_m=self.error,feature_departure_m=self._value(m,self.q)+m['radius_m'],exclusion_radius_m=m['radius_m'],certified_goal_rate_m_s=rate,memory_index=len(self.memories)-1,goal_fiber_preserved=True);self.rejoin_events.append(event);self.emit('certified_original_goal_rejoin',**{k:v for k,v in event.items() if k!='cycle'});return self._publish(c,answer)
 def summary(self):
  out=super().summary();out.update(revision='binding_feasibility_and_compact_memory_rejoin',new_memory_kind='exclude a compact neighborhood of the executed failed 5D feature; all original-goal postures remain admissible',compact_memory_checks=self.ball_interval_checks,compact_memory_subdivisions=self.ball_subdivisions,old_memory_records_discarded=0,goal_rejoin_entry='actual departure from failed feature neighborhood plus a certified descending original-goal velocity; EE retreat is allowed');return out
