"""Goal-side dominance can invalidate an executable but unproductive heading."""
import numpy as np
from reheading_policy import LowDimPolicy as Previous
from goal_entry_policy_activated import LowDimPolicy as TransportOnly

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.pending_scan=False;self.pending_scan_trigger=None;self.reheading_brakes=0;self.dominance_switches=0
    def _fresh_candidates(self,geometry):
        point,n,J,gap=geometry;d=self._goal_point_for_blocker()-point;goal=d-n*(n@d)
        if np.linalg.norm(goal)<1e-8:
            d=self._entry_point()-point;goal=d-n*(n@d)
        if np.linalg.norm(goal)<1e-8:return None,[]
        goal/=np.linalg.norm(goal);side=np.cross(n,goal);side/=np.linalg.norm(side)
        sign=1. if side@(self._entry_point()-point)>=0 else -1.
        return goal,[('goal_tangent',goal),('entry_side',sign*side),('other_entry_side',-sign*side),('reverse_goal_tangent',-goal)]
    def _surface_action(self,c,s,arrays,geometry):
        old_action=TransportOnly._surface_action(self,c,s,arrays,geometry)
        if old_action is None:self.old_heading_rejections+=1
        waiting=self.pending_scan
        if not waiting and (self.circulation_tangent is None or self.k-self.feature_last_progress<100):return old_action
        goal,candidates=self._fresh_candidates(geometry)
        if goal is None:return old_action
        old=self._tangent(geometry).copy();J=geometry[2];old_rate=None if old_action is None else float(goal@J@old_action[0][1][0])
        trigger=self.pending_scan_trigger if waiting else ('unavailable' if old_action is None else 'goal_side_dominated')
        threshold=.0002/(100*self.dt);key=self._local_key(geometry);tests=[]
        for label,tangent in candidates:
            if self._already_tried(label,key):self.taboo_rejections+=1;continue
            if np.linalg.norm(tangent-old)*c.max_task_speed*self.dt<=2e-7:continue
            self.tangent_override=tangent
            try:chosen=self._try_direction(c,s,arrays,tangent@J)
            finally:self.tangent_override=None
            rate=None if chosen is None else float(goal@J@chosen[1][0])
            acceptable=chosen is not None
            if acceptable and trigger=='goal_side_dominated':
                acceptable=rate>threshold if waiting else rate>max(0.,old_rate)+threshold
            tests.append(dict(label=label,certified=chosen is not None,goal_side_rate=rate,accepted_for_reselection=bool(acceptable)))
            if not acceptable:continue
            item=dict(cycle=self.k,episode=key[1],row_id=list(self.blocker_id),label=label,trigger=trigger,q=self.q.tolist(),previous=self.previous.tolist(),old_tangent=old.tolist(),new_tangent=tangent.tolist(),angle_deg=float(np.degrees(np.arccos(np.clip(old@tangent,-1,1)))),safe_scale=chosen[1][1],memory_count=len(self.memories),old_goal_side_rate=old_rate,new_goal_side_rate=rate,dominance_threshold_m_s=threshold,candidate_tests=tests)
            self.pending_reheading=item;self._reheading_key=key
            return chosen,tangent,1.
        if waiting:
            self.pending_scan=False;self.pending_scan_trigger=None
            self.emit('target_end_reheading_not_certified_after_brake',candidate_tests=tests)
        return old_action
    def _use_tangent(self,tangent,sign):
        if self.pending_reheading is None:return TransportOnly._use_tangent(self,tangent,sign)
        item=self.pending_reheading
        if np.max(np.abs(self.previous))>1e-8:
            self.pending_reheading=None;self.pending_scan=True;self.pending_scan_trigger=item['trigger'];self.reheading_brakes+=1
            self.command_epoch+=1;self.brake_pending=True;self.no_action_start=None
            self.emit('target_end_reheading_brake_requested',label=item['label'],trigger=item['trigger'],old_goal_side_rate=item['old_goal_side_rate'],new_goal_side_rate=item['new_goal_side_rate'])
            return
        key=self._reheading_key
        self.reheading_attempts.append(dict(body=key[0],episode=key[1],state=key[2].copy(),label=item['label']))
        self.pending_scan=False;self.pending_scan_trigger=None;self.dominance_switches+=int(item['trigger']=='goal_side_dominated')
        # The stopped state has just been re-solved and re-certified. Only now
        # commit a new direction; no moving-state candidate survives the stop.
        super()._use_tangent(tangent,sign)
    def summary(self):
        out=super().summary();out.update(reheading_braking_requests=self.reheading_brakes,goal_side_dominance_reheadings=self.dominance_switches,reheading_rule='after actual stagnation, replace old heading if unavailable OR a certified target-side candidate strictly improves projected goal-side speed; stop and re-certify before changing a moving heading')
        return out
