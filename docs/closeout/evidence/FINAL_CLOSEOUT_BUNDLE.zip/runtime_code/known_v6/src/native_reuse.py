"""Plane reuse on LiuQP's native fused path.

Each cycle, robot spheres that moved less than `reuse_distance` since their
planes were computed, and whose newly arrived candidate obstacles all lie
behind those planes, keep their planes; only their gaps are recomputed, as the
distance to each plane (a stale closest point would overstate the gap).  All
other spheres go through LiuQP's unchanged native fused kernel.  Obstacles must
be static between map updates, so every map update clears the reuse state.
"""
from __future__ import annotations

import numpy as np

from controller import ProtocolLiuQPController, ProtocolSeparatingPlane

TOLERANCE = 1e-10


class NativeReuseLiuQPController(ProtocolLiuQPController):
    def __init__(self, *args, reuse_distance: float = 0.002, **kwargs):
        super().__init__(*args, **kwargs)
        self.reuse_distance = float(reuse_distance)
        self._state: dict[int, dict] = {}
        self._reused: set[int] = set()
        self._candidates_now: dict[int, np.ndarray] = {}
        self.counts = {"reused_spheres": 0, "recomputed_spheres": 0}

    def update_obstacles(self, *args, **kwargs):
        # Also called from the parent constructor, before _state exists.
        if hasattr(self, "_state"):
            self._state.clear()
        return super().update_obstacles(*args, **kwargs)

    def _prefetch_exact_closest_pairs(self, positions, radii):
        positions = np.asarray(positions, dtype=float)
        radii = np.asarray(radii, dtype=float)
        queried = self.obstacle_index.query_spheres(positions, radii)
        self._reused = set()
        recompute = []
        for i, (center, query) in enumerate(zip(positions, queried)):
            candidates = np.unique(np.asarray(query, dtype=np.int64))
            self._candidates_now[i] = candidates
            state = self._state.get(i)
            if state is not None and np.linalg.norm(center - state["center"]) <= self.reuse_distance:
                survivors = np.setdiff1d(candidates, state["candidates"], assume_unique=True)
                for plane in state["planes"]:
                    if not len(survivors):
                        break
                    behind = self._minimum_support(survivors, plane.normal_to_obstacle) >= plane.offset - TOLERANCE
                    survivors = survivors[~behind]
                if not len(survivors):
                    self._reused.add(i)
                    continue
            recompute.append(i)
        self.counts["reused_spheres"] += len(self._reused)
        self.counts["recomputed_spheres"] += len(recompute)
        batches, raw_counts, stats = {}, {}, {}
        geometry_ms = prune_ms = 0.0
        if recompute:
            index = np.asarray(recompute, dtype=np.int64)
            full = self._multiplier_dense
            # The native kernel keys its warm-start memory by row position, so
            # hand it exactly the rows of the spheres being recomputed.
            self._multiplier_dense = np.ascontiguousarray(full[index])
            try:
                sub_batches, geometry_ms, prune_ms = super()._prefetch_exact_closest_pairs(positions[index], radii[index])
                full[index] = self._multiplier_dense
            finally:
                self._multiplier_dense = full
            for local, original in enumerate(recompute):
                batches[original] = sub_batches[local]
                raw_counts[original] = self._prefetched_raw_counts[local]
                stats[original] = self._prefetched_closest_stats[local]
        for i in self._reused:
            batches[i] = None  # served from stored planes in active_planes_for_robot_sphere
            raw_counts[i] = len(self._candidates_now[i])
            stats[i] = (0, 0, 0.0, 0)
        self._prefetched_raw_counts = raw_counts
        self._prefetched_closest_stats = stats
        return batches, geometry_ms, prune_ms

    def active_planes_for_robot_sphere(self, robot_index, center, radius, directional_batch=None, exact_batch=None):
        if robot_index in self._reused:
            current = set(self._candidates_now[robot_index].tolist())
            planes = []
            for plane in self._state[robot_index]["planes"]:
                if plane.obstacle_index not in current:
                    continue
                clearance = plane.offset - float(plane.normal_to_obstacle @ center) - float(radius) - self.safety_margin
                planes.append(ProtocolSeparatingPlane(
                    robot_index=robot_index, obstacle_index=plane.obstacle_index, proxy_id=plane.proxy_id,
                    normal_to_obstacle=plane.normal_to_obstacle, surface_point=plane.surface_point,
                    offset=plane.offset, clearance=clearance))
            self._last_support_batch_stats = (0, 0.0, 0)
            self._last_closest_batch_stats = (0, 0, 0.0, 0, True)
            return planes, len(current), len(current) - len(planes), 0.0, 0.0
        result = super().active_planes_for_robot_sphere(robot_index, center, radius, directional_batch, exact_batch)
        if robot_index in self._candidates_now:
            self._state[robot_index] = {"center": np.array(center, dtype=float),
                                        "candidates": np.sort(self._candidates_now[robot_index]),
                                        "planes": result[0]}
        return result
