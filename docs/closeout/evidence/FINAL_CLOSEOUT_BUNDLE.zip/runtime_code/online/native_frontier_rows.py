"""Exact ordered frontier-plane pruning; no geometry or QP rule changes."""
import ctypes
import numpy as np
from native_mvt import DLL
_lib=ctypes.CDLL(str(DLL));_dp=ctypes.POINTER(ctypes.c_double);_ip=ctypes.POINTER(ctypes.c_int32)
_fn=_lib.frontier_select_planes;_fn.argtypes=[_dp,_dp,_dp,_dp,_ip,ctypes.c_int32,_ip];_fn.restype=ctypes.c_int32

def select_planes(centers,half,normals,nearest,order):
    arrays=[np.ascontiguousarray(x,dtype=np.float64) for x in [centers,half,normals,nearest]]
    ids=np.ascontiguousarray(order,dtype=np.int32);result=np.empty(len(ids),dtype=np.int32)
    count=_fn(*(x.ctypes.data_as(_dp) for x in arrays),ids.ctypes.data_as(_ip),len(ids),result.ctypes.data_as(_ip))
    if count<0:raise RuntimeError('frontier plane selection failed: '+str(count))
    return result[:count]
