"""Freeze a revision that diagnoses executed, rather than predicted, progress."""
from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
archive=ROOT/'revisions/blocker_v3';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
s=(ROOT/'blocker_policy.py').read_text()
s=s.replace('from polished_policy import LowDimPolicy as Previous','from blocker_policy_v3 import LowDimPolicy as Previous\nfrom polished_policy import LowDimPolicy as OriginalControl')
s=s.replace("        if direction@s['J']@nominal['velocity']>1e-4:return None\n",'')
s=s.replace('    def __call__(self,c,s,arrays):\n','''    def __call__(self,c,s,arrays):
        self.expected=None;self.last_delta=np.zeros(6)
        if self.error<=1e-3 and self.mode=='OBSTACLE_RELEASE':
            self.switch('RESERVE_GOAL','goal_tolerance_reached');self.blocker_id=None
''')
s=s.replace('        if nominal is None:self.brake_pending=True;return np.zeros(6)',"        if nominal is None:nominal=dict(velocity=s['x'].copy(),delta=np.zeros(6))  # diagnosis only; never publish this fallback")
s=s.replace('super().__call__(c,s,arrays)','OriginalControl.__call__(self,c,s,arrays)')
s=s.replace('persistent_stall_with_geometric_positive_dual','actual_executed_stall_with_geometric_positive_dual')
(ROOT/'blocker_policy_v4.py').write_text(s)
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='blocker_v3':";new="        if job.get('policy_version')=='blocker_v4':\n            from blocker_policy_v4 import LowDimPolicy\n        elif job.get('policy_version')=='blocker_v3':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'blocker_v3_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('blocker_v3','blocker_v4');j['policy_version']='blocker_v4'
(ROOT/'blocker_v4_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'BLOCKER_V4_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='detect persistent actual executed stagnation even when nominal QP predicts progress or auxiliary numerical solve is rejected; selected positive-dual geometric row and all admission checks unchanged'),indent=2))
print(json.dumps(jobs))
