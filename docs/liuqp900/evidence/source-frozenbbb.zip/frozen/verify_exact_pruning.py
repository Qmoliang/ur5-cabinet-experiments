from pathlib import Path
import os,time,json
os.sched_setaffinity(0,{48,49,50,51})
import numpy as np
from pilot_adapter import ROOT,build
from continuation_policy import LowDimPolicy as Full
from diagnostic_exact_pruned_policy import LowDimPolicy as Fast
R=ROOT;job=json.loads((R/'reproduction_jobs.json').read_text())[0];ctx=build(job['task']);old=Full(ctx,job,lambda **kw:None);new=Fast(ctx,job,lambda **kw:None);records=[]
for name in ['exact_failure_trace','old_zero_delay','old_full_refresh_cycle']:
 q=np.load(R/'trials'/name/'trajectory.npz')['q']
 for k in np.linspace(0,len(q)-1,12,dtype=int):
  old.k=new.k=int(k);a=old.continuation_witnesses(q[k]);b=new.continuation_witnesses(q[k]);assert len(a['rows'])==len(b['rows']),(name,k)
  err=0.
  for x,y in zip(a['rows'],b['rows']):
   assert (x['kind'],x['id'],x['fraction'])==(y['kind'],y['id'],y['fraction']),(name,k,x,y)
   err=max(err,abs(x['slack']-y['slack']),float(np.max(np.abs(x['b']-y['b']))))
  assert err==0.,(name,k,err)
  records.append(dict(source=name,cycle=int(k),rows=len(a['rows']),maximum_difference=err,original_s=a['seconds'],pruned_s=b['seconds']))
result=dict(states=len(records),all_witness_identities_and_values_bitwise_equal=True,old_total_s=sum(x['original_s'] for x in records),pruned_total_s=sum(x['pruned_s'] for x in records),candidates=new.bound_candidates,exact_evaluations=new.exact_candidates,records=records)
(R/'EXACT_PRUNING_EQUIVALENCE.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='records'},indent=2))
