"""Combined LiuQP + NEO rule for obstacles that may move (E0-E2).

The controller gets no labels and no object count: every certificate i has an
estimated velocity v_i (zero for static ones) and every plane row is

    n^T J qdot  <=  n^T v_i + (d - s_i * buffer_s) / tau_i

with n the separating normal (robot -> obstacle), d LiuQP's clearance and
s_i = max(0, -n^T v_i) the speed at which certificate i approaches.

  * n^T v_i is NEO's obstacle-velocity term (the gap also shrinks because the
    obstacle moves);
  * d / tau_i lets the gap shrink at most exponentially with time constant
    tau_i.  LiuQP is tau = dt (one step: it lets the gap close in 20 ms, so
    against an approaching object it reacts only when it is ~1 cm away);
    NEO's damper is tau = (d_i - d_s) / xi.  Here tau grows with the speed s_i
    at which certificate i approaches the robot sphere (adaptive influence):

        tau_i = dt + reaction_s * min(1, s_i / reference_speed)

    so a static certificate keeps LiuQP's row exactly (tau = dt, shift 0) and
    LiuQP's strength in narrow passages is untouched, while a fast-approaching
    one is held off from about s_i * reaction_s away;
  * s_i * buffer_s is a standoff (prediction along the normal): the gap is not
    allowed to decay to zero but to the distance the certificate covers in
    buffer_s, so a late conflict still leaves room (an exponential approach
    to zero gap turned every disturbance into contact).

Task yield (NEO's slack, which lets the task give way): the attraction is
scaled by clip((ttc - reaction_s) / (yield_s - reaction_s), 0, 1), with ttc the
smallest d / s_i over approaching rows of the previous cycle.

Swept broadphase: LiuQP only builds rows for certificates within ~5 cm, so a
moving certificate's index box is grown by |v_i| * sweep_s (run.py).

Escape (escape.py) only moves away from certificates that approached the arm in
the last solve; an infeasible QP with nothing approaching is LiuQP's own case
(the arm stops).  Contact-recovery rows also get the n^T v_i shift.
"""
from __future__ import annotations

import numpy as np


class CombinedRule:
    def __init__(self, dt, *, reaction_s=0.2, reference_speed=0.05, yield_s=0.6, buffer_s=0.1,
                 damper=True, adaptive=True, task_yield=True, buffer=True):
        self.dt = float(dt)
        self.reaction_s = float(reaction_s)
        self.reference_speed = float(reference_speed)
        self.yield_s = float(yield_s)
        self.buffer_s = float(buffer_s)
        self.damper, self.adaptive, self.task_yield = bool(damper), bool(adaptive), bool(task_yield)
        self.buffer = bool(buffer)
        self.velocities = None
        self.min_ttc = np.inf
        self.moving_rows = 0
        self.approaching_ids = set()
        self.task_scale = 1.0

    def set_velocities(self, velocities):
        """Per-certificate velocities for the next solve (None: all static)."""
        self.velocities = None if velocities is None else np.asarray(velocities, dtype=float)
        # Yield uses the previous cycle's time to contact.
        if self.task_yield and np.isfinite(self.min_ttc):
            span = max(self.yield_s - self.reaction_s, 1e-6)
            self.task_scale = float(np.clip((self.min_ttc - self.reaction_s) / span, 0.0, 1.0))
        else:
            self.task_scale = 1.0
        self.min_ttc = np.inf
        self.moving_rows = 0
        self.approaching_ids = set()

    def tau(self, approach_speed):
        if not self.damper:
            return self.dt
        if not self.adaptive:
            return self.dt + self.reaction_s
        return self.dt + self.reaction_s * min(1.0, approach_speed / self.reference_speed)

    def __call__(self, plane, bound):
        """(collision-row upper bound, shift for the contact-recovery row)."""
        v = None if self.velocities is None else self.velocities[plane.obstacle_index]
        if v is None or not np.any(v):
            if self.damper and not self.adaptive:
                # Fixed-influence ablation: NEO-style tau on static rows too.
                return float(plane.clearance) / self.tau(0.0), 0.0
            return bound, 0.0
        shift = float(np.asarray(plane.normal_to_obstacle) @ v)
        approach = max(0.0, -shift)
        self.moving_rows += 1
        if approach > 1e-9:
            self.min_ttc = min(self.min_ttc, max(float(plane.clearance), 0.0) / approach)
            self.approaching_ids.add(int(plane.proxy_id))
        standoff = approach * self.buffer_s if self.buffer else 0.0
        return shift + (float(plane.clearance) - standoff) / self.tau(approach), shift

    def escape_ids(self):
        """Certificates approaching the arm in the last solve (escape only moves away from these)."""
        return set(self.approaching_ids)
