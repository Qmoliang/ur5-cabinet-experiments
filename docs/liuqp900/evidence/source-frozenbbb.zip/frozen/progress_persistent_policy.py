"""Persistent low-dimensional bypass with a non-resetting achieved-readiness ledger."""
import numpy as np
from progress_execution_policy import LowDimPolicy as Previous
from continuation_certified_policy import LowDimPolicy as Certified

class LowDimPolicy(Previous):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.readiness_frontier=-float('inf');self.frontier_cycle=0;self.frontier_records=[];self.persistent_reference=None;self.persistent_checkpoints=[];self.bypass_travel=0.;self.last_bypass_point=None;self.persistent_continuations=0
 def continuation_witnesses(self,q):
  previous_gain=self.last_ready_gain;state=super().continuation_witnesses(q);m=-state['deficit']
  if self.mode in ('CERT_PREP','RESERVE_GOAL'):
   if m>self.readiness_frontier+.0002:
    self.readiness_frontier=m;self.frontier_cycle=self.k;self.frontier_records.append(dict(cycle=self.k,margin=m,source='full_map_preparation'));self.last_ready_gain=self.k
   else:self.last_ready_gain=previous_gain
   self.best_ready_margin=self.readiness_frontier
  return state
 def choose_bypass(self,c,s,arrays):
  chosen=super().choose_bypass(c,s,arrays)
  if chosen is not None:
   self.persistent_reference=dict(cycle=self.k,feature=np.r_[self.ee,self.P@(self.q-self.qg)].copy(),margin=self.bypass['margin'],frontier=self.readiness_frontier,label=self.bypass['label']);self.bypass_travel=0.;self.last_bypass_point=self.ee.copy()
  return chosen
 def finish_bypass(self,reason):
  self.witness_anchor=None;state=Certified.continuation_witnesses(self,self.q);self.future_state=state;m=-state['deficit'];p=self.persistent_reference;frontier=self.readiness_frontier
  certified=False
  if not state['rows']:certified=self.continuation_certificate()
  advance=certified or m>=frontier+.0002;debt=max(0.,frontier-m);feature=np.r_[self.ee,self.P@(self.q-self.qg)]
  closed_loop=self.bypass_travel>=2*self.ctx.controller.near_distance and np.linalg.norm(feature-p['feature'])<=.001
  continue_same=(not advance and reason=='local_displacement_completed' and debt<=self.ctx.controller.near_distance and not closed_loop)
  rec=dict(cycle=self.k,start_cycle=p['cycle'],margin=m,frontier_before=frontier,new_global_progress=advance,readiness_debt_m=debt,continue_same_bypass=continue_same,closed_local_loop=closed_loop,reason=reason,travel_m=self.bypass_travel)
  self.persistent_checkpoints.append(rec);self.emit('persistent_bypass_progress_assessed',**{k:v for k,v in rec.items() if k!='cycle'})
  if continue_same:
   # Transport the committed orientation through the updated task tangent plane.
   row=min(state['rows'],key=lambda r:r['slack']) if state['rows'] else None
   if row is not None:
    n=np.linalg.pinv(self.current_s['J'],rcond=1e-8).T@row['b']
    if np.linalg.norm(n)>1e-8:
     n/=np.linalg.norm(n);t=self.bypass_tangent-n*(n@self.bypass_tangent)
     if np.linalg.norm(t)>1e-8:self.bypass_tangent=t/np.linalg.norm(t)
   self.bypass['ee']=self.ee.copy();self.bypass_best_move=0.;self.bypass_last_move=self.k;self.solve_cache={};self.persistent_continuations+=1;return
  if advance:
   self.readiness_frontier=max(frontier,m);self.frontier_cycle=self.k;self.frontier_records.append(dict(cycle=self.k,margin=m,source='persistent_bypass',terminal_certified=certified))
  record=dict(start_cycle=p['cycle'],end_cycle=self.k,label=p['label'],reason='new_global_readiness' if advance else 'loop_or_local_motion_failure' if closed_loop or reason!='local_displacement_completed' else 'readiness_debt_budget',margin_gain_m=m-p['margin'],global_frontier_gain_m=m-frontier,accepted=advance,travel_m=self.bypass_travel)
  self.bypass_records.append(record);self.emit('local_bypass_contract_assessed',**record)
  self.mode='CERT_PREP';self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8;self.best_ready_margin=self.readiness_frontier;self.last_ready_gain=self.k if advance else self.k-100;self.macro_anchor=None;self.agreement_anchor=None;self.witness_anchor=None;self.solve_cache={};self.bypass=None;self.persistent_reference=None;self.last_bypass_point=None
 def __call__(self,c,s,arrays):
  if self.mode=='ENTRY_BYPASS' and self.last_bypass_point is not None:
   self.bypass_travel+=float(np.linalg.norm(self.ee-self.last_bypass_point));self.last_bypass_point=self.ee.copy()
  return super().__call__(c,s,arrays)
 def summary(self):
  out=super().summary();out.update(readiness_frontier_m=self.readiness_frontier,readiness_frontier_records=self.frontier_records,persistent_bypass_checkpoints=self.persistent_checkpoints,persistent_bypass_continuations=self.persistent_continuations,global_progress_rule='local recovery below earlier best is not new readiness; keep transported bypass orientation until new full-map readiness or terminal certificate, actual motion failure, observed loop, or original-near-distance debt budget',global_progress_guarantee='readiness ledger never resets downward; this does not prove arbitrary global reachability or forbid all cycles')
  return out
