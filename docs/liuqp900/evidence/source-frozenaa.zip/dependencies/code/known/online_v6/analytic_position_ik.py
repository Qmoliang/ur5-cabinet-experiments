"""Position-only IK for this audited UR5 chain, verified against MuJoCo."""
import numpy as np,mujoco
def candidates(model,target,parameters,reference):
    data=mujoco.MjData(model);data.qpos[:6]=0;mujoco.mj_kinematics(model,data);S=data.xpos[model.body('shoulder_link').id].copy();B=data.xmat[model.body('shoulder_link').id].reshape(3,3).copy();t=B.T@(np.asarray(target)-S)
    assert np.allclose(model.body_pos[model.body('forearm_link').id],[0,-.131,.425])
    assert np.allclose(model.body_pos[model.body('wrist_1_link').id],[0,0,.392])
    assert np.allclose(model.body_pos[model.body('wrist_2_link').id],[0,.127,0])
    assert np.allclose(model.body_pos[model.body('wrist_3_link').id],[0,0,.1])
    assert np.allclose(model.site_pos[model.site('attachment_site').id],[0,.07,0])
    u,v=np.asarray(parameters).T;theta=np.pi/2+v;tx=np.cos(u)*t[0]+np.sin(u)*t[1];ty=-np.sin(u)*t[0]+np.cos(u)*t[1];tz=np.full_like(u,t[2]);dy=ty-.134;cost=dy/.07
    dx=tx-.425*np.sin(theta);dz=tz-.425*np.cos(theta);d=np.hypot(dx,dz);h2=.1**2+.07**2-dy**2
    cb=(d*d+.392**2-h2)/(2*.392*np.maximum(d,1e-30));mask=(np.abs(cost)<=1)&(np.abs(cb)<=1)&(d>1e-12)
    u,v,theta,tx,ty,tz,dx,dz,cost,cb=[x[mask] for x in [u,v,theta,tx,ty,tz,dx,dz,cost,cb]]
    result=[]
    for elbow in [-1,1]:
      alpha=np.arctan2(dx,dz)+elbow*np.arccos(cb);q3=alpha-theta;wx=.425*np.sin(theta)+.392*np.sin(alpha);wz=.425*np.cos(theta)+.392*np.cos(alpha)
      gx=tx-wx;gz=tz-wz;gamma=alpha+np.pi/2;vx=np.cos(gamma)*gx-np.sin(gamma)*gz;vz=np.sin(gamma)*gx+np.cos(gamma)*gz
      for wrist in [-1,1]:
       q5=wrist*np.arccos(cost);q4=np.arctan2(vx,vz)-np.arctan2(-.07*np.sin(q5),.1);q=np.c_[u,v,q3,q4,q5,np.full(len(u),reference[5])];q[:,:5]=(q[:,:5]+np.pi)%(2*np.pi)-np.pi
       for j in range(6):
        options=np.stack([q[:,j]-2*np.pi,q[:,j],q[:,j]+2*np.pi],axis=1);valid=(options>=model.jnt_range[j,0]+.015)&(options<=model.jnt_range[j,1]-.015);rank=np.where(valid,np.abs(options-reference[j]),np.inf);ix=np.argmin(rank,axis=1);q[:,j]=options[np.arange(len(q)),ix]
       result.append(q)
    return np.vstack(result) if result else np.empty((0,6))

def goal_configurations(checker,target,rng,*,keep=6,budget=6.):
    import time
    from scipy.stats import qmc
    from escape_point import WORKSPACE_A,WORKSPACE_B,SELF_MARGIN
    started=time.perf_counter();reference=np.asarray(getattr(checker,'goal_reference_q',np.zeros(6)))
    seed=int(rng.integers(1,2**30));params=(qmc.Sobol(2,scramble=True,seed=seed).random_base2(17)*2-1)*np.pi
    qs=candidates(checker.model,target,params,reference);found=[]
    model=checker.model;ids=[g for g in range(model.ngeom) if model.geom_bodyid[g]==0 and int(model.geom_type[g])==int(mujoco.mjtGeom.mjGEOM_BOX) and model.geom_contype[g]]
    centers=np.asarray([model.geom_pos[g] for g in ids]);half=np.asarray([model.geom_size[g] for g in ids]);a,b=checker.selected_self_pairs.T
    for q in qs:
        if time.perf_counter()-started>budget:break
        P=checker.sphere_positions(q)
        if np.min(WORKSPACE_B[None]-P@WORKSPACE_A.T-checker.radii[:,None])<0:continue
        if np.min(np.linalg.norm(P[b]-P[a],axis=1)-checker.radii[a]-checker.radii[b])<SELF_MARGIN:continue
        if len(ids) and np.min(np.linalg.norm(np.maximum(np.abs(P[:,None]-centers)-half,0),axis=2)-checker.radii[:,None])<checker.margin:continue
        if not checker.free(q):continue
        if np.linalg.norm(checker.gripper_position(q)-target)>.0002:raise RuntimeError('analytic IK validation failed')
        if any(np.max(np.abs(q-x))<.1 for x in found):continue
        found.append(q.copy())
        if len(found)>=keep:break
    return found
