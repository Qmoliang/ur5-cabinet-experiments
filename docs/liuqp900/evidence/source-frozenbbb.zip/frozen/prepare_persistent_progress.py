from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;s=(R/'pilot_worker_execution_progress.py').read_text().replace("        if job.get('policy_version')=='progress_execution':","        if job.get('policy_version')=='progress_persistent':\n            from progress_persistent_policy import LowDimPolicy\n        elif job.get('policy_version')=='progress_execution':");(R/'pilot_worker_persistent_progress.py').write_text(s)
s=(R/'launch_execution_progress.py').read_text().replace("ROOT/'pilot_worker_execution_progress.py'","ROOT/'pilot_worker_persistent_progress.py'");(R/'launch_persistent_progress.py').write_text(s)
j=json.loads((R/'execution_progress_jobs.json').read_text())
for x in j:x['name']=x['name'].replace('_v5','_v6');x['policy_version']='progress_persistent'
(R/'persistent_progress_jobs.json').write_text(json.dumps(j,indent=2));a=R/'revisions/progress_persistent';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
(R/'PERSISTENT_PROGRESS_FREEZE.json').write_text(json.dumps(dict(jobs=j,source_hashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in R.glob('*.py')},scope='non-resetting readiness frontier and persistent transported low-dimensional bypass; all earlier frozen versions retained'),indent=2))
