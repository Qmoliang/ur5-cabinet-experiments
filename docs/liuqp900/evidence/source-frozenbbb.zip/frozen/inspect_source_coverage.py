from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;idx={}
for p in list(R.glob('*.py'))+list((R/'revisions').rglob('*.py'))+[R/'code/online/protocol_liuqp_controller.py']:idx.setdefault(hashlib.sha256(p.read_bytes()).hexdigest(),[]).append(str(p))
missing={}
for f in (R/'trials').iterdir():
 d=json.loads((f/'source_hashes.json').read_text());m={k:v for k,v in d.items() if v not in idx}
 if m:missing[f.name]=m
print(json.dumps(missing,indent=2))
