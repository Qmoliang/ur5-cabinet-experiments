"""Control-cycle timing of short E4 runs: controller ms percentiles, wall cycle, statuses, row counts."""
import csv
import sys
from collections import Counter
from pathlib import Path

import numpy as np

for run in sys.argv[1:]:
    inner = next(Path(run).glob("A-CV-*"))
    rows = list(csv.DictReader(open(inner / "cycles.csv")))
    ctl = np.array([float(r["total_controller_ms"]) for r in rows])
    comp = np.array([float(r["control_compute_ms"]) for r in rows])
    status = Counter(r["status"][:18] for r in rows)
    dyn = np.array([int(r["e4_dynamic_rows"]) for r in rows])
    act = np.array([int(r["active_obstacle_rows"]) for r in rows])
    print(f"{Path(run).name:16s} cycles {len(rows)}  controller ms p50 {np.median(ctl):6.1f} p99 {np.percentile(ctl, 99):6.1f} max {ctl.max():7.1f}  "
          f"cycle compute p50 {np.median(comp):6.1f} p99 {np.percentile(comp, 99):6.1f}  dynamic rows max {dyn.max()}  "
          f"obstacle rows p50 {np.median(act):.0f} max {act.max()}  {dict(status.most_common(3))}")
