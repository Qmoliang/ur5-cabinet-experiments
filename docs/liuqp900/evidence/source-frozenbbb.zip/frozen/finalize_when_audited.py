from pathlib import Path
import time,subprocess,sys
ROOT=Path(__file__).resolve().parent
while True:
    pending=[p.parent.name for p in (ROOT/'trials').glob('*/result.json') if not (p.parent/'audit.json').exists()]
    if not pending:break
    print('Audits pending: '+', '.join(pending),flush=True);time.sleep(15)
subprocess.run([sys.executable,str(ROOT/'export_study.py')],check=True)
