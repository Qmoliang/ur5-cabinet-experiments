"""Add OpenMP to the independent loops of bucket_fit_native.cpp (decisions stay sequential)."""
from pathlib import Path
import sys
p = Path(sys.argv[1]); s = p.read_text()

def sub(old, new):
    global s
    assert s.count(old) == 1, old[:70]
    s = s.replace(old, new)

# grouped union: groups are independent
sub('''  std::vector<M3> result(count);
  for (size_t g = 0; g < count; ++g) {
    const auto& members = groups[g];''', '''  std::vector<M3> result(count);
#pragma omp parallel for schedule(dynamic, 8)
  for (int64_t gi = 0; gi < (int64_t)count; ++gi) {
    const size_t g = (size_t)gi;
    const auto& members = groups[g];''')
# normals: points are independent (one candidate buffer per thread)
sub('''  std::vector<std::pair<double, int64_t>> cand;
  for (int64_t i = 0; i < n; ++i) {
    for (int s = 1;; ++s) {''', '''#pragma omp parallel
  {
  std::vector<std::pair<double, int64_t>> cand;
#pragma omp for schedule(dynamic, 64)
  for (int64_t i = 0; i < n; ++i) {
    for (int s = 1;; ++s) {''')
sub('''    for (int a = 0; a < 3; ++a) nrm[a] /= len;
    normals[i] = nrm;
  }
  return normals;''', '''    for (int a = 0; a < 3; ++a) nrm[a] /= len;
    normals[i] = nrm;
  }
  }
  return normals;''')
# recursion: fit every node of a level in parallel, then decide in order
sub('''    std::vector<Node> next;
    for (size_t ni = 0; ni < pending.size(); ++ni) {
      Node& node = pending[ni];
      Fit fit = fit_group(c, node.idx);''', '''    std::vector<Node> next;
    std::vector<Fit> fits(pending.size());
#pragma omp parallel for schedule(dynamic, 4)
    for (int64_t ni = 0; ni < (int64_t)pending.size(); ++ni) fits[ni] = fit_group(c, pending[ni].idx);
    for (size_t ni = 0; ni < pending.size(); ++ni) {
      Node& node = pending[ni];
      const Fit& fit = fits[ni];''')
# per-proxy outputs: independent; record failure instead of returning inside the loop
sub('''  for (int64_t pi = 0; pi < count; ++pi) {
    const Fit& f = accepted[pi].fit;
    maximum_overshoot = std::max(maximum_overshoot, f.overshoot);''', '''  int limit_failures = 0;
#pragma omp parallel for schedule(dynamic, 16) reduction(+:limit_failures)
  for (int64_t pi = 0; pi < count; ++pi) {
    const Fit& f = accepted[pi].fit;''')
sub('''    if (failed) return -2;
    if (limit_mode == 0 || limit_mode == 1) effective = radius_limit - offset;''', '''    if (failed) { limit_failures += 1; continue; }
    if (limit_mode == 0 || limit_mode == 1) effective = radius_limit - offset;''')
sub('''  double surface = 0.0;
  for (int64_t i = 0; i < n; ++i) surface = std::max(surface, eigvalsh3(sym(uncertainty + 9 * i))[2]);''', '''  if (limit_failures) return -2;
  for (int64_t pi = 0; pi < count; ++pi) maximum_overshoot = std::max(maximum_overshoot, accepted[pi].fit.overshoot);
  double surface = 0.0;
#pragma omp parallel for reduction(max:surface)
  for (int64_t i = 0; i < n; ++i) surface = std::max(surface, eigvalsh3(sym(uncertainty + 9 * i))[2]);''')
p.write_text(s); print('patched')
