"""Bucket-parallel CenterVox certificate fitting.

fit_matched_voxel_proxies never lets a proxy span two fixed cluster buckets, so
fitting disjoint sets of whole buckets separately gives the same proxies as one
batch call.  fit_by_bucket splits the changed buckets into balanced chunks, fits
them in a persistent fork pool, and reassembles one PointCloudProxySet in the
original input order (per-point fields) and chunk order (per-proxy fields).
UR5_FIT_WORKERS (default 1 = serial) sets the pool size.
"""
from __future__ import annotations

import multiprocessing
import os
from dataclasses import fields, replace

import numpy as np

from pointcloud_proxy import PointCloudProxySet, fit_matched_voxel_proxies

PER_POINT = {"raw_points", "filtered_points", "filtered_uncertainty_shapes", "filtered_point_offsets"}
PER_PROXY = {"centers", "sphere_radii", "ellipsoid_shapes", "rotations", "cluster_keys", "proxy_offset_radii",
             "proxy_uncertainty_shapes", "base_sphere_radii", "base_ellipsoid_shapes", "ellipsoid_outer_shapes",
             "proxy_ids"}
MAXIMA = {"maximum_ellipsoid_overshoot", "validation_sampled_max_distance", "validation_lipschitz_correction",
          "surface_cover_radius", "validation_spacing"}
_POOL = None
LAST_TIMING: dict = {}


def _fit(args):
    import time as _time
    points, offsets, uncertainty, kwargs = args
    started = _time.perf_counter()
    result = fit_matched_voxel_proxies(points, filtered_point_offsets=offsets,
                                       filtered_point_uncertainty_shapes=uncertainty, **kwargs)
    return result, 1000.0 * (_time.perf_counter() - started)


def _pool(workers):
    global _POOL
    if _POOL is None:
        _POOL = multiprocessing.get_context("fork").Pool(workers)
    return _POOL


def fit_by_bucket(labels, points, *, filtered_point_offsets=None, filtered_point_uncertainty_shapes=None, **kwargs):
    dump = os.environ.get("UR5_DUMP_FIT")
    if dump:  # debugging: keep the latest refit batch for offline profiling
        import pickle
        with open(dump, "wb") as handle:
            pickle.dump(dict(labels=np.asarray(labels), points=np.asarray(points),
                             offsets=filtered_point_offsets, uncertainty=filtered_point_uncertainty_shapes,
                             kwargs=kwargs), handle)
    import bucket_fit
    native_kwargs = dict(kwargs, filtered_point_offsets=filtered_point_offsets,
                         filtered_point_uncertainty_shapes=filtered_point_uncertainty_shapes)
    if bucket_fit._native_applicable(native_kwargs):
        # Whole batch in C++ (OpenMP inside), same result as the serial Python fit.
        return bucket_fit.fit(points, **native_kwargs)
    workers = int(os.environ.get("UR5_FIT_WORKERS", "1"))
    labels = np.asarray(labels)
    if workers <= 1 or len(points) < 2000:
        return fit_matched_voxel_proxies(points, filtered_point_offsets=filtered_point_offsets,
                                         filtered_point_uncertainty_shapes=filtered_point_uncertainty_shapes, **kwargs)
    # whole buckets per chunk, balanced by point count (largest first)
    _, bucket_of, counts = np.unique(labels, axis=0, return_inverse=True, return_counts=True)
    bucket_of = bucket_of.reshape(-1)
    loads = np.zeros(workers)
    chunk_of_bucket = np.empty(len(counts), dtype=np.int64)
    for bucket in np.argsort(-counts, kind="stable"):
        chunk = int(np.argmin(loads))
        chunk_of_bucket[bucket] = chunk
        loads[chunk] += counts[bucket]
    chunk_of_point = chunk_of_bucket[bucket_of]
    selections = [np.flatnonzero(chunk_of_point == c) for c in range(workers)]
    selections = [s for s in selections if len(s)]
    pick = lambda values, s: None if values is None else np.asarray(values)[s]
    jobs = [(np.asarray(points)[s], pick(filtered_point_offsets, s), pick(filtered_point_uncertainty_shapes, s), kwargs)
            for s in selections]
    import time as _time
    started = _time.perf_counter()
    timed = _pool(workers).map(_fit, jobs)
    parts = [part for part, _ in timed]
    LAST_TIMING.update(wall_ms=1000.0 * (_time.perf_counter() - started),
                       chunk_ms=[ms for _, ms in timed], chunk_points=[len(s) for s in selections])
    n = len(points)
    merged = {}
    proxy_offset = 0
    index_parts = []
    for part, s in zip(parts, selections):
        if not np.array_equal(np.asarray(part.filtered_points), np.asarray(points)[s]):
            raise AssertionError("fit reordered its input points")
        index_parts.append((s, np.asarray(part.filtered_cluster_indices) + proxy_offset))
        proxy_offset += len(part.centers)
    first = parts[0]
    for field in fields(PointCloudProxySet):
        name = field.name
        values = [getattr(p, name) for p in parts]
        if name == "filtered_cluster_indices":
            out = np.empty(n, dtype=np.int64)
            for s, idx in index_parts:
                out[s] = idx
            merged[name] = out
        elif name in PER_POINT:
            if values[0] is None:
                merged[name] = None
                continue
            sample = np.asarray(values[0])
            out = np.empty((n,) + sample.shape[1:], dtype=sample.dtype)
            for (s, _), v in zip(index_parts, values):
                out[s] = v
            merged[name] = out
        elif name in PER_PROXY:
            merged[name] = None if values[0] is None else np.concatenate([np.asarray(v) for v in values], axis=0)
        elif name in MAXIMA:
            merged[name] = max(values)
        else:
            merged[name] = getattr(first, name)
    return replace(first, **merged)
