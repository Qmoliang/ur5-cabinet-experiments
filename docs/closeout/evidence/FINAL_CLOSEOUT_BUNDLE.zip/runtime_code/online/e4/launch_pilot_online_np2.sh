#!/bin/bash
# Catch-up, revised: plain NEO-paper only for the no-racket condition.  With rackets the plain mode
# freezes the world during its ~0.23 s solves, so the racket waits for it: not a valid test (the
# compute-delay variant covers rackets).  Also re-runs the timed-out NEO-matched racket case (its
# solves fit the 20 ms cycle, so plain mode is valid for it).  Takes a free 16-CPU slot as runs end.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/pilot_online
export UR5_NO_RETURN_FREE=1 E4_TIMEOUT=14400 E4_MEM=40G
jobs=()
for seed in 1 2 3 4 5; do for scene in drawer cage_wide shelf; do
  out=$P/neo_paper_k0_v0.0/${scene}_s$seed
  [ -f $out/case.json ] || jobs+=("neo_paper $scene $seed 0 0.0")
done; done
[ -f $P/neo_matched_k1_v0.5/drawer_s1/case.json ] || jobs+=("neo_matched drawer 1 1 0.5")
echo "${#jobs[@]} jobs" > pilot_online_np2.jobs
for job in "${jobs[@]}"; do
  set -- $job
  while :; do
    for c in 0 16 32 64 80 96; do
      ps -eo args | grep -v grep | grep -q -- "--cpus $c:16" || { slot=$c; break 2; }
    done
    sleep 30
  done
  out=$P/${1}_k$4_v$5/${2}_s$3
  geo=; [ $2 = drawer ] && geo=1
  UR5_COMPUTE_DELAY=0 E4_GEODESIC=$geo E4_SCENE=$2 ./e4_map.sh $out $3 $slot $1 $4 $5 &
  sleep 60   # let the run claim its CPUs before the next slot check
done
wait
echo DONE > pilot_online_np.done
