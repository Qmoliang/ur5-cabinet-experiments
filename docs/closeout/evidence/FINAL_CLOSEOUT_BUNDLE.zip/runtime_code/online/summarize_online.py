"""Online camera test: improved LiuQP variants on 20 start poses."""
import csv
import glob
import json
import os
from pathlib import Path

import numpy as np

OUT = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/online_improved")
KNOWN_TRAPPED = {2, 3, 5, 6, 8, 9, 10, 13, 14, 15, 18}
results = {}
for case in sorted(p for p in glob.glob(str(OUT / "*_seed*")) if os.path.isdir(p)):
    name = Path(case).name
    variant, seed = name.rsplit("_seed", 1)
    summary_path = Path(case) / "summary.json"
    if not summary_path.exists():
        results.setdefault(variant, {})[int(seed)] = None  # crashed or still running
        continue
    s = json.loads(summary_path.read_text())
    run = next(p for p in Path(case).iterdir() if p.is_dir())
    rows = list(csv.DictReader(open(run / "cycles.csv")))
    controller = np.array([float(r["total_controller_ms"]) for r in rows])
    age = np.array([float(r["snapshot_age_ms"]) for r in rows])
    reuse = s.get("online_reuse_counts") or {}
    total = reuse.get("reused_spheres", 0) + reuse.get("recomputed_spheres", 0)
    results.setdefault(variant, {})[int(seed)] = dict(
        success=s["success"], time=s.get("first_success_time_s"), final_mm=1000 * s["final_error_m"],
        penetrating=s.get("exact_penetrating_cycles"), depth_mm=-1000 * float(s.get("maximum_penetration_m") or 0.0),
        controller_p50=float(np.median(controller)),
        controller_p99=float(np.percentile(controller, 99)), map_age_p50=float(np.median(age)),
        late=s.get("observability_late_samples"), never=s.get("observability_never_observed_samples"),
        reuse_share=(reuse.get("reused_spheres", 0) / total) if total else None,
        build_ms=s.get("geodesic_build_ms_median"))

for variant in ("base", "reuse", "geodesic", "both", "frontier", "frontier_geodesic", "full"):
    runs = results.get(variant, {})
    done = {k: v for k, v in runs.items() if v is not None}
    med = lambda xs: float(np.median(xs)) if xs else None
    print(json.dumps({
        "variant": variant, "finished": len(done), "crashed_or_missing": sorted(k for k, v in runs.items() if v is None),
        "reached": sum(r["success"] for r in done.values()),
        "reached_known_trapped_seeds": sum(done[s]["success"] for s in KNOWN_TRAPPED if s in done),
        "penetrating_cycles": sum((r["penetrating"] or 0) for r in done.values()),
        "runs_with_penetration": sum(bool(r["penetrating"]) for r in done.values()),
        "deepest_penetration_mm": max([r["depth_mm"] for r in done.values()], default=0.0),
        "reach_time_s": med([r["time"] for r in done.values() if r["success"]]),
        "controller_ms_p50": med([r["controller_p50"] for r in done.values()]),
        "controller_ms_p99": med([r["controller_p99"] for r in done.values()]),
        "map_age_s": med([r["map_age_p50"] / 1000 for r in done.values()]),
        "observability_late_never": [sum((r["late"] or 0) for r in done.values()), sum((r["never"] or 0) for r in done.values())],
        "reuse_share": med([r["reuse_share"] for r in done.values() if r["reuse_share"] is not None]),
        "geodesic_build_ms": med([r["build_ms"] for r in done.values() if r["build_ms"]]),
        "failed": {s: round(r["final_mm"], 1) for s, r in sorted(done.items()) if not r["success"]},
    }))
