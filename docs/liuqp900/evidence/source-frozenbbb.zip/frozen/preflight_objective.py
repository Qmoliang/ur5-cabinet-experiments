from pathlib import Path
import os,json
os.sched_setaffinity(0,{48,49,50,51})
import numpy as np
from scipy.optimize import linprog
from pilot_adapter import ROOT,build,online
from reserve_objective import solve_reserve
from verified_qp import solve_verified

OLD=ROOT.parent/'liuqp_lowdim_pilot_20261106';tr=np.load(OLD/'trials/confirm_original_shelf_t2_baseline_300s/trajectory.npz')
ctx=build('iris_4shelves_t2');c=ctx.controller;c.osqp_adaptive_row_threshold=10**9;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.osqp_max_iterations=3000;c.pilot_verified_fallback=True
low=ctx.model.jnt_range[:6,0]+.015;high=ctx.model.jnt_range[:6,1]-.015;out=[]
for label,q in [('initial',ctx.q0.copy()),('before_limit',tr['q'][150]),('stalled',tr['q'][-1])]:
    online.set_configuration(ctx.model,ctx.data,q);c.applied_velocity=np.zeros(6);c.previous_velocity=np.zeros(6)
    original,metrics=c.solve(ctx.target);H,g,A,l,u=c.last_qp_arrays;s=c.pilot_nominal;p=online.attachment_position(ctx.model,ctx.data);error=np.linalg.norm(p-ctx.target);d=(ctx.target-p)/error;J=s['J']
    record=dict(label=label,q=q.tolist(),error_mm=float(error)*1000,original_velocity=original.tolist(),original_goal_rate_mm_s=float(d@J@original)*1000,variants=[])
    metric=solve_reserve(H,g,A,l,u,q,np.zeros(6),low,high,c.task_weight,error,.02,10.)
    if metric is not None:
        forward=solve_verified(H,g+metric['delta'],A,l,u);diff=float(np.max(np.abs(forward.x-metric['velocity'])))
        record['variants'].append(dict(kind='reserve_metric',velocity=metric['velocity'].tolist(),goal_rate_mm_s=float(d@J@metric['velocity'])*1000,consumption_cost=metric['consumption_cost'],forward_difference=diff));assert diff<1e-5
    distance=np.minimum(q-low,high-q);j=int(np.argmin(distance/(high-low)));sign=1. if q[j]-low[j]<high[j]-q[j] else -1.;b=np.eye(6)[j]*sign
    up=np.isfinite(u);lo=np.isfinite(l);lp=linprog(-b,A_ub=np.vstack([A[up],-A[lo]]),b_ub=np.r_[u[up],-l[lo]],bounds=[(None,None)]*6,method='highs')
    record['critical_joint']=j;record['release_sign']=sign;record['release_support']=None if not lp.success else float(-lp.fun)
    if lp.success and -lp.fun>1e-6:
        release=solve_reserve(H,g,A,l,u,q,np.zeros(6),low,high,c.task_weight,error,.02,10.,release=(b,.5*-lp.fun))
        if release is not None:
            v=release['velocity'];lo_joint,hi_joint=c.joint_velocity_bounds();bounded=np.clip(v,lo_joint,hi_joint);safe=[]
            for scale in [1,.75,.5,.25,.125,.0625]:
                if ctx.guard.braking_safe(ctx.proxy_guard,q,scale*bounded):safe.append(scale)
            forward=solve_verified(H,g+release['delta'],A,l,u);diff=float(np.max(np.abs(forward.x-v)));assert diff<1e-5
            record['variants'].append(dict(kind='targeted_release',velocity=v.tolist(),goal_rate_mm_s=float(d@J@v)*1000,release_rate=float(b@v),release_dual=release['release_dual'],forward_difference=diff,safe_scales=safe))
    out.append(record);print(json.dumps(record,indent=2),flush=True)
(ROOT/'OBJECTIVE_PREFLIGHT.json').write_text(json.dumps(out,indent=2))
