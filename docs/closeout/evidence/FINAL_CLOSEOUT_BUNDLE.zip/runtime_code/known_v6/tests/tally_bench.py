"""Static benchmark tally (5 mm): totals per method and a per-scene matrix."""
import collections
import glob
import json
from pathlib import Path

total = collections.defaultdict(lambda: [0, 0])
per = collections.defaultdict(lambda: [0, 0])
for f in glob.glob("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/bench/*/*_seed*/summary.json"):
    p = Path(f)
    ctl = p.parent.parent.name
    stem = p.parent.name.rsplit("_seed", 1)[0]
    rep = "ellipsoid" if "_ellipsoid_" in stem else "sphere"
    obj = "geodesic" if stem.endswith("geodesic_native") else "straight"
    scene = stem.split(f"_{rep}_")[0]
    ok = bool(json.load(open(f)).get("success"))
    for key, store in (((ctl, rep, obj), total), ((scene, ctl, rep, obj), per)):
        store[key][0] += ok
        store[key][1] += 1
print("TOTAL reached over all tasks (5 mm):")
for key, (r, n) in sorted(total.items()):
    print(f"  {key[0]:12s} {key[1]:10s} {key[2]:9s} {r:4d}/{n}")
print("\nper scene: geodesic(straight)   LiuQP-E | LiuQP-S | NEOm-E | NEOm-S | NEOp-E | NEOp-S")
for scene in sorted({k[0] for k in per}):
    cells = []
    for ctl in ("liuqp", "neo_matched", "neo_paper"):
        for rep in ("ellipsoid", "sphere"):
            g, s = per.get((scene, ctl, rep, "geodesic")), per.get((scene, ctl, rep, "straight"))
            cells.append("   -   " if g is None else f"{g[0]:2d}({s[0]:2d})")
    print(f"  {scene:20s} " + " | ".join(cells))
