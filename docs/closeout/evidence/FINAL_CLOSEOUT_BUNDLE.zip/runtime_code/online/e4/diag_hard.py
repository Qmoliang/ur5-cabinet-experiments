"""Why drawer / wall2 fail: (1) where LiuQP-E stops (which robot sphere is limiting, against which real
box, real gap vs certificate clearance); (2) why the escape found 0 goal postures: goal search with the
obstacle-only checker vs the arm-limit checker, by method, and what limits the best goal posture."""
import copy
import glob
import json
import sys

names = sys.argv[1:]
sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/feasibility.py").read().split("variants = []")[0])
sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
from escape_point import (WORKSPACE_A, WORKSPACE_B, goal_configurations, plain_goal_configurations,  # noqa: E402
                          refined_goal_configurations, with_arm_limits)

V = "/mnt/ssd2/hsjed/ur5_cabinet/v6runs"


def box_gaps(boxes, p, r):
    """Real gap of each robot sphere to each box: (n_spheres, n_boxes)."""
    c = np.array([b.center for b in boxes])
    h = np.array([b.half_size for b in boxes])
    d = np.abs(p[:, None, :] - c[None]) - h[None]
    outside = np.linalg.norm(np.maximum(d, 0), axis=2)
    inside = np.minimum(np.max(d, axis=2), 0)
    return outside + inside - r[:, None]


def describe(tag, q, checker, arm, scene, model, target):
    p = checker.sphere_positions(q)
    r = checker.radii
    g = box_gaps(scene.boxes, p, r)
    i, j = np.unravel_index(np.argmin(g), g.shape)
    body = model.body(int(checker.body_ids[i])).name
    work = float(np.min(WORKSPACE_B[None] - p @ WORKSPACE_A.T - r[:, None]))
    err = np.linalg.norm(checker.gripper_position(q) - target)
    # tightest real gaps per body (distinct bodies)
    per = {}
    for k in np.argsort(g.min(axis=1)):
        b = model.body(int(checker.body_ids[k])).name
        if b not in per:
            per[b] = (1000 * g[k].min(), scene.boxes[int(np.argmin(g[k]))].name)
        if len(per) >= 3:
            break
    print(f"  {tag:28s} err {1000*err:6.1f} mm | cert clr {1000*checker.clearance(q):+6.1f} mm (beyond 6 mm margin)"
          f" | arm-limit clr {1000*arm.clearance(q):+6.1f} | workspace {1000*work:+6.1f} | real gaps: "
          + ", ".join(f"{b} {v:+.0f}mm to {n}" for b, (v, n) in per.items()))


for name in names:
    path = f"{K}/assets/scene.json" if name == "drawer" else f"{K}/assets/scenes/{name}.json"
    payload = json.load(open(path))
    scene = scene_of(payload)
    model = build_model(scene)
    robot = build_robot_certificate(model)
    target = np.asarray(scene.waypoints[-1])
    print(f"\n=== {name}: target {np.round(target, 3).tolist()}, boxes "
          + "; ".join(f"{b.name} c{np.round(b.center, 3).tolist()} h{np.round(b.half_size, 3).tolist()}" for b in scene.boxes))
    for rep in ("ellipsoid", "sphere"):
        cover = build_volume_cover(scene.boxes, rep, 0.075)
        radii = np.array([s.radius for s in robot])
        index = NativeBallTree(cover.centers, cover.aabb_half_extents, query_padding=float(radii.max() + 0.06))
        checker = ConfigurationChecker(model, robot, cover.centers, rep, radii=cover.sphere_radii,
                                       shapes=cover.ellipsoid_shapes, margin=MARGIN, index=index)
        arm = with_arm_limits(copy.copy(checker), np.asarray(scene.q0))
        print(f" [{rep}] cover cells {len(cover.centers)}")
        if rep == "ellipsoid":
            print(" where LiuQP-E stops / ends (bench_safe or depth_sweep baseline):")
            base = f"{V}/depth_sweep/liuqp" if name.startswith("wall2_top") else f"{V}/bench_safe/liuqp"
            for d in sorted(glob.glob(f"{base}/{name}_ellipsoid_straight_seed0[1-6]")):
                s = json.load(open(f"{d}/summary.json"))
                qh = np.load(f"{d}/q_history.npy")
                describe(f"seed{d[-2:]} {'REACHED' if s['success'] else 'stuck'}", qh[-1][:6], checker, arm, scene, model, target)
        print(" goal postures (gripper exactly on target):")
        for label, chk in (("obstacles only", checker), ("+ floor/workspace/self", arm)):
            for method in ("push400x200", "plain300", "refined"):
                rng = np.random.default_rng(3)
                if method == "push400x200":
                    goals = goal_configurations(chk, target, rng, attempts=200, keep=6, max_nfev=400)
                elif method == "plain300":
                    goals = plain_goal_configurations(chk, target, rng, keep=6)
                else:
                    goals = [g for g in refined_goal_configurations(chk, target, rng, keep=6) if chk.free(g)]
                print(f"  {label:24s} {method:12s} {len(goals)} legal")
                if goals and method == "push400x200":
                    describe("best goal", max(goals, key=chk.clearance), checker, arm, scene, model, target)
        # best achievable certificate clearance at the target regardless of legality (push-out, margin 0)
        checker.margin = 0.0
        best = None
        rng = np.random.default_rng(5)
        for q in goal_configurations(checker, target, rng, attempts=120, keep=40, max_nfev=400) or []:
            if best is None or arm.clearance(q) > arm.clearance(best):
                best = q
        checker.margin = MARGIN
        arm.margin = MARGIN
        if best is not None:
            describe("best at margin 0", best, checker, arm, scene, model, target)
        else:
            print("  no posture clear of the certificates even at margin 0")
        index.close()
