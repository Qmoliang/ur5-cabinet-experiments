from pathlib import Path
R=Path(__file__).resolve().parent
s=(R/'pilot_worker_continuation.py').read_text()
def change(a,b):
 global s
 assert a in s,a;s=s.replace(a,b)
change("current_mode='TRACK',pending_mode='TRACK')","current_mode='TRACK',pending_mode='TRACK',current_id=-1,pending_id=-1)")
change("latency_tail_uses=0", """latency_tail_uses=0
latency_cycle=np.load(job['latency_cycle_file']) if job.get('latency_cycle_file') else None
trace_cycles=[];trace_ticks=[];trace_q=[];trace_proposed=[];trace_modes=[];trace_offsets=[0];trace_b=[];trace_h=[];trace_fraction=[];trace_kind=[];trace_ids=[];trace_refresh=[];applied_ids=[]
""")
change("delay['current'],delay['pending']=delay['pending'],None", "delay['current'],delay['pending']=delay['pending'],None\n                delay['current_id'],delay['pending_id']=delay['pending_id'],-1")
change("                latency_tail_uses+=int(fresh_calls-1>=len(latency_ticks))", "                if job.get('strict_latency_trace') and fresh_calls-1>=len(latency_ticks):raise RuntimeError('Exact per-call latency tape exhausted; no implicit tail extension')\n                latency_tail_uses+=int(fresh_calls-1>=len(latency_ticks))")
change("            if str(metrics.status).lower().startswith('solved') and policy is not None and policy.expected is not None:", """            if latency_cycle is not None:
                assert k<len(latency_cycle);ticks=int(latency_cycle[k])
            if job.get('trace_decisions'):
                trace_cycles.append(k);trace_ticks.append(ticks);trace_q.append(q.copy());trace_modes.append('TRACK' if policy is None else policy.mode)
                trace_proposed.append(command.copy() if policy is None or policy.expected is None else policy.expected.copy())
                fs=None if policy is None else getattr(policy,'future_state',None)
                wr=[] if fs is None or policy.expected is None or policy.mode!='CERT_PREP' else fs['rows']
                for r in wr:
                    trace_b.append(r['b'].copy());trace_h.append(r['slack']);trace_fraction.append(r['fraction']);trace_kind.append({'environment':0,'workspace':1,'self':2}[r['kind']]);trace_ids.append(r['id'])
                trace_offsets.append(len(trace_h));trace_refresh.append(-1 if policy is None else getattr(policy,'refreshes',-1))
            if str(metrics.status).lower().startswith('solved') and policy is not None and policy.expected is not None:""")
change("                delay['current']=command;", "                delay['current_id']=fresh_calls-1;delay['current']=command;")
change("                delay['pending']=command;", "                delay['pending_id']=fresh_calls-1;delay['pending']=command;")
change("        actual=ctx.guard.filter", "        applied_id=delay['current_id'] if applied_mode not in ('BRAKE','FEASIBILITY_BRAKE') else -1\n        actual=ctx.guard.filter")
change("        rows.append(q.copy());", "        applied_ids.append(applied_id)\n        rows.append(q.copy());")
change("    np.savez_compressed(folder/'trajectory.npz'", "    if job.get('trace_decisions'):np.savez_compressed(folder/'decision_trace.npz',cycles=np.asarray(trace_cycles),ticks=np.asarray(trace_ticks),q=np.asarray(trace_q),proposed=np.asarray(trace_proposed),modes=np.asarray(trace_modes),offsets=np.asarray(trace_offsets),b=np.asarray(trace_b).reshape(-1,6),h=np.asarray(trace_h),fraction=np.asarray(trace_fraction),kind=np.asarray(trace_kind),ids=np.asarray(trace_ids).reshape(-1,2),refresh=np.asarray(trace_refresh),applied_ids=np.asarray(applied_ids))\n    np.savez_compressed(folder/'trajectory.npz'")
change("result['latency_model']='measured_control_compute' if latency_ticks is None else 'recorded_failed_schedule_diagnostic'", "result['latency_model']='fixed_failure_cycle_schedule' if latency_cycle is not None else 'measured_control_compute' if latency_ticks is None else 'recorded_failed_schedule_diagnostic'")
(R/'pilot_worker_progress.py').write_text(s)
s=(R/'launch_final.py').read_text().replace("ROOT/'pilot_worker_continuation.py'","ROOT/'pilot_worker_progress.py'");(R/'launch_progress.py').write_text(s)
compile((R/'pilot_worker_progress.py').read_text(),'worker','exec')
