from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
archive=ROOT/'revisions/contract_objective';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='viability':";new="        if job.get('policy_version')=='polished':\n            from polished_policy import LowDimPolicy\n        elif job.get('policy_version')=='viability':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'final_ablations.json').read_text())
repeat=json.loads((ROOT/'contract_jobs.json').read_text())[2];jobs.insert(0,repeat)
for j in jobs:j['name']='polished_'+j['name'];j['policy_version']='polished'
(ROOT/'polished_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'POLISHED_STUDY_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='solve effective original 6-variable QP before safety admission; retain original rows and check requested release; no numerical tolerance increase',no_path=True),indent=2))
print(json.dumps(jobs))
