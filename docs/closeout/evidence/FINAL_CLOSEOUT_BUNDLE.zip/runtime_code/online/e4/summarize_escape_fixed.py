"""Escape after the chain fixes (escape_fixed/{joint,frame}) vs LiuQP-E alone (bench_safe) and the escape
batch before the fixes (escape_batch, frame tracking, no goal fallback).  Same 20 starts per scene."""
import collections
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from review_stats import mcnemar  # noqa: E402

V = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
SCENES = ["drawer", "iris_4shelves_t0", "iris_4shelves_t2", "iris_bins_t0", "iris_bins_t1"]
ARMS = {"alone": V / "bench_safe/liuqp", "before fixes": V / "escape_batch/liuqp",
        "fixed joint": V / "escape_fixed/joint", "fixed frame": V / "escape_fixed/frame"}


def load(path):
    s = json.load(open(path / "summary.json"))
    p = s.get("protective_stop") or {}
    ev = json.load(open(path / "guidance.json"))["events"] if (path / "guidance.json").exists() else []
    return dict(r=bool(s["success"]), t=s.get("first_sustained_success_time_s"),
                c=bool(p.get("stopped")) or (s.get("exact_penetrating_cycles") or 0) > 0, ev=ev)


R = {a: {sc: [load(root / f"{sc}_ellipsoid_straight_seed{i:02d}") for i in range(1, 21)] for sc in SCENES}
     for a, root in ARMS.items()}
print(f"{'scene':18s} " + " ".join(f"{a:>13s}" for a in ARMS) + "   joint vs alone (+/-, p)   frame vs alone")
for sc in SCENES:
    cells = [f"{sum(x['r'] for x in R[a][sc]):>10d}/20" for a in ARMS]
    out = []
    for a in ("fixed joint", "fixed frame"):
        g = sum(y["r"] and not x["r"] for x, y in zip(R["alone"][sc], R[a][sc]))
        l = sum(x["r"] and not y["r"] for x, y in zip(R["alone"][sc], R[a][sc]))
        out.append(f"+{g}/-{l} p {mcnemar(g, l):.2g}")
    print(f"{sc:18s} " + " ".join(cells) + "   " + "   ".join(out))
for a in ARMS:
    runs = [x for sc in SCENES for x in R[a][sc]]
    ev = [e for x in runs for e in x["ev"]]
    ends = collections.Counter(e["event"] for e in ev if e["event"] in ("chain_done", "chain_abort"))
    ss = [e["search_ms"] / 1000 for e in ev if e["event"] == "escape_search" and e.get("result") == "chain"]
    gi = [e["goal_ik_ms"] / 1000 for e in ev if e["event"] == "escape_search" and e.get("goal_ik_ms", 0) > 0]
    esc = [len([e for e in x["ev"] if e["event"] == "escape_search"]) for x in runs]
    t = [x["t"] for x in runs if x["r"]]
    line = (f"{a:13s} reached {sum(x['r'] for x in runs)}/{len(runs)}, contacts {sum(x['c'] for x in runs)},"
            f" median reach {np.median(t):.1f} s")
    if ss:
        line += (f" | escapes/run {np.mean(esc):.1f}, chains done {ends['chain_done']} / aborted {ends['chain_abort']},"
                 f" route search median {np.median(ss):.1f} s, 90% {np.percentile(ss, 90):.1f} s, max {max(ss):.1f} s")
    if gi:
        line += f", goal search (once/run) median {np.median(gi):.1f} s"
    print(line)
