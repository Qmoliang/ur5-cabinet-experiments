"""How much of the truly free drawer cavity does a proxy cover block?

Every cover tested here is a certified outer cover of the cabinet, so any
proxy volume inside the free cavity is pure over-approximation: space the robot
could use but the controller must avoid.

Inputs are known-environment covers rebuilt at a given cell span, or the final
published map of an online run.  For online ellipsoids the published outer
ellipsoid of (core + measurement uncertainty) is used, which can only
overstate what ellipsoids block.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

STEP = 0.0025
# Free cavity of the drawer (inner faces of bottom/ceiling/sides/back, open front).
CAVITY = {"x": (0.350, 0.800), "y": (0.23633091, 0.57633091), "z": (0.510, 0.650)}
# Free space directly in front of the opening, which the forearm must cross.
FRONT = {"x": (0.250, 0.350), "y": CAVITY["y"], "z": CAVITY["z"]}
TARGET = np.array([0.63, 0.40633091, 0.58])
APPROACH_HALF_WIDTH = 0.06  # |y - target_y| band the hand travels through


def grid_axes(region: dict = CAVITY) -> list[np.ndarray]:
    return [
        np.arange(low + 0.5 * STEP, high, STEP)
        for low, high in (region["x"], region["y"], region["z"])
    ]


def blocked_mask(
    centers: np.ndarray, shapes: np.ndarray, region: dict = CAVITY
) -> np.ndarray:
    """Grid points inside any ellipsoid {p: (p-c)^T Q^-1 (p-c) <= 1}."""
    axes = grid_axes(region)
    mask = np.zeros([len(axis) for axis in axes], dtype=bool)
    half = np.sqrt(np.maximum(np.einsum("nii->ni", shapes), 0.0))
    inverse = np.linalg.inv(shapes)
    for center, extent, inv in zip(centers, half, inverse):
        ranges = []
        for axis, values in enumerate(axes):
            low = np.searchsorted(values, center[axis] - extent[axis], side="left")
            high = np.searchsorted(values, center[axis] + extent[axis], side="right")
            ranges.append((low, high))
        if any(low >= high for low, high in ranges):
            continue
        sub = np.meshgrid(*[axes[i][ranges[i][0]:ranges[i][1]] for i in range(3)], indexing="ij")
        delta = np.stack([sub[i] - center[i] for i in range(3)], axis=-1)
        inside = np.einsum("...i,ij,...j->...", delta, inv, delta) <= 1.0
        mask[ranges[0][0]:ranges[0][1], ranges[1][0]:ranges[1][1], ranges[2][0]:ranges[2][1]] |= inside
    return mask


def known_cover(representation: str, span: float):
    root = Path(__file__).resolve().parent.parent / "known_v6"
    sys.path[:0] = [str(root / "src"), str(root / "src" / "core"), str(root)]
    from known_volume import build_volume_cover
    from run import load_scene
    cover = build_volume_cover(load_scene().boxes, representation, span)
    if representation == "sphere":
        shapes = np.eye(3)[None] * (cover.sphere_radii ** 2)[:, None, None]
    else:
        shapes = cover.ellipsoid_shapes
    return cover.centers, shapes


def online_cover(npz: Path, representation: str):
    data = np.load(npz)
    if representation == "sphere":
        radii = data["sphere_radii"] + data["uncertainty_offsets"]
        shapes = np.eye(3)[None] * (radii ** 2)[:, None, None]
    else:
        shapes = data["ellipsoid_outer_shapes"]
    return data["centers"], shapes


def metrics(mask: np.ndarray, front: np.ndarray) -> dict:
    x, y, z = grid_axes()
    approach_x = (x <= TARGET[0])
    band_y = np.abs(y - TARGET[1]) <= APPROACH_HALF_WIDTH
    target_y = int(np.argmin(np.abs(y - TARGET[1])))
    # Largest free vertical run at each x along the target column.
    column = mask[:, target_y, :]
    free_heights = []
    for row in column[approach_x]:
        best = run = 0
        for blocked in row:
            run = 0 if blocked else run + 1
            best = max(best, run)
        free_heights.append(best * STEP)
    return {
        "cavity_blocked_fraction": float(mask.mean()),
        "front_blocked_fraction": float(front.mean()),
        "approach_blocked_fraction": float(mask[approach_x][:, band_y].mean()),
        "narrowest_free_height_mm": 1000.0 * float(min(free_heights)),
        "true_free_height_mm": 1000.0 * (CAVITY["z"][1] - CAVITY["z"][0]),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--known", nargs="*", default=[], help="representation:span")
    parser.add_argument("--online", nargs="*", default=[], help="label:representation:npz")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rows = []
    slices = {}
    for spec in args.known:
        representation, span = spec.split(":")
        centers, shapes = known_cover(representation, float(span))
        mask = blocked_mask(centers, shapes)
        front = blocked_mask(centers, shapes, FRONT)
        label = f"known_{representation}_{round(float(span) * 1000):03d}mm"
        rows.append({"label": label, "proxies": len(centers), **metrics(mask, front)})
        slices[label] = mask[:, mask.shape[1] // 2, :]
        print(json.dumps(rows[-1]), flush=True)
    for spec in args.online:
        label, representation, npz = spec.split(":", 2)
        centers, shapes = online_cover(Path(npz), representation)
        mask = blocked_mask(centers, shapes)
        front = blocked_mask(centers, shapes, FRONT)
        rows.append({"label": label, "proxies": len(centers), **metrics(mask, front)})
        slices[label] = mask[:, mask.shape[1] // 2, :]
        print(json.dumps(rows[-1]), flush=True)
    existing = args.out / "geometry.json"
    previous = json.loads(existing.read_text()) if existing.exists() else []
    labels = {row["label"] for row in rows}
    (existing).write_text(json.dumps([r for r in previous if r["label"] not in labels] + rows, indent=2))
    np.savez_compressed(args.out / f"slices_{len(previous)}.npz", **slices)


if __name__ == "__main__":
    main()
