"""Experiment B batch: LiuQP-E alone (bench_safe / depth_sweep, 60 s) vs LiuQP-E + chained escape
(escape_batch, 120 s), same scenes, same 20 starts, same safety layer.
reached = sustained 5 mm success; contact = protective stop or exact penetration; escape time = wall time
of one escape search (the arm stands still meanwhile); paired = same start, only one of the two reached."""
import collections
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from review_stats import mcnemar  # noqa: E402

V = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
SCENES = ["drawer", "cage", "cage_wide", "exit", "iris_bins_t0", "iris_bins_t2", "iris_bins_t3",
          "iris_ur3_shelf_t0", "iris_ur3_shelf_t1", "iris_ur3_shelf_t2",
          "iris_4shelves_t0", "iris_4shelves_t2", "iris_bins_t1", "wall2_topm10", "wall2_topm15", "wall2"]


def load(path):
    if not (path / "summary.json").exists():
        return None
    s = json.load(open(path / "summary.json"))
    p = s.get("protective_stop") or {}
    out = dict(reached=bool(s["success"]), t=s.get("first_sustained_success_time_s"),
               contact=bool(p.get("stopped")) or (s.get("exact_penetrating_cycles") or 0) > 0, escapes=[], ends=[])
    g = path / "guidance.json"
    if g.exists():
        ev = json.load(open(g))["events"]
        out["escapes"] = [e for e in ev if e.get("event") == "escape_search"]
        out["ends"] = [e["event"] for e in ev if e["event"] in ("chain_done", "chain_abort")]
    return out


tot = collections.Counter()
search_all = []
print(f"{'scene':20s} {'LiuQP-E':>9s} {'+escape':>9s} {'gained':>6s} {'lost':>5s} {'p':>7s} {'contacts':>9s} "
      f"{'t alone':>8s} {'t escape':>9s} {'escapes/run':>11s} {'escape s med/max':>17s} {'no route':>8s}")
for scene in SCENES:
    base_root = V / "depth_sweep/liuqp" if scene.startswith("wall2_top") else V / "bench_safe/liuqp"
    pairs = []
    for seed in range(1, 21):
        rid = f"{scene}_ellipsoid_straight_seed{seed:02d}"
        a, b = load(base_root / rid), load(V / "escape_batch/liuqp" / rid)
        if a is not None and b is not None:
            pairs.append((a, b))
    if not pairs:
        continue
    gained = sum(b["reached"] and not a["reached"] for a, b in pairs)
    lost = sum(a["reached"] and not b["reached"] for a, b in pairs)
    searches = [e["search_ms"] / 1000 for _a, b in pairs for e in b["escapes"]]
    search_all += searches
    no_route = sum(e.get("result") != "chain" for _a, b in pairs for e in b["escapes"])
    ta = [a["t"] for a, _b in pairs if a["reached"] and a["t"]]
    tb = [b["t"] for _a, b in pairs if b["reached"] and b["t"]]
    print(f"{scene:20s} {sum(a['reached'] for a, _ in pairs):3d}/{len(pairs):<5d} {sum(b['reached'] for _, b in pairs):3d}/{len(pairs):<5d} "
          f"{gained:6d} {lost:5d} {mcnemar(gained, lost):7.3g} {sum(a['contact'] for a, _ in pairs):3d} -> {sum(b['contact'] for _, b in pairs):<3d} "
          f"{np.median(ta) if ta else float('nan'):7.1f}s {np.median(tb) if tb else float('nan'):8.1f}s "
          f"{np.mean([len(b['escapes']) for _, b in pairs]):11.1f} "
          f"{(np.median(searches) if searches else float('nan')):8.1f}/{(max(searches) if searches else float('nan')):<8.1f} {no_route:8d}")
    tot["n"] += len(pairs)
    tot["a"] += sum(a["reached"] for a, _ in pairs)
    tot["b"] += sum(b["reached"] for _, b in pairs)
    tot["gained"] += gained
    tot["lost"] += lost
    tot["ca"] += sum(a["contact"] for a, _ in pairs)
    tot["cb"] += sum(b["contact"] for _, b in pairs)
print(f"\nall: LiuQP-E {tot['a']}/{tot['n']}, +escape {tot['b']}/{tot['n']}, gained {tot['gained']}, lost {tot['lost']}, "
      f"p {mcnemar(tot['gained'], tot['lost']):.3g}; contacts {tot['ca']} -> {tot['cb']}")
if search_all:
    s = np.array(search_all)
    print(f"escape search time over {len(s)} escapes: median {np.median(s):.1f} s, 90% {np.percentile(s, 90):.1f} s, "
          f"max {s.max():.1f} s, share under 5 s {np.mean(s < 5):.0%}, under 1 s {np.mean(s < 1):.0%}")
