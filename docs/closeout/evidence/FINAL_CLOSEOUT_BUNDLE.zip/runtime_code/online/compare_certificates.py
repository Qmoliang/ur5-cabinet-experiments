"""Online vs dense-cloud CenterVox certificates: where does the online thickness come from?

For each map (frontier cells dropped): the uncertainty part (sqrt of the largest
eigenvalue of proxy_uncertainty_shapes), the geometric part (thin semi-axis of
base_ellipsoid_shapes), the outer shell's thin semi-axis, and the overshoot of
the outer shell past the real cabinet (largest boundary-sample distance to the
nearest box).  "edge" = certificates within 10 cm of the drawer opening's front
edges (x < 0.40, near z = 0.51 or z = 0.65).
"""
import pickle
import sys

import numpy as np

sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
import run_protocol_v3_async_online as online  # noqa: E402

scene = online._protocol_scene("camera_quarter")
lo = np.array([np.asarray(b.center) - np.asarray(b.half_size) for b in scene.boxes])
hi = np.array([np.asarray(b.center) + np.asarray(b.half_size) for b in scene.boxes])
u = np.random.default_rng(0).normal(size=(300, 3))
u /= np.linalg.norm(u, axis=1, keepdims=True)


def overshoot(c, S):
    w, v = np.linalg.eigh(S)
    pts = c + u @ (v @ np.diag(np.sqrt(np.maximum(w, 0))) @ v.T).T
    d = np.linalg.norm(np.maximum(0, np.maximum(lo[None] - pts[:, None], pts[:, None] - hi[None])), axis=2).min(axis=1)
    return d.max()


def describe(label, path):
    stored = pickle.load(open(path, "rb"))
    p, n = stored["proxies"], stored["frontier_cells"]
    keep = len(p.centers) - n
    c = np.asarray(p.centers)[:keep]
    unc = np.sqrt(np.maximum(np.linalg.eigvalsh(np.asarray(p.proxy_uncertainty_shapes)[:keep])[:, -1], 0))
    base = np.sqrt(np.maximum(np.linalg.eigvalsh(np.asarray(p.base_ellipsoid_shapes)[:keep])[:, 0], 0))
    outer_shapes = np.asarray(p.ellipsoid_outer_shapes)[:keep]
    outer = np.sqrt(np.maximum(np.linalg.eigvalsh(outer_shapes)[:, 0], 0))
    over = np.array([overshoot(ci, Si) for ci, Si in zip(c, outer_shapes)])
    edge = (c[:, 0] < 0.40) & ((np.abs(c[:, 2] - 0.51) < 0.10) | (np.abs(c[:, 2] - 0.65) < 0.10)) & \
        (c[:, 1] > 0.15) & (c[:, 1] < 0.66)
    f = lambda x: f"{1000*np.median(x):5.1f}/{1000*np.percentile(x, 90):5.1f}"
    print(f"{label:12s} n={keep:5d} (edge {int(edge.sum()):4d}) | uncertainty {f(unc)} edge {f(unc[edge])} | "
          f"geometric thin {f(base)} edge {f(base[edge])} | outer thin {f(outer)} edge {f(outer[edge])} | "
          f"overshoot {f(over)} edge {f(over[edge])}   (median/p90 mm)", flush=True)


for label, path in zip(sys.argv[1::2], sys.argv[2::2]):
    describe(label, path)
