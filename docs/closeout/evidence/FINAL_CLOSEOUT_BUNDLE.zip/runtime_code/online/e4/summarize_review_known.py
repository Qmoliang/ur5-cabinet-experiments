"""Reviewer batch, known map: is NEO's racket advantage its 0.30 m range?  Baselines from pilot_known20,
new variants from review_known (same protocol, same starts).  Pooled over 4 scenes x straight/geodesic.
Paired: same scene / attraction / seed / condition, both launched; exact McNemar on 'hit by a racket'."""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from review_stats import mcnemar, rate  # noqa: E402

V = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
R = {}
for root in ("pilot_known20", "review_known"):
    for f in (V / root).glob("*/*_seed*/summary.json"):
        ctl_attr, k, v = f.parent.parent.name.rsplit("_", 2)
        ctl, attr = ctl_attr.rsplit("_", 1)
        s = json.load(open(f))
        o = s.get("objects") or {}
        p = s.get("protective_stop") or {}
        kinds = p.get("kinds") or {}
        stopped = bool(p.get("stopped"))
        reached = bool(o.get("success_after")) if (o.get("count") or 0) else bool(s.get("success"))
        R[(ctl, k + "_" + v, attr + "/" + f.parent.name)] = dict(
            launched=any(d["launched"] for d in o.get("described", [])), clean=reached and not stopped,
            hit=stopped and "object" in kinds, other=stopped and "object" not in kinds)
CONDS = {"k1_v0.25": "1 racket @0.25 m/s", "k1_v0.5": "1 racket @0.5 m/s", "k2_v0.5": "2 rackets @0.5 m/s"}
CTLS = ["liuqp", "liuqp_h06", "combined", "neo_matched", "neo_split", "neo_paper"]
print(f"{len(R)} runs")
for cond, label in CONDS.items():
    print(f"\n  {label}: launched-only clean | hit | other stop ; all-runs clean")
    for ctl in CTLS:
        out = [o for (c, k, _), o in R.items() if c == ctl and k == cond]
        la = [o for o in out if o["launched"]]
        if not out:
            continue
        print(f"    {ctl:12s} clean {rate(sum(o['clean'] for o in la), len(la))}  hit {rate(sum(o['hit'] for o in la), len(la))}"
              f"  other {sum(o['other'] for o in la):2d}  all-runs clean {rate(sum(o['clean'] for o in out), len(out))}")
print("\n  paired, hit by a racket (both launched): only A hit / only B hit, McNemar p")
for a, b in (("neo_split", "neo_matched"), ("neo_split", "neo_paper"), ("liuqp_h06", "liuqp"),
             ("liuqp_h06", "neo_split"), ("combined", "neo_split"), ("combined", "liuqp_h06")):
    for cond, label in CONDS.items():
        x = [(o, R.get((b, k, run))) for (c, k, run), o in R.items() if c == a and k == cond]
        x = [(p, q) for p, q in x if q and p["launched"] and q["launched"]]
        only_a = sum(p["hit"] and not q["hit"] for p, q in x)
        only_b = sum(q["hit"] and not p["hit"] for p, q in x)
        print(f"    {a:10s} vs {b:12s} {label:20s} n {len(x):3d}  only {a} hit {only_a:3d}  "
              f"only {b} hit {only_b:3d}  p {mcnemar(only_a, only_b):.3g}")
