"""Offline refit of an online run's final observed cells with other fit settings; protrusion beyond the true
boxes near the limiting certificate.  Usage: refit.py run scene.json [overshoot_mm ...]"""
import json, os, sys, csv
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("UR5_NATIVE_FIT", "0")
from pointcloud_proxy import fit_matched_voxel_proxies

run, scene_json = Path(sys.argv[1]), sys.argv[2]
settings = [float(v) for v in sys.argv[3:]] or [25.0]
inner = next(run.glob("A-CV-*"))
p = np.load(inner / "final_causal_proxies.npz")
boxes = json.load(open(scene_json))["boxes"]
bc = np.array([b["center"] for b in boxes]); bh = np.array([b["half_size"] for b in boxes])
rows = list(csv.DictReader(open(inner / "cycles.csv")))
ids = list(p["proxy_ids"]); lim = int(float(rows[-1]["limiting_proxy_id"]))
focus = p["centers"][ids.index(lim)]
pts, off, U = p["filtered_points"], p["filtered_point_offsets"], p["filtered_uncertainty_shapes"]
rng = np.random.default_rng(0); n = rng.normal(size=(400, 3)); n /= np.linalg.norm(n, axis=1, keepdims=True)
box_h = (n @ bc.T) + np.abs(n) @ bh.T   # (dirs, boxes)

def protrusion(fit, near):
    c = fit.centers; Q = fit.base_ellipsoid_shapes; Uu = fit.proxy_uncertainty_shapes; o = fit.proxy_offset_radii
    sel = np.where(np.linalg.norm(c - focus, axis=1) < near)[0]
    out = []
    for k in sel:
        core = np.sqrt(np.maximum(np.einsum("ni,ij,nj->n", n, Q[k], n), 0))
        unc = np.sqrt(np.maximum(np.einsum("ni,ij,nj->n", n, Uu[k], n), 0))
        h = n @ c[k] + core + unc + o[k]
        exc = (h[:, None] - box_h).max(axis=0); i = int(np.argmin(exc)); j = int(np.argmax(h - box_h[:, i]))
        out.append((exc[i], core[j], unc[j]))
    return np.array(out)

for s in settings:
    fit = fit_matched_voxel_proxies(pts, filter_size=0.005, cluster_size=0.10, maximum_aabb_overshoot=s / 1000,
                                    already_filtered=True, filtered_point_offsets=off,
                                    filtered_point_uncertainty_shapes=U, cluster_origin=np.array([-0.25, -0.15, -0.02]),
                                    maximum_uncertainty_union_inflation=1.05, certificate_radius_limit=0.070)
    o = protrusion(fit, 0.08)
    print(f"overshoot {s:4.1f} mm: {len(fit.centers):6d} certificates; near focus {len(o)}: protrusion p50/p90/max "
          f"{np.percentile(o[:,0],50)*1e3:5.1f} {np.percentile(o[:,0],90)*1e3:5.1f} {o[:,0].max()*1e3:5.1f} mm; "
          f"core p90 {np.percentile(o[:,1],90)*1e3:4.1f}, unc p90 {np.percentile(o[:,2],90)*1e3:4.1f}")
