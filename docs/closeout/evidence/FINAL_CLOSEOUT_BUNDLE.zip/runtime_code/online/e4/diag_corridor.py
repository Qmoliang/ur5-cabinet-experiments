"""Replay the escape planner from real drawer stuck postures: is the shortcut RRT route legal at 6 mm, and is
the IRIS-ZO junction chain (what LiuQP is given) legal?  Light regions (60 samples x 3 iterations, FAST=3)
and the default effort (as in guidance.py) are both checked."""
import json
import sys

runs = sys.argv[1:]
sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/feasibility.py").read().split("variants = []")[0])
sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
from escape_point import corridor, parallel_goal_configurations, rrt_parallel, with_arm_limits  # noqa: E402
from guidance import densify, shortcut  # noqa: E402

payload = json.load(open(f"{K}/assets/scene.json"))
scene = scene_of(payload)
model = build_model(scene)
robot = build_robot_certificate(model)
cover = build_volume_cover(scene.boxes, "ellipsoid", 0.075)
radii = np.array([s.radius for s in robot])
index = NativeBallTree(cover.centers, cover.aabb_half_extents, query_padding=float(radii.max() + 0.06))
checker = ConfigurationChecker(model, robot, cover.centers, "ellipsoid", radii=cover.sphere_radii,
                               shapes=cover.ellipsoid_shapes, margin=MARGIN, index=index)
checker = with_arm_limits(checker, np.asarray(scene.q0))
target = np.asarray(scene.waypoints[-1])
goals = parallel_goal_configurations(checker, target, 1, seeds=200, push=True)


def worst(points):
    checker.margin = MARGIN
    w = np.inf
    bad = 0
    for a, b in zip(points[:-1], points[1:]):
        n = max(2, int(np.ceil(np.max(np.abs(b - a)) / 0.01)))
        seg = min(checker.clearance(a + t * (b - a)) for t in np.linspace(0, 1, n))
        bad += seg < 0
        w = min(w, seg)
    return w, bad, len(points) - 1


for run in runs:
    g = json.load(open(f"{run}/guidance.json"))
    q_hist = np.load(f"{run}/q_history.npy")[:, :6]
    stall = [e for e in g["events"] if e["event"] == "escape_search"][0]["cycle"]
    stuck = q_hist[stall]
    checker.margin = MARGIN + 0.003
    start = stuck
    if not checker.free(stuck):
        rng = np.random.default_rng(0)
        for sigma in (0.02, 0.05, 0.1, 0.2):
            tries = [p for p in (stuck + rng.normal(0, sigma, 6) for _ in range(40)) if checker.free(p)]
            if tries:
                start = min(tries, key=lambda p: float(np.linalg.norm(p - stuck)))
                break
    gs = [g_ for g_ in goals if checker.free(g_)] or goals
    def ne(q, ref):
        out = np.asarray(q, dtype=float).copy()
        for j in range(6):
            for shift in (-2 * np.pi, 2 * np.pi):
                alt = out[j] + shift
                if checker.lower[j] <= alt <= checker.upper[j] and abs(alt - ref[j]) < abs(out[j] - ref[j]):
                    out[j] = alt
        return out
    gs = [ne(g_, start) for g_ in gs]
    print("start free at 9 mm", checker.free(start), "goals", len(gs), flush=True)
    path, _ = rrt_parallel(checker, start, gs, 7)
    if path is None:
        print(run, "no route")
        continue
    rng = np.random.default_rng(1)
    vertices = shortcut(checker, path, rng, rounds=60)
    dense = densify(vertices)
    print(f"\n{run.split('/')[-1]}: route vertices {len(vertices)}; at 6 mm: route worst {1000*worst(vertices)[0]:+.1f} mm")
    lower = np.maximum(dense.min(axis=0) - 0.5, checker.lower)
    upper = np.minimum(dense.max(axis=0) + 0.5, checker.upper)
    for label, samples, iterations in (("light 60x3", 60, 3), ("default 200x6", 200, 6), ("heavy 1000x10", 1000, 10)):
        checker.margin = MARGIN + 0.003
        t = time.perf_counter() if "time" in globals() else None
        import time
        t = time.perf_counter()
        regions, junctions = corridor(checker, dense, np.random.default_rng(2), lower, upper,
                                      samples=samples, iterations=iterations)
        ms = 1000 * (time.perf_counter() - t)
        chain = [start] + list(junctions)
        w, bad, legs = worst(chain)
        # how far the region polytopes reach: straight legs between junctions vs the route
        print(f"   corridor {label:14s}: {len(regions)} regions in {ms:6.0f} ms; junction chain worst {1000*w:+7.1f} mm, "
              f"illegal legs {bad}/{legs}")
index.close()
