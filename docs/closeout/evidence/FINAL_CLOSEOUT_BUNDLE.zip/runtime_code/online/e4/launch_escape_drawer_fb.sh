#!/bin/bash
# Drawer rerun (2026-10-28) with the push-out goal-search fallback (escape_point.py), else as below.
# Experiment B batch (approved 2026-10-28): LiuQP-E + stall-triggered chained IRIS-ZO escape
# (UR5_GUIDANCE=escape_chain, UR5_ESCAPE_FAST=3: parallel goal postures and route search, whole-arm
# tracking) on the 14 benchmark scenes (original starts) + wall2 with the target 10 / 15 cm below the top,
# 20 starts each.  Same safety layer as bench_safe / depth_sweep (whose LiuQP-E runs are the baseline).
# 120 s per run (the escape needs time to plan and move).  12 workers x 8 CPUs (CPUs 0-95).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/escape_drawer_fb
SCENES="drawer"
jobs=()
for seed in $(seq 1 20); do
  for scene in $SCENES; do
    jobs+=("$scene $seed")
  done
done
echo "${#jobs[@]} jobs" > escape_drawer_fb.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 10)); do
    set -- ${jobs[$i]}
    id=${1}_ellipsoid_straight_seed$(printf "%02d" $2)
    [ -f $P/liuqp/$id/summary.json ] && continue
    ./known_job.sh $P/liuqp $1 ellipsoid straight $2 $((w * 8)) UR5_CONTROLLER=liuqp UR5_E4_SAFETY=1 UR5_ACCEL_LIMIT=10 \
      UR5_GUIDANCE=escape_chain UR5_ESCAPE_FAST=3 UR5_MAX_CYCLES=6000 UR5_JOB_CPUS=8
  done
}
for w in $(seq 0 9); do worker $w & done
wait
echo DONE > escape_drawer_fb.done
