from pathlib import Path
import os,sys,json,subprocess,concurrent.futures,queue
ROOT=Path(__file__).resolve().parent;PY='/home/hsjed/envs/ur5cab/bin/python'
patterns=sys.argv[1:] or ['pilot_v*']
folders=[p for p in sorted({p for pattern in patterns for p in (ROOT/'trials').glob(pattern)}) if (p/'result.json').exists() and not (p/'audit.json').exists()]
slots=queue.Queue();slots.put('56,57,58,59');slots.put('60,61,62,63')
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libstdc++.so.6')
def run(folder):
    cpus=slots.get()
    try:
        with (folder/'audit.log').open('w') as log:
            try:code=subprocess.run([PY,'-u',str(ROOT/'audit_pilot.py'),str(folder),cpus],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
            except subprocess.TimeoutExpired:code='timeout'
        out=dict(name=folder.name,exit_code=code,audit_exists=(folder/'audit.json').exists())
        if out['audit_exists']:
            a=json.loads((folder/'audit.json').read_text());out.update(safety_passed=a['safety_passed'],goal_passed=a['goal_passed'],minimum_proxy_gap_mm=a['minimum_proxy_gap_mm'])
        print(json.dumps(out),flush=True);return out
    finally:slots.put(cpus)
prior=json.loads((ROOT/'AUDIT_STATUS.json').read_text()) if (ROOT/'AUDIT_STATUS.json').exists() else []
results={x['name']:x for x in prior}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for out in pool.map(run,folders):results[out['name']]=out;(ROOT/'AUDIT_STATUS.json').write_text(json.dumps(list(results.values()),indent=2))
