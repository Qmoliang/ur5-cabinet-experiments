#!/bin/bash
# E4: online drawer (live map from wrist/forearm + 3 fixed cameras), moving objects seen only by the
# fixed cameras; liuqp / liuqphe / combined x 20 start seeds x (k=0 | k=1,2,3 x 0.25,0.5,1.0 m/s);
# 7 runs at a time on 16 CPUs each (CPUs 0-111).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
E=$PWD/e4
jobs=()
for seed in $(seq 1 20); do
  for ctl in combined liuqphe liuqp; do
    jobs+=("$E/${ctl}_k0_v0.0/seed$(printf %02d $seed) $seed $ctl 0 0.0")
    for k in 1 2 3; do
      for v in 0.25 0.5 1.0; do
        jobs+=("$E/${ctl}_k${k}_v$v/seed$(printf %02d $seed) $seed $ctl $k $v")
      done
    done
  done
done
echo "${#jobs[@]} jobs" > $E.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 7)); do
    set -- ${jobs[$i]}
    [ -f $1/summary.json ] && continue
    rm -rf $1
    ./e4_one.sh $1 $2 $((w * 16)) $3 $4 $5
  done
}
for w in $(seq 0 6); do worker $w & done
wait
echo DONE > $E.done
