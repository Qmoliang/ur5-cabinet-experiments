"""Benchmark tables: static scenes and the racket, at 5 mm success tolerance.

Static: per scene x controller x representation x objective -> reached / 20,
median reach time, runs with penetration, controller errors, controller p99.
Racket: per scene x controller x representation x speed -> runs with racket
contact, median minimum racket clearance, median retreat, reached after the
racket left, controller errors.
"""
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

ROOT = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")


def load(folder):
    rows = defaultdict(list)
    for summary in folder.glob("*/*_seed*/summary.json"):
        s = json.loads(summary.read_text())
        stem = summary.parent.name.rsplit("_seed", 1)[0]
        rows[(summary.parent.parent.name, stem)].append(s)
    return rows


def med(values):
    values = [v for v in values if v is not None]
    return float(np.median(values)) if values else float("nan")


static = load(ROOT / "bench")
print("STATIC (5 mm): scene | controller | rep | objective | reached | reach_t | pen_runs | errors | p99")
for (ctl, stem), runs in sorted(static.items(), key=lambda kv: (kv[0][1], kv[0][0])):
    reached = [r for r in runs if r.get("success")]
    print(f"{stem:44s} {ctl:12s} reached {len(reached):2d}/{len(runs):2d} "
          f"t {med([r.get('first_sustained_success_time_s') for r in reached]):5.1f}s "
          f"pen {sum(bool(r.get('exact_penetrating_cycles')) for r in runs):2d} "
          f"err {sum(bool(r.get('controller_error')) for r in runs):2d} "
          f"p99 {med([r.get('controller_ms_p99') for r in runs]):6.1f}ms")

racket = load(ROOT / "racket")
print("\nRACKET: scene_rep | controller_speed | contact runs | min clearance mm | retreat mm | reached after | errors")
for (cfg, stem), runs in sorted(racket.items(), key=lambda kv: (kv[0][1], kv[0][0])):
    info = [r.get("racket") or {} for r in runs]
    print(f"{stem:40s} {cfg:18s} contact {sum(bool(i.get('contact_cycles')) for i in info):2d}/{len(runs):2d} "
          f"min {1000*med([i.get('min_distance_m') for i in info]):7.1f} "
          f"retreat {1000*med([i.get('max_retreat_m') for i in info]):6.1f} "
          f"after {sum(bool(i.get('success_after_racket')) for i in info):2d} "
          f"err {sum(bool(r.get('controller_error')) for r in runs):2d}")
