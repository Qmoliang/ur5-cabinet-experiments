"""ctypes wrapper for geodesic_native.cpp, same interface as geodesic.GeodesicAttractor.

`rebuild` lets an online runtime refresh the field whenever the map changes.
"""
from __future__ import annotations

import ctypes
import sys
import time
from pathlib import Path

import numpy as np

LIBRARY = Path(__file__).resolve().parent / (
    "geodesic_native.dll" if sys.platform == "win32" else "geodesic_native.so"
)


class NativeGeodesicAttractor:
    def __init__(self, centers, target, representation, *, radii=None, shapes=None,
                 inflation: float = 0.03, voxel: float = 0.0075, lookahead: float = 0.08,
                 lower=(-0.10, -0.10, 0.25), upper=(0.95, 0.95, 1.15), extra_centers=None, extra_radii=None):
        self._lib = ctypes.CDLL(str(LIBRARY))
        dp, ip = ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_int32)
        self._lib.gd_create.argtypes = [dp, ctypes.c_double, ip]
        self._lib.gd_create.restype = ctypes.c_void_p
        self._lib.gd_destroy.argtypes = [ctypes.c_void_p]
        self._lib.gd_clear.argtypes = [ctypes.c_void_p]
        self._lib.gd_block_ellipsoids.argtypes = [ctypes.c_void_p, dp, dp, dp, ctypes.c_int32, ctypes.c_double]
        self._lib.gd_block_spheres.argtypes = [ctypes.c_void_p, dp, dp, ctypes.c_int32, ctypes.c_double]
        self._lib.gd_solve.argtypes = [ctypes.c_void_p, dp]
        self._lib.gd_solve.restype = ctypes.c_int64
        self._lib.gd_command.argtypes = [ctypes.c_void_p, dp, ctypes.c_double, dp]
        self._lib.gd_command.restype = ctypes.c_int32
        self.inflation = float(inflation)
        self.lookahead = float(lookahead)
        self.representation = representation
        self.target = np.ascontiguousarray(target, dtype=np.float64)
        lower = np.ascontiguousarray(lower, dtype=np.float64)
        dims = np.ascontiguousarray(np.ceil((np.asarray(upper) - lower) / voxel), dtype=np.int32)
        self._handle = self._lib.gd_create(lower.ctypes.data_as(dp), float(voxel), dims.ctypes.data_as(ip))
        self._out = np.zeros(3, dtype=np.float64)
        self.rebuild(centers, radii=radii, shapes=shapes, extra_centers=extra_centers, extra_radii=extra_radii)

    def rebuild(self, centers, *, radii=None, shapes=None, extra_centers=None, extra_radii=None) -> None:
        """Re-mark obstacles and re-solve the wavefront (e.g. after a map update).

        extra_centers/extra_radii: additional spheres (e.g. coarsened unseen cells).
        """
        started = time.perf_counter()
        dp = ctypes.POINTER(ctypes.c_double)
        self._lib.gd_clear(self._handle)
        centers = np.ascontiguousarray(centers, dtype=np.float64).reshape(-1, 3)
        if self.representation == "sphere":
            radii = np.ascontiguousarray(radii, dtype=np.float64)
            self._lib.gd_block_spheres(self._handle, centers.ctypes.data_as(dp), radii.ctypes.data_as(dp),
                                       len(centers), self.inflation)
        else:
            values, vectors = np.linalg.eigh(np.asarray(shapes, dtype=np.float64))
            axes = np.ascontiguousarray(np.sqrt(np.maximum(values, 0.0)))
            rotations = np.ascontiguousarray(vectors)
            self._lib.gd_block_ellipsoids(self._handle, centers.ctypes.data_as(dp), rotations.ctypes.data_as(dp),
                                          axes.ctypes.data_as(dp), len(centers), self.inflation)
        if extra_centers is not None and len(extra_centers):
            extra_centers = np.ascontiguousarray(extra_centers, dtype=np.float64).reshape(-1, 3)
            extra_radii = np.ascontiguousarray(extra_radii, dtype=np.float64)
            self._lib.gd_block_spheres(self._handle, extra_centers.ctypes.data_as(dp), extra_radii.ctypes.data_as(dp),
                                       len(extra_centers), self.inflation)
        self.reachable_cells = int(self._lib.gd_solve(self._handle, self.target.ctypes.data_as(dp)))
        self.build_ms = 1000.0 * (time.perf_counter() - started)

    def command(self, gripper) -> np.ndarray:
        if self.reachable_cells < 0:
            return self.target  # goal blocked at this inflation: fall back to LiuQP's own pull
        dp = ctypes.POINTER(ctypes.c_double)
        gripper = np.ascontiguousarray(gripper, dtype=np.float64)
        if self._lib.gd_command(self._handle, gripper.ctypes.data_as(dp), self.lookahead,
                                self._out.ctypes.data_as(dp)):
            return self._out.copy()
        return self.target

    def close(self):
        if self._handle:
            self._lib.gd_destroy(self._handle)
            self._handle = None

    def __del__(self):
        self.close()
