from pathlib import Path
import json
from model import BoxObstacle,SceneDefinition
def load_scene():
    import os
    # E4: another known-map scene (same JSON format) instead of the drawer.
    path=os.environ.get('UR5_E4_SCENE_JSON') or (Path(__file__).resolve().parent/'assets/scene.json')
    x=json.loads(Path(path).read_text(encoding='utf-8'))
    return SceneDefinition(name=x['name'],description=x['description'],boxes=tuple(BoxObstacle(b['name'],tuple(b['center']),tuple(b['half_size']),b['material']) for b in x['boxes']),q0=tuple(x['q0']),waypoints=tuple(tuple(p) for p in x['waypoints']),duration=x['duration'])
