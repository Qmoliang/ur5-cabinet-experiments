"""Identical bounded search over supplied known/observed proxy arrays."""
import os,time,hashlib
import numpy as np
from scipy.optimize import minimize,least_squares
import mujoco
from scipy.stats import qmc
from unified_policy import POLICY
from collision_oracle import CollisionOracle,SearchDeadline
from position_ik import candidates as analytic_candidates
from taskspace_search import TaskspaceBiTree,add_posture_goals

# One bounded worker-local state; exact geometry hashes prevent reuse across maps.
_SEARCH_STATE={}
def geometry_key(arrays,initial_q,target):
 h=hashlib.sha256()
 for name in sorted(arrays):
  value=arrays[name];h.update(name.encode())
  if isinstance(value,str):h.update(value.encode())
  else:
   a=np.ascontiguousarray(value);h.update(str((a.shape,a.dtype.str)).encode());h.update(a.tobytes())
 h.update(np.asarray(initial_q,dtype=float).tobytes());h.update(np.asarray(target,dtype=float).tobytes())
 return h.hexdigest()

def worker_init(cpus=None):
 if cpus:os.sched_setaffinity(0,set(cpus))
 os.environ["OPENBLAS_NUM_THREADS"]="1";os.environ["OMP_NUM_THREADS"]="1";os.environ["UNIFIED_PLANNER_PROCESS"]="1"
 from proxy_geometry import NativeEllipsoidSupport
 NativeEllipsoidSupport().set_pair_threads(1)

def local_goals(oracle,q0,target,rng,limit):
 goals=[];diagnostics=[];anchor=q0.copy()
 for attempt in range(2):
  if time.perf_counter()>limit:break
  seedq=anchor if attempt==0 else np.clip(q0+rng.normal(0,.35,6),oracle.lower,oracle.upper)
  # Find the target manifold with robot kinematics first. Starting the joint
  # clearance optimizer far from its Cartesian equality caused false no-goal results.
  def kin_residual(q):
   oracle.check_deadline();ee=oracle.gripper_position(q)
   return np.r_[100*(ee-target),1e-4*(q-q0)]
  def kin_jacobian(q):
   oracle.check_deadline();oracle.gripper_position(q);mujoco.mj_comPos(oracle.model,oracle.data);J=np.zeros((3,oracle.model.nv));mujoco.mj_jacSite(oracle.model,oracle.data,J,None,oracle.site)
   return np.vstack([100*J[:,:6],1e-4*np.eye(6)])
  kin=least_squares(kin_residual,seedq,jac=kin_jacobian,bounds=(oracle.lower,oracle.upper),max_nfev=80,ftol=1e-10,xtol=1e-10,gtol=1e-10)
  seedq=kin.x;error=float(np.linalg.norm(oracle.gripper_position(seedq)-target));slack=oracle.exact_clearance(seedq)
  diagnostics.append(dict(kind="robot_kinematics",evaluations=int(kin.nfev),error_m=error,slack_m=slack))
  if error<.0008 and slack>=0:goals.append(seedq.copy());break
  def constraint(x):
   ee,J,g,G,w,W=oracle.evaluate(x[:6]);return np.r_[g-x[6],w,.0007-np.linalg.norm(ee-target)]
  def jacobian(x):
   ee,J,g,G,w,W=oracle.evaluate(x[:6]);d=ee-target;return np.vstack([np.c_[G,-np.ones(len(g))],np.c_[W,np.zeros(len(w))],np.r_[-d/max(np.linalg.norm(d),1e-12)@J,0.]])
  objective=lambda x:-x[6]+1e-6*np.sum((x[:6]-q0)**2)
  gradient=lambda x:np.r_[2e-6*(x[:6]-q0),-1.]
  r=minimize(objective,np.r_[seedq,POLICY["goal_margin_m"]],jac=gradient,method="SLSQP",bounds=list(zip(oracle.lower,oracle.upper))+[(POLICY["goal_margin_m"],.012)],constraints=[dict(type="ineq",fun=constraint,jac=jacobian)],options=dict(maxiter=160,ftol=1e-10))
  anchor=r.x[:6];error=float(np.linalg.norm(oracle.gripper_position(anchor)-target));slack=oracle.exact_clearance(anchor)
  diagnostics.append(dict(kind="local",iterations=int(r.nit),error_m=error,slack_m=slack,message=str(r.message)))
  if error<.0008 and slack>=0:goals.append(anchor.copy());break
 return goals,diagnostics

class BiTree:
 def __init__(self,oracle,start,goal,rng,pad):
  self.oracle=oracle;self.rng=rng;self.lower=np.maximum(np.minimum(start,goal)-pad,oracle.lower);self.upper=np.minimum(np.maximum(start,goal)+pad,oracle.upper);self.trees=[([start.copy()],[-1]),([goal.copy()],[-1])];self.swapped=False;self.iterations=0
 def extend(self,tree,target):
  points,parents=tree;idx=int(np.argmin(np.linalg.norm(np.asarray(points)-target,axis=1)));d=target-points[idx];length=np.linalg.norm(d);new=target if length<=.08 else points[idx]+d*(.08/length)
  if not self.oracle.free(new) or not self.oracle.segment_free(points[idx],new):return None
  points.append(new.copy());parents.append(idx);return len(points)-1
 def branch(self,tree,index):
  path=[]
  while index>=0:path.append(tree[0][index]);index=tree[1][index]
  return path[::-1]
 def advance(self,count=64):
  for _ in range(count):
   self.iterations+=1;sample=self.trees[1][0][0] if self.iterations%10==0 else self.rng.uniform(self.lower,self.upper);i=self.extend(self.trees[0],sample)
   if i is not None:
    target=self.trees[0][0][i]
    while True:
     j=self.extend(self.trees[1],target)
     if j is None:break
     if np.linalg.norm(self.trees[1][0][j]-target)<1e-9:
      path=self.branch(self.trees[0],i)+self.branch(self.trees[1],j)[::-1][1:]
      return path[::-1] if self.swapped else path
   self.trees.reverse();self.swapped=not self.swapped
  return None

def _search_geometry(model,robot,arrays,initial_q,q0,target,generation,request_index,budget=None):
 start=time.perf_counter();budget=POLICY["planner_budget_s"] if budget is None else budget
 seed=POLICY["planner_seed"]+1000*request_index;rng=np.random.default_rng(seed);oracle=None
 result=dict(status="no_goal",generation=int(generation),request_index=request_index,planner_seed=seed,path=[],q_start=np.asarray(q0).tolist())
 try:
  key=geometry_key(arrays,initial_q,target)
  if _SEARCH_STATE.get("key")!=key:
   _SEARCH_STATE.clear();_SEARCH_STATE.update(key=key,oracle=CollisionOracle(model,robot,arrays,initial_q),goals=[])
  state=_SEARCH_STATE;oracle=state["oracle"];oracle.deadline=start+budget;oracle.margin=POLICY["goal_margin_m"];q0=np.asarray(q0);target=np.asarray(target)
  result["phase"]="local_goals";goals=list(state["goals"]);diagnostics=[]
  result["reused_goal_count"]=len(goals)
  oracle.deadline=start+budget*.35
  if not goals:
   try:goals,diagnostics=local_goals(oracle,q0,target,rng,oracle.deadline)
   except SearchDeadline:goals=[];diagnostics=[dict(kind="local",status="phase_budget_exhausted")]
  oracle.deadline=start+budget;result["goal_diagnostics"]=diagnostics
  # Cache successful IK independently of the optional direct-route shortcut.
  # A long-arc certificate can be expensive even for a feasible straight
  # joint path. Certify its actual bounded execution segments, and defer
  # this shortcut when its phase allowance expires rather than restarting IK.
  state["goals"]=list(goals)
  result["phase"]="local_direct_connection"
  saved_deadline=oracle.deadline;saved_margin=oracle.margin
  oracle.deadline=min(saved_deadline,time.perf_counter()+min(1.,budget*.15))
  oracle.margin=POLICY["operating_margin_m"]
  try:
   for goal in goals:
    count=max(1,int(np.ceil(np.max(np.abs(goal-q0))/POLICY["path_spacing_rad"])))
    nodes=[q0+(goal-q0)*t for t in np.linspace(0,1,count+1)]
    if all(oracle.segment_free(a,b) and oracle.segment_certified(a,b) for a,b in zip(nodes[:-1],nodes[1:])):
     result.update(status="path",phase="finished",path=[x.tolist() for x in nodes[1:]],goal=goal.tolist(),goals=len(goals),goal_slack_m=None,path_continuously_certified=True,certified_margin_m=POLICY["operating_margin_m"],nodes=len(nodes),local_direct_segments=count)
     return result
  except SearchDeadline:
   result["local_direct_deferred"]=True
  finally:
   oracle.deadline=saved_deadline;oracle.margin=saved_margin
  use_taskspace=POLICY.get("taskspace_posture_search",False)
  if use_taskspace:
   state["goals"]=goals;oracle.deadline=min(start+budget*.65,start+budget)
   try:add_posture_goals(oracle,q0,target,goals,state)
   except SearchDeadline:pass
   finally:oracle.deadline=start+budget
   result["posture_candidates_checked"]=state.get("posture_cursor",0)
   result["posture_feasible_count"]=state.get("posture_feasible_count",0)
   use_taskspace=state.get("posture_feasible_count",0)>0
  result["search_parameterization"]="taskspace_posture" if use_taskspace else "joint_space"
  # The global kinematic fallback sees only the robot and supplied proxy certifier.
  result["phase"]="global_goals"
  if len(goals)<8 and time.perf_counter()<start+budget*.65 and (not result.get("reused_goal_count") or state.get("route_failures",0)>=POLICY.get("goal_rediversify_after_route_failures",3)):
   state["route_failures"]=0
   if result.get("reused_goal_count"):state["goal_diversification_rounds"]=state.get("goal_diversification_rounds",0)+1
   branch_quota=min(8,1+state.get("goal_diversification_rounds",0))
   params=(qmc.Sobol(3,scramble=True,seed=seed).random_base2(15)*2-1)*np.pi
   if not np.any(oracle.execution.body_masks[:,5]):params[:,2]=q0[5]
   pool=analytic_candidates(model,target,params,q0)
   order=np.argsort(np.linalg.norm(pool-q0,axis=1),kind="stable")
   # Preserve shoulder/elbow/wrist diversity. The closest six poses may all
   # occupy one disconnected approach branch in a cluttered workspace.
   azimuth=np.arctan2(target[1],target[0])
   def branch(q):return (int(np.cos(q[0]-azimuth)>=0),int(np.sin(q[2])>=0),int(np.sin(q[4])>=0))
   observed_oracle=None;unseen_sensing=[]
   if np.any(oracle.guard.isbox):
    mask=~oracle.guard.isbox
    observed_arrays={k:(v[mask] if isinstance(v,np.ndarray) and len(v)==len(mask) else v) for k,v in arrays.items()}
    observed_oracle=CollisionOracle(model,robot,observed_arrays,initial_q);observed_oracle.deadline=oracle.deadline
   groups={}
   for q in pool[order]:groups.setdefault(branch(q),[]).append(q)
   cursors={k:0 for k in groups};represented={k:sum(branch(q)==k for q in goals) for k in groups}
   while groups and len(goals)<8 and time.perf_counter()<start+budget*.65:
    advanced=False
    for k in list(groups):
     if len(goals)>=8:break
     if represented.get(k,0)>=branch_quota:continue
     i=cursors[k]
     if i>=len(groups[k]):continue
     advanced=True;cursors[k]+=1;q=groups[k][i]
     if not oracle.free(q):
      # A robot-only IK posture feasible against measured obstacles can guide
      # sensing; it is NEVER accepted for execution while unseen space blocks it.
      if observed_oracle is not None and len(unseen_sensing)<32 and observed_oracle.free(q):
       p=observed_oracle.sphere_positions(q);ri,oi=oracle.guard.pairs(p,p,observed_oracle.radii+POLICY["goal_margin_m"])
       for obstacle in oi[oracle.guard.isbox[oi]]:
        point=oracle.guard.centers[int(obstacle)]
        if not any(np.linalg.norm(point-x)<.05 for x in unseen_sensing):unseen_sensing.append(point.copy())
        if len(unseen_sensing)>=32:break
       result["sensing_points"]=[x.tolist() for x in unseen_sensing]
      continue
     if np.linalg.norm(oracle.gripper_position(q)-target)>.0008:continue
     if any(np.max(np.abs(q-x))<.1 for x in goals):continue
     goals.append(q.copy());represented[k]=represented.get(k,0)+1
    if not advanced:break
    if not goals and result.get("sensing_points") and time.perf_counter()-start>POLICY.get("information_request_after_s",2.):
     result["status"]="needs_observation";return result
   result["goal_branches"]=[list(branch(q)) for q in goals]
  state["goals"]=list(goals)
  result["goals"]=len(goals);result["goals_found_s"]=time.perf_counter()-start;result["phase"]="start_operating_check"
  if not goals:return result
  goals.sort(key=lambda q:float(np.linalg.norm(q-q0)))
  oracle.margin=POLICY["operating_margin_m"]
  if not oracle.free(q0):result["status"]="start_not_operating_feasible";return result
  origin=q0.copy();bridge=[]
  result["phase"]="direct_connection"
  reuse=False
  if "origin" in state and state.get("tree_mode")==use_taskspace:
   oracle.margin=POLICY["operating_margin_m"]
   reuse=oracle.segment_free(origin,state["origin"]) and oracle.segment_certified(origin,state["origin"])
   oracle.margin=POLICY["operating_margin_m"]
  if reuse:
   if not np.array_equal(origin,state["origin"]):bridge.append(origin.copy())
   origin=state["origin"].copy();trees=state["trees"];path=state.get("pending_path")
   result["reused_tree_nodes"]=sum(len(t.trees[0][0])+len(t.trees[1][0]) for t in trees)
  else:
   state.pop("pending_path",None);path=None
   trees=[TaskspaceBiTree(oracle,origin,goals,np.random.default_rng(seed))] if use_taskspace else [BiTree(oracle,origin,g,np.random.default_rng(seed+17*i+int(pad*10)),pad) for pad in [.5,1.5,3.5] for i,g in enumerate(goals)]
   state.update(origin=origin.copy(),trees=trees,tree_goal_keys={g.tobytes() for g in goals},tree_mode=use_taskspace)
  if reuse:
   if use_taskspace:trees[0].add_goals(goals)
   else:
    represented=state.setdefault("tree_goal_keys",set())
    for i,g in enumerate(goals):
     if g.tobytes() not in represented:
      trees.extend(BiTree(oracle,origin,g,np.random.default_rng(seed+17*i+int(pad*10)),pad) for pad in [.5,1.5,3.5]);represented.add(g.tobytes())
  if path is None:
   for goal in goals:
    if oracle.segment_free(origin,goal):path=[origin,goal];break
  result["phase"]="rrt"
  while path is None and time.perf_counter()<oracle.deadline:
   for tree in trees:
    path=tree.advance(8)
    if path is not None:break
   if path is None and oracle.unknown_witnesses and time.perf_counter()-start>max(4.,budget*.4):
    result["status"]="needs_observation";return result
  if path is None:result["status"]="no_route";return result
  state["pending_path"]=list(path)
  result["phase"]="continuous_validation"
  path=bridge+path
  oracle.margin=POLICY["operating_margin_m"]
  # Certify bounded joint spans first. Certifying a long shortcut directly
  # can consume the budget in loose global arc bounds before any route exists.
  bounded=[path[0]]
  for a,b in zip(path[:-1],path[1:]):
   count=max(1,int(np.ceil(np.max(np.abs(b-a))/.08)))
   bounded.extend(a+(b-a)*t for t in np.linspace(0,1,count+1)[1:])
  path=bounded
  result["validation_edges"]=len(path)-1;result["validated_edges"]=0
  for a,b in zip(path[:-1],path[1:]):
   if not oracle.segment_certified(a,b):
    state.pop("pending_path",None);state.pop("origin",None);state.pop("trees",None)
    result["status"]="path_not_continuously_certified";return result
   result["validated_edges"]+=1
  # The certified route is usable even if optional shortening runs out of time.
  result["phase"]="shortcut"
  oracle.margin=POLICY["operating_margin_m"]
  for _ in range(12):
   if len(path)<3 or time.perf_counter()>oracle.deadline-.5:break
   i,j=sorted(rng.choice(len(path),2,replace=False))
   if j>i+1:
    try:ok=oracle.segment_free(path[i],path[j]) and oracle.segment_certified(path[i],path[j])
    except SearchDeadline:break
    if ok:path=path[:i+1]+path[j:]
  result["path_continuously_certified"]=True
  chain=[]
  for a,b in zip(path[:-1],path[1:]):
   count=max(1,int(np.ceil(np.max(np.abs(b-a))/POLICY["path_spacing_rad"])))
   chain.extend((a+(b-a)*t).tolist() for t in np.linspace(0,1,count+1)[1:])
  result.update(status="path",phase="finished",path=chain,goal=path[-1].tolist(),goal_slack_m=None,certified_margin_m=POLICY["operating_margin_m"],nodes=sum(len(t.trees[0][0])+len(t.trees[1][0]) for t in trees))
  return result
 except SearchDeadline:
  result["status"]="budget_exhausted";return result
 except Exception as exc:
  import traceback
  result.update(status="error",error=repr(exc),traceback=traceback.format_exc());return result
 finally:
  result["seconds"]=time.perf_counter()-start
  if oracle is not None:
   if result.get("phase")=="rrt" and result.get("status") in ["budget_exhausted","no_route"]:
    _SEARCH_STATE["route_failures"]=_SEARCH_STATE.get("route_failures",0)+1
   result["checks"]=oracle.checks
   if result.get("status")!="path" and oracle.unknown_witnesses:
    if result.get("goals",0)>0 or not result.get("sensing_points"):result["sensing_points"]=[x.tolist() for x in oracle.unknown_witnesses]


# A tentative route may direct sensing but never reaches the controller until
# the complete current map, including every unseen-space box, certifies it.
_SENSING_ROUTE={}
def search(model,robot,arrays,initial_q,q0,target,generation,request_index,budget=None):
 if not np.any(np.asarray(arrays["boxes"])>0):
  return _search_geometry(model,robot,arrays,initial_q,q0,target,generation,request_index,budget)
 started=time.perf_counter();budget=POLICY["planner_budget_s"] if budget is None else budget;deadline=started+budget
 q0=np.asarray(q0,dtype=float);target=np.asarray(target,dtype=float)
 context=hashlib.sha256(np.r_[initial_q,target].astype(float).tobytes()).hexdigest()
 if _SENSING_ROUTE.get("context")!=context:_SENSING_ROUTE.clear();_SENSING_ROUTE["context"]=context
 state=_SENSING_ROUTE;full_key=geometry_key(arrays,initial_q,target)
 if state.get("full_key")!=full_key:
  state["full_oracle"]=CollisionOracle(model,robot,arrays,initial_q);state["full_key"]=full_key
 full=state["full_oracle"];full.deadline=deadline;full.margin=POLICY["operating_margin_m"]
 keep=~np.any(np.asarray(arrays["boxes"])>0,axis=1)
 observed={k:(v[keep] if isinstance(v,np.ndarray) and len(v)==len(keep) else v) for k,v in arrays.items()}
 result=dict(status="needs_planning",generation=int(generation),request_index=request_index,planner_seed=POLICY["planner_seed"]+1000*request_index,path=[],q_start=q0.tolist(),phase="candidate_route",tentative_route_executed=False)
 try:
  candidate=state.get("candidate")
  if candidate is not None and not np.array_equal(np.asarray(candidate[0]),q0):candidate=None;state.pop("candidate",None)
  if candidate is None:
   remaining=deadline-time.perf_counter()
   if remaining<=.2:raise SearchDeadline()
   proposal=_search_geometry(model,robot,observed,initial_q,q0,target,generation,request_index,max(.1,remaining*.8))
   result.update({k:v for k,v in proposal.items() if k not in ["path","seconds","status","path_continuously_certified","certified_margin_m"]})
   result["measured_geometry_candidate_certified"]=bool(proposal.get("path_continuously_certified",False))
   result["path_continuously_certified"]=False
   if proposal.get("status")!="path":result["status"]=proposal["status"];return result
   candidate=[q0.tolist()]+proposal["path"];state["candidate"]=candidate
  result["candidate_route_points"]=len(candidate);result["phase"]="full_map_validation";unseen=[];measured=None
  def collect():
   for x in full.unknown_witnesses:
    if not any(np.linalg.norm(np.asarray(x)-np.asarray(y))<.035 for y in unseen):unseen.append(np.asarray(x).tolist())
    if len(unseen)>=32:break
  for index,q in enumerate(candidate):
   full.margin=POLICY["goal_margin_m"] if index==len(candidate)-1 else POLICY["operating_margin_m"]
   if full.free(np.asarray(q)):continue
   if measured is None:measured=CollisionOracle(model,robot,observed,initial_q)
   measured.deadline=deadline;measured.margin=full.margin
   if not measured.free(np.asarray(q)):
    state.pop("candidate",None);result["status"]="candidate_blocked_by_measured_geometry";return result
   collect()
   if len(unseen)>=16:break
  if unseen:
   result.update(status="needs_observation",path=[],sensing_points=unseen,candidate_route_for_sensing=candidate)
   return result
  full.margin=POLICY["operating_margin_m"]
  for a,b in zip(candidate[:-1],candidate[1:]):
   if full.segment_certified(np.asarray(a),np.asarray(b)):continue
   for t in [.25,.5,.75]:full.free(np.asarray(a)+(np.asarray(b)-a)*t)
   collect()
   if unseen:result.update(status="needs_observation",path=[],sensing_points=unseen,candidate_route_for_sensing=candidate);return result
   state.pop("candidate",None);result["status"]="candidate_not_continuously_certified";return result
  result.update(status="path",path=candidate[1:],goal=candidate[-1],path_continuously_certified=True,unknown_space_continuously_certified=True,certified_margin_m=POLICY["operating_margin_m"],phase="finished",goal_slack_m=None)
  return result
 except SearchDeadline:
  result["status"]="budget_exhausted";return result
 except Exception as exc:
  import traceback
  result.update(status="error",error=repr(exc),traceback=traceback.format_exc());return result
 finally:
  result["seconds"]=time.perf_counter()-started
