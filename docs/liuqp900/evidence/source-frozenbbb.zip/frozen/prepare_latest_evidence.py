from pathlib import Path
R=Path(__file__).resolve().parent
s=(R/'assess_goal_plane.py').read_text().replace('goal_plane_final_jobs.json','memory_aligned_jobs.json').replace('goal_plane_final_cycle_','memory_aligned_final_cycle_').replace('GOAL_PLANE_FINAL_EVIDENCE.json','MEMORY_ALIGNED_EVIDENCE.json')
s=s.replace("goal_plane_count=p['goal_side_planes']", "memory_certificate_refinements=p.get('memory_certificate_refinements',0),goal_plane_count=p['goal_side_planes']")
(R/'assess_memory_aligned.py').write_text(s)
s=(R/'audit_terminal_replay.py').read_text().replace("glob('certified*')","glob('memory_aligned*')").replace('TERMINAL_CERTIFICATE_REPLAY.json','LATEST_TERMINAL_CERTIFICATE_REPLAY.json');(R/'audit_latest_terminal.py').write_text(s)
