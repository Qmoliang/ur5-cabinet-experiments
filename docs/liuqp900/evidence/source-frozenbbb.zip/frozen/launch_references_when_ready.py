from pathlib import Path
import subprocess,time,sys
r=Path(__file__).resolve().parent
while not all((r/'trials'/n/'result.json').exists() for n in ['continuation_measured_1_v1','continuation_measured_2_v1']):time.sleep(5)
subprocess.run([sys.executable,str(r/'launch_continuation.py'),str(r/'reference_jobs.json')],check=True)
