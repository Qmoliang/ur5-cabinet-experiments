from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parent;p=R/'pilot_worker_progress.py';s=p.read_text().replace("        if job.get('policy_version')=='progress_retreat':","        if job.get('policy_version')=='progress_incremental':\n            from progress_incremental_policy import LowDimPolicy\n        elif job.get('policy_version')=='progress_retreat':");p.write_text(s)
j=json.loads((R/'development_jobs.json').read_text())
for x in j:x['name']=x['name'].replace('_v1','_v3');x['policy_version']='progress_incremental'
(R/'development_v3_jobs.json').write_text(json.dumps(j,indent=2));a=R/'revisions/progress_v3';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
s=(R/'launch_progress.py').read_text().replace('[40,41,42,43]','[32,33,34,35]').replace('[44,45,46,47]','[36,37,38,39]');(R/'launch_incremental.py').write_text(s)
