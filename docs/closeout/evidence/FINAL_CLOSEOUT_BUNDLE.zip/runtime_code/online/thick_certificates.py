"""How far do the frozen map's certificates reach beyond the real cabinet?

For each observed-surface proxy (frontier cells left out), sample its outer
ellipsoid E(c, S) = {c + S^(1/2) u : |u| <= 1} and take the largest distance
of a boundary sample to the nearest real box: the certificate's overshoot.
Then report the proxies nearest a chosen robot sphere at the run's final pose.
"""
import pickle
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
import run_protocol_v3_async_online as online  # noqa: E402
import mujoco  # noqa: E402

map_path, case, sphere_index = sys.argv[1], Path(sys.argv[2]), int(sys.argv[3])
stored = pickle.load(open(map_path, "rb"))
proxies, frontier = stored["proxies"], stored["frontier_cells"]
keep = len(proxies.centers) - frontier
centres = np.asarray(proxies.centers)[:keep]
outer = np.asarray(proxies.ellipsoid_outer_shapes)[:keep]
scene = online._protocol_scene("camera_quarter")
lo = np.array([np.asarray(b.center) - np.asarray(b.half_size) for b in scene.boxes])
hi = np.array([np.asarray(b.center) + np.asarray(b.half_size) for b in scene.boxes])


def box_distance(points):
    d = np.linalg.norm(np.maximum(0, np.maximum(lo[None] - points[:, None], points[:, None] - hi[None])), axis=2)
    return d.min(axis=1)


rng = np.random.default_rng(0)
u = rng.normal(size=(400, 3))
u /= np.linalg.norm(u, axis=1, keepdims=True)
overshoot = np.empty(keep)
axes = np.empty((keep, 3))
for i in range(keep):
    w, v = np.linalg.eigh(outer[i])
    root = v @ np.diag(np.sqrt(np.maximum(w, 0))) @ v.T
    overshoot[i] = box_distance(centres[i] + u @ root.T).max()
    axes[i] = np.sort(np.sqrt(np.maximum(w, 0)))
print(f"{keep} surface certificates: overshoot beyond real cabinet median {1000*np.median(overshoot):.1f} mm, "
      f"p90 {1000*np.percentile(overshoot, 90):.1f}, max {1000*overshoot.max():.1f}; "
      f"thin semi-axis median {1000*np.median(axes[:, 0]):.1f} mm, long median {1000*np.median(axes[:, 2]):.1f} mm")

model = online.build_model(scene)
data = mujoco.MjData(model)
robot = online.build_robot_certificate(model)
run = next(p for p in case.iterdir() if p.is_dir())
online.set_configuration(model, data, np.load(run / "q_history.npy")[-1])
p = online.certificate_world_positions(data, robot)[sphere_index]
r = robot[sphere_index].radius
# distance from the robot sphere to each certificate (boundary samples, approximate)
gaps = np.empty(keep)
for i in range(keep):
    w, v = np.linalg.eigh(outer[i])
    root = v @ np.diag(np.sqrt(np.maximum(w, 0))) @ v.T
    gaps[i] = np.linalg.norm(centres[i] + u @ root.T - p, axis=1).min() - r
for i in np.argsort(gaps)[:3]:
    print(f"  near sphere {sphere_index}: certificate at {centres[i].round(3)}, gap {1000*gaps[i]:.1f} mm, "
          f"semi-axes {np.round(1000*axes[i], 1)} mm, overshoot past real surface {1000*overshoot[i]:.1f} mm")
print(f"  sphere {sphere_index} true gap to real cabinet {1000*(box_distance(p[None])[0]-r):.1f} mm")
