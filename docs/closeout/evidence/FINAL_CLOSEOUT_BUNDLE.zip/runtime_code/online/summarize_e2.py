"""Compare guidance variants on the 20 known-cabinet start poses."""
import glob
import json
from pathlib import Path

import numpy as np

RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
VARIANTS = [("e0", "LiuQP alone"), ("e2b_stall_iris", "stall + IRIS-ZO"),
            ("e2b_stall_rrt", "stall + RRT vertices"), ("e2b_stall_rrtdense", "stall + RRT dense"),
            ("e2b_always_iris", "always + IRIS-ZO"), ("e2b_always_rrt", "always + RRT vertices")]
TRAPPED = {2, 3, 5, 6, 8, 9, 10, 13, 14, 15, 18}
rows = []
for folder, name in VARIANTS:
    runs = {}
    for path in glob.glob(str(RUNS / folder / "ellipsoid_075mm_seed*" / "summary.json")):
        seed = int(path.split("seed")[1][:2])
        summary = json.loads(Path(path).read_text())
        guidance_file = Path(path).with_name("guidance.json")
        events = json.loads(guidance_file.read_text())["events"] if guidance_file.exists() else []
        subgoal_counts = [e["subgoals"] for e in events if e["event"] == "planned"]
        runs[seed] = dict(success=summary["success"],
                          time=summary.get("first_sustained_success_time_s"),
                          penetrating=summary["exact_penetrating_cycles"],
                          calls=summary.get("guidance_calls") or 0,
                          failures=summary.get("guidance_failures") or 0,
                          plan_s=(summary.get("guidance_plan_ms_total") or 0.0) / 1000,
                          subgoals=subgoal_counts)
    if len(runs) != 20:
        print(f"{name}: only {len(runs)} runs finished")
        continue
    trapped = [runs[s] for s in TRAPPED]
    easy = [runs[s] for s in set(runs) - TRAPPED]
    reach_times = [r["time"] for r in trapped if r["success"]]
    planned = [r for r in runs.values() if r["calls"]]
    row = {
        "variant": name,
        "reached_all": sum(r["success"] for r in runs.values()),
        "reached_trapped": sum(r["success"] for r in trapped),
        "reached_easy": sum(r["success"] for r in easy),
        "penetrating_cycles": sum(r["penetrating"] for r in runs.values()),
        "trapped_reach_time_median_s": float(np.median(reach_times)) if reach_times else None,
        "easy_reach_time_median_s": float(np.median([r["time"] for r in easy if r["success"]])) if any(r["success"] for r in easy) else None,
        "plans_total": sum(r["calls"] for r in runs.values()),
        "plan_failures": sum(r["failures"] for r in runs.values()),
        "plan_s_per_run_median": float(np.median([r["plan_s"] for r in planned])) if planned else None,
        "subgoals_per_plan_median": float(np.median([n for r in planned for n in r["subgoals"]])) if planned else None,
        "trapped_failed_seeds": sorted(s for s in TRAPPED if not runs[s]["success"]),
        "easy_failed_seeds": sorted(s for s in set(runs) - TRAPPED if not runs[s]["success"]),
    }
    rows.append(row)
    print(json.dumps(row))
(RUNS / "e2b_summary.json").write_text(json.dumps(rows, indent=2))
