#!/bin/bash
cd /mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6
export MUJOCO_GL=egl OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
OUT=/mnt/ssd2/hsjed/ur5_cabinet/v6runs/known_sweep
run() {
  local id=${1}_$(printf "%03d" $(python3 -c "print(round($2*1000))"))mm
  UR5_KNOWN_CELL_SPAN=$2 UR5_KNOWN_OUT=$OUT/$id systemd-run --user --scope -q -p MemoryMax=32G -E UR5_KNOWN_CELL_SPAN -E UR5_KNOWN_OUT -E MUJOCO_GL -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS \
    taskset -c $3-$(($3+7)) timeout 21600 ~/envs/ur5cab/bin/python -c "
import sys,json,time; sys.path[:0]=[\"src\",\"src/core\",\".\"]
import run; t=time.time(); s=run.run(\"$1\", maximum_cycles=3000)
print(json.dumps({k:s.get(k) for k in (\"success\",\"final_error_m\",\"proxy_count\")}), \"wall_s\", round(time.time()-t,1))
" > $OUT/$id.log 2>&1
}
run ellipsoid 0.100 8   &
run ellipsoid 0.150 16  &
run ellipsoid 0.200 24  &
run ellipsoid 0.300 32  &
run sphere    0.040 40  &
run sphere    0.045 48  &
wait
echo DONE > $OUT/DONE2
