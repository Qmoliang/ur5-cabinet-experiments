from pathlib import Path
import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build
from goal_plane_acceptance_policy import LowDimPolicy as Old
from goal_plane_memory_policy import LowDimPolicy as New
R=ROOT;j=json.loads((R/'trials/goal_plane_regression_end_2/job.json').read_text());source=json.loads((R/'MEMORY_REJECTION_DIAGNOSIS.json').read_text());q=np.array(source['q']);v=np.array(source['raw_velocity']);ctx=build(j['task'],start=q,previous=np.zeros(6));old=Old(ctx,j,lambda **kw:None);new=New(ctx,j,lambda **kw:None)
a=old.memory_safe(q,v);b=new.memory_safe(q,v);assert not a and b
samples=np.linspace(0,1,2001);minimum=min(new._value(m,q+.02*t*v) for t in samples for m in new.memories)
out=dict(old_accepted=a,new_accepted=b,tolerance_unchanged=True,tolerance=-1e-10,minimum_dense_check=minimum,refinements=new.memory_bound_refinements,examples=new.memory_bound_examples,scope='analytic endpoint-consistent bound is the certificate; dense samples only cross-check it, not a replacement proof')
(R/'MEMORY_BOUND_VALIDATION.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
