"""Execution-time certificate checks for delayed commands and their braking continuation."""
from __future__ import annotations
import time
import numpy as np
import mujoco
from unified_policy import POLICY

class ExecutionGuard:
    def __init__(self,model,robot,dt=.02,margin=.006,acceleration=10.):
        assert abs(dt-POLICY["dt_s"])<1e-15 and abs(margin-POLICY["environment_margin_m"])<1e-12 and abs(acceleration-POLICY["acceleration_limit"])<1e-12
        self.model=model;self.data=mujoco.MjData(model);self.dt=dt;self.margin=margin;self.acceleration=acceleration
        self.joint_min=np.asarray(model.jnt_range[:6,0],dtype=float);self.joint_max=np.asarray(model.jnt_range[:6,1],dtype=float);self.joint_padding=POLICY["joint_padding_rad"]
        self.velocity_limits=np.array(POLICY["velocity_limits"]);self.joint_infeasible=0
        self.bodies=np.array([r.body_id for r in robot]);self.local=np.array([r.local_center for r in robot]);self.radii=np.array([r.radius for r in robot]);bounds=[]
        for b,p in zip(self.bodies,self.local):
            d=np.linalg.norm(p);b=int(b)
            while b:
                d+=np.linalg.norm(model.body_pos[b]);j0=model.body_jntadr[b]
                for j in range(j0,j0+model.body_jntnum[b]):d+=2*np.linalg.norm(model.jnt_pos[j])
                b=int(model.body_parentid[b])
            bounds.append(d)
        self.workspace_lower=np.array(POLICY["workspace_lower"]);self.workspace_upper=np.array(POLICY["workspace_upper"])
        self.self_pairs=np.empty((0,2),dtype=int);self.self_margin=POLICY["self_margin_m"];self.self_rejections=0
        self.max_depth=8;self.deadline_check=None;self.body_masks=[];self.body_curvature=[];self.point_invariant_joints={}
        for idx,(body,local) in enumerate(zip(self.bodies,self.local)):
            body=int(body);j=int(model.body_jntadr[body]);fixed=set()
            if model.body_jntnum[body]==1 and np.linalg.norm(np.cross(model.jnt_axis[j],local-model.jnt_pos[j]))<1e-14:fixed.add(j)
            self.point_invariant_joints[idx]=fixed
        for idx,(body,local) in enumerate(zip(self.bodies,self.local)):
            b=int(body);active=[];length=np.linalg.norm(local)
            while b:
                length+=np.linalg.norm(model.body_pos[b]);start=model.body_jntadr[b]
                for j in range(start,start+model.body_jntnum[b]):
                    if j not in self.point_invariant_joints[idx]:active.append(j)
                    length+=2*np.linalg.norm(model.jnt_pos[j])
                b=int(model.body_parentid[b])
            self.body_masks.append([j in active for j in range(6)]);self.body_curvature.append(2*length)
        self.body_masks=np.asarray(self.body_masks,dtype=float);self.body_curvature=np.asarray(self.body_curvature)
        self.executed_states=[]
        self.lever=2*max(bounds);self.calls=0;self.modified=0;self.failed=0;self.ms=[];self.events=[]
    def positions(self,q):
        self.data.qpos[:6]=q;mujoco.mj_kinematics(self.model,self.data)
        return self.data.xpos[self.bodies]+np.einsum('nij,nj->ni',self.data.xmat[self.bodies].reshape(-1,3,3),self.local)
    def set_self_pairs(self,pairs):
        self.self_pairs=np.asarray(pairs,dtype=int).reshape(-1,2).copy();lcas=[];masks=[];lever=[]
        for i,j in self.self_pairs:
            def ancestors(body):
                out=[]
                while True:
                    out.append(body)
                    if body==0:return out
                    body=int(self.model.body_parentid[body])
            ai=ancestors(int(self.bodies[i]));aj=set(ancestors(int(self.bodies[j])));common=next(body for body in ai if body in aj);lcas.append(common);pairmask=[];pairlever=[]
            for index in [i,j]:
                body=int(self.bodies[index]);length=np.linalg.norm(self.local[index]);active=[]
                while body!=common:
                    length+=np.linalg.norm(self.model.body_pos[body]);start=self.model.body_jntadr[body]
                    for k in range(start,start+self.model.body_jntnum[body]):
                        if k not in self.point_invariant_joints[index]:active.append(k)
                        length+=2*np.linalg.norm(self.model.jnt_pos[k])
                    body=int(self.model.body_parentid[body])
                pairmask.append([k in active for k in range(6)]);pairlever.append(2*length)
            masks.append(pairmask);lever.append(pairlever)
        self.lca=np.asarray(lcas,dtype=int);self.relative_masks=np.asarray(masks,dtype=float);self.relative_curvature=np.asarray(lever)
    def self_gap(self,p):
        if not len(self.self_pairs):return float('inf')
        i,j=self.self_pairs.T
        return float(np.min(np.linalg.norm(p[j]-p[i],axis=1)-self.radii[i]-self.radii[j]))
    def self_segment_bound(self,pa,pb,ra,rb,dq):
        if not len(self.self_pairs):return float('inf')
        i,j=self.self_pairs.T
        a=np.einsum('nji,nj->ni',ra[self.lca],pa[j]-pa[i]);b=np.einsum('nji,nj->ni',rb[self.lca],pb[j]-pb[i]);delta=b-a
        t=np.clip(-np.sum(a*delta,axis=1)/np.maximum(np.sum(delta*delta,axis=1),1e-30),0,1)
        amount=np.einsum('nkj,j->nk',self.relative_masks,np.abs(dq));padding=np.sum(self.relative_curvature*amount**2/8,axis=1)
        lower=np.linalg.norm(a+t[:,None]*delta,axis=1)-padding;B=4*padding
        for endpoint in [a,b]:
            normal=endpoint/np.maximum(np.linalg.norm(endpoint,axis=1)[:,None],1e-30)
            initial=np.einsum('ni,ni->n',normal,a);slope=np.einsum('ni,ni->n',normal,delta)
            tau=np.clip((B-slope)/np.maximum(2*B,1e-30),0,1)
            lower=np.maximum(lower,initial+tau*(slope-B)+B*tau*tau)
        return float(np.min(lower-self.radii[i]-self.radii[j]-2e-9))
    def segment(self,guard,q0,q1):
        def state(q):
            p=self.positions(q);return p,self.data.xmat.reshape(-1,3,3).copy()
        def certify(a,b,pa,pb,ra,rb,depth):
            if self.deadline_check is not None:self.deadline_check()
            curve=self.body_curvature*(self.body_masks@np.abs(b-a))**2/8
            environment=(guard.certify_curved(pa,pb,self.radii+self.margin+2e-7,curve) if hasattr(guard,"certify_curved") else guard.certify(pa,pb,self.radii+self.margin+curve+2e-7)).minimum_clearance_m>=-1e-10
            self_ok=self.self_segment_bound(pa,pb,ra,rb,b-a)>=self.self_margin-1e-10
            wa_all=np.concatenate([pa-self.workspace_lower-self.radii[:,None],self.workspace_upper-pa-self.radii[:,None]],axis=1)
            wb_all=np.concatenate([pb-self.workspace_lower-self.radii[:,None],self.workspace_upper-pb-self.radii[:,None]],axis=1)
            B=4*curve[:,None];slope=wb_all-wa_all;tau=np.clip((B-slope)/np.maximum(2*B,1e-30),0,1)
            work_bound=wa_all+tau*(slope-B)+B*tau*tau;wa=wa_all.min(axis=1);wb=wb_all.min(axis=1)
            if environment and self_ok and work_bound.min()>=-1e-10:return True
            if depth>=self.max_depth or min(wa.min(),wb.min())< -1e-10:return False
            if self.self_gap(pb)<self.self_margin-1e-10:return False
            if guard.certify(pb,pb,self.radii+self.margin+2e-7).minimum_clearance_m< -1e-10:return False
            mid=(a+b)/2;pm,rm=state(mid)
            return certify(a,mid,pa,pm,ra,rm,depth+1) and certify(mid,b,pm,pb,rm,rb,depth+1)
        pa,ra=state(q0);pb,rb=state(q1)
        return certify(q0,q1,pa,pb,ra,rb,0)
    def braking_safe(self,guard,q,v):
        current=q.copy();speed=v.copy()
        for _ in range(10):
            nxt=current+self.dt*speed
            if np.any(nxt<self.joint_min+self.joint_padding-1e-12) or np.any(nxt>self.joint_max-self.joint_padding+1e-12):return False
            if not self.segment(guard,current,nxt):return False
            current=nxt;speed=speed-np.clip(speed,-self.acceleration*self.dt,self.acceleration*self.dt)
            if np.max(np.abs(speed))<1e-12:return True
        return False
    def filter(self,guard,q,previous,proposed,lower,upper,cycle,generation):
        from unified_joint_braking import joint_velocity_bounds, JointLimitInfeasible
        t=time.perf_counter();self.calls+=1;self.executed_states.append(np.asarray(q).copy())
        try:
            safe_lower,safe_upper=joint_velocity_bounds(q,previous,self.joint_min,self.joint_max,self.velocity_limits,self.dt,self.acceleration,self.joint_padding)
            lower=np.maximum(lower,safe_lower);upper=np.minimum(upper,safe_upper)
            if np.any(lower>upper):raise JointLimitInfeasible('controller bounds conflict with execution braking bounds')
        except JointLimitInfeasible:
            self.joint_infeasible+=1
            if len(self.events)<100:self.events.append(dict(cycle=cycle,generation=int(generation),event='joint_braking_infeasible'))
            raise
        proposed=np.clip(proposed,lower,upper)
        if self.braking_safe(guard,q,proposed):chosen=proposed
        else:
            brake=np.clip(previous-np.clip(previous,-self.acceleration*self.dt,self.acceleration*self.dt),lower,upper)
            chosen=None
            for v in [brake+a*(proposed-brake) for a in (.75,.5,.25,.125,.0625,0.)]:
                if self.braking_safe(guard,q,v):chosen=v;break
            if chosen is None:
                self.failed+=1;chosen=brake
                if len(self.events)<100:self.events.append(dict(cycle=cycle,generation=int(generation),event='no_certified_braking_command'))
                p0=self.positions(q);env_gap=float(guard.certify(p0,p0,self.radii+self.margin).minimum_clearance_m);self_gap=self.self_gap(p0)
                import os,json
                from pathlib import Path
                folder=os.environ.get("UNIFIED_CASE_DIR")
                if folder:
                    folder=Path(folder);np.save(folder/"guard_failure_q_history.npy",np.array(self.executed_states))
                    source=getattr(guard,"cover",getattr(guard,"proxies",None))
                    if source is not None:
                        fields={}
                        for name in ["centers","ellipsoid_shapes","base_ellipsoid_shapes","sphere_radii","proxy_offset_radii","box_half_extents","cell_half_extents"]:
                            value=getattr(source,name,None)
                            if value is not None:fields[name]=np.asarray(value)
                        np.savez_compressed(folder/"guard_failure_proxies.npz",**fields)
                    (folder/"guard_failure.json").write_text(json.dumps(dict(cycle=cycle,generation=int(generation),q=np.asarray(q).tolist(),previous=np.asarray(previous).tolist(),proposed=np.asarray(proposed).tolist(),environment_slack_m=env_gap,self_gap_m=self_gap),indent=2))

                raise RuntimeError(f'No certified command; env_slack={env_gap}, self_gap={self_gap}, q={q.tolist()}')
            self.modified+=1
        self.ms.append(1000*(time.perf_counter()-t));return chosen
    def summary(self):
        return dict(required_margin_m=self.margin,self_required_margin_m=self.self_margin,self_pairs=len(self.self_pairs),self_continuous_and_braking_checked=True,self_common_ancestor_frame=True,workspace_continuous_checked=True,acceleration_limit=self.acceleration,calls=self.calls,modified=self.modified,failed=self.failed,ms_p50=float(np.median(self.ms)),ms_p99=float(np.percentile(self.ms,99)),events=self.events,braking_checked=True,joint_arc_remainder_included=True,joint_braking_checked=True,joint_infeasible=self.joint_infeasible)
