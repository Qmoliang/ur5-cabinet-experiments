"""Incremental directional coverage audit (UR5_INCREMENTAL_AUDIT=1, default on).

The audit proves, per CenterVox cell, the chain samples -> cell certificate ->
proxy certificate.  Each per-cell value depends only on that cell object and
the published parameters of its proxy.  Cells whose object is the same one
already audited (the manager reuses unchanged cells by identity) and whose
proxy parameters are bit-identical keep their cached values; only the rest are
recomputed.  The global minima/maxima are then taken over all cells as before.
"""
from pathlib import Path

p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/incremental_proxy_manager.py")
s = p.read_text()

old_head = '''        """Vectorized audit of the complete directional certificate chain."""

        proxies = self.snapshot
        keys = self._last_ordered_keys
'''
assert s.count(old_head) == 1
s = s.replace(old_head, '''        """Vectorized audit of the complete directional certificate chain."""

        if os.environ.get("UR5_INCREMENTAL_AUDIT", "1") == "1":
            return self._incremental_directional_coverage_audit(tolerance)
        proxies = self.snapshot
        keys = self._last_ordered_keys
''')

anchor = '''    def _adaptive_sphere_coverage_audit(
        self, tolerance: float
    ) -> ProxyCoverageAudit:'''
assert s.count(anchor) == 1
s = s.replace(anchor, '''    def _incremental_directional_coverage_audit(
        self, tolerance: float
    ) -> ProxyCoverageAudit:
        """Same proof as the full audit, recomputing only changed cells."""

        proxies = self.snapshot
        keys = self._last_ordered_keys
        cells = [self._cells[key] for key in keys]
        proxy_indices = np.asarray(proxies.filtered_cluster_indices, dtype=np.int64)
        # Everything of the owning proxy that enters a cell's audit values.
        rows = np.concatenate([
            np.asarray(proxies.centers, dtype=float)[proxy_indices],
            np.asarray(proxies.base_ellipsoid_shapes, dtype=float)[proxy_indices].reshape(-1, 9),
            np.asarray(proxies.proxy_uncertainty_shapes, dtype=float)[proxy_indices].reshape(-1, 9),
            np.asarray(proxies.sphere_radii, dtype=float)[proxy_indices, None],
            np.asarray(proxies.proxy_offset_radii, dtype=float)[proxy_indices, None],
        ], axis=1)
        cache = getattr(self, "_audit_cache", {})
        values = np.empty((len(keys), 5), dtype=float)
        todo = []
        for index, (key, cell) in enumerate(zip(keys, cells)):
            hit = cache.get(key)
            if hit is not None and hit[0] is cell and np.array_equal(hit[1], rows[index]):
                values[index] = hit[2]
            else:
                todo.append(index)
        raw_source_count = sum(int(sample.source_count) for cell in cells for sample in cell.samples.values())
        if todo:
            todo = np.asarray(todo, dtype=np.int64)
            sub_cells = [cells[i] for i in todo]
            representatives = np.asarray([c.representative for c in sub_cells], dtype=float)
            cell_shapes = np.asarray([c.uncertainty_shape for c in sub_cells], dtype=float)
            sample_points, sample_shapes, owners = [], [], []
            for local, cell in enumerate(sub_cells):
                for sample in cell.samples.values():
                    if sample.uncertainty_shape is None:
                        raise AssertionError("directional sample lost U")
                    sample_points.append(sample.point)
                    sample_shapes.append(sample.uncertainty_shape)
                    owners.append(local)
            owners = np.asarray(owners, dtype=np.int64)
            displacements = np.asarray(sample_points, dtype=float) - representatives[owners]
            candidates = (
                np.asarray(sample_shapes, dtype=float)
                if self._uses_partitioned_uncertainty or self.uncertainty_fusion_mode in {"support_interval_uncertainty", "raw_join_uncertainty"}
                else minkowski_outer_shapes(
                    np.asarray(sample_shapes, dtype=float),
                    np.einsum("ni,nj->nij", displacements, displacements),
                )
            )
            sample_values = self._batch_containment_values(candidates, cell_shapes[owners])
            center_values = np.full(len(todo), -np.inf)
            np.maximum.at(center_values, owners, sample_values)
            sub_proxy = proxy_indices[todo]
            offset_values = self._batch_containment_values(
                cell_shapes, np.asarray(proxies.proxy_uncertainty_shapes, dtype=float)[sub_proxy])
            deltas = representatives - np.asarray(proxies.centers, dtype=float)[sub_proxy]
            base_shapes = np.asarray(proxies.base_ellipsoid_shapes, dtype=float)[sub_proxy]
            solved = np.linalg.solve(base_shapes, deltas[:, :, None])[:, :, 0]
            ellipsoid_values = np.einsum("ni,ni->n", deltas, solved)
            published = (np.asarray(proxies.sphere_radii, dtype=float)
                         + np.asarray(proxies.proxy_offset_radii, dtype=float))[sub_proxy]
            uncertainty_radii = np.sqrt(np.maximum(np.linalg.eigvalsh(cell_shapes)[:, -1], 0.0))
            sphere_slacks = published - np.linalg.norm(deltas, axis=1) - uncertainty_radii
            offset_slacks = (np.asarray(proxies.proxy_offset_radii, dtype=float)[sub_proxy]
                             - np.asarray([c.cover_radius for c in sub_cells], dtype=float))
            fresh = np.stack([center_values, offset_values, ellipsoid_values, sphere_slacks, offset_slacks], axis=1)
            values[todo] = fresh
            for local, index in enumerate(todo):
                cache[keys[index]] = (cells[index], rows[index].copy(), fresh[local].copy())
        self._audit_cache = {key: cache[key] for key in keys}
        self.last_audit_recomputed_cells = len(todo)
        minimum_center_slack = float(np.min(1.0 - values[:, 0]))
        minimum_proxy_uncertainty_slack = float(np.min(1.0 - values[:, 1]))
        maximum_ellipsoid_value = float(np.max(values[:, 2]))
        minimum_sphere_slack = float(np.min(values[:, 3]))
        minimum_offset_slack = float(np.min(values[:, 4]))
        sphere_certificate_required = not (
            self.ellipsoid_cover_mode == "adaptive_irredundant"
            and self.radius_limit_representation == "ellipsoid"
        )
        certified = bool(
            minimum_center_slack >= -tolerance
            and minimum_offset_slack >= -tolerance
            and minimum_proxy_uncertainty_slack >= -tolerance
            and maximum_ellipsoid_value <= 1.0 + tolerance
            and (not sphere_certificate_required or minimum_sphere_slack >= -tolerance)
        )
        cover_inclusion_minimal = bool(
            self.ellipsoid_cover_mode != "adaptive_irredundant"
            or (
                proxies.certificate_cover_selected_count == len(proxies.centers)
                and proxies.certificate_cover_minimum_unique_witnesses > 0
            )
        )
        certified = bool(certified and cover_inclusion_minimal)
        return ProxyCoverageAudit(
            raw_sample_bins=raw_source_count,
            center_voxels=len(keys),
            proxy_count=len(proxies.centers),
            minimum_centervox_cover_slack=minimum_center_slack,
            minimum_proxy_offset_slack=minimum_offset_slack,
            maximum_base_ellipsoid_value=maximum_ellipsoid_value,
            minimum_sphere_certificate_slack=minimum_sphere_slack,
            all_raw_sample_balls_certified=certified,
            minimum_measurement_uncertainty_slack=minimum_center_slack,
            minimum_proxy_uncertainty_slack=minimum_proxy_uncertainty_slack,
            certificate_cover_inclusion_minimal=cover_inclusion_minimal,
            certificate_cover_candidate_count=proxies.certificate_cover_candidate_count,
            certificate_cover_selected_count=proxies.certificate_cover_selected_count,
            certificate_cover_reverse_deleted=proxies.certificate_cover_reverse_deleted,
            certificate_cover_minimum_unique_witnesses=proxies.certificate_cover_minimum_unique_witnesses,
        )

''' + anchor)
if "\nimport os\n" not in s:
    s = s.replace("import numpy as np\n", "import os\n\nimport numpy as np\n", 1)
p.write_text(s)
print("patched")
