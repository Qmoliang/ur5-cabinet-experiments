from pathlib import Path
import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build
from goal_side_plane_policy import LowDimPolicy
from diagnostic_exact_pruned_policy import LowDimPolicy as Local
R=ROOT;job=json.loads((R/'reproduction_jobs.json').read_text())[0];ctx=build(job['task']);p=LowDimPolicy(ctx,job,lambda **kw:None);out=[]
for name in ['exact_failure_trace','old_zero_delay','old_full_refresh_zero_delay_exact']:
 q=np.load(R/'trials'/name/'trajectory.npz')['q'][-1];p.k=0;state=Local.continuation_witnesses(p,q);env=[r for r in state['rows'] if r['kind']=='environment'];away=0;goal_away=0;records=[]
 for r in env:
  i,j=r['id'];x=p.future_guard.positions((1-r['fraction'])*q+r['fraction']*p.qg)[i].copy();_,n=ctx.proxy_guard.point_geometry(x[None,:],np.array([j]),optimizer=True);local=-n[0];local/=max(np.linalg.norm(local),1e-30);goal,offset=p.plane(i,j);d=p.goal_points[i]-x;dl=float(local@d);dg=float(goal@d);away+=int(dl<0);goal_away+=int(dg<0)
  if dl<0 and len(records)<4:records.append(dict(robot=i,proxy=j,fraction=r['fraction'],physical_slack=r['slack'],local_normal_goal_projection_m=dl,terminal_plane_goal_projection_m=dg))
 out.append(dict(name=name,colliding_environment_witnesses=len(env),nearest_normals_pointing_away_from_terminal_body_point=away,terminal_side_normals_pointing_away=goal_away,examples=records,scope='geometric comparison, not a claim that every motion away from the final end-effector target is wrong; temporary retreat remains allowed'))
(R/'GOAL_SIDE_GEOMETRY_EVIDENCE.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
