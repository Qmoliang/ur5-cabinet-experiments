#!/bin/bash
# Experiment A (approved 2026-10-28): target-depth sweep on the four always-failing scenes.
# Original LiuQP (sphere) and LiuQP-E (ellipsoid), straight attraction, original starts, 20 seeds,
# safety layer (self / floor rows, accel 10, least-violation fallback, protective stop), as bench_safe.
# Goal-pose clearance per target in parallel.  16 workers x 2 CPUs (CPUs 0-31), clearance on 32-51.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/depth_sweep
mkdir -p $P
SCENES=$(~/envs/ur5cab/bin/python /mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/e4/make_depth_scenes.py)
echo "$SCENES" > depth_sweep.scenes
i=0
for s in $SCENES; do
  taskset -c $((32 + i)) ~/envs/ur5cab/bin/python /mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/e4/goal_clearance.py $s >> depth_sweep_clearance.jsonl 2>/dev/null &
  i=$((i + 1))
done
jobs=()
for seed in $(seq 1 20); do
  for s in $SCENES; do
    for rep in sphere ellipsoid; do
      jobs+=("$s $rep $seed")
    done
  done
done
echo "${#jobs[@]} jobs" > depth_sweep.jobs
worker() {
  local w=$1
  for ((k = w; k < ${#jobs[@]}; k += 16)); do
    set -- ${jobs[$k]}
    id=${1}_${2}_straight_seed$(printf "%02d" $3)
    [ -f $P/liuqp/$id/summary.json ] && continue
    ./known_job.sh $P/liuqp $1 $2 straight $3 $((w * 2)) UR5_CONTROLLER=liuqp UR5_E4_SAFETY=1 UR5_ACCEL_LIMIT=10
  done
}
for w in $(seq 0 15); do worker $w & done
wait
echo DONE > depth_sweep.done
