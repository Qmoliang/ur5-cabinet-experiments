"""Experiment B online: the stall-triggered chained escape (escape_point.EscapePointGuidance) on the live map.

The escape plans only in what the cameras have published: its collision checker is the published
snapshot's own certificate guard (ContinuousProxyGuard: base ellipsoids, directional uncertainty, offsets,
unseen-space frontier cells), with LiuQP's 6 mm margin, plus the workspace / floor / self-collision rows.
On every map publication the checker switches to the new snapshot; goal postures that are no longer clear
are dropped (searched again at the next escape when none is left); a chain being followed is re-checked
and dropped when a newly seen obstacle blocks it, so the next stall plans again on the newer map.
No pause limit (as on the known map)."""
from __future__ import annotations

import json
import os
import time

import mujoco
import numpy as np

from escape_point import EscapePointGuidance, with_arm_limits
from guidance import ConfigurationChecker


class LiveMapChecker(ConfigurationChecker):
    """ConfigurationChecker over one published snapshot: clearance from the snapshot's certificate guard."""

    def __init__(self, model, certificate, guard, margin: float):
        self.model = model
        self.data = mujoco.MjData(model)
        self.robot = list(certificate)
        self.body_ids = np.array([sphere.body_id for sphere in certificate])
        self.local_centers = np.array([sphere.local_center for sphere in certificate])
        self.radii = np.array([sphere.radius for sphere in certificate])
        self.representation = "ellipsoid"
        self.set_guard(guard)
        self.margin = float(margin)
        self.index = None
        self.lower = model.jnt_range[:6, 0].copy()
        self.upper = model.jnt_range[:6, 1].copy()
        self.site = model.site("attachment_site").id
        self.checks = 0

    def set_guard(self, guard) -> None:
        self.guard = guard
        proxies = guard.proxies
        self.centers = np.asarray(proxies.centers, dtype=float)
        # World-axis half extents of each (rotated) ellipsoid: only the goal search's push-out
        # heuristic samples these; every legality decision uses the guard.
        shapes = np.asarray(proxies.base_ellipsoid_shapes, dtype=float).reshape(-1, 3, 3)
        self.axes = np.sqrt(np.maximum(np.einsum("nii->ni", shapes), 1e-12)) if len(shapes) else np.zeros((0, 3))

    def clearance(self, q: np.ndarray) -> float:
        self.checks += 1
        if np.any(q < self.lower) or np.any(q > self.upper):
            return -np.inf
        p = self.sphere_positions(q)
        return float(self.guard.certify(p, p, self.radii).minimum_clearance_m) - self.margin


def _spec(checker):
    """Picklable description of a live-map checker (its published snapshot as plain arrays)."""
    guard = checker.guard
    return dict(model=checker.model, robot=checker.robot, proxies=guard.proxies, eigenvalues=guard.eigenvalues,
                rotations=guard.rotations, uncertainty_eigenvalues=guard.uncertainty_eigenvalues,
                margin=checker.margin, initial_q=checker.initial_q)


def _worker_init(spec, rest):
    """Spawned search worker: rebuild the checker over the same snapshot (no MVT handle: the guard then
    pre-filters candidates by bounding boxes, the same certificates and exact distances)."""
    import types

    import escape_point
    from run_protocol_v3_async_online import ContinuousProxyGuard

    packet = types.SimpleNamespace(proxies=spec["proxies"], mvt=None, ellipsoid_eigenvalues=spec["eigenvalues"],
                                   ellipsoid_rotations=spec["rotations"],
                                   uncertainty_eigenvalues=spec["uncertainty_eigenvalues"])
    checker = LiveMapChecker(spec["model"], spec["robot"], ContinuousProxyGuard(packet, "ellipsoid"), spec["margin"])
    checker.initial_q = spec["initial_q"]
    escape_point._PARALLEL_JOB = (with_arm_limits(checker, spec["initial_q"]),) + tuple(rest)


def spawn_pool(job, workers):
    import multiprocessing as mp

    checker, *rest = job
    return mp.get_context("spawn").Pool(processes=workers, initializer=_worker_init, initargs=(_spec(checker), rest))


class OnlineEscape:
    def __init__(self, model, robot, controller, target, packet, guard, *, initial_q, seed: int, dt: float, margin=0.006):
        self.initial_q = np.asarray(initial_q, dtype=float).copy()
        self.generation = getattr(packet, "generation", 0)
        self.map_updates = 0
        self.invalidated = 0
        self.check_ms = []
        self.dt = float(dt)
        self.hold = 0
        self.held_total = 0
        self.command = np.asarray(target, dtype=float)
        live = LiveMapChecker(model, robot, guard, margin)
        live.initial_q = self.initial_q
        checker = with_arm_limits(live, self.initial_q)
        import escape_point
        escape_point.POOL = spawn_pool
        self.guidance = EscapePointGuidance(checker, controller, np.asarray(target, dtype=float),
                                            mode="chain", seed=seed, minimum_margin=margin,
                                            references=[self.initial_q])

    @property
    def active(self) -> bool:
        return self.guidance.escape_q is not None

    def on_map(self, packet, guard, cycle: int) -> None:
        started = time.perf_counter()
        g = self.guidance
        g.checker.set_guard(guard)   # the arm-limit wrapper reads the guard at call time
        self.map_updates += 1
        self.generation = getattr(packet, "generation", self.generation)
        if g.goals:
            g.goals = [q for q in g.goals if g.checker.free(q)] or None   # None: search again at the next escape
        if g.chain and g.escape_q is not None:
            rest = g.chain[g.chain_index:]
            blocked = next((k for k in range(len(rest) - 1)
                            if not g.checker.segment_free(rest[k], rest[k + 1], step=0.05)), None)
            if blocked is not None:
                self.invalidated += 1
                g.stats.events.append({"cycle": cycle, "event": "chain_invalidated", "left": len(rest),
                                       "blocked_leg": int(blocked), "generation": int(self.generation)})
                g.chain = []
                g._clear_escape()
        self.check_ms.append(1000 * (time.perf_counter() - started))

    def update(self, q, gripper, cycle: int) -> np.ndarray:
        g = self.guidance
        if self.hold > 0:
            # Waiting out the search: the escape's own clocks (point timeout, stall window) start only
            # once the arm may move.
            g.point_started = cycle
            g.escape_started = cycle
            g.history.clear()
            return self.command
        before = len(g.stats.events)
        command = g.update(np.asarray(q, dtype=float), np.asarray(gripper, dtype=float), cycle)
        self.command = command
        for e in g.stats.events[before:]:
            if e.get("event") == "escape_search":
                # The search blocks the loop while simulated time stands still; the arm waits that long
                # in simulated time too (zero velocity), so the pause shows in every reported time.
                self.hold += int(np.ceil(e.get("search_ms", 0.0) / 1000.0 / self.dt))
                self.held_total += int(np.ceil(e.get("search_ms", 0.0) / 1000.0 / self.dt))
        return command

    def holding(self) -> bool:
        if self.hold > 0:
            self.hold -= 1
            return True
        return False

    def finish(self, run_dir) -> dict:
        s = self.guidance.stats
        (run_dir / "guidance.json").write_text(json.dumps({"events": s.events, "subgoals": s.subgoals}, default=float))
        searches = [e for e in s.events if e.get("event") == "escape_search"]
        return dict(mode="escape_chain_online", track=os.environ.get("UR5_ESCAPE_TRACK", "frame"),
                    escapes=len(searches), chains=sum(e.get("result") == "chain" for e in searches),
                    search_s=[round(e.get("search_ms", 0) / 1000, 2) for e in searches],
                    pause_s=self.held_total * self.dt, map_updates=self.map_updates, chains_invalidated=self.invalidated,
                    map_check_ms_p50=float(np.median(self.check_ms)) if self.check_ms else None,
                    map_check_ms_max=float(max(self.check_ms)) if self.check_ms else None)
