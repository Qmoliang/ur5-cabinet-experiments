#!/bin/bash
# Escape rerun after the two chain fixes (2026-10-28): every junction leg is checked like an RRT edge and
# replaced by the checked route where it fails; a chain point counts as passed when the arm is near it or
# any later point up to the look-ahead target.  Plus the push-out goal fallback.  Scenes where the escape
# fires, 20 starts, joint-space and frame (Eq. 17) tracking.  12 workers x 8 CPUs, 120 s per run.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/escape_fixed
SCENES="drawer iris_4shelves_t0 iris_4shelves_t2 iris_bins_t0 iris_bins_t1"
jobs=()
for track in joint frame; do
  for seed in $(seq 1 20); do
    for scene in $SCENES; do
      jobs+=("$scene $seed $track")
    done
  done
done
echo "${#jobs[@]} jobs" > escape_fixed.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 12)); do
    set -- ${jobs[$i]}
    id=${1}_ellipsoid_straight_seed$(printf "%02d" $2)
    [ -f $P/$3/$id/summary.json ] && continue
    ./known_job.sh $P/$3 $1 ellipsoid straight $2 $((w * 8)) UR5_CONTROLLER=liuqp UR5_E4_SAFETY=1 UR5_ACCEL_LIMIT=10 \
      UR5_GUIDANCE=escape_chain UR5_ESCAPE_FAST=3 UR5_ESCAPE_TRACK=$3 UR5_MAX_CYCLES=6000 UR5_JOB_CPUS=8
  done
}
for w in $(seq 0 11); do worker $w & done
wait
echo DONE > escape_fixed.done
