from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;s=(R/'pilot_worker_goal_plane.py').read_text().replace("        if job.get('policy_version')=='goal_side_plane':","        if job.get('policy_version')=='goal_plane_acceptance':\n            from goal_plane_acceptance_policy import LowDimPolicy\n        elif job.get('policy_version')=='goal_side_plane':");(R/'pilot_worker_goal_plane_acceptance.py').write_text(s)
s=(R/'launch_goal_plane.py').read_text().replace("ROOT/'pilot_worker_goal_plane.py'","ROOT/'pilot_worker_goal_plane_acceptance.py'").replace('[32,33,34,35]','[48,49,50,51]').replace('[36,37,38,39]','[52,53,54,55]');(R/'launch_goal_plane_acceptance.py').write_text(s)
j=json.loads((R/'goal_plane_jobs.json').read_text())
for x in j:x['name']+='_accepted';x['policy_version']='goal_plane_acceptance'
(R/'goal_plane_acceptance_jobs.json').write_text(json.dumps(j,indent=2));a=R/'revisions/goal_plane_acceptance';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
(R/'GOAL_PLANE_ACCEPTANCE_FREEZE.json').write_text(json.dumps(dict(jobs=j,sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['goal_plane_acceptance_policy.py','goal_side_plane_policy.py','diagnostic_exact_pruned_policy.py','pilot_worker_goal_plane_acceptance.py']}),indent=2))
