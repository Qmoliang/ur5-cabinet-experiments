from pathlib import Path
import shutil,subprocess,sys,json,hashlib
R=Path(__file__).resolve().parent;a=R/'revisions/original_trace_worker';a.mkdir(parents=True,exist_ok=True)
for n in ['pilot_worker_continuation.py','launch_final.py','prepare_trace.py']:shutil.copy2(R/n,a/n)
subprocess.run([sys.executable,str(a/'prepare_trace.py')],check=True)
expected=json.loads((R/'trials/exact_failure_trace/source_hashes.json').read_text())['pilot_worker_progress.py'];actual=hashlib.sha256((a/'pilot_worker_progress.py').read_bytes()).hexdigest();assert actual==expected,(expected,actual);print('restored original trace worker',actual)
