from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;O=R.parent/'liuqp_entry_certificate_20261107'
base=json.loads((R/'development_v4_jobs.json').read_text())[0];jobs=[]
for name in ['final_original_cycle_1','final_original_cycle_repeat']:jobs.append(dict(base,name=name))
for i in [1,2]:
 j=dict(base);j.pop('latency_cycle_file');j.update(name='final_original_measured_'+str(i));jobs.append(j)
for oldname,newname in [('certified_failure_1','regression_failed_timing_1'),('certified_failure_2','regression_failed_timing_2'),('certified_end_1','regression_end_1'),('certified_end_2','regression_end_2'),('certified_measured_1','regression_stall_measured_1'),('certified_measured_2','regression_stall_measured_2')]:
 j=json.loads((O/'trials'/oldname/'job.json').read_text());j.pop('cpus',None);j.update(name=newname,policy_version='progress_bypass',trace_decisions=True,wall_limit_s=1200)
 if j.get('latency_ticks_file'):j['strict_latency_trace']=True
 jobs.append(j)
(R/'final_jobs.json').write_text(json.dumps(jobs,indent=2));s=(R/'launch_progress.py').read_text().replace('cpu_slots.put([40,41,42,43]);cpu_slots.put([44,45,46,47])','cpu_slots.put([48,49,50,51]);cpu_slots.put([52,53,54,55]);cpu_slots.put([56,57,58,59])').replace('max_workers=2','max_workers=3');(R/'launch_frozen.py').write_text(s)
a=R/'revisions/progress_final';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
files=list(R.glob('*.py'))+[R/'GOAL_BRANCH_PORTS.json',R/'INPUTS.json',R/'code/online/protocol_liuqp_controller.py',R/'code/common/policy.json']
(R/'FINAL_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_hashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},scope='same shelf, same terminal pose, actual progress acceptance plus short 2D task-space bypass contracts; no RRT or future configuration optimization',original_failure_schedule='complete 15000-cycle exogenous schedule; no tail extension',regression_schedule='old per-call timing files retained; strict exhaustion fails instead of extending',failure_policy='retain every attempt; no final-version modification based on outcomes'),indent=2));print('frozen',len(jobs),'runs')
