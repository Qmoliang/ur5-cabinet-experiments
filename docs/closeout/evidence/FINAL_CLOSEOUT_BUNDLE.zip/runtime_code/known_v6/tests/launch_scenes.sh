#!/bin/bash
# Known-map scenario batch: 40 workers x 2 CPUs (CPUs 0-79), each takes every 40th job.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
OUT=$PWD/scenes
mkdir -p $OUT
jobs=()
for seed in $(seq 1 20); do
  for scene in cage cage_wide wall; do
    for rep in ellipsoid sphere; do for attr in straight geodesic_native; do jobs+=("$scene $rep $attr $seed"); done; done
  done
  for attr in straight geodesic_native; do jobs+=("exit ellipsoid $attr $seed"); done
done
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 40)); do
    set -- ${jobs[$i]}
    id=$1_$2_$3_seed$(printf "%02d" $4)
    [ -f $OUT/$id/summary.json ] && continue
    ./known_job.sh $OUT $1 $2 $3 $4 $((w * 2))
  done
}
for w in $(seq 0 39); do worker $w & done
wait
echo DONE > $OUT/SCENES_DONE
