"""Geometry-driven outer-cover quality, without scene/seed selectors."""
import math,itertools
import numpy as np
from unified_policy import POLICY
def axis_partition(length):
    maximum=POLICY["maximum_cell_span_m"];epsilon=POLICY["axis_overhang_budget_m"]
    if length<=0:raise ValueError("nonpositive solid dimension")
    widths=[];x=0.;half=length*.5
    while half-x>1e-13:
        width=min(maximum,2*(x+epsilon)/(math.sqrt(3)-1),half-x)
        if width<=0 or len(widths)>10000:raise RuntimeError("partition did not converge")
        widths.append(width);x+=width
    if len(widths)>1 and widths[-1]<min(epsilon*.1,maximum*.01):
        last=(widths[-1]+widths[-2])*.5;widths=widths[:-2]+[last,last]
    widths=np.asarray(widths+widths[::-1]);edges=np.r_[0,np.cumsum(widths)];edges[-1]=length
    centers=(edges[:-1]+edges[1:])*.5;halves=(edges[1:]-edges[:-1])*.5
    error=np.maximum(math.sqrt(3)*halves-centers,centers+math.sqrt(3)*halves-length)
    assert error.max(initial=0)<=epsilon+1e-12
    return centers,halves
def partition_boxes(boxes):
    centers=[];halves=[];owners=[]
    for k,box in enumerate(boxes):
        origin=np.asarray(box.center)-np.asarray(box.half_size)
        axes=[axis_partition(2*float(h)) for h in box.half_size]
        for i,j,l in itertools.product(*[range(len(a[0])) for a in axes]):
            ids=[i,j,l];centers.append(origin+np.array([axes[d][0][ids[d]] for d in range(3)]));halves.append([axes[d][1][ids[d]] for d in range(3)]);owners.append(k)
    return np.asarray(centers),np.asarray(halves),np.asarray(owners,dtype=np.int64)
def outer_error(cover,boxes):
    bc=np.array([b.center for b in boxes])[cover.box_indices];bh=np.array([b.half_size for b in boxes])[cover.box_indices]
    ext=cover.aabb_half_extents
    return float(np.maximum(np.abs(cover.centers-bc)+ext-bh,0).max(initial=0))
def online_identity_quality(proxies):
    # Exact measured E(U)+B(r) cells and exact frontier boxes add no fitting overhang.
    if getattr(proxies,"certificate_cover_mode","")!="exact_cell_certificates":raise ValueError("online source cells must remain exact")
    return dict(rule="source_identity",extra_fitting_error_m=0.,uncertainty_preserved=True)
