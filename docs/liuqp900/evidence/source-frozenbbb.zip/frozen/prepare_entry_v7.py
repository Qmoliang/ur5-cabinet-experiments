"""Correct persistent-escape state transitions without changing task gains."""
from pathlib import Path
import json,hashlib,shutil,ast
ROOT=Path(__file__).resolve().parent
source=(ROOT/'goal_entry_policy_v5.py').read_text();tree=ast.parse(source);cls=next(x for x in tree.body if isinstance(x,ast.ClassDef));node=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='__call__')
method='    '+ast.get_source_segment(source,node)+'\n'
old="""        self.mode='OPEN';b=n@Jpoint;b/=max(np.linalg.norm(b),1e-12);chosen=self._try_direction(c,s,arrays,b);self.mode=previous_mode
        if chosen is not None:
            if self.mode!='OPEN':self.switch('OPEN','tangent_unavailable_reopen_surface')
            if self.brake_pending:return np.zeros(6)
            self.no_action_start=None;return self._publish(c,chosen[0])"""
new="""        # Radial correction is a subaction of the SAME boundary-following
        # episode; it must not re-enable Cartesian attraction or flush the
        # command queue on every temporary tangent obstruction.
        b=n@Jpoint;b/=max(np.linalg.norm(b),1e-12);chosen=self._try_direction(c,s,arrays,b)
        if chosen is not None:
            self.radial_subactions+=int(self.mode=='BYPASS')
            self.no_action_start=None;return self._publish(c,chosen[0])"""
assert old in method;method=method.replace(old,new)
old="""        self.expected=None;self.last_delta=np.zeros(6);self.current_s=s"""
new="""        self.expected=None;self.last_delta=np.zeros(6);self.current_s=s
        if not self.escape_active:
            history=[item['error_m'] for item in self.history[-100:]]
            stalled=(len(history)==100 and history[0]-min(history)<.0002 and self.error>.002 and np.max(np.abs(s['x']))<.002)
            if not stalled:return np.zeros(6)
            self.escape_active=True;self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8
            self.emit('original_liuqp_stall_activates_target_end_module',error_m=self.error,epoch=self.command_epoch)"""
assert old in method;method=method.replace(old,new)
prefix='''import numpy as np
from goal_entry_policy_v6 import LowDimPolicy as Previous
from goal_entry_policy import JointControl

class LowDimPolicy(Previous):
    def __init__(self,ctx,job,event):
        super().__init__(ctx,job,event);self.radial_subactions=0
        self.escape_active=bool(job.get('start_snapshot'))
'''
suffix='''    def summary(self):
        out=super().summary();out.update(persistent_radial_subactions=self.radial_subactions,escape_active=self.escape_active,activation='immediate for declared real-stall replay; otherwise original LiuQP until measured original-task stagnation',normal_correction_preserves_bypass_mode=True)
        return out
'''
(ROOT/'goal_entry_policy_v7.py').write_text(prefix+method+suffix);compile(prefix+method+suffix,'goal_entry_policy_v7.py','exec')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='goal_entry_v6':";new="        if job.get('policy_version')=='goal_entry_v7':\n            from goal_entry_policy_v7 import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_v6':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'entry_v6_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('entry_v6','entry_v7');j['policy_version']='goal_entry_v7'
(ROOT/'entry_v7_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_v7';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'ENTRY_V7_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},corrections=['keep radial corrections inside the persistent surface-following task instead of repeatedly switching back to Cartesian goal tracking','preserve unmodified original LiuQP from the public start until its own measured stagnation; replay starts are already declared stalled'],same_target_endpoint=True,same_goal_and_gains=True,same_physical_safety=True,no_route=True),indent=2))
print(json.dumps(jobs))
