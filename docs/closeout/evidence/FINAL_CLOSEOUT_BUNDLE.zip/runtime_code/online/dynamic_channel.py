"""Rows for detected moving objects, appended to the online LiuQP QP every cycle (E4).

The detector (dynamic_perception.py) publishes sphere certificates with a
velocity each at its capture time t_c.  At control time t they are moved to
c + v (t - t_c) (latency compensation) and grown by LATENCY_GROWTH |v| (t - t_c)
+ BASE_GROWTH (velocity error).  Each robot sphere i / certificate j pair within
the query distance gives one plane row n^T J_i qdot <= upper, n = (c_j - p_i)/|.|,
clearance d = |c_j - p_i| - r_i - r_j - safety margin, under one of three rules:

  liuqp      upper = n^T v + d / dt               (LiuQP with the obstacle at t + dt)
  liuqphe    the same, plus static copies at t + H/3, 2H/3, H (H = 0.3 s), escape on
  combined   upper = n^T v + (d - s * 0.1) / tau, tau = dt + 0.2 min(1, s / 0.05),
             s = max(0, -n^T v)  (known_v6/src/combined.py), task yield, escape on

The static map rows are untouched (their velocity is zero, where the combined
rule equals LiuQP).  Overlapping pairs also get LiuQP's contact-recovery row.
"""
from __future__ import annotations

import numpy as np

ID_BASE = 50_000_000
LATENCY_GROWTH = 0.25
BASE_GROWTH = 0.005
QUERY = 0.05             # base query distance; moving certificates add |v| * SWEEP_S
SWEEP_S = 0.3
MAX_PER_SPHERE = 8
REACTION_S, REFERENCE_SPEED, BUFFER_S, YIELD_S = 0.2, 0.05, 0.1, 0.6
HORIZON_S = 0.3


class DynamicChannel:
    def __init__(self, mode, dt, safety_margin, repulsive_speed=0.035, contact_distance=0.0):
        if mode.startswith("neo"):
            mode = "neo"   # detections only; online_neo.py builds NEO's own damper rows
        if mode not in ("liuqp", "liuqphe", "combined", "neo"):
            raise ValueError(mode)
        self.mode, self.dt = mode, float(dt)
        self.safety_margin, self.repulsive_speed = float(safety_margin), float(repulsive_speed)
        self.contact_distance = float(contact_distance)
        self.centers = np.empty((0, 3))
        self.radii = np.empty(0)
        self.velocities = np.empty((0, 3))
        self.ids = np.empty(0, dtype=np.int64)
        self.min_ttc = np.inf
        self.task_scale = 1.0
        self.approaching = set()
        self.rows_last = 0

    def set_detection(self, result, t_now):
        """Install the latest detector result, compensated to control time t_now."""
        if result is None or len(result["centers"]) == 0:
            self.centers, self.radii = np.empty((0, 3)), np.empty(0)
            self.velocities, self.ids = np.empty((0, 3)), np.empty(0, dtype=np.int64)
            return
        age = max(0.0, float(t_now) - float(result["t"]))
        v = np.asarray(result["velocities"], float)
        speed = np.linalg.norm(v, axis=1)
        centers = np.asarray(result["centers"], float) + v * age
        radii = np.asarray(result["radii"], float) + LATENCY_GROWTH * speed * age + BASE_GROWTH
        ids = ID_BASE + np.arange(len(centers))
        if self.mode == "liuqphe":
            copies = [centers + v * (f * HORIZON_S) for f in (1 / 3, 2 / 3, 1.0)]
            centers = np.vstack([centers, *copies])
            radii = np.concatenate([radii] * 4)
            v = np.vstack([v] + [np.zeros_like(v)] * 3)
            ids = ID_BASE + np.arange(len(centers))
        self.centers, self.radii, self.velocities, self.ids = centers, radii, v, ids

    def begin_cycle(self):
        if self.mode == "combined" and np.isfinite(self.min_ttc):
            self.task_scale = float(np.clip((self.min_ttc - REACTION_S) / (YIELD_S - REACTION_S), 0.0, 1.0))
        else:
            self.task_scale = 1.0
        self.min_ttc = np.inf
        self.approaching = set()

    def escape_ids(self):
        if self.mode == "combined":
            return set(self.approaching)
        return set(self.ids.tolist())

    def rows(self, positions, jacobians, radii):
        """[(row, upper, identity)] for this cycle (called inside the controller's QP assembly)."""
        out = []
        if len(self.centers) == 0:
            self.rows_last = 0
            return out
        delta = self.centers[None, :, :] - positions[:, None, :]
        length = np.linalg.norm(delta, axis=2)
        clearance = length - radii[:, None] - self.radii[None, :] - self.safety_margin
        speed = np.linalg.norm(self.velocities, axis=1)
        query = QUERY + (speed * SWEEP_S if self.mode == "combined" else 0.0)
        for i in range(len(positions)):
            candidates = np.nonzero(clearance[i] < query)[0]
            if not len(candidates):
                continue
            candidates = candidates[np.argsort(clearance[i, candidates])][:MAX_PER_SPHERE]
            for j in candidates:
                if length[i, j] < 1e-9:
                    continue
                n = delta[i, j] / length[i, j]
                row = n @ jacobians[i]
                d = float(clearance[i, j])
                shift = float(n @ self.velocities[j])
                if self.mode == "combined":
                    approach = max(0.0, -shift)
                    tau = self.dt + REACTION_S * min(1.0, approach / REFERENCE_SPEED)
                    upper = shift + (d - approach * BUFFER_S) / tau
                    if approach > 1e-9:
                        self.min_ttc = min(self.min_ttc, max(d, 0.0) / approach)
                        self.approaching.add(int(self.ids[j]))
                else:
                    upper = shift + d / self.dt
                out.append((row, float(upper), ("collision", i, int(self.ids[j]))))
                if d + self.safety_margin <= self.contact_distance:
                    penetration = max(0.0, -(d + self.safety_margin))
                    repulsion = self.repulsive_speed * min(1.0, 0.25 + penetration / max(self.safety_margin, 1e-12))
                    out.append((row, float(-repulsion + shift), ("contact_recovery", i, int(self.ids[j]))))
        self.rows_last = len(out)
        return out

    def exclusion(self, margin=0.05):
        """Spheres whose points must not enter the static map (tracked objects)."""
        return self.centers.copy(), self.radii + margin
