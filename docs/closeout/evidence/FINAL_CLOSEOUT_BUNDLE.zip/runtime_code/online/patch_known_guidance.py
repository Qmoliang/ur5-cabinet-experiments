"""Add the UR5_GUIDANCE switch to known_v6/run.py (idempotent).

Default ("off") leaves the loop exactly as before.  "iris_zo" feeds LiuQP the
current guidance target instead of the final target; success is still judged
against the final target.
"""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
source = path.read_text()
if "UR5_GUIDANCE" in source:
    print("already patched")
    raise SystemExit

edits = [
    (
        "    controller.osqp_max_iterations = int(osqp_max_iterations)\n",
        "    controller.osqp_max_iterations = int(osqp_max_iterations)\n"
        "    guidance = None\n"
        "    guidance_mode = os.environ.get(\"UR5_GUIDANCE\", \"off\")\n"
        "    if guidance_mode == \"iris_zo\":\n"
        "        sys.path.insert(0, str(ROOT.parent / \"online_v6\"))\n"
        "        from ball_tree import NativeBallTree\n"
        "        from guidance import ConfigurationChecker, StallTriggeredGuidance\n"
        "        # Planning keeps 10 mm more than LiuQP's safety margin so LiuQP can track it.\n"
        "        planner_tree = NativeBallTree(cover.centers, cover.aabb_half_extents)\n"
        "        checker = ConfigurationChecker(\n"
        "            model, robot, cover.centers, representation,\n"
        "            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,\n"
        "            margin=SAFETY_MARGIN + 0.010, index=planner_tree,\n"
        "        )\n"
        "        guidance = StallTriggeredGuidance(\n"
        "            checker, target, seed=int(os.environ.get(\"UR5_START_SEED\", \"0\")),\n"
        "        )\n"
        "    elif guidance_mode != \"off\":\n"
        "        raise ValueError(\"UR5_GUIDANCE must be off or iris_zo\")\n",
    ),
    (
        "            qdot, metrics = controller.solve(target)\n",
        "            command = target if guidance is None else guidance.current_target()\n"
        "            qdot, metrics = controller.solve(command)\n",
    ),
    (
        "            ee_history.append(ee.copy())\n",
        "            ee_history.append(ee.copy())\n"
        "            if guidance is not None:\n"
        "                guidance.update(q_after, ee, cycle)\n",
    ),
    (
        "        \"success\": maximum_success_hold >= SUCCESS_HOLD_CYCLES,\n",
        "        \"success\": maximum_success_hold >= SUCCESS_HOLD_CYCLES,\n"
        "        \"guidance_mode\": guidance_mode,\n"
        "        \"guidance_calls\": None if guidance is None else guidance.stats.calls,\n"
        "        \"guidance_failures\": None if guidance is None else guidance.stats.failures,\n"
        "        \"guidance_plan_ms_total\": None if guidance is None else float(sum(guidance.stats.plan_ms)),\n"
        "        \"guidance_plan_ms_max\": None if guidance is None else float(max(guidance.stats.plan_ms, default=0.0)),\n"
        "        \"guidance_regions\": None if guidance is None else guidance.stats.regions,\n",
    ),
    (
        "    np.save(output / \"q_history.npy\", np.asarray(q_history))\n",
        "    np.save(output / \"q_history.npy\", np.asarray(q_history))\n"
        "    if guidance is not None:\n"
        "        (output / \"guidance.json\").write_text(json.dumps(\n"
        "            {\"events\": guidance.stats.events, \"subgoals\": guidance.stats.subgoals}, indent=2))\n",
    ),
]
for old, new in edits:
    assert source.count(old) == 1, old
    source = source.replace(old, new)
path.write_text(source)
print("patched")
