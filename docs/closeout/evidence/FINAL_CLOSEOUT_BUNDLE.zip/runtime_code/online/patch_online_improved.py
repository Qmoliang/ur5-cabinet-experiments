"""Add online geodesic attraction (UR5_ONLINE_GEODESIC=1) to online_v6/run_protocol_v3_async_online.py.

The field is rebuilt for every published map in the background publication
step (native, ~0.1-0.3 s) and installed together with that map; the 50 Hz loop
only queries it.  Default off: the loop is unchanged.  Idempotent.
"""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/run_protocol_v3_async_online.py")
source = path.read_text()
if "UR5_ONLINE_GEODESIC" in source:
    print("already patched")
    raise SystemExit
edits = [
    (
        "def _prepare_publication(\n",
        "# Online geodesic attraction: set by run_one when UR5_ONLINE_GEODESIC=1.\n"
        "_GEODESIC = {\"enabled\": False, \"target\": None, \"build_ms\": []}\n"
        "\n"
        "\n"
        "def _attach_geodesic(packet, representation: str) -> None:\n"
        "    \"\"\"Build the geodesic field for this packet's proxies (native).\"\"\"\n"
        "    if not _GEODESIC[\"enabled\"]:\n"
        "        return\n"
        "    from geodesic_fast import NativeGeodesicAttractor\n"
        "    proxies = packet.proxies\n"
        "    if representation == \"sphere\":\n"
        "        field = NativeGeodesicAttractor(\n"
        "            proxies.centers, _GEODESIC[\"target\"], \"sphere\",\n"
        "            radii=np.asarray(proxies.sphere_radii) + np.asarray(proxies.proxy_offset_radii),\n"
        "        )\n"
        "    else:\n"
        "        field = NativeGeodesicAttractor(\n"
        "            proxies.centers, _GEODESIC[\"target\"], \"ellipsoid\",\n"
        "            shapes=proxies.ellipsoid_outer_shapes,\n"
        "        )\n"
        "    _GEODESIC[\"build_ms\"].append(field.build_ms)\n"
        "    packet.geodesic = field\n"
        "\n"
        "\n"
        "def _prepare_publication(\n",
    ),
    (
        "    except Exception:\n"
        "        materialized.close()\n"
        "        raise\n"
        "    return materialized, guard, observed\n",
        "    except Exception:\n"
        "        materialized.close()\n"
        "        raise\n"
        "    _attach_geodesic(materialized, representation)\n"
        "    return materialized, guard, observed\n",
    ),
    (
        "    active_packet = initial_packet\n",
        "    active_packet = initial_packet\n"
        "    _GEODESIC[\"enabled\"] = os.environ.get(\"UR5_ONLINE_GEODESIC\", \"0\") == \"1\"\n"
        "    _GEODESIC[\"target\"] = np.asarray(target, dtype=float)\n"
        "    _GEODESIC[\"build_ms\"] = []\n"
        "    _attach_geodesic(initial_packet, representation)\n"
        "    attractor = getattr(initial_packet, \"geodesic\", None)\n",
    ),
    (
        "                active_packet = next_packet\n",
        "                active_packet = next_packet\n"
        "                attractor = getattr(active_packet, \"geodesic\", attractor)\n",
    ),
    (
        "            qdot_proposed, metrics = controller.solve(target)\n",
        "            command = target if attractor is None else attractor.command(attachment_position(model, data))\n"
        "            qdot_proposed, metrics = controller.solve(command)\n",
    ),
    (
        "        \"perception_sync\": perception_sync,\n",
        "        \"perception_sync\": perception_sync,\n"
        "        \"online_geodesic\": _GEODESIC[\"enabled\"],\n"
        "        \"geodesic_build_ms_median\": float(np.median(_GEODESIC[\"build_ms\"])) if _GEODESIC[\"build_ms\"] else None,\n"
        "        \"online_reuse_counts\": getattr(controller, \"reuse_counts\", None),\n",
    ),
]
for old, new in edits:
    assert source.count(old) == 1, old[:80]
    source = source.replace(old, new)
path.write_text(source)
print("patched")
