from pathlib import Path
import time,subprocess
ROOT=Path(__file__).resolve().parent
waiting=['blocker_v5_joint_only_gate','blocker_v5_joint_only_from_stall']
while not all((ROOT/'trials'/name/'result.json').exists() for name in waiting):time.sleep(15)
print('Prior CPU slots finished; launching retained-geometry batch.',flush=True)
subprocess.run(['/home/hsjed/envs/ur5cab/bin/python','-u',str(ROOT/'launch_batch.py'),str(ROOT/'retained_jobs.json')],check=True)
