from pathlib import Path
import json,hashlib,shutil
R=Path(__file__).resolve().parent;s=(R/'pilot_worker_progress.py').read_text().replace("        if job.get('policy_version')=='progress_bypass':","        if job.get('policy_version')=='progress_execution':\n            from progress_execution_policy import LowDimPolicy\n        elif job.get('policy_version')=='progress_bypass':");(R/'pilot_worker_execution_progress.py').write_text(s)
s=(R/'launch_incremental.py').read_text().replace("ROOT/'pilot_worker_progress.py'","ROOT/'pilot_worker_execution_progress.py'");(R/'launch_execution_progress.py').write_text(s)
j=json.loads((R/'development_v4_jobs.json').read_text())
for x in j:x['name']=x['name'].replace('_v4','_v5');x['policy_version']='progress_execution'
(R/'execution_progress_jobs.json').write_text(json.dumps(j,indent=2));a=R/'revisions/progress_execution';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
(R/'EXECUTION_PROGRESS_FREEZE.json').write_text(json.dumps(dict(jobs=j,source_hashes={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in R.glob('*.py')},scope='separate execution-time nonlinear progress acceptance intervention; preceding final-freeze files are not modified'),indent=2))
