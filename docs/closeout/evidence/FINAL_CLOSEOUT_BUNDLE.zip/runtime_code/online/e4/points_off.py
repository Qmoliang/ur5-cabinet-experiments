"""Distance of the map's cell representatives outside the true boxes (signed distance to the union)."""
import json, sys, csv
from pathlib import Path
import numpy as np
run, scene_json = Path(sys.argv[1]), sys.argv[2]
inner = next(run.glob("A-CV-*"))
p = np.load(inner / "final_causal_proxies.npz")
boxes = json.load(open(scene_json))["boxes"]
bc = np.array([b["center"] for b in boxes]); bh = np.array([b["half_size"] for b in boxes])
pts = p["filtered_points"]; U = p["filtered_uncertainty_shapes"]
q = np.abs(pts[:, None, :] - bc[None]) - bh[None]
d = (np.linalg.norm(np.maximum(q, 0), axis=2) + np.minimum(q.max(axis=2), 0)).min(axis=1)
ue = np.sqrt(np.linalg.eigvalsh(U)[:, -1])
rows = list(csv.DictReader(open(inner / "cycles.csv")))
ids = list(p["proxy_ids"]); focus = p["centers"][ids.index(int(float(rows[-1]["limiting_proxy_id"])))]
near = np.linalg.norm(pts - focus, axis=1) < 0.08
for name, m in (("all", np.ones(len(d), bool)), ("near limiting", near)):
    print(f"{name:14s} n={m.sum():6d} representative distance outside boxes p50/p90/p99/max mm: "
          + " ".join(f"{np.percentile(d[m], q)*1e3:5.1f}" for q in (50, 90, 99, 100))
          + f" | uncertainty major semi-axis p50/p90 {np.percentile(ue[m],50)*1e3:4.1f} {np.percentile(ue[m],90)*1e3:4.1f}")
