#!/bin/bash
# E2 rerun with the margin ladder: every guidance variant, same 20 start poses.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
COMMON="UR5_KNOWN_INDEX=ball_tree UR5_GUIDANCE=iris_zo"
run() { ./launch_seeds.sh $PWD/e2b_$1 ellipsoid 0.075 $2 $COMMON UR5_GUIDANCE_TRIGGER=$3 UR5_GUIDANCE_SUBGOALS=$4; }
run stall_iris      64  stall  iris &
run stall_rrt       84  stall  rrt &
run stall_rrtdense  104 stall  rrt_dense &
wait
run always_iris     64  always iris &
run always_rrt      84  always rrt &
wait
echo DONE > $PWD/E2B_DONE
