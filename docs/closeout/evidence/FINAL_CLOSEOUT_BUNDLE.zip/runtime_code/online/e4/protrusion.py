"""How far do the online certificates reach beyond the true geometry?  For each observed certificate
near a point, protrusion = max over directions of (certificate support - support of the nearest true box).
Split into the parts: ellipsoid core, uncertainty shape, offset."""
import json, sys
from pathlib import Path
import numpy as np

run, scene_json, radius = Path(sys.argv[1]), sys.argv[2], float(sys.argv[3]) if len(sys.argv) > 3 else 0.08
inner = next(run.glob("A-CV-*"))
p = np.load(inner / "final_causal_proxies.npz")
boxes = json.load(open(scene_json))["boxes"]
bc = np.array([b["center"] for b in boxes]); bh = np.array([b["half_size"] for b in boxes])
br = [np.array(b.get("rotation", np.eye(3).tolist())) if "rotation" in b else np.eye(3) for b in boxes]
c = p["centers"]; Q = p["ellipsoid_shapes"]; U = p["proxy_uncertainty_shapes"]; off = p["uncertainty_offsets"]
unseen = np.all(np.abs(U.reshape(len(c), -1)) < 1e-15, axis=1)
import csv
rows = list(csv.DictReader(open(inner / "cycles.csv")))
lim = int(float(rows[-1]["limiting_proxy_id"])); ids = list(p["proxy_ids"])
focus = c[ids.index(lim)] if lim in ids else np.array([float(rows[-1][k]) for k in ("ee_x", "ee_y", "ee_z")])
rng = np.random.default_rng(0); n = rng.normal(size=(400, 3)); n /= np.linalg.norm(n, axis=1, keepdims=True)
sel = np.where((np.linalg.norm(c - focus, axis=1) < radius) & ~unseen)[0]
def box_support(i, n):
    R = br[i]; return n @ bc[i] + np.abs(n @ R) @ bh[i]
out = []
for k in sel:
    core = np.sqrt(np.maximum(np.einsum("ni,ij,nj->n", n, Q[k], n), 0))
    unc = np.sqrt(np.maximum(np.einsum("ni,ij,nj->n", n, U[k], n), 0))
    h = n @ c[k] + core + unc + off[k]
    # nearest box = the one whose support excess is smallest
    exc = [np.max(h - box_support(i, n)) for i in range(len(boxes))]
    i = int(np.argmin(exc)); j = int(np.argmax(h - box_support(i, n)))
    out.append((exc[i], core[j], unc[j], off[k]))
out = np.array(out)
print(f"{run.name}: focus {focus.round(3)}, {len(sel)} observed certificates within {radius} m")
for q in (50, 90, 99, 100):
    print(f"  p{q}: protrusion {np.percentile(out[:,0],q)*1000:5.1f} mm  (core {np.percentile(out[:,1],q)*1000:4.1f}, uncertainty {np.percentile(out[:,2],q)*1000:4.1f}, offset {np.percentile(out[:,3],q)*1000:4.1f})")
