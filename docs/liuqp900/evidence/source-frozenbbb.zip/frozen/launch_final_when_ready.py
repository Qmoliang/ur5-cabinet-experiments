from pathlib import Path
import time,subprocess
ROOT=Path(__file__).resolve().parent
waiting=['blocker_v3_joint_only_from_stall','blocker_v4_joint_only_from_stall']
while not all((ROOT/'trials'/name/'result.json').exists() for name in waiting):time.sleep(15)
print('Both prior CPU slots finished; launching final frozen batch.',flush=True)
subprocess.run(['/home/hsjed/envs/ur5cab/bin/python','-u',str(ROOT/'launch_batch.py'),str(ROOT/'blocker_v5_jobs.json')],check=True)
