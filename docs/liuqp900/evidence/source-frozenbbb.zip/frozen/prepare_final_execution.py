from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
source=(ROOT/'verified_qp.py').read_text();assert 'except RuntimeError:return None' in source
source=source.replace('import numpy as np','import numpy as np\nNUMERICAL_REJECTIONS=0',1)
source=source.replace('except RuntimeError:return None','''except (RuntimeError,np.linalg.LinAlgError):
        global NUMERICAL_REJECTIONS
        NUMERICAL_REJECTIONS+=1
        return None''')
compile(source,'verified_qp_recovery.py','exec');(ROOT/'verified_qp_recovery.py').write_text(source)
source=(ROOT/'pilot_worker.py').read_text()
source=source.replace('from pilot_adapter import build,online,POLICY,FORBIDDEN_COUNTS',"import importlib\nsys.modules['verified_qp']=importlib.import_module('verified_qp_recovery')\nfrom pilot_adapter import build,online,POLICY,FORBIDDEN_COUNTS")
source=source.replace('ctx=None; rows=[];',"qp_braking=False;qp_brake_steps=0;qp_failure_events=[]\nctx=None; rows=[];",1)
old="        if job.get('policy_version')=='goal_entry_v7':";new="        if job.get('policy_version')=='goal_entry_final':\n            from goal_entry_policy_final import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_v7':";assert old in source;source=source.replace(old,new)
old='            t=time.perf_counter();command,metrics=ctl.solve(ctx.target);elapsed=time.perf_counter()-t'
new='''            if policy is not None:policy.expected=None
            ctl.pilot_supplied_solution=None
            t=time.perf_counter();command,metrics=ctl.solve(ctx.target);elapsed=time.perf_counter()-t
            if str(metrics.status).lower().startswith('solved'):qp_braking=False'''
assert old in source;source=source.replace(old,new)
old="            if policy is not None and policy.expected is not None:";new="            if str(metrics.status).lower().startswith('solved') and policy is not None and policy.expected is not None:";assert old in source;source=source.replace(old,new)
old="""            if not str(metrics.status).lower().startswith('solved'):
                status='qp_not_converged';event(event=status,cycle=k,solver_status=str(metrics.status));break"""
new="""            if not str(metrics.status).lower().startswith('solved'):
                qp_failure_events.append(dict(cycle=k,status=str(metrics.status),previous_max=float(np.max(np.abs(previous))),charged_ticks=ticks))
                if not job.get('certified_feasibility_brake',False):
                    status='qp_not_converged';event(event=status,cycle=k,solver_status=str(metrics.status));break
                if np.max(np.abs(previous))<1e-8:
                    status='qp_not_solved_at_rest';event(event=status,cycle=k,solver_status=str(metrics.status));break
                brake_lower,brake_upper=ctl.joint_velocity_bounds()
                certified_brake=np.clip(previous-np.clip(previous,-POLICY['acceleration_limit']*dt,POLICY['acceleration_limit']*dt),brake_lower,brake_upper)
                physical_stop=ctx.guard.braking_safe(ctx.proxy_guard,q,certified_brake)
                memory_stop=policy is None or not hasattr(policy,'memory_safe') or policy.memory_safe(q,certified_brake)
                if not physical_stop or not memory_stop:
                    status='qp_failure_without_certified_brake';event(event=status,cycle=k,physical_stop=physical_stop,memory_stop=memory_stop);break
                delay=new_delay();delay['remaining']=max(1,ticks);qp_braking=True
                ctl._previous_qp_dual=None
                event(event='qp_failure_certified_brake_and_retry',cycle=k,solver_status=str(metrics.status),charged_ticks=ticks)"""
assert old in source;source=source.replace(old,new)
old="        if policy is not None and (policy.brake_pending or policy.terminal):"
new="""        if qp_braking:
            brake_lower,brake_upper=ctl.joint_velocity_bounds()
            command=np.clip(previous-np.clip(previous,-POLICY['acceleration_limit']*dt,POLICY['acceleration_limit']*dt),brake_lower,brake_upper)
            applied_delta=np.zeros(6);applied_mode='FEASIBILITY_BRAKE';qp_brake_steps+=1
        elif policy is not None and (policy.brake_pending or policy.terminal):"""
assert old in source;source=source.replace(old,new)
source=source.replace("        if modified:delay=new_delay();ctl.previous_velocity=actual.copy()","        if modified:delay=new_delay();ctl.previous_velocity=actual.copy()\n        if qp_braking:ctl.previous_velocity=actual.copy()")
source=source.replace("    result['solver_profile']=job.get('solver_profile','original')","    result['solver_profile']=job.get('solver_profile','original')\n    result['qp_failure_events']=qp_failure_events\n    result['qp_certified_braking_steps']=qp_brake_steps\n    result['numerical_fallback_rejections']=getattr(sys.modules['verified_qp'],'NUMERICAL_REJECTIONS',0)")
compile(source,'pilot_worker_recovery.py','exec');(ROOT/'pilot_worker_recovery.py').write_text(source)
source=(ROOT/'launch_batch.py').read_text().replace("ROOT/'pilot_worker.py'","ROOT/'pilot_worker_recovery.py'")
assert 'pilot_worker_recovery.py' in source;(ROOT/'launch_recovery_batch.py').write_text(source)
jobs=[j for j in json.loads((ROOT/'entry_v7_jobs.json').read_text()) if j['persistent_memory']]
for j in jobs:j['name']=j['name'].replace('entry_v7','entry_final');j['policy_version']='goal_entry_final';j['certified_feasibility_brake']=True
(ROOT/'entry_final_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_final';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'FINAL_EXECUTION_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},controller_law_unchanged_from_v7=True,corrections=['activate by actual original-task stagnation even when joints still move','on failed original QP, execute only the existing physically and memory-certified braking continuation, charge solver latency as braking intervals, clear stale commands, and retry','stop with failure if QP remains unsolved at rest or braking cannot be certified','clear per-solve expected-command data before solving; reject singular numerical fallback instead of uncaught exception'],original_qp_constraints_not_relaxed=True,physical_safety_not_relaxed=True,no_route=True,controls='v7 ablations reused as versioned reference; they completed their budgets without QP-failure recovery'),indent=2))
print(json.dumps(jobs))
