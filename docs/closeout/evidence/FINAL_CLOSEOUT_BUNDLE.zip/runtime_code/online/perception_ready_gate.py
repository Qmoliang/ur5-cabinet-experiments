"""Common stop-and-sense initialization before entering the confined approach.
The hold uses the current pose, not a navigation waypoint or a privileged map.
"""
import numpy as np
class PerceptionReadyGate:
    def __init__(self,initial_position,target,threshold=.4,required_frames=2):
        self.target=np.asarray(target);self.threshold=threshold;self.required_frames=required_frames;self.state='braking';self.hold_q=None;self.hold_position=None;self.settled_cycle=None;self.generations=[];self.events=[];self.brake_cycles=0
    def confirm_initial(self,q,generations):
        if len(set(generations))<self.required_frames:return
        self.hold_q=np.asarray(q).copy();self.generations=list(generations);self.state='done'
        self.events.append(dict(event='certified_stationary_initial_maps',cycle=0,generations=list(generations)))
    @property
    def ready(self):return self.state=='done'
    @property
    def active(self):return self.state in ('braking','waiting')
    def update(self,q,p,velocity,cycle):
        if self.state=='approach' and np.linalg.norm(np.asarray(p)-self.target)<=self.threshold:
            self.state='braking';self.events.append(dict(event='stop_for_fresh_map',cycle=cycle,error_m=float(np.linalg.norm(np.asarray(p)-self.target))))
        if self.state=='braking' and np.max(np.abs(velocity))<1e-6:
            self.state='waiting';self.hold_q=np.asarray(q).copy();self.hold_position=np.asarray(p).copy();self.settled_cycle=cycle;self.events.append(dict(event='stationary',cycle=cycle,q=self.hold_q.tolist()))
    def on_map(self,packet,cycle):
        if self.state!='waiting':return
        if packet.source_cycle>=self.settled_cycle and np.max(np.abs(np.asarray(packet.source_q)-self.hold_q))<5e-4 and packet.generation not in self.generations:
            self.generations.append(int(packet.generation));self.events.append(dict(event='fresh_stationary_frame',cycle=cycle,generation=int(packet.generation),source_cycle=int(packet.source_cycle)))
            if len(self.generations)>=self.required_frames:self.state='done';self.events.append(dict(event='resume_final_target',cycle=cycle))
    def command(self,current_position):return np.asarray(current_position) if self.hold_position is None else self.hold_position
    def brake(self,previous,dt,acceleration):
        self.brake_cycles+=1;return previous-np.clip(previous,-acceleration*dt,acceleration*dt)
    def summary(self):return dict(state=self.state,threshold_m=self.threshold,required_fresh_frames=self.required_frames,brake_hold_cycles=self.brake_cycles,events=self.events,counts_within_120s_horizon=True)
