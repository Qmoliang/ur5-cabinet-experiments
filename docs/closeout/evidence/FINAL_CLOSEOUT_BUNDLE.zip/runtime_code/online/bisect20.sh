#!/bin/bash
# Bisect the seed-20 failure: native CenterVox kernels and bucket-major assembly on/off.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export UR5_CENTERVOX=0.005 UR5_STATIC_DEDUP=1 UR5_FIT_WORKERS=8 UR5_FRONTIER_CELL_VOXELS=1 UR5_FRONTIER_MERGE=1 UR5_FRONTIER_FINE_RADIUS=0.15
OUT=v6runs/bisect20; rm -rf $OUT; mkdir -p $OUT
slot=0
for native in 1 0; do for major in 1 0; do
  id=native${native}_major${major}
  UR5_NATIVE_CENTERVOX=$native UR5_BUCKET_MAJOR=$major systemd-run --user --scope -q -p MemoryMax=32G \
    -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_CENTERVOX \
    -E UR5_STATIC_DEDUP -E UR5_FIT_WORKERS -E UR5_FRONTIER_CELL_VOXELS -E UR5_FRONTIER_MERGE -E UR5_FRONTIER_FINE_RADIUS \
    -E UR5_NATIVE_CENTERVOX -E UR5_BUCKET_MAJOR \
    timeout 2400 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py ellipsoid --map incremental \
    --timing paced --cpus $((slot * 32)):32 --start-seed 20 --frontier --geodesic --look --static-cameras low_side \
    --out $OUT/$id > $OUT/$id.log 2>&1 &
  slot=$((slot + 1))
done; done
wait
echo DONE > $OUT/DONE
