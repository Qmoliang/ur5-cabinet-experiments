#!/bin/bash
# One E4 run (online drawer, best live configuration + moving objects).
# Usage: e4_one.sh <out_dir> <start_seed> <first_cpu> <controller: liuqp|liuqphe|combined> <objects> <speed>
OUT=$1; seed=$2; cpu=$3; ctl=$4; k=$5; speed=$6
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export UR5_COMPUTE_DELAY=${UR5_COMPUTE_DELAY:-0} UR5_NO_RETURN_FREE=${UR5_NO_RETURN_FREE:-0} UR5_CENTERVOX=${UR5_CENTERVOX:-0.005} UR5_STATIC_DEDUP=1 UR5_FIT_WORKERS=8 UR5_FRONTIER_MERGE=1 UR5_FRONTIER_FINE_RADIUS=0.15 UR5_FRONTIER_CELL_VOXELS=1
mkdir -p $(dirname $OUT)
systemd-run --user --scope -q -p MemoryMax=${E4_MEM:-32G} -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID \
  -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_CENTERVOX -E UR5_FRONTIER_CELL_VOXELS \
  -E UR5_STATIC_DEDUP -E UR5_FIT_WORKERS -E UR5_FRONTIER_MERGE -E UR5_FRONTIER_FINE_RADIUS -E UR5_NO_RETURN_FREE -E UR5_COMPUTE_DELAY -E UR5_NEO_MOVING_INFLUENCE -E UR5_DEPTH_DROPOUT -E UR5_DEPTH_NOISE_UNIFORM \
  timeout ${E4_TIMEOUT:-2400} ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py ${E4_REP:-ellipsoid} --map incremental \
  --timing paced --cpus $cpu:16 --start-seed $seed --frontier ${E4_GEODESIC:+--geodesic} --look --static-cameras low_side_detect --scene ${E4_SCENE:-drawer} --far-start \
  --objects $k --object-speed $speed --e4-controller $ctl --accel 10 --e4-seed $((seed + 100)) \
  --cycles ${E4_CYCLES:-3000} --out $OUT > $OUT.log 2>&1
# Keep the analysis files; drop the large per-publication snapshots.
rm -f "$OUT"/A-CV-*/causal_*_snapshots.npz
