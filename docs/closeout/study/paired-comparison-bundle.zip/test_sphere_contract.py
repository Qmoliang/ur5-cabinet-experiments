"""Preflight of representation propagation and geometric correctness; no task runs."""
from pathlib import Path
import os,sys,json,hashlib,importlib.util,inspect,datetime
from types import SimpleNamespace
import numpy as np,mujoco
V=Path(__file__).resolve().parent;B=V.parent/'final_r17'
sys.path[:0]=[str(V/'code/common'),str(V/'code/online'),str(V/'audit_tools')]
from proxy_geometry import ExactProxyGuard,from_published
from independent_geometry import IndependentGuard
from pointcloud_proxy import PointCloudProxySet
from collision_oracle import CollisionOracle
from unified_policy import POLICY
import run_protocol_v3_async_online as online
from mixed_geometry import install,HybridProxyGuard
from online_escape import OnlineEscape
import active_depth_views as views

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ps(C,Q,off,boxes):
 vals,rot=np.linalg.eigh(Q);r=np.sqrt(vals[:,-1]);n=len(C)
 return PointCloudProxySet(raw_points=C.copy(),filtered_points=C.copy(),centers=C,sphere_radii=r,ellipsoid_shapes=Q,rotations=rot,cluster_keys=np.arange(n)[:,None],filtered_cluster_indices=np.arange(n),maximum_ellipsoid_overshoot=0.,proxy_offset_radii=off,filtered_uncertainty_shapes=Q.copy(),proxy_uncertainty_shapes=np.zeros_like(Q),base_sphere_radii=r.copy(),base_ellipsoid_shapes=Q.copy(),ellipsoid_outer_shapes=Q.copy(),proxy_ids=np.arange(n,dtype=np.int64),filtered_point_offsets=off.copy(),box_half_extents=boxes)
report={'scope':'fixed-input module checks, not additional scene experiments','tests':{}}
# Primitive truth is analytic, independent of both production certifiers.
rng=np.random.default_rng(53419);C=np.array([[.3,.1,.5],[.4,-.2,.6],[.6,.1,.4]])
Q=np.array([np.diag(np.array(x)**2) for x in [[.025,.003,.008],[.015,.004,.006],[.004,.004,.004]]]);off=np.array([.001,.002,0.]);boxes=np.array([[0,0,0],[0,0,0],[.0025,.0025,.0025]])
proxies=ps(C,Q,off,boxes);a=from_published(proxies,'sphere');g=ExactProxyGuard(a)
p=C[rng.integers(0,3,600)]+rng.uniform(-.045,.045,(600,3));ids=rng.integers(0,3,600);delta=C[ids]-p
expected=np.where(ids==2,np.linalg.norm(np.maximum(np.abs(delta)-boxes[ids],0),axis=1),np.linalg.norm(delta,axis=1)-proxies.sphere_radii[ids])-off[ids]
dist,normal=g.point_geometry(p,ids);assert np.max(np.abs(dist-expected))<1e-12
n=rng.normal(size=(600,3));n/=np.linalg.norm(n,axis=1)[:,None]
support=np.where(ids==2,np.sum(np.abs(n)*boxes[ids],axis=1),proxies.sphere_radii[ids])+off[ids]
assert np.max(np.abs(g.support(n,ids)-support))<1e-12
ind=IndependentGuard(C,Q,off,proxies.sphere_radii,boxes,'sphere')
robot_r=np.full(len(p),.003);brute=np.linalg.norm(p[:,None]-C,axis=2)-proxies.sphere_radii[None]-off[None]-robot_r[:,None]
brute[:,2]=np.linalg.norm(np.maximum(np.abs(p-C[2])-boxes[2],0),axis=1)-robot_r
reference=min(.02,float(brute.min()));assert abs(ind.reference_gap(p,robot_r)-reference)<1e-12
assert abs(g.certify(p,p,robot_r).minimum_clearance_m-min(0,reference))<1e-12
report['tests']['analytic_sphere_distance_support_and_independent_audit']={'queries':600,'maximum_error_m':float(np.max(np.abs(dist-expected)))}
# A thin-axis witness must be free for the ellipsoid and blocked for its enclosing ball.
single=ps(C[:1],Q[:1],off[:1],boxes[:1]);x=C[:1]+np.array([[0,.012,0]])
es=ExactProxyGuard(from_published(single,'ellipsoid')).certify(x,x,np.array([.002])).safe
ss=ExactProxyGuard(from_published(single,'sphere')).certify(x,x,np.array([.002])).safe
assert es and not ss
report['tests']['anisotropic_witness_switches_geometry']={'ellipsoid_free':es,'sphere_free':ss}
# Identical isotropic sets must behave identically for continuous certification.
iso=ps(C[:2],np.array([np.eye(3)*.01**2,np.eye(3)*.02**2]),off[:2],boxes[:2]);gs=ExactProxyGuard(from_published(iso,'sphere'));ge=ExactProxyGuard(from_published(iso,'ellipsoid'))
max_iso=0.
for _ in range(100):
 x=C[:1]+rng.uniform(-.04,.04,(1,3));y=x+rng.uniform(-.006,.006,(1,3));rr=np.array([.003]);curve=np.array([.0001])
 # Avoid interior points: the ellipsoid implementation reports unsigned interior distance.
 if min(np.linalg.norm(z[0]-C[j])-iso.sphere_radii[j] for z in [x,y] for j in range(2))<.001:continue
 sv=gs.certify_curved(x,y,rr,curve).minimum_clearance_m;ev=ge.certify_curved(x,y,rr,curve).minimum_clearance_m;max_iso=max(max_iso,abs(sv-ev));assert abs(sv-ev)<1e-7
report['tests']['isotropic_continuous_equivalence']={'maximum_difference_m':max_iso}
# All source inputs are identical; only top-level treatment metadata changes.
spec=json.loads((V/'EVALUATION_SPEC.json').read_text());base_spec=json.loads((B/'EVALUATION_SPEC.json').read_text());assert spec['matrix_cases']==base_spec['matrix_cases'];assert spec['smoke_cases']==base_spec['smoke_cases']
assert (V/'code/common/policy.json').read_bytes()==(B/'code/common/policy.json').read_bytes()
assert (V/'acceptance_policy.json').read_bytes()==(B/'acceptance_policy.json').read_bytes()
assert all(sha(Path(p))==h for p,h in json.loads((V/'INPUT_MANIFEST.json').read_text()).items())
report['tests']['same_300_inputs_and_criteria']=True
# Reconstruct a real recorded model; constructors do not execute a trajectory.
case=B/'runs/online__cage__s01';run=next(case.glob('A-CV-*'));cfg=json.loads((case/'case.json').read_text());model=mujoco.MjModel.from_xml_path(str(run/'scene.xml'));data=mujoco.MjData(model);q=np.array(cfg['initial_configuration']);data.qpos[:6]=q;mujoco.mj_forward(model,data);robot=online.build_robot_certificate(model)
positions=online.certificate_world_positions(data,robot);radii=np.array([s.radius for s in robot]);site=model.site('attachment_site').id;target=data.site_xpos[site].copy()+[.05,0,0]
near=positions[-1];C2=np.array([near+[.04,0,.02],near+[0,.08,.03],near+[.09,0,.02]])
small=ps(C2,Q,off,boxes);packet=SimpleNamespace(proxies=small,mvt=None,ellipsoid_eigenvalues=None,ellipsoid_rotations=None,uncertainty_eigenvalues=None,generation=0)
scene=SimpleNamespace(boxes=[],waypoints=[target])
install(online);ctl=online._new_controller('sphere',model,data,scene,robot,small,None,ellipsoid_pair_threads=1)
assert ctl.representation=='sphere' and ctl.obstacle_shapes is None
assert np.array_equal(ctl.obstacle_radii,small.sphere_radii[:2])
guard=online.ContinuousProxyGuard(packet,'sphere');assert isinstance(guard,HybridProxyGuard) and guard.representation=='sphere'
guide=OnlineEscape(model,robot,ctl,target,packet,guard,initial_q=q,seed=42,dt=.02)
try:
 assert guide.oracle.guard.representation=='sphere'
 online._update_controller(ctl,packet,'sphere');guide.on_map(packet,guard,0)
 assert ctl.representation==guide.oracle.guard.representation=='sphere'
 assert np.array_equal(guide.oracle.guard.isbox,np.any(boxes>0,axis=1))
finally:guide.executor.shutdown(wait=True)
report['tests']['controller_planner_map_update_and_guard_propagation']=True
# New ellipsoid branch must preserve the existing view selection, including LOS.
old_spec=importlib.util.spec_from_file_location('baseline_active_views',B/'code/common/active_depth_views.py');oldmod=importlib.util.module_from_spec(old_spec);old_spec.loader.exec_module(oldmod)
names=[model.camera(i).name for i in range(model.ncam) if model.camera(i).name.startswith('static_')]
if not names:
 # Saved scene XML precedes runtime rig insertion. Restore the recorded public rig
 # for this fixed-input view-policy test; both implementations receive the same rig.
 import xml.etree.ElementTree as ET
 xml=ET.parse(run/'scene.xml');world=xml.getroot().find('worldbody')
 for cam in cfg['cameras']:
  ET.SubElement(world,'camera',name=cam['name'],pos=' '.join(map(str,cam['position'])),fovy='58')
 model=mujoco.MjModel.from_xml_string(ET.tostring(xml.getroot(),encoding='unicode'))
 names=[cam['name'] for cam in cfg['cameras']]
assert len(names)==4
class FreeOccupancy:
 def certify_swept_spheres(self,*args,**kwargs):return SimpleNamespace(safe=True)
occupancy=FreeOccupancy();roi=(np.array([-.9,-.9,0]),np.array([.9,.9,1.3]));poses=model.cam_pos.copy();quats=model.cam_quat.copy()
def viewrun(cls,rep,proxies):
 model.cam_pos[:]=poses;model.cam_quat[:]=quats
 obj=cls(model,robot,names,roi,representation=rep) if cls is views.ActiveDepthViews else cls(model,robot,names,roi)
 updates=obj.choose(proxies,positions,radii,occupancy,target=target,sensing_points=[target])
 return updates
original=viewrun(oldmod.ActiveDepthViews,'ellipsoid',small);current=viewrun(views.ActiveDepthViews,'ellipsoid',small)
assert original==current and len(current)>0
iso2=ps(C2,np.array([np.eye(3)*r*r for r in small.sphere_radii]),off,boxes)
spherical=viewrun(views.ActiveDepthViews,'sphere',small);isotropic=viewrun(oldmod.ActiveDepthViews,'ellipsoid',iso2)
assert len(spherical)==len(isotropic)>0
for x,y in zip(spherical,isotropic):
 assert x['camera']==y['camera'] and np.allclose(x['position'],y['position'],rtol=0,atol=1e-9) and np.allclose(x['focus'],y['focus'],rtol=0,atol=1e-9)
 assert abs(x['score']-y['score'])<1e-8
report['tests']['ellipsoid_view_behavior_unchanged']={'camera_updates':len(current),'exact_match':True}
report['tests']['sphere_view_matches_isotropic_reference']={'camera_updates':len(spherical),'passed':True}
# Saved maps provide real uncertainty sets; verify the ball construction for all tasks.
map_checks=[]
for key in [k for k in spec['matrix_cases'] if k.endswith('__s01')]:
 p=next((B/'runs'/key).rglob('causal_proxy_snapshots.npz'));z=np.load(p);lo,hi=map(int,z['offsets'][:2]);qq=z['ellipsoid_shapes'][lo:hi];rr=z['sphere_radii'][lo:hi];bb=z['box_half_extents'][lo:hi];measured=~np.any(bb>0,axis=1);difference=np.max(np.abs(rr[measured]-np.sqrt(np.maximum(np.linalg.eigvalsh(qq[measured])[:,-1],0))))
 assert difference<1e-10
 map_checks.append(dict(id=key,cells=int(measured.sum()),max_radius_error_m=float(difference)))
report['tests']['15_task_recorded_map_enclosing_ball_checks']=map_checks
report['passed']=True;report['created_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(V/'REPRESENTATION_PREFLIGHT.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2),flush=True)
