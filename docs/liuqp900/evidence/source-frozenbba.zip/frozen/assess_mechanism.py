from pathlib import Path
import json,hashlib,numpy as np
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_reheading_study_20261107'
read=lambda p:json.loads(p.read_text())
checks={}
for i in [1,2]:
 a=ROOT/'trials'/('reference_failure_'+str(i))/'trajectory.npz';b=OLD/'trials'/('reheading_v2_measured_'+str(i))/'trajectory.npz'
 if a.exists():
  aa=np.load(a)['q'];bb=np.load(b)['q'];n=min(len(aa),len(bb));checks['failure_'+str(i)]=dict(same_length=len(aa)==len(bb),states=n,max_q_difference=float(np.max(np.abs(aa[:n]-bb[:n]))))
a=ROOT/'trials/certified_failure_1/trajectory.npz';b=ROOT/'trials/certified_failure_1_repeat/trajectory.npz'
if a.exists() and b.exists():
 aa=np.load(a)['q'];bb=np.load(b)['q'];checks['repeat_failure_1']=dict(same_length=len(aa)==len(bb),max_q_difference=float(np.max(np.abs(aa-bb))) if aa.shape==bb.shape else None)
records=[]
for f in sorted((ROOT/'trials').glob('certified*')):
 if not (f/'result.json').exists():continue
 r=read(f/'result.json');ps=r['policy_summary'];z=np.load(f/'trajectory.npz');q=z['q'];v=z['velocity'];m=z['control_mode'];qg=np.array(ps['goal_port']['goal_q']);enter=np.flatnonzero(m=='CERT_ENTER');residual=[];rates=[]
 for k in enter:
  d=qg-q[k];alpha=float(d@v[k]/max(d@d,1e-30));residual.append(float(np.linalg.norm(v[k]-alpha*d)));rates.append(alpha)
 transitions=[e for e in ps['continuation_events'] if e['mode']=='CERT_ENTER'];first=None if not transitions else transitions[0]['cycle'];n=len(v) if first is None else min(len(v),first+1)
 records.append(dict(name=f.name,initial_error_mm=float(z['goal_error'][0]*1000),peak_preparation_error_mm=float(np.max(z['goal_error'][:n])*1000),first_certified_entry_s=None if first is None else first*.02,preparation_joint_change_rad=(q[n]-q[0]).tolist(),entry_executed_cycles=len(enter),max_entry_ray_velocity_residual_rad_s=max(residual,default=None),minimum_entry_scalar_rate=min(rates,default=None),inherited_memories=ps['memory_count'],latency_tail_uses=r['latency_trace_tail_uses'],certificate_calls=ps['continuation_certificates'],certificate_passes=ps['continuation_passes'],certificate_rejections=ps['continuation_gate_rejections']))
freeze=read(ROOT/'FINAL_FREEZE.json');changed=[name for name,d in freeze['manifest'].items() if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=d]
old=read(ROOT/'PROTECTED_PREVIOUS_STUDY.json');old_changed=[p for p,d in old.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest()!=d]
assert not changed and not old_changed
out=dict(reference_and_repeat=checks,final_trials=records,freeze_changed=changed,protected_old_count=len(old),protected_old_changed=old_changed,metadata_correction='Inherited policy_summary.current_goal_q_tracking=false is stale for CERT_ENTER: final implementation deliberately follows one fixed terminal joint-contraction feedback; no intermediate joint goals or searched route. Original raw result files preserved.')
(ROOT/'MECHANISM_EVIDENCE.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
