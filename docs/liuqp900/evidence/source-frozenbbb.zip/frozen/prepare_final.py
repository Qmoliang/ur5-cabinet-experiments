from pathlib import Path
import json,shutil,hashlib
r=Path(__file__).resolve().parent;old=r.parent/'liuqp_reheading_study_20261107'
p=r/'pilot_worker_continuation.py';s=p.read_text().replace("        if job.get('policy_version')=='continuation_maximin':","        if job.get('policy_version')=='continuation_certified':\n            from continuation_certified_policy import LowDimPolicy\n        elif job.get('policy_version')=='continuation_maximin':");s=s.replace("guard={} if ctx is None else ctx.guard.summary()","guard={} if ctx is None or not ctx.guard.ms else ctx.guard.summary()");p.write_text(s)
s=(r/'launch_continuation.py').read_text().replace('[48,49,50,51]','[40,41,42,43]').replace('[52,53,54,55]','[44,45,46,47]');(r/'launch_final.py').write_text(s)
source=json.loads((r/'candidate_jobs.json').read_text());jobs=[]
for i,j in enumerate(source[:2],1):jobs.append(dict(j,name='certified_failure_'+str(i),policy_version='continuation_certified'))
for i in [1,2]:
 f=old/'trials'/('reheading_v2_measured_'+str(i));j=dict(source[i-1]);j.pop('latency_ticks_file');j.update(name='certified_end_'+str(i),policy_version='continuation_certified',start_snapshot=str(next(f.glob('snapshot_final_*.npz'))),initial_memories=str(f/'goalward_memories.json'));jobs.append(j)
jobs.append(dict(source[2],name='certified_original_start',policy_version='continuation_certified'))
for i in [1,2]:
 j=dict(source[0]);j.pop('latency_ticks_file');j.update(name='certified_measured_'+str(i),policy_version='continuation_certified');jobs.append(j)
jobs.append(dict(jobs[0],name='certified_failure_1_repeat'))
(r/'final_jobs.json').write_text(json.dumps(jobs,indent=2))
refs=[dict(j,name='reference_failure_'+str(i),policy_version='reheading_v2') for i,j in enumerate(source[:2],1)];(r/'reference_jobs.json').write_text(json.dumps(refs,indent=2))
a=r/'revisions/continuation_certified';a.mkdir()
for p in list(r.glob('*.py'))+list(r.glob('*.json')):shutil.copy2(p,a/p.name)
manifest={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in list(r.glob('*.py'))+[r/'GOAL_BRANCH_PORTS.json',r/'INPUTS.json',r/'code/common/policy.json',r/'code/online/protocol_liuqp_controller.py']}
(r/'FINAL_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,reference_jobs=refs,manifest=manifest,rule='frozen final evaluation; all successes and failures retained; no post-outcome tuning',hardware='MuJoCo kinematic feedback only',unknown_environment_scope='original frozen causal observed map; no new sensing',future_configurations_optimized=0,planner_calls_forbidden=True,certificate_family='one fixed terminal contraction feedback parameterized by a scalar; not arbitrary reachability'),indent=2))
print('frozen',len(jobs),'new-controller trials +',len(refs),'failure references')
