"""Online pilot summary: per scene x controller x condition.

clean = reached within 5 mm held 1 s (after every racket has gone when there are rackets), no protective stop.
hit / scene / floor / self = cause of the protective stop.  Racket conditions count only runs where a racket was
launched (launch depends on each controller's own approach; 'n/L' shows launched of runs).
"""
import collections, csv, glob, json, sys
from pathlib import Path
import numpy as np

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/pilot_online")
ctls = ["liuqp", "combined", "neo_paper", "neo_matched", "neo_paper_delay", "neo_matched_delay"]
conds = ["k0_v0.0", "k1_v0.25", "k1_v0.5", "k2_v0.5"]
rows = collections.defaultdict(list); crashed = []
for run in ROOT.glob("*/*_s*"):
    if not run.is_dir():
        continue
    f = next(run.glob("A-CV-*/summary.json"), None)
    if f is None:
        if (run / "failure.json").exists() or (run.parent / (run.name + ".log")).exists():
            crashed.append(str(run.relative_to(ROOT)))
        continue
    group = run.parent.name; ctl, cond = group.rsplit("_k", 1); cond = "k" + cond
    scene = run.name.rsplit("_s", 1)[0]
    s = json.load(open(f)); e = s.get("e4") or {}
    p = e.get("protective_stop") or {}; kinds = p.get("kinds") or {}
    o = e.get("objects") or {}
    launched = any(d.get("launched") for d in o.get("described", []))
    stopped = bool(p.get("stopped"))
    cause = None
    if stopped:
        cause = "hit" if "object" in kinds else "scene" if "scene" in kinds else "floor" if "floor" in kinds else "self"
    reached = bool(e.get("success_after")) if (e.get("object_count") or 0) > 0 else e.get("first_success_5mm_s") is not None
    inner = f.parent
    r = list(csv.DictReader(open(inner / "cycles.csv")))
    age = [float(x["snapshot_age_ms"]) for x in r if x["snapshot_age_ms"]]
    per = e.get("per_object") or []
    rows[(scene, ctl, cond)].append(dict(
        launched=launched, clean=reached and not stopped, cause=cause, t=e.get("first_success_5mm_s"),
        p99=s.get("controller_ms_p99", 0.0), age=np.median(age) / 1000 if age else np.nan,
        delays=[x["detection_delay_s"] for x in per if x.get("launched") and x.get("detection_delay_s") is not None],
        missed=sum(1 for x in per if x.get("launched") and x.get("missed")),
        objs=sum(1 for x in per if x.get("launched")), final=s.get("final_error_m", np.nan),
        held=(e.get("delay") or {}).get("held_cycles")))

print(f"{ROOT}: {sum(len(v) for v in rows.values())} runs with summary; crashed/unfinished: {len(crashed)} {crashed[:6]}")
print("cell: clean/counted [hit scene floor self] launched/runs")
for scene in ("drawer", "cage_wide", "shelf"):
    print(f"\n  {scene}")
    for ctl in ctls:
        cells = []
        for cond in conds:
            out = rows.get((scene, ctl, cond), [])
            n = len(out)
            cnt = out if cond == "k0_v0.0" else [o for o in out if o["launched"]]
            c = collections.Counter(o["cause"] for o in cnt if o["cause"])
            cells.append(f"{sum(o['clean'] for o in cnt)}/{len(cnt)} [{c['hit']} {c['scene']} {c['floor']} {c['self']}] {len(cnt)}/{n}")
        base = rows.get((scene, ctl, "k0_v0.0"), [])
        ts = [o["t"] for o in base if o["clean"] and o["t"] is not None]
        t = f"{np.median(ts):5.1f}s" if ts else "   -  "
        print(f"    {ctl:18s} " + "  ".join(f"{cd}: {cl:22s}" for cd, cl in zip(conds, cells)) + f" reach t {t}")

print("\nper controller (all runs): controller p99 ms median, map age s median, detection delay ms median, missed/launched objects")
for ctl in ctls:
    out = [o for k, v in rows.items() if k[1] == ctl for o in v]
    if not out:
        continue
    d = [x for o in out for x in o["delays"]]
    print(f"  {ctl:18s} p99 {np.median([o['p99'] for o in out]):6.1f}  map age {np.nanmedian([o['age'] for o in out]):4.2f}  "
          f"detect {1000*np.median(d) if d else float('nan'):5.0f} ms  missed {sum(o['missed'] for o in out)}/{sum(o['objs'] for o in out)}"
          + (f"  held cycles median {np.median([o['held'] or 0 for o in out]):.0f}" if 'delay' in ctl else ""))
