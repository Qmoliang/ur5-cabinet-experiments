"""known_v6/run.py: UR5_WHOLE_ARM=1 adds link pulls along the geodesic field (needs geodesic_native)."""
from pathlib import Path

p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
s = p.read_text()
old = """    controller.task_gain = 2.0
"""
assert s.count(old) == 1
s = s.replace(old, """    if os.environ.get("UR5_WHOLE_ARM", "0") == "1":
        if attractor is None:
            raise ValueError("UR5_WHOLE_ARM needs a geodesic attraction mode")
        from whole_arm import enable_whole_arm
        enable_whole_arm(controller, attractor, target, robot)
""" + old)
old = """        "attraction_mode": attraction_mode,
"""
assert s.count(old) == 1
s = s.replace(old, old + """        "whole_arm": os.environ.get("UR5_WHOLE_ARM", "0") == "1",
        "whole_arm_active_cycles": getattr(controller, "whole_arm_active_cycles", None),
""")
p.write_text(s)
print("patched")
