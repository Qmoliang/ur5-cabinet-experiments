"""known_v6/run.py: scene from UR5_SCENE_JSON, valid perturbed starts, scene-fitted geodesic bounds."""
from pathlib import Path

p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
s = p.read_text()


def sub(old, new):
    global s
    assert s.count(old) == 1, old[:80]
    s = s.replace(old, new)


sub("""    payload = json.loads((ROOT / "assets" / "scene.json").read_text(encoding="utf-8"))""",
    """    scene_path = Path(os.environ.get("UR5_SCENE_JSON", str(ROOT / "assets" / "scene.json")))
    payload = json.loads(scene_path.read_text(encoding="utf-8"))""")

sub("""    start_seed = int(os.environ.get("UR5_START_SEED", "0"))
    if start_seed:
        initial_q = initial_q + np.random.default_rng(start_seed).normal(0.0, 0.05, initial_q.shape)
    set_configuration(model, data, initial_q)
""", """    start_seed = int(os.environ.get("UR5_START_SEED", "0"))
    start_attempts = 0
    if start_seed:
        sigma = float(os.environ.get("UR5_START_SIGMA", "0.05"))
        rng = np.random.default_rng(start_seed)
        base_q = initial_q.copy()
        if os.environ.get("UR5_START_CHECK", "0") == "1":
            # Redraw until the start pose clears both representations' covers
            # by the safety margin, so sphere and ellipsoid share start poses.
            from start_check import StartChecker
            checker = StartChecker(scene.boxes, MAXIMUM_CELL_SPAN, SAFETY_MARGIN + 0.002)
            while True:
                start_attempts += 1
                initial_q = base_q + rng.normal(0.0, sigma, base_q.shape)
                if checker.valid(model, data, initial_q) or start_attempts >= 500:
                    break
        else:
            initial_q = base_q + rng.normal(0.0, sigma, base_q.shape)
    set_configuration(model, data, initial_q)
""")

old_native = """        attractor = NativeGeodesicAttractor(
            cover.centers, target, representation,
            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,
        )"""
sub(old_native, """        # The field box covers the scene, start and target (15 cm around them).
        corners = np.concatenate([
            np.array([np.asarray(b.center) - np.asarray(b.half_size) for b in scene.boxes]),
            np.array([np.asarray(b.center) + np.asarray(b.half_size) for b in scene.boxes]),
            [initial_ee, target]])
        field_lower = np.maximum(corners.min(axis=0) - 0.15, [-1.0, -1.0, 0.05])
        field_upper = corners.max(axis=0) + 0.15
        attractor = NativeGeodesicAttractor(
            cover.centers, target, representation,
            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,
            lower=tuple(field_lower), upper=tuple(field_upper),
        )""")

sub("""        "scene_name": scene.name,
""", """        "scene_name": scene.name,
        "start_attempts": start_attempts,
        "initial_q": initial_q.tolist(),
""")
p.write_text(s)
print("patched")
