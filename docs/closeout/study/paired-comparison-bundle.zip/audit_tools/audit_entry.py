"""Frozen online evaluation adjudicator for the finite closeout protocol."""
from pathlib import Path
import os,sys,json,hashlib,subprocess,time,traceback
import numpy as np
U=Path('/mnt/ssd2/hsjed/ur5_cabinet/v6runs/unified_static_20261102')
V=Path(sys.argv[1]).resolve();key=sys.argv[2];case=V/'runs'/key;A=V/'audits';A.mkdir(exist_ok=True);(V/'outcomes').mkdir(exist_ok=True)
if os.environ.get('AUDIT_CPU'):os.sched_setaffinity(0,{int(os.environ['AUDIT_CPU'])})
started=time.monotonic();record=dict(id=key,strict_pass=False,goal=False,attempt_valid=False,safety_verified=False,continue_evaluation=False,case=str(case),version=str(V/'code'))
TERMINAL_FAILURES={'initial_operating_clearance_unavailable','operating_contract_unavailable','repeated_stalled_route'}
def classify_completed(goal,safety,trace_valid,reference):
    if not trace_valid or not reference:return 'invalid_evidence',False,False
    if not safety:return 'safety_audit_failed',True,False
    return ('passed' if goal else 'not_reached'),True,True

def initial_no_motion_check(witness,job):
    assert witness['cycle']==0 and np.max(np.abs(witness['previous']))<1e-12
    assert np.allclose(witness['q'],job['entry']['initial_q'],atol=1e-12,rtol=0)
    history=np.load(case/'guard_failure_q_history.npy')
    assert history.size==0 or np.max(np.abs(history-np.asarray(witness['q'])))<1e-12
    os.environ.update(job['environment']);sys.path[:0]=[str(V/'code/common'),str(V/'code/online')]
    import mujoco,run_protocol_v3_async_online as online
    run=next(case.glob('A-CV-*'));model=mujoco.MjModel.from_xml_path(str(run/'scene.xml'));data=mujoco.MjData(model);data.qpos[:6]=witness['q'];mujoco.mj_kinematics(model,data)
    robot=online.build_robot_certificate(model);body=np.array([x.body_id for x in robot]);local=np.array([x.local_center for x in robot]);radii=np.array([x.radius for x in robot]);pos=data.xpos[body]+np.einsum('nij,nj->ni',data.xmat[body].reshape(-1,3,3),local)
    scene=json.loads(Path(job['entry']['scene_json']).read_text());centers=np.array([b['center'] for b in scene['boxes']]);half=np.array([b['half_size'] for b in scene['boxes']]);physical=np.linalg.norm(np.maximum(np.abs(pos[:,None]-centers)-half,0),axis=2)-radii[:,None]
    assert physical.min()>=job['policy']['environment_margin_m']-1e-7
    q=np.asarray(witness['q']);assert np.all(q>=model.jnt_range[:6,0]+job['policy']['joint_padding_rad']) and np.all(q<=model.jnt_range[:6,1]-job['policy']['joint_padding_rad'])
    assert np.all(pos-radii[:,None]>=np.asarray(job['policy']['workspace_lower'])-1e-10) and np.all(pos+radii[:,None]<=np.asarray(job['policy']['workspace_upper'])+1e-10)
    return float(physical.min()*1000)
try:
    entry=json.loads((U/'entries'/(key+'.json')).read_text());assert entry['mode']=='online';entry=dict(entry,representation='sphere');job=json.loads((case/'job.json').read_text());raw=json.loads((case/'run_result.json').read_text());policy=json.loads((V/'acceptance_policy.json').read_text())
    assert job['entry']==entry and Path(job['code_root']).resolve()==(V/'code').resolve()
    assert job['representation']=='sphere' and job['source_entry_sha256']==hashlib.sha256((U/'entries'/(key+'.json')).read_bytes()).hexdigest()
    for name,digest in job['common_hashes'].items():assert hashlib.sha256((V/'code/common'/name).read_bytes()).hexdigest()==digest,name
    record.update(task=entry['task'],seed=entry['seed'],mode='online',run_status=raw['status'],input_and_common_hashes_match=True,acceptance_policy=policy,representation='sphere',paired_baseline='final_r17')
    if raw['status']!='completed':
        witness_path=case/'guard_failure.json'
        if witness_path.exists():
            witness=json.loads(witness_path.read_text())
            if witness['cycle']==0:
                gap=initial_no_motion_check(witness,job)
                record.update(outcome='initial_map_not_certified',attempt_valid=True,safety_verified=True,continue_evaluation=True,audit_scope='independent_initial_state_and_no_motion',physical_state_min_mm=gap,witness=str(witness_path))
            else:record.update(outcome='execution_safety_certificate_interrupted',witness=str(witness_path),error=raw.get('error'))
        else:record.update(outcome='execution_error',error=raw.get('error'))
    else:
        output=A/(key+'_online.json')
        if not output.exists():
            env=dict(os.environ,AUDIT_OUTPUT_DIR=str(A),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
            with (A/(key+'_online.log')).open('w') as log:
                subprocess.run(['/home/hsjed/envs/ur5cab/bin/python','-u',str(Path(__file__).with_name('audit_online_closeout.py')),key,str(case)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1800,check=True)
        base=json.loads(output.read_text());summary=json.loads((case/'summary.json').read_text());assert summary['representation']=='sphere';assert all(summary['representation_contract'][n]=='sphere' for n in ['requested','controller','planner','execution']);goal=bool(base['success_1mm_50']);reason=summary.get('termination_reason','active_horizon_exhausted');maximum=int(job['policy']['maximum_cycles']);cycles=int(base['cycles'])
        trace_valid=0<cycles<=maximum and (cycles==maximum or (job['policy'].get('stop_after_goal_hold',False) and goal) or reason in TERMINAL_FAILURES)
        reference=bool(base.get('goal_fk_verified',False) and base['goal_fk_max_difference_m']<1e-9 and base['reference_max_difference_m']<=1e-7)
        checks={name:bool(base[name]) for name in ['continuous_proxy_passed','physical_and_self_continuous_passed','cell_coverage_identity_passed','all_coverage_checks','all_mvt_checks','joint_position_and_braking_passed','initial_prior_unchanged','stationary_map_updates_passed','historical_visibility_frontier_replay_passed','camera_origins_outside_obstacles']}
        checks.update(workspace=bool(base['workspace_audit']['passed']),acceleration=base['peak_acceleration']<=job['policy']['acceleration_limit']+.0001,execution_guard=base['execution_guard_failed']==0,physical_penetration=summary['exact_penetrating_cycles']==0)
        safety=all(checks.values());outcome,valid,cont=classify_completed(goal,safety,trace_valid,reference)
        record.update(outcome=outcome,attempt_valid=valid,safety_verified=safety,continue_evaluation=cont,strict_pass=bool(goal and safety and trace_valid and reference),goal=goal,audit_scope='independent_full_trajectory',termination_reason=reason,executed_cycles=cycles,maximum_active_cycles=maximum,trace_valid=trace_valid,reference_agrees=reference,safety_checks=checks,completion_charged_s=base.get('completion_with_initial_observation_s'),controller_ms_p99=summary.get('controller_ms_p99'),controller_time_is_pass_criterion=False,completion_time_is_pass_criterion=False,minimum_proxy_gap_mm=base['minimum_proxy_gap_mm'],physical_state_min_mm=base['physical_state_min_mm'],self_state_min_mm=base['selected_self_state_min_mm'],audit=str(output))
except Exception as exc:
    record.update(outcome='audit_error',audit_error=repr(exc),traceback=traceback.format_exc())
record['audit_wall_s']=time.monotonic()-started;record['audit_runner_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();p=V/'outcomes'/(key+'.json');tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(record,indent=2));tmp.replace(p);print(json.dumps(record),flush=True)
