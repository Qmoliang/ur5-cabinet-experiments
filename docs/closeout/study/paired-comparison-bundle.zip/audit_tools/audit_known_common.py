import pathlib,sys,os,json,csv,collections,time
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np,mujoco
R=pathlib.Path('/mnt/ssd2/hsjed/ur5_cabinet/v6runs/unified_static_20261102');case=pathlib.Path(sys.argv[1]);key=sys.argv[2];sys.path.insert(0,str(pathlib.Path(json.loads((case/'job.json').read_text())['code_root'])/'known/known_v6'));import run as kr
from pathlib import Path as _AuditPath; AUDIT=_AuditPath(os.environ.get('AUDIT_OUTPUT_DIR',str(R/'audits')));AUDIT.mkdir(parents=True,exist_ok=True)
start=time.perf_counter();d=json.loads((case/'summary.json').read_text());pa=json.loads((AUDIT/f'{key}_proxy.json').read_text());q=np.load(case/'q_history.npy');ee=np.load(case/'ee_history.npy');target=np.array(d['target_m']);model=mujoco.MjModel.from_xml_path(str(case/'runtime_scene.xml' if (case/'runtime_scene.xml').exists() else case/'scene.xml'));data=mujoco.MjData(model);robot=[x for x in kr.build_robot_certificate(model) if model.body_mocapid[x.body_id]<0];body=np.array([s.body_id for s in robot]);lc=np.array([s.local_center for s in robot]);rad=np.array([s.radius for s in robot]);parent=model.body_parentid;site=model.site('attachment_site').id
scene=json.loads((R/'scenes'/(json.loads((R/'entries'/(key+'.json')).read_text())['task']+'.json')).read_text());bc=np.array([b['center'] for b in scene['boxes']]);bh=np.array([b['half_size'] for b in scene['boxes']]);lever=[]
for b,l in zip(body,lc):
 length=np.linalg.norm(l);b=int(b)
 while b:
  length+=np.linalg.norm(model.body_pos[b]);j0=model.body_jntadr[b]
  for j in range(j0,j0+model.body_jntnum[b]):length+=2*np.linalg.norm(model.jnt_pos[j])
  b=int(parent[b])
 lever.append(length)
K=2*max(lever)
def pos(qi):
 data.qpos[:6]=qi;mujoco.mj_kinematics(model,data);return data.xpos[body]+np.einsum('nij,nj->ni',data.xmat[body].reshape(-1,3,3),lc)
positions=[];fk=[]
for qi in q:positions.append(pos(qi));fk.append(data.site_xpos[site].copy())
positions=np.asarray(positions);fk=np.asarray(fk);assert ee.shape==fk.shape;fk_difference=float(np.max(np.linalg.norm(ee-fk,axis=1)));assert fk_difference<1e-9
from continuous_robot_audit import audit_motion
p0=positions[0];pairs=np.array([(i,j) for i in range(len(rad)) for j in range(i+1,len(rad)) if body[i]!=body[j] and parent[body[i]]!=body[j] and parent[body[j]]!=body[i] and np.linalg.norm(p0[j]-p0[i])-rad[i]-rad[j]>=.005]);motion=audit_motion(q,positions,rad,bc,bh,pairs,K,pos);bad=motion['bad_intervals'];sub=motion['subdivisions'];physical=np.array([motion['minimum_environment_m']]);selfgap=np.array([motion['minimum_self_m']])
errors=np.linalg.norm(fk[1:]-target,axis=1);hold=best=0;completion=None
for i,e in enumerate(errors):
 hold=hold+1 if e<.001 else 0;best=max(best,hold)
 if hold>=50 and completion is None:completion=(i+1)*.02
plan_s=float(d.get('guidance_plan_ms_total') or 0)/1000;charged=None if completion is None else completion+plan_s
rows=list(csv.DictReader(open(case/'cycles.csv')));counts=collections.Counter(x['status'] for x in rows);coverage=json.loads((case/'coverage.json').read_text());safe=pa['continuous_proxy_passed'] and not bad and pa['peak_acceleration']<=10.0001 and d['exact_penetrating_cycles']==0 and d.get('execution_guard',{}).get('failed',0)==0 and coverage['complete_solid_cell_volume_covered']
# Independently verify unchanged padded joint limits and actual velocity/acceleration.
qlow=model.jnt_range[:6,0]+.015;qhigh=model.jnt_range[:6,1]-.015;vel=np.diff(q,axis=0)/.02
speed=np.abs(vel).copy();travel=np.zeros_like(speed)
while np.max(speed)>1e-15:
 travel+=.02*speed;speed=np.maximum(speed-.2,0)
stop=q[:-1]+np.sign(vel)*travel
joint_slack=float(np.min(np.r_[(q-qlow).ravel(),(qhigh-q).ravel()]));brake_slack=float(np.min(np.r_[(stop-qlow).ravel(),(qhigh-stop).ravel()]))
vratio=float(np.max(np.abs(vel)/np.array([1.,1.,1.,1.4,1.4,1.4])))
from audit_shared_inputs import audit_workspace, audit_partition
workspace=audit_workspace(q,positions,rad,K,pos);partition=audit_partition(case,json.loads((R/'entries'/(key+'.json')).read_text()))
safe=safe and workspace['passed'] and partition['passed'] and joint_slack>=-1e-10 and brake_slack>=-1e-10 and vratio<=1+1e-9
result=dict(key=key,path=str(case),representation=d['representation'],guidance=d.get('guidance_mode','off'),cycles=len(q)-1,goal_success=best>=50,max_hold=best,completion_sim_s=completion,planning_wall_s=plan_s,completion_charged_s=charged,charged_within120=charged is not None and charged<=120,final_error_mm=float(errors[-1]*1000),safe=bool(safe),strict_success=bool(safe and best>=50 and len(q)>=51),strict_success_charged=bool(safe and charged is not None and charged<=120),continuous_proxy_passed=pa['continuous_proxy_passed'],minimum_sampled_proxy_gap_mm=pa['minimum_sampled_proxy_gap_mm'],physical_self_continuous_passed=not bad,physical_failed_intervals=bad,physical_state_min_mm=float(physical.min()*1000),selected_self_state_min_mm=float(selfgap.min()*1000),peak_acceleration=pa['peak_acceleration'],guard_failed=d.get('execution_guard',{}).get('failed',0),coverage=coverage['complete_solid_cell_volume_covered'],proxy_count=d['proxy_count'],qp_status_counts=dict(counts),last10s_error_change_mm=float((errors[max(0,len(errors)-501)]-errors[-1])*1000),last10s_joint_displacement_rad=float(np.linalg.norm(q[-1]-q[max(0,len(q)-501)])),last_executed_velocity_norm=float(np.linalg.norm((q[-1]-q[-2])/.02)),fk_saved_ee_max_difference_m=fk_difference,physical_subdivisions=sub,audit_wall_s=time.perf_counter()-start)
result.update(motion_audit_method=motion['method'],environment_continuous_passed=motion['environment_passed'],self_certificate_continuous_passed=motion['self_passed'],motion_failure_witnesses=motion['witnesses'],joint_slack_rad=joint_slack,braking_slack_rad=brake_slack,peak_velocity_ratio=vratio,recorded_duration_s=(len(q)-1)*.02,static_motion_passed=bool(safe))
result.update(workspace_audit=workspace,partition_audit=partition)
(AUDIT/f'{key}_common.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
