"""Incremental one-dimensional retreat: do not turn posture error into a distant gate."""
import numpy as np
from progress_retreat_policy import LowDimPolicy as Previous
from continuation_certified_policy import LowDimPolicy as Certified

class LowDimPolicy(Previous):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.retreat_extensions=0;self.last_retreat_certificate_cycle=-100;self.retreat_scalar=0.;self.retreat_scalar_cap=0.
 def start_retreat(self):
  z=self.P@(self.q-self.qg);d=self.outward;t=self.ctx.target;pad=float(np.max(self.ctx.guard.radii));lo=self.ctx.guard.workspace_lower+pad;hi=self.ctx.guard.workspace_upper-pad
  caps=[(hi[j]-t[j])/d[j] if d[j]>0 else (lo[j]-t[j])/d[j] for j in range(3) if abs(d[j])>1e-12];self.retreat_scalar_cap=max(0.,min(caps))
  # Extend only one already-declared local entry radius beyond the actual axial position.
  self.retreat_scalar=min(self.retreat_scalar_cap,max(self.radius,float(d@(self.ee-t)))+self.radius);self.retreat_gate=t+self.retreat_scalar*d
  self.active_retreat=dict(start_cycle=self.k,start_q=self.q.tolist(),gate=self.retreat_gate.tolist(),retreat_distance_m=self.retreat_scalar,initial_posture_error_m=float(np.linalg.norm(z)),initial_ready_margin_m=-self.future_state['deficit'],memory_count=len(self.memories),gate_rule='increment actual axial position by one original local entry radius; never scale retreat distance by posture-error norm')
  self.retreat_best=float(np.linalg.norm(self.ee-self.retreat_gate)+np.linalg.norm(z));self.retreat_last_gain=self.k;self.mode='RETREAT_POSTURE';self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8;self.retreat_requested=False;self.trust_radius=.04;self.continuation_rows=np.empty((0,6));self.continuation_bounds=np.empty(0);self.solve_cache={};self.last_retreat_certificate_cycle=self.k;self.emit('taskspace_retreat_contract_started',**self.active_retreat)
 def finish_retreat(self,reason,passed):
  self.witness_anchor=None;self.future_state=Certified.continuation_witnesses(self,self.q)
  return super().finish_retreat(reason,passed)
 def __call__(self,c,s,arrays):
  if self.mode=='RETREAT_POSTURE' and not self.brake_pending and not self.terminal:
   if self.k-self.last_retreat_certificate_cycle>=100:
    self.last_retreat_certificate_cycle=self.k;self.witness_anchor=None;self.future_state=Certified.continuation_witnesses(self,self.q)
    if not self.future_state['rows'] and self.continuation_certificate():
     self.finish_retreat('whole_terminal_feedback_became_certified',True);self.expected=None;self.last_delta=np.zeros(6);return np.zeros(6)
   z=self.P@(self.q-self.qg);score=float(np.linalg.norm(self.ee-self.retreat_gate)+np.linalg.norm(z))
   if score<self.retreat_best-.0002:self.retreat_best=score;self.retreat_last_gain=self.k
   if self.k-self.retreat_last_gain>=100 and np.linalg.norm(z)>self.radius and np.linalg.norm(self.ee-self.retreat_gate)<=self.radius and self.retreat_scalar+self.radius<=self.retreat_scalar_cap+1e-12:
    self.retreat_scalar+=self.radius;self.retreat_gate=self.ctx.target+self.retreat_scalar*self.outward;self.retreat_best=float(np.linalg.norm(self.ee-self.retreat_gate)+np.linalg.norm(z));self.retreat_last_gain=self.k;self.retreat_extensions+=1;self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8;self.solve_cache={};self.expected=None;self.last_delta=np.zeros(6);self.emit('retreat_distance_extended_after_actual_posture_stall',scalar_m=self.retreat_scalar,gate=self.retreat_gate.tolist(),posture_error_m=float(np.linalg.norm(z)));return np.zeros(6)
  return super().__call__(c,s,arrays)
 def summary(self):
  out=super().summary();out.update(retreat_distance_extensions=self.retreat_extensions,retreat_distance_rule='one-dimensional incremental retreat in original local-entry-radius units, extended only after actual posture stall at a reached gate; fixed terminal feedback checked every original progress window; no future configuration optimization')
  return out
