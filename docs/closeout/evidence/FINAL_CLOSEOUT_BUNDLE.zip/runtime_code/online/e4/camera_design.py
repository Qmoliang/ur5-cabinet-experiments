"""Fixed-camera design for an online scene: which free space around the target can each candidate
camera see, with the arm present (entering and at the target)?  Picks two cameras greedily on top
of the scene's existing low/side pair.  Usage: camera_design.py <cage|cage_wide|shelf> <known bench run dir>

Visibility of a point p from camera c: inside the camera's field of view (58 deg) and the first
geom on the ray c->p is not closer than |p - c| - 1 cm (scene boxes and robot geoms block)."""
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
SCENES = {"cage": "cage.json", "cage_wide": "cage_wide.json", "shelf": "iris_ur3_shelf_t0.json"}
scene_name, bench_run = sys.argv[1], Path(sys.argv[2])
scene_json = HERE.parent / "known_v6" / "assets" / "scenes" / SCENES[scene_name]
os.environ["UR5_E4_SCENE_JSON"] = str(scene_json)
sys.path[:0] = [str(HERE)]
import mujoco  # noqa: E402

import run_protocol_v3_async_online as online  # noqa: E402
from model import build_model, set_configuration  # noqa: E402
from run_v6_case import _scene_cameras  # noqa: E402

scene = online._protocol_scene("camera_quarter")
model = build_model(scene)
data = mujoco.MjData(model)
target = np.asarray(scene.waypoints[-1], float)
boxes = scene.boxes
lo = np.array([np.asarray(b.center) - np.asarray(b.half_size) for b in boxes])
hi = np.array([np.asarray(b.center) + np.asarray(b.half_size) for b in boxes])

# Arm poses: entering (gripper first within 8 cm of the scene box) and at the target.
q_hist = np.load(bench_run / "q_history.npy")
ee = np.load(bench_run / "ee_history.npy")
box_lo, box_hi = lo.min(axis=0), hi.max(axis=0)
to_box = np.linalg.norm(np.maximum(0, np.maximum(box_lo - ee, ee - box_hi)), axis=1)
enter = int(np.argmax(to_box < 0.08))
poses = [q_hist[enter], q_hist[min(len(q_hist) - 1, enter + (len(q_hist) - enter) // 3)], q_hist[-1]]

# Free-space sample points within 10 cm of the target (not inside any scene box).
rng = np.random.default_rng(0)
points = target + rng.uniform(-0.10, 0.10, (1500, 3))
inside = np.zeros(len(points), bool)
for a, b in zip(lo, hi):
    inside |= np.all((points > a - 0.005) & (points < b + 0.005), axis=1)
points = points[~inside][:400]


def visible(cam, look, q):
    set_configuration(model, data, q)
    forward = (look - cam) / np.linalg.norm(look - cam)
    seen = np.zeros(len(points), bool)
    geomid = np.zeros(1, dtype=np.int32)
    for i, p in enumerate(points):
        v = p - cam
        dist = float(np.linalg.norm(v))
        if dist < 1e-6 or math.degrees(math.acos(np.clip(v @ forward / dist, -1, 1))) > 29.0:
            continue
        hit = mujoco.mj_ray(model, data, cam, v / dist, None, 1, -1, geomid)
        seen[i] = hit < 0 or hit >= dist - 0.01
    return seen


def coverage(cams):
    total = np.zeros((len(poses), len(points)), bool)
    for cam, look in cams:
        for j, q in enumerate(poses):
            total[j] |= visible(cam, look, q)
    return total


existing = []
for item in _scene_cameras(str(scene_json), detect=False).split(";"):
    f = item.split(":")
    existing.append((np.array([float(v) for v in f[1].split(",")]), np.array([float(v) for v in f[2].split(",")])))
base = coverage(existing)
print(f"{scene_name}: {len(points)} free points within 10 cm of the target; arm poses entering/mid/final")
print("existing low/side cameras: visible fraction per pose", base.mean(axis=1).round(3))

candidates = []
for r in (0.6, 0.8, 1.0):
    for az in range(-150, 151, 20):          # azimuth around the target, 0 = from -x (robot side)
        for el in (-20, 0, 20, 40, 60, 75):
            a, e = math.radians(az), math.radians(el)
            c = target + r * np.array([-math.cos(e) * math.cos(a), -math.cos(e) * math.sin(a), math.sin(e)])
            if c[2] < 0.1 or np.any(np.all((c > lo - 0.05) & (c < hi + 0.05), axis=1)):
                continue
            if np.linalg.norm(c[:2]) < 0.25:   # not inside the robot's base column
                continue
            candidates.append(c)
scores = []
for c in candidates:
    scores.append(coverage([(c, target)]))
chosen, current = [], base.copy()
for _ in range(2):
    gains = [np.mean(current | s) for s in scores]
    best = int(np.argmax(gains))
    chosen.append(candidates[best])
    current |= scores[best]
    print(f"add camera at {np.round(candidates[best], 3)} looking at the target: visible fraction per pose "
          f"{current.mean(axis=1).round(3)}")
spec = ";".join(f"static_design{k}:{','.join(f'{v:.4f}' for v in c)}:{','.join(f'{v:.4f}' for v in target)}"
                for k, c in enumerate(chosen))
out = HERE / "assets" / f"design_cameras_{scene_name}.txt"
out.write_text(spec + "\n")
print("saved", out, spec)
