#!/bin/bash
# Native path: original fused LiuQP vs + reuse / + geodesic / + both, 20 start poses.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
./launch_seeds.sh $PWD/n0_original ellipsoid 0.075 64 &
./launch_seeds.sh $PWD/n1_reuse    ellipsoid 0.075 84 UR5_NATIVE_REUSE=1 &
./launch_seeds.sh $PWD/n2_geodesic ellipsoid 0.075 104 UR5_ATTRACTION=geodesic_native &
wait
./launch_seeds.sh $PWD/n3_both     ellipsoid 0.075 64 UR5_NATIVE_REUSE=1 UR5_ATTRACTION=geodesic_native &
wait
# Isolated timing: one run at a time on the same cores.
for seed in 1 2; do
  ./known_seed_one.sh $PWD/nt_original ellipsoid 0.075 $seed 120
  ./known_seed_one.sh $PWD/nt_reuse    ellipsoid 0.075 $seed 120 UR5_NATIVE_REUSE=1
  ./known_seed_one.sh $PWD/nt_geodesic ellipsoid 0.075 $seed 120 UR5_ATTRACTION=geodesic_native
  ./known_seed_one.sh $PWD/nt_both     ellipsoid 0.075 $seed 120 UR5_NATIVE_REUSE=1 UR5_ATTRACTION=geodesic_native
done
echo DONE > $PWD/N_DONE
