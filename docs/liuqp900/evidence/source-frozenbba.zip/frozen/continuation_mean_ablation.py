"""Matched post-development ablation: keep final certificates and entry feedback, replace maximin by mean witness objective."""
from continuation_certified_policy import LowDimPolicy as Final
from continuation_cached_policy import LowDimPolicy as Mean
class LowDimPolicy(Final):
 def _solve(self,c,s,arrays,release=None):return Mean._solve(self,c,s,arrays,release)
 def summary(self):
  out=super().summary();out['ablation']='same final certificate/entry feedback, mean witness objective instead of maximin';return out
