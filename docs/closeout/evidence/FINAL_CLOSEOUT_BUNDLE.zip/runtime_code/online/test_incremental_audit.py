"""Incremental vs full coverage audit, every frame of a replay: identical values, and timing."""
import os
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
import run_v6_case  # noqa: E402

os.environ["UR5_STATIC_CAMERAS"] = run_v6_case.STATIC_CAMERA_PRESETS["low_side"]
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
os.environ["UR5_FRONTIER"] = "1"
os.environ["UR5_FRONTIER_CELL_VOXELS"] = "1"
import run_protocol_v3_async_online as online  # noqa: E402

case, frames = Path(sys.argv[1]), int(sys.argv[2])
MODE = sys.argv[3] if len(sys.argv) > 3 else "1"
run = next(p for p in case.iterdir() if p.is_dir())
qs = np.load(run / "causal_source_configurations.npz")["q"][:frames]
worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=0.005, maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm", "static_low", "static_side"),
    scene_version="camera_quarter")
manager = worker.proxy_manager
for i, q in enumerate(qs):
    os.environ["UR5_INCREMENTAL_AUDIT"] = MODE
    row = worker.process(q, i, i, 0.0, transferable=True, include_dense_snapshot=False).frame_row
    os.environ["UR5_INCREMENTAL_AUDIT"] = "0"
    t = time.perf_counter(); full = asdict(manager._directional_coverage_audit(1e-9)); full_ms = 1000 * (time.perf_counter() - t)
    os.environ["UR5_INCREMENTAL_AUDIT"] = "1"
    t = time.perf_counter(); inc = asdict(manager._directional_coverage_audit(1e-9)); inc_ms = 1000 * (time.perf_counter() - t)
    diffs = {k: (full[k], inc[k]) for k in full if full[k] != inc[k]}
    print(f"frame {i:2d}: in-process audit {float(row['proxy_coverage_audit_ms']):6.1f} ms; recheck full {full_ms:6.1f} ms, incremental {inc_ms:6.1f} ms "
          f"({manager.last_audit_recomputed_cells} of {full['center_voxels']} cells recomputed); "
          f"certified {inc['all_raw_sample_balls_certified']}; differing fields: {diffs or 'none'}", flush=True)
worker.close()
