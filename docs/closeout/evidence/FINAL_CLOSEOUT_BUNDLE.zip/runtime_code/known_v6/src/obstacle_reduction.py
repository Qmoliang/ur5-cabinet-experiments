"""IRIS-style reduction of obstacle certificates inside LiuQP.

LiuQP's erase-remove, per robot sphere: take the nearest obstacle, build its
separating plane, delete every obstacle lying fully behind it, repeat.  Two
IRIS-ZO ideas are added on the obstacle side; both may only delete obstacles
that are provably behind a valid plane, so safety is unchanged.

tree   Group deletion.  Obstacles sit in a tree of bounding spheres.  After a
       plane is placed, a node whose bounding sphere lies entirely behind it
       deletes all of its obstacles in one test.  Obstacles are still visited
       nearest first in LiuQP's exact order (lower bound, then index), so the
       kept planes are identical to LiuQP's; only the number of tests changes.

reuse  Iteration across control cycles.  Obstacles are static, so last cycle's
       plane is still a valid separating plane.  While a robot sphere stays
       within `reuse_distance` of where its planes were computed, its planes
       are kept, only its gaps are recomputed, and only obstacles that newly
       entered its neighbourhood are tested against those planes.  A reused
       plane is valid but no longer tangent at the current closest point, so
       it is slightly conservative.
"""
from __future__ import annotations

import heapq

import numpy as np

from controller import ProtocolLiuQPController, ProtocolSeparatingPlane


class ObstacleTree:
    """Bounding-sphere tree over obstacle proxies (built once per map)."""

    def __init__(self, centers: np.ndarray, extents: np.ndarray, leaf_size: int = 4):
        self.centers = np.asarray(centers, dtype=float)
        self.extents = np.asarray(extents, dtype=float)  # radius of a sphere containing each proxy
        self.node_center: list[np.ndarray] = []
        self.node_radius: list[float] = []
        self.children: list[tuple[int, int] | None] = []
        self.members: list[np.ndarray] = []
        self.root = self._build(np.arange(len(self.centers)), leaf_size)

    def _build(self, indices: np.ndarray, leaf_size: int) -> int:
        center = self.centers[indices].mean(axis=0)
        radius = float(np.max(np.linalg.norm(self.centers[indices] - center, axis=1) + self.extents[indices]))
        node = len(self.node_center)
        self.node_center.append(center)
        self.node_radius.append(radius * (1 + 1e-9) + 1e-12)
        self.members.append(indices)
        self.children.append(None)
        if len(indices) > leaf_size:
            spread = np.ptp(self.centers[indices], axis=0)
            axis = int(np.argmax(spread))
            order = indices[np.argsort(self.centers[indices, axis], kind="stable")]
            half = len(order) // 2
            left = self._build(order[:half], leaf_size)
            right = self._build(order[half:], leaf_size)
            self.children[node] = (left, right)
        return node


class ObstacleReductionLiuQPController(ProtocolLiuQPController):
    def __init__(self, *args, reduction: str = "tree", reuse_distance: float = 0.002, **kwargs):
        super().__init__(*args, **kwargs)
        modes = set(reduction.split("+"))
        if not modes <= {"tree", "reuse"}:
            raise ValueError("reduction must combine tree and/or reuse")
        self.use_tree = "tree" in modes
        self.use_reuse = "reuse" in modes
        self.reuse_distance = float(reuse_distance)
        self.native_exact_pair_batch = False  # per-sphere Python plane path, as the baseline
        if self.representation == "sphere":
            extents = np.asarray(self.obstacle_radii, dtype=float) + self.obstacle_offsets
        else:
            extents = np.sqrt(np.max(self.obstacle_eigenvalues, axis=1)) + self.obstacle_offsets
        self.tree = ObstacleTree(self.obstacle_centers, extents)
        self._state: dict[int, dict] = {}
        self.counts = {"exact_planes": 0, "leaf_tests": 0, "node_tests": 0,
                       "reused_spheres": 0, "recomputed_spheres": 0}

    # -- one sphere, full erase-remove -----------------------------------
    def _erase_remove(self, robot_index, center, radius, candidates):
        tolerance = 1e-10
        bounds = self._ordering_lower_bound(center, radius, candidates)
        if not self.use_tree:
            remaining = list(candidates[np.lexsort((candidates, bounds))])
            planes = []
            while remaining:
                kept = int(remaining[0])
                plane = self.separating_plane(robot_index, center, radius, kept)
                self.counts["exact_planes"] += 1
                planes.append(plane)
                indices = np.asarray(remaining, dtype=np.int64)
                self.counts["leaf_tests"] += len(indices)
                behind = self._minimum_support(indices, plane.normal_to_obstacle) >= plane.offset - tolerance
                remaining = [int(i) for i, drop in zip(indices, behind) if not bool(drop)]
            return planes
        # Best-first over the tree; leaves come out in LiuQP's (bound, index) order.
        alive = np.zeros(len(self.obstacle_centers), dtype=bool)
        alive[candidates] = True
        leaf_bound = np.full(len(self.obstacle_centers), np.inf)
        leaf_bound[candidates] = bounds
        tree = self.tree
        # Entries: (bound, tie, node, checked).  Leaves use node = -1 and tie =
        # obstacle index.  `checked` = how many planes this entry (or its parent)
        # was already tested against, so each plane is tested at most once per
        # branch, as IRIS-ZO tests each sample once per new plane.
        heap = [(-np.inf, -1, tree.root, 0)]
        planes = []

        def node_bound(node):
            return float(np.linalg.norm(center - tree.node_center[node]) - tree.node_radius[node]
                         - radius - self.safety_margin)

        while heap:
            bound, tie, node, checked = heapq.heappop(heap)
            if node < 0:  # a leaf obstacle
                obstacle = tie
                if not alive[obstacle]:
                    continue
                new_planes = planes[checked:]
                if new_planes:
                    self.counts["leaf_tests"] += len(new_planes)
                    single = np.array([obstacle])
                    if any(self._minimum_support(single, p.normal_to_obstacle)[0] >= p.offset - tolerance
                           for p in new_planes):
                        alive[obstacle] = False
                        continue
                plane = self.separating_plane(robot_index, center, radius, obstacle)
                self.counts["exact_planes"] += 1
                planes.append(plane)
                alive[obstacle] = False
                continue
            members = tree.members[node]
            if not alive[members].any():
                continue
            # One test removes the whole node if it lies entirely behind a plane
            # added since the node was queued.
            dropped = False
            for plane in planes[checked:]:
                self.counts["node_tests"] += 1
                if float(plane.normal_to_obstacle @ tree.node_center[node]) - tree.node_radius[node] >= plane.offset - tolerance:
                    alive[members] = False
                    dropped = True
                    break
            if dropped:
                continue
            # Anything queued is first tested against every existing plane (a
            # child is smaller than its parent, so an earlier plane may now
            # cover it); after that it is only tested against newer planes.
            seen = len(planes)
            children = tree.children[node]
            if children is None:
                leaves = members[alive[members]]
                for plane in planes:
                    if not len(leaves):
                        break
                    self.counts["leaf_tests"] += len(leaves)
                    behind = self._minimum_support(leaves, plane.normal_to_obstacle) >= plane.offset - tolerance
                    alive[leaves[behind]] = False
                    leaves = leaves[~behind]
                for obstacle in leaves:
                    heapq.heappush(heap, (float(leaf_bound[obstacle]), int(obstacle), -1, seen))
            else:
                for child in children:
                    if not alive[tree.members[child]].any():
                        continue
                    covered = False
                    for plane in planes:
                        self.counts["node_tests"] += 1
                        if float(plane.normal_to_obstacle @ tree.node_center[child]) - tree.node_radius[child] >= plane.offset - tolerance:
                            alive[tree.members[child]] = False
                            covered = True
                            break
                    if not covered:
                        # A node's bound never exceeds its leaves', so order is preserved.
                        heapq.heappush(heap, (node_bound(child), -1, child, seen))
        return planes

    def _with_clearance(self, plane, center, radius):
        clearance = plane.offset - float(plane.normal_to_obstacle @ center) - float(radius) - self.safety_margin
        return ProtocolSeparatingPlane(
            robot_index=plane.robot_index, obstacle_index=plane.obstacle_index, proxy_id=plane.proxy_id,
            normal_to_obstacle=plane.normal_to_obstacle, surface_point=plane.surface_point,
            offset=plane.offset, clearance=clearance)

    def active_planes_for_robot_sphere(self, robot_index, center, radius, directional_batch=None, exact_batch=None):
        if exact_batch is not None or directional_batch is not None or not self.redundant_plane_pruning:
            return super().active_planes_for_robot_sphere(robot_index, center, radius, directional_batch, exact_batch)
        candidates = np.asarray(self._candidate_indices(center, radius), dtype=np.int64)
        if not len(candidates):
            self._state.pop(robot_index, None)
            return [], 0, 0, 0.0, 0.0
        state = self._state.get(robot_index)
        if self.use_reuse and state is not None and np.linalg.norm(center - state["center"]) <= self.reuse_distance:
            new = np.setdiff1d(candidates, state["candidates"], assume_unique=True)
            survivors = new
            for plane in state["planes"]:
                if not len(survivors):
                    break
                self.counts["leaf_tests"] += len(survivors)
                behind = self._minimum_support(survivors, plane.normal_to_obstacle) >= plane.offset - 1e-10
                survivors = survivors[~behind]
            if not len(survivors):
                self.counts["reused_spheres"] += 1
                current = set(candidates.tolist())
                planes = [self._with_clearance(p, center, radius) for p in state["planes"] if p.obstacle_index in current]
                return planes, len(candidates), len(candidates) - len(planes), 0.0, 0.0
        self.counts["recomputed_spheres"] += 1
        planes = self._erase_remove(robot_index, center, radius, candidates)
        self._state[robot_index] = {"center": np.array(center, dtype=float), "candidates": np.sort(candidates),
                                    "planes": planes}
        return planes, len(candidates), len(candidates) - len(planes), 0.0, 0.0
