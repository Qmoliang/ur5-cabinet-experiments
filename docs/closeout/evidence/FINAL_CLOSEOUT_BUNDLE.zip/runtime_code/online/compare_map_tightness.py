"""Compare the final full-history map with the final running-bound map.

Both replays see exactly the same camera frames.  Reports, per shared
CenterVox cell, how much larger the running bound is than the full-history
bound, and, per map, how much of the free drawer cavity the proxies block.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from geometry_blocking import CAVITY, blocked_mask, metrics, FRONT  # noqa: E402
from incremental_proxy_manager import IncrementalMatchedProxyManager  # noqa: E402


def proxies(data, representation: str):
    if representation == "sphere":
        return data["proxy_centers"], np.eye(3)[None] * (data["proxy_radii"] ** 2)[:, None, None]
    return data["proxy_centers"], data["proxy_outer_shapes"]


def main() -> None:
    legacy_dir, new_dir, case, representation, out = sys.argv[1:6]
    legacy = np.load(Path(legacy_dir) / f"{case}_final_map.npz")
    new = np.load(Path(new_dir) / f"{case}_final_map.npz")
    legacy_index = {tuple(key): i for i, key in enumerate(legacy["keys"])}
    pairs = [(legacy_index[tuple(key)], j) for j, key in enumerate(new["keys"]) if tuple(key) in legacy_index]
    old_shapes = legacy["cell_shapes"][[i for i, _ in pairs]]
    new_shapes = new["cell_shapes"][[j for _, j in pairs]]
    old_axes = np.sqrt(np.linalg.eigvalsh(old_shapes))
    new_axes = np.sqrt(np.linalg.eigvalsh(new_shapes))
    longest_ratio = new_axes[:, -1] / old_axes[:, -1]
    volume_ratio = np.prod(new_axes, axis=1) / np.prod(old_axes, axis=1)
    old_inside_new = IncrementalMatchedProxyManager._batch_containment_values(old_shapes, new_shapes)
    row = {
        "case": case,
        "shared_cells": len(pairs),
        "legacy_cells": int(len(legacy["keys"])),
        "new_cells": int(len(new["keys"])),
        "longest_axis_ratio_p50": float(np.median(longest_ratio)),
        "longest_axis_ratio_p99": float(np.percentile(longest_ratio, 99)),
        "volume_ratio_p50": float(np.median(volume_ratio)),
        "volume_ratio_p99": float(np.percentile(volume_ratio, 99)),
        "legacy_bound_inside_new_fraction": float(np.mean(old_inside_new <= 1.0 + 1e-9)),
    }
    for name, data in (("legacy", legacy), ("new", new)):
        centers, shapes = proxies(data, representation)
        mask = blocked_mask(centers, shapes)
        front = blocked_mask(centers, shapes, FRONT)
        result = metrics(mask, front)
        row[f"{name}_proxies"] = int(len(centers))
        row[f"{name}_cavity_blocked"] = result["cavity_blocked_fraction"]
        row[f"{name}_narrowest_free_height_mm"] = result["narrowest_free_height_mm"]
    print(json.dumps(row))
    path = Path(out)
    rows = json.loads(path.read_text()) if path.exists() else []
    rows = [r for r in rows if r["case"] != case] + [row]
    path.write_text(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
