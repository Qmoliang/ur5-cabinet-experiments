from pathlib import Path
import json,shutil
p=Path(__file__).resolve().parent;j=json.loads((p/'development_jobs.json').read_text())
for x in j:x['name']+='_v1'
(p/'development_v1_jobs.json').write_text(json.dumps(j,indent=2))
a=p/'revisions/continuation_v1_logging_fix';a.mkdir();shutil.copy2(p/'continuation_policy.py',a/'continuation_policy.py')
