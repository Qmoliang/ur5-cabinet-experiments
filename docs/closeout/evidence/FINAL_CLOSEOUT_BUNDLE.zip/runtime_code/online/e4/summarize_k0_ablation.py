"""No-object online drawer: reached within 5 mm (held 1 s) per variant and seed, plus final error and map age."""
import csv
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e4_k0_ablation")
for variant in sorted(p.name for p in ROOT.iterdir() if p.is_dir()):
    cells, finals, ages = [], [], []
    for d in sorted((ROOT / variant).glob("seed*")):
        if not d.is_dir() or not (d / "summary.json").exists():
            continue
        inner = next(d.glob("A-CV-*"))
        rows = list(csv.DictReader(open(inner / "cycles.csv")))
        err = np.array([float(r["error_m"]) for r in rows])
        pen = np.array([int(r["exact_penetrating_contact_count"]) for r in rows]) > 0
        ok = (err < 0.005) & ~pen
        run = 0
        reached = False
        for v in ok:
            run = run + 1 if v else 0
            reached = reached or run >= 50
        cells.append(f"{d.name[4:]}:{'Y' if reached else 'n'}{err[-1] * 1000:4.1f}")
        finals.append(reached)
        ages.append(np.median([float(r["snapshot_age_ms"]) for r in rows]))
    if cells:
        print(f"{variant:9s} reached {sum(finals)}/{len(finals)}  map age median {np.median(ages):5.0f} ms   " + " ".join(cells))
