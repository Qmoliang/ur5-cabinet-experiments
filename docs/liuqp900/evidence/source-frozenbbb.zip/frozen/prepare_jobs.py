from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_goal_entry_study_20261106'
s=(ROOT/'pilot_worker_integration.py').read_text();old="        if job.get('policy_version')=='goal_entry_activated':";new="        if job.get('policy_version')=='reheading':\n            from reheading_policy import LowDimPolicy\n        elif job.get('policy_version')=='heading_trace':\n            from trace_heading_policy import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_activated':";assert old in s;s=s.replace(old,new);(ROOT/'pilot_worker_reheading.py').write_text(s)
s=(ROOT/'launch_batch.py').read_text().replace("ROOT/'pilot_worker.py'","ROOT/'pilot_worker_reheading.py'");(ROOT/'launch_reheading.py').write_text(s)
oldjobs=json.loads((OLD/'integration_jobs.json').read_text());bad=next(j for j in oldjobs if j.get('latency_ticks_file'));initial=next(j for j in oldjobs if not j.get('start_snapshot'))
bad=dict(bad,latency_ticks_file=str(ROOT/'FAILED_DELAY_TICKS.npy'))
jobs=[dict(bad,name='reference_failed_schedule',policy_version='heading_trace')]
jobs.extend(dict(bad,name='reheading_failed_schedule_'+str(i),policy_version='reheading') for i in [1,2,3])
measured=dict(bad);measured.pop('latency_ticks_file')
jobs.extend(dict(measured,name='reheading_measured_'+str(i),policy_version='reheading') for i in [1,2,3])
jobs.append(dict(initial,name='reheading_original_start',policy_version='reheading'))
(ROOT/'jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/reheading_v1';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
files=list(ROOT.glob('*.py'))+[ROOT/'INPUTS.json',ROOT/'GOAL_BRANCH_PORTS.json',ROOT/'FAILED_DELAY_TICKS.npy',ROOT/'code/common/policy.json',ROOT/'code/online/protocol_liuqp_controller.py']
(ROOT/'STUDY_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},method='re-anchor only when transported direction is unavailable, actual progress has stalled, and the arm is at rest; retain all active no-return constraints and current escape episode',candidate_dimension='four signed directions in a two-dimensional tangent plane',selection='goal tangent first, then terminal-entry-oriented orthogonal choices, then reverse goal tangent; all require original QP and certificates',hardware='MuJoCo only, confirmed by user',unchanged_physical_safety=True,unchanged_scene_and_snapshot=True,no_path_search=True),indent=2))
print(json.dumps([j['name'] for j in jobs]))
