from pathlib import Path
import json,hashlib,itertools
R=Path(__file__).resolve().parent;p=R/'export_progress_study.py';s=p.read_text()
s=s.replace("interruption=read(f/'DIAGNOSTIC_INTERRUPTION.json') if (f/'DIAGNOSTIC_INTERRUPTION.json').exists() else None\n rec=dict(name=f.name,version=j['policy_version'],status='diagnostic_prefix_interrupted' if interruption else r['status'],raw_result_status=r['status'],interruption=interruption", "rec=dict(name=f.name,version=j['policy_version'],status=r['status']")
s=s.replace("'old_full_refresh_zero_delay_exact'],\n 'retained_diagnostic_prefix':['old_full_refresh_zero_delay'],", "'old_full_refresh_zero_delay'],")
s=s.replace("'old_full_refresh_zero_delay_exact','Full refresh + no delay'", "'old_full_refresh_zero_delay','Full refresh + no delay'")
s=s.replace(",'EXACT_COMBINED_FREEZE.json']:", "]:")
s=s.replace("\nfor n in ['EXACT_PRUNING_EQUIVALENCE.json','COMBINED_PREFIX_REPLAY.json']:\n if (R/n).exists():shutil.copy2(R/n,OUT/n)", '')
s=s.replace("'组合诊断的慢实现保留中止前缀，完整试验使用等价负间隙见证筛选：36个实际轨迹状态的见证标识、值、梯度逐位一致，并对原已执行前缀另作逐关节状态核查。该优化减少距离计算，不删除原地图或改变执行安全门。',\n", '')
expected=json.loads((R/'trials/old_full_refresh_zero_delay_exact/source_hashes.json').read_text())['export_progress_study.py'];found=None
for ending,bom,tail in itertools.product(['\n','\r\n'],[b'',b'\xef\xbb\xbf'],['', '\n','\n\n','\r\n','\r\n\r\n']):
 candidate=bom+s.rstrip('\n').replace('\n',ending).encode()+tail.encode()
 if hashlib.sha256(candidate).hexdigest()==expected:found=candidate;break
assert found is not None,expected
out=R/'revisions/packaging_original';out.mkdir(parents=True,exist_ok=True);(out/'export_progress_study.py').write_bytes(found);print('restored original packaging helper',expected)
