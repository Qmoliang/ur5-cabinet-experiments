#!/bin/bash
# Known-environment resolution sweep: same LiuQP, same certified volume cover,
# only the sub-box span (and so the proxy size/count) changes.
cd /mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6
export MUJOCO_GL=egl OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
OUT=/mnt/ssd2/hsjed/ur5_cabinet/v6runs/known_sweep
mkdir -p $OUT
run() { # representation span cpu_first
  local id=${1}_$(printf "%03d" $(python3 -c "print(round($2*1000))"))mm
  UR5_KNOWN_CELL_SPAN=$2 UR5_KNOWN_OUT=$OUT/$id systemd-run --user --scope -q -p MemoryMax=32G -E UR5_KNOWN_CELL_SPAN -E UR5_KNOWN_OUT -E MUJOCO_GL -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS \
    taskset -c $3-$(($3+7)) timeout 21600 ~/envs/ur5cab/bin/python -c "
import sys,json,time; sys.path[:0]=[\"src\",\"src/core\",\".\"]
import run; t=time.time(); s=run.run(\"$1\", maximum_cycles=3000)
print(json.dumps({k:s.get(k) for k in (\"success\",\"final_error_m\",\"proxy_count\")}), \"wall_s\", round(time.time()-t,1))
" > $OUT/$id.log 2>&1
}
run sphere    0.075 0   &
run sphere    0.050 8   &
run sphere    0.035 16  &
run sphere    0.025 24  &
run sphere    0.018 32  &
run sphere    0.012 40  &
run sphere    0.009 48  &
run ellipsoid 0.075 56  &
run ellipsoid 0.035 96  &
run ellipsoid 0.018 104 &
wait
echo ALL_DONE > $OUT/ALL_DONE
