"""Run the known-environment full-volume LiuQP comparison."""
from __future__ import annotations

import os
import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parents[1]/"common"))
from unified_policy import POLICY
CORE = ROOT / "src" / "core"
SRC = ROOT / "src"
sys.path.insert(0, str(CORE))
sys.path.insert(0, str(SRC))

from controller import ProtocolLiuQPController  # noqa: E402
from known_volume import build_volume_cover, coverage_audit  # noqa: E402
from robot import (  # noqa: E402
    DT,
    JOINT_NAMES,
    BoxObstacle,
    SceneDefinition,
    attachment_position,
    build_model,
    build_robot_certificate,
    set_configuration,
)
from voxel_index import NativeMultilevelMVT  # noqa: E402
import robot as _robot_module  # noqa: E402

if os.environ.get("UR5_SCENE_JSON"):
    import re as _re

    def _scene_xml(scene):
        """The drawer model with its cabinet geoms replaced by this scene's boxes."""
        xml = (ROOT / "assets" / "drawer.xml").read_text(encoding="utf-8")
        xml = _re.sub(r'\n\s*<geom name="(drawer_|cabinet_)[^"]*" type="box"[^>]*/>', "", xml)
        geoms = "".join(
            '\n    <geom name="{}" type="box" pos="{}" size="{}" material="shelf" contype="1" conaffinity="1" />'.format(
                b.name, " ".join(map(repr, b.center)), " ".join(map(repr, b.half_size)))
            for b in scene.boxes)
        marker = '<geom name="floor"'
        head, tail = xml.split(marker, 1)
        line_end = tail.index("/>") + 2
        if os.environ.get("UR5_RACKET", "0") == "1":
            from racket import mjcf_body
            geoms += mjcf_body()
        if int(os.environ.get("UR5_OBJECTS") or "0") > 0:
            from objects import mjcf_bodies
            geoms += mjcf_bodies(int(os.environ["UR5_OBJECTS"]))
        return head + marker + tail[:line_end] + geoms + tail[line_end:]

    _robot_module.build_xml = _scene_xml

# v6: the sphere/ellipsoid resolution sweep overrides the cell span.
MAXIMUM_CELL_SPAN = POLICY["maximum_cell_span_m"]
MAXIMUM_CYCLES = 3000
SUCCESS_TOLERANCE = float(os.environ.get("UR5_SUCCESS_TOL") or "0.005")
SUCCESS_HOLD_CYCLES = 50
SAFETY_MARGIN = POLICY["operating_margin_m"]
NEAR_DISTANCE = 0.04
CONTACT_DISTANCE = 0.0
MVT_BASE_VOXEL_SIZE = 0.015
MVT_OUTWARD_PADDING = 5e-6


def load_scene() -> SceneDefinition:
    scene_path = Path(os.environ.get("UR5_SCENE_JSON", str(ROOT / "assets" / "scene.json")))
    payload = json.loads(scene_path.read_text(encoding="utf-8"))
    return SceneDefinition(
        name=payload["name"],
        description=payload["description"],
        boxes=tuple(
            BoxObstacle(
                name=item["name"],
                center=tuple(item["center"]),
                half_size=tuple(item["half_size"]),
                material=item["material"],
            )
            for item in payload["boxes"]
        ),
        q0=tuple(payload["q0"]),
        waypoints=tuple(tuple(item) for item in payload["waypoints"]),
        duration=float(payload["duration"]),
    )


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes() -> dict[str, str]:
    paths = [
        ROOT / "run.py",
        ROOT / "src" / "known_volume.py",
        CORE / "controller.py",
        CORE / "geometry.py",
        CORE / "native_support.py",
        CORE / "robot.py",
        CORE / "voxel_index.py",
        ROOT / "native" / "collision.dll",
        ROOT / "assets" / "drawer.xml",
        ROOT / "assets" / "scene.json",
    ]
    return {str(path.relative_to(ROOT)).replace("\\", "/"): sha256(path) for path in paths}


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        raise ValueError("cannot write an empty CSV")
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def finite_or_none(value: float):
    return float(value) if np.isfinite(value) else None


def run(
    representation: str,
    *,
    maximum_cycles: int = MAXIMUM_CYCLES,
    osqp_max_iterations: int = 6000,
) -> dict:
    np.random.seed(0)
    if representation not in {"sphere", "ellipsoid"}:
        raise ValueError("representation must be sphere or ellipsoid")
    if maximum_cycles <= 0:
        raise ValueError("maximum_cycles must be positive")
    if osqp_max_iterations <= 0:
        raise ValueError("osqp_max_iterations must be positive")

    output = Path(os.environ.get("UR5_KNOWN_OUT", str(ROOT / "results" / representation)))
    output.mkdir(parents=True, exist_ok=True)
    scene = load_scene()
    cover = build_volume_cover(scene.boxes, representation, MAXIMUM_CELL_SPAN)
    audit = coverage_audit(cover,scene.boxes)
    if not audit["complete_solid_cell_volume_covered"]:
        raise AssertionError("full-volume proxy construction failed its 8-corner proof")

    model = build_model(scene)
    data = mujoco.MjData(model)
    initial_q = np.asarray(scene.q0, dtype=float)
    if os.environ.get("UR5_E4_FAR_START_FILE"):
        # Pilot: the approach-phase start (gripper ~40 cm in front of the scene).
        initial_q = np.load(os.environ["UR5_E4_FAR_START_FILE"]).astype(float)
    # v6 robustness: a seeded per-joint offset of the formal start pose.
    start_seed = int(os.environ.get("UR5_START_SEED", "0"))
    start_attempts = 0
    start_file = os.environ.get("UR5_START_Q_FILE")
    if start_file and start_seed:
        # Recorded start poses, one per seed (e.g. the arm already inside the drawer).
        initial_q = np.load(start_file)[start_seed - 1].astype(float)
    elif start_seed:
        sigma = float(os.environ.get("UR5_START_SIGMA", "0.05"))
        rng = np.random.default_rng(start_seed)
        base_q = initial_q.copy()
        if os.environ.get("UR5_START_CHECK", "0") in ("1", "ellipsoid"):
            # Redraw until the start pose clears both representations' covers
            # by the safety margin, so sphere and ellipsoid share start poses.
            from start_check import StartChecker
            # UR5_START_CHECK=ellipsoid: a start inside the drawer clears only
            # the ellipsoid cover (the sphere cover overlaps it there).
            checker = StartChecker(scene.boxes, MAXIMUM_CELL_SPAN, SAFETY_MARGIN + 0.001,
                                   sphere_too=os.environ.get("UR5_START_CHECK") != "ellipsoid")
            while True:
                start_attempts += 1
                initial_q = base_q + rng.normal(0.0, sigma, base_q.shape)
                if checker.valid(model, data, initial_q):
                    break
                if start_attempts >= 500:
                    raise RuntimeError("no start pose clear of the covers in 500 draws")
        else:
            initial_q = base_q + rng.normal(0.0, sigma, base_q.shape)
    set_configuration(model, data, initial_q)
    initial_ee = attachment_position(model, data)
    target = np.asarray(scene.waypoints[-1], dtype=float)
    robot = build_robot_certificate(model)
    if os.environ.get("UR5_RACKET", "0") == "1":
        # The racket is a mocap body, not part of the robot.
        racket_body = model.body("racket").id
        robot = [sphere for sphere in robot if sphere.body_id != racket_body]
    object_count = int(os.environ.get("UR5_OBJECTS") or "0")
    if object_count > 0:
        object_bodies = {model.body(f"object{k}").id for k in range(object_count)}
        robot = [sphere for sphere in robot if sphere.body_id not in object_bodies]
    robot_radii = np.asarray([item.radius for item in robot], dtype=float)

    query_padding = NEAR_DISTANCE + SAFETY_MARGIN + MVT_OUTWARD_PADDING
    index = NativeMultilevelMVT(
        cover.centers,
        cover.aabb_half_extents + MVT_OUTWARD_PADDING,
        base_voxel_size=MVT_BASE_VOXEL_SIZE,
        maximum_query_half_extent=float(np.max(robot_radii) + query_padding),
        query_padding=query_padding,
        simd=True,
    )
    # v6 index study: same candidates, different lookup.  "mvt" keeps the fused
    # native path; the other two use LiuQP's plain per-sphere candidate path.
    index_mode = os.environ.get("UR5_KNOWN_INDEX", "mvt")
    if index_mode != "mvt":
        sys.path.insert(0, str(ROOT.parent / "online_v6"))
        from ball_tree import NativeBallTree, UnfusedIndex
        if index_mode == "mvt_unfused":
            index = UnfusedIndex(index)
        elif index_mode == "ball_tree":
            index = NativeBallTree(
                cover.centers,
                cover.aabb_half_extents + MVT_OUTWARD_PADDING,
                query_padding=query_padding,
            )
        else:
            raise ValueError("UR5_KNOWN_INDEX must be mvt, mvt_unfused or ball_tree")
    from execution_guard import ExecutionGuard
    from proxy_geometry import ExactProxyGuard,from_known_cover
    certificate_guard=ExactProxyGuard(from_known_cover(cover))
    execution_guard=ExecutionGuard(model,robot,DT,.006,10.)
    common = dict(
        model=model,
        data=data,
        scene=scene,
        robot_spheres=robot,
        obstacle_centers=cover.centers,
        representation=representation,
        obstacle_offsets=np.zeros(len(cover.centers)),
        proxy_ids=cover.proxy_ids,
        safety_margin=SAFETY_MARGIN,
        near_distance=NEAR_DISTANCE,
        contact_distance=CONTACT_DISTANCE,
        obstacle_index=index,
        redundant_plane_pruning=True,
        ellipsoid_pair_threads=POLICY["pair_threads"],
        ellipsoid_pair_affinity_mask=0,
    )
    controller_class = ProtocolLiuQPController
    if os.environ.get("UR5_LINK_REGIONS", "0") == "1":
        from link_regions import LinkRegionLiuQPController
        controller_class = LinkRegionLiuQPController
    if os.environ.get("UR5_NATIVE_REUSE", "0") == "1":
        from native_reuse import NativeReuseLiuQPController
        controller_class = NativeReuseLiuQPController
    reduction = os.environ.get("UR5_OBSTACLE_REDUCTION", "")
    if reduction:
        from functools import partial
        from obstacle_reduction import ObstacleReductionLiuQPController
        controller_class = partial(ObstacleReductionLiuQPController, reduction=reduction)
    if representation == "sphere":
        controller = controller_class(**common, obstacle_radii=cover.sphere_radii)
    else:
        controller = controller_class(**common, obstacle_shapes=cover.ellipsoid_shapes)
    if os.environ.get("UR5_PYTHON_PLANES", "0") == "1":
        # Same per-sphere plane path as the link-region controller uses for
        # its fallback, so plane-solve counts compare like for like.
        controller.native_exact_pair_batch = False
    controller.safety_margin=POLICY["operating_margin_m"]
    controller.osqp_absolute_tolerance=POLICY["qp_tolerance"];controller.osqp_relative_tolerance=POLICY["qp_tolerance"];controller.osqp_max_iterations=POLICY["qp_max_iterations"]
    controller.task_gain=POLICY["task_gain"];controller.max_task_speed=POLICY["max_task_speed"]
    attractor = None
    attraction_mode = os.environ.get("UR5_ATTRACTION", "straight")
    if attraction_mode == "geodesic":
        sys.path.insert(0, str(ROOT.parent / "online_v6"))
        from geodesic import GeodesicAttractor
        attractor_started = time.perf_counter()
        attractor = GeodesicAttractor(
            cover.centers, target, representation,
            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,
        )
        attractor_build_ms = (time.perf_counter() - attractor_started) * 1000.0
    elif attraction_mode == "geodesic_native":
        sys.path.insert(0, str(ROOT.parent / "online_v6"))
        from geodesic_fast import NativeGeodesicAttractor
        # The field box covers the scene, start and target (15 cm around them).
        corners = np.concatenate([
            np.array([np.asarray(b.center) - np.asarray(b.half_size) for b in scene.boxes]),
            np.array([np.asarray(b.center) + np.asarray(b.half_size) for b in scene.boxes]),
            [initial_ee, target]])
        field_lower = np.maximum(corners.min(axis=0) - 0.15, [-1.0, -1.0, 0.05])
        field_upper = corners.max(axis=0) + 0.15
        attractor = NativeGeodesicAttractor(
            cover.centers, target, representation,
            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,
            lower=tuple(field_lower), upper=tuple(field_upper),
        )
        attractor_build_ms = attractor.build_ms
    elif attraction_mode != "straight":
        raise ValueError("UR5_ATTRACTION must be straight or geodesic")
    if os.environ.get("UR5_WHOLE_ARM", "0") == "1":
        if attractor is None:
            raise ValueError("UR5_WHOLE_ARM needs a geodesic attraction mode")
        from whole_arm import enable_whole_arm
        enable_whole_arm(controller, attractor, target, robot)
    if os.environ.get("UR5_POSTURE_GOAL"):
        from whole_arm import enable_posture
        enable_posture(controller, np.load(os.environ["UR5_POSTURE_GOAL"]),
                       weight=float(os.environ.get("UR5_POSTURE_WEIGHT", "0.02")))
    controller.task_gain = 2.0
    controller.max_task_speed = 0.18
    controller.osqp_adaptive_row_threshold = 512
    controller.osqp_absolute_tolerance = 1e-4
    controller.osqp_relative_tolerance = 1e-4
    controller.osqp_max_iterations = POLICY["qp_max_iterations"]
    controller_kind = os.environ.get("UR5_CONTROLLER") or "liuqp"
    liuqp_controller = controller
    rule = None
    combined_off = set(filter(None, (os.environ.get("UR5_COMBINED_OFF") or "").split(",")))
    if controller_kind == "combined":
        from combined import CombinedRule
        rule = CombinedRule(DT, reaction_s=float(os.environ.get("UR5_COMBINED_REACTION") or "0.2"),
                            damper="damper" not in combined_off, adaptive="adaptive" not in combined_off,
                            task_yield="yield" not in combined_off, buffer="buffer" not in combined_off)
        controller.row_rule = rule
    liuqp_type = controller_kind in ("liuqp", "combined")
    if not liuqp_type:
        from neo_adapter import NEOAdapter
        controller = NEOAdapter(model, data, robot, cover, representation, controller_kind)
    racket = None
    if os.environ.get("UR5_RACKET", "0") == "1":
        from racket import Racket, combined_cover
        racket = Racket.from_env(model, robot, representation, MAXIMUM_CELL_SPAN)
        racket_index = None
    accel_limit = float(os.environ.get("UR5_ACCEL_LIMIT") or "0") or None
    if accel_limit is not None:
        if liuqp_type:
            controller.acceleration_limit = accel_limit
        else:
            controller.neo.acceleration_limit = accel_limit
    applied_velocity = np.zeros(len(JOINT_NAMES))
    safety = os.environ.get("UR5_E4_SAFETY", "0") == "1"
    fallback_cycles = 0
    protective = dict(stopped=False, time_s=None, kinds={}, bodies={}, depth_m=0.0)
    if safety:
        from robot import certificate_world_positions as _cwp
        from unified_self_rows import SelfCollisionRows

        self_rows = SelfCollisionRows(model, data, robot, DT, _cwp)
        execution_guard.set_self_pairs(self_rows.pairs)
        if liuqp_type:
            controller.extra_rows = self_rows.rows
        else:
            controller.neo.self_rows = self_rows
            controller.neo.safety_fallback = True
    objects = None
    object_index = None
    object_ids = set()
    if object_count > 0:
        from objects import MovingObjects
        objects = MovingObjects(model, robot, representation, MAXIMUM_CELL_SPAN, scene.boxes, target, initial_ee,
                                count=object_count, speed=float(os.environ.get("UR5_OBJECT_SPEED") or "0.25"),
                                seed=int(os.environ.get("UR5_START_SEED") or "0"))
    object_geoms = objects.geoms if objects is not None else set()
    from rl_hook import take_hook
    rl_hook = take_hook()   # RL pilot (rl/worker.py); None in every normal run
    if rl_hook is not None:
        rl_hook.bind(rule=rule, objects=objects, target=target, scene_boxes=scene.boxes, dt=DT)
    object_contact_cycles = 0
    object_contact_bodies = {}
    first_object_contact_s = None
    static_penetrating_cycles = 0
    hold_after_objects = 0
    success_after_objects = False
    success_after_objects_s = None
    peak_joint_ratio = 0.0
    peak_tcp_speed = 0.0
    peak_joint_accel = 0.0
    yield_cycles = 0
    objects_were_visible = False
    controller_error = None
    liuqp_cold_retries = 0
    escape_cycles = 0
    racket_ids = set()
    controller_failures = 0
    racket_contact_cycles = 0
    racket_geoms = {model.geom(n).id for n in ("racket_head", "racket_handle")} if racket is not None else set()
    hold_after_racket = 0
    success_after_racket = False
    guidance = None
    guidance_mode = os.environ.get("UR5_GUIDANCE", "off")
    if guidance_mode == "iris_zo":
        sys.path.insert(0, str(ROOT.parent / "online_v6"))
        from ball_tree import NativeBallTree
        from guidance import ConfigurationChecker, StallTriggeredGuidance
        # Planning keeps 10 mm more than LiuQP's safety margin so LiuQP can track it.
        planner_tree = NativeBallTree(cover.centers, cover.aabb_half_extents)
        checker = ConfigurationChecker(
            model, robot, cover.centers, representation,
            radii=cover.sphere_radii, shapes=cover.ellipsoid_shapes,
            margin=SAFETY_MARGIN + 0.010, index=planner_tree,
        )
        guidance = StallTriggeredGuidance(
            checker, target, seed=int(os.environ.get("UR5_START_SEED", "0")),
            minimum_margin=SAFETY_MARGIN, references=[initial_q],
            subgoal_mode=os.environ.get("UR5_GUIDANCE_SUBGOALS", "iris"),
            trigger=os.environ.get("UR5_GUIDANCE_TRIGGER", "stall"),
        )
    elif guidance_mode=="escape_chain":
        from known_adapter import create
        guidance=create(model,robot,controller,target,initial_q,cover)
    elif guidance_mode != "off":
        raise ValueError("UR5_GUIDANCE must be off, iris_zo, escape_random, escape_iris, escape_chain or escape_graph")

    cycles: list[dict] = []
    q_history = [initial_q.copy()]
    ee_history = [initial_ee.copy()]
    success_hold = 0
    maximum_success_hold = 0
    first_success_cycle = None
    penetrating_cycles = 0
    maximum_penetration = 0.0
    started = time.perf_counter()
    try:
        for cycle in range(maximum_cycles):
            cycle_started = time.perf_counter()
            q_before = data.qpos[: len(JOINT_NAMES)].copy()
            command = target if guidance is None else (guidance.update(q_before,ee_history[-1],cycle) if getattr(guidance,"pre_step",False) else guidance.current_target())
            if attractor is not None:
                command = attractor.command(ee_history[-1])
            if rl_hook is not None:
                command = command + rl_hook.before_solve(cycle, cycle * DT, ee_history[-1], q_before,
                                                         applied_velocity)
            racket_distance = None
            if racket is not None:
                t_now = cycle * DT
                racket.arm_at_trigger(data, t_now)
                moving = racket.world_cover(t_now + DT)
                obstacles = cover if moving is None else combined_cover(cover, moving)
                horizon = float(os.environ.get("UR5_RACKET_HORIZON") or "0")
                if controller_kind == "liuqp" and moving is not None and horizon > 0.0:
                    # Copies of the racket where it will be over the horizon.
                    for fraction in (1.0 / 3.0, 2.0 / 3.0, 1.0):
                        future = racket.world_cover(t_now + DT + fraction * horizon)
                        if future is not None:
                            obstacles = combined_cover(obstacles, future)
                racket_ids = set(np.asarray(obstacles.proxy_ids)[len(cover.centers):].tolist())
                if controller_kind == "liuqp":
                    if racket_index is not None:
                        racket_index.close()
                        racket_index = None
                    active_index = index
                    if moving is not None:
                        racket_index = NativeMultilevelMVT(
                            obstacles.centers, obstacles.aabb_half_extents + MVT_OUTWARD_PADDING,
                            base_voxel_size=MVT_BASE_VOXEL_SIZE,
                            maximum_query_half_extent=float(np.max(robot_radii) + query_padding),
                            query_padding=query_padding, simd=True)
                        active_index = racket_index
                    if moving is not None or getattr(racket, "_was_active", False):
                        kwargs = dict(proxy_ids=obstacles.proxy_ids, obstacle_index=active_index,
                                      obstacle_offsets=np.zeros(len(obstacles.centers)))
                        if representation == "sphere":
                            kwargs["obstacle_radii"] = obstacles.sphere_radii
                        else:
                            kwargs["obstacle_shapes"] = obstacles.ellipsoid_shapes
                        controller.update_obstacles(obstacles.centers, **kwargs)
                    racket._was_active = moving is not None
                else:
                    # NEO: the racket where it is now, plus its velocity in the dampers.
                    current = racket.world_cover(t_now)
                    if current is None:
                        controller.set_cover(cover)
                    else:
                        combined_now = combined_cover(cover, current)
                        velocities = np.zeros((len(combined_now.centers), 3))
                        velocities[len(cover.centers):] = racket.velocity(t_now)
                        controller.set_cover(combined_now, velocities)
            object_distance = None
            if objects is not None:
                t_now = cycle * DT
                objects.update(data, t_now, ee_history[-1], DT)
                visible = objects.any_visible(t_now) or objects.any_visible(t_now + DT)
                if liuqp_type:
                    if controller_kind == "liuqp":
                        # Earlier convention: objects where they will be at t + dt.
                        obstacles, velocities, half = objects.world_cover(cover, t_now + DT)
                        object_ids = set(np.asarray(obstacles.proxy_ids)[len(cover.centers):].tolist())
                        horizon = float(os.environ.get("UR5_RACKET_HORIZON") or "0")
                        future_times = [t_now + DT + f * horizon for f in (1 / 3, 2 / 3, 1.0)] if horizon > 0 else []
                    else:
                        sweep = 0.0 if "sweep" in combined_off else rule.reaction_s + 0.1
                        obstacles, velocities, half = objects.world_cover(cover, t_now, sweep_s=sweep)
                        rule.set_velocities(velocities)
                        controller.task_scale = rule.task_scale
                        object_ids = set()   # + horizon copies below; escape adds rule.escape_ids()
                        horizon = float(os.environ.get("UR5_COMBINED_HORIZON") or "0")
                        future_times = [t_now + f * horizon for f in (1 / 3, 2 / 3, 1.0)] if horizon > 0 else []
                    if future_times and visible:
                        from dataclasses import replace as _replace
                        from racket import combined_cover
                        for tf in future_times:
                            future, _v, future_half = objects.world_cover(cover, tf)
                            extra = slice(len(cover.centers), len(future.centers))
                            if extra.stop > extra.start:
                                # Only the objects' certificates at tf (static ones are already in).
                                part = _replace(future, **{name: getattr(future, name)[extra]
                                         for name in ("centers", "cell_half_extents", "box_indices", "sphere_radii",
                                                      "ellipsoid_shapes", "aabb_half_extents", "proxy_ids")})
                                before = len(obstacles.centers)
                                obstacles = combined_cover(obstacles, part)
                                half = np.concatenate([half, future_half[extra]])
                                if rule is not None:
                                    velocities = np.concatenate([velocities, np.zeros((len(obstacles.centers) - before, 3))])
                                object_ids |= set(np.asarray(obstacles.proxy_ids)[before:].tolist())
                        if rule is not None:
                            rule.velocities = velocities
                    if object_index is not None:
                        object_index.close()
                        object_index = None
                    active_index = index
                    if visible:
                        object_index = NativeMultilevelMVT(
                            obstacles.centers, half + MVT_OUTWARD_PADDING,
                            base_voxel_size=MVT_BASE_VOXEL_SIZE,
                            maximum_query_half_extent=float(np.max(robot_radii) + query_padding),
                            query_padding=query_padding, simd=True)
                        active_index = object_index
                    if visible or objects_were_visible:
                        kwargs = dict(proxy_ids=obstacles.proxy_ids, obstacle_index=active_index,
                                      obstacle_offsets=np.zeros(len(obstacles.centers)))
                        if representation == "sphere":
                            kwargs["obstacle_radii"] = obstacles.sphere_radii
                        else:
                            kwargs["obstacle_shapes"] = obstacles.ellipsoid_shapes
                        if visible:
                            controller.update_obstacles(obstacles.centers, **kwargs)
                        else:
                            static_kwargs = dict(kwargs, proxy_ids=cover.proxy_ids, obstacle_index=index,
                                                 obstacle_offsets=np.zeros(len(cover.centers)))
                            if representation == "sphere":
                                static_kwargs["obstacle_radii"] = cover.sphere_radii
                            else:
                                static_kwargs["obstacle_shapes"] = cover.ellipsoid_shapes
                            controller.update_obstacles(cover.centers, **static_kwargs)
                            if rule is not None:
                                rule.velocities = None
                    objects_were_visible = visible
                else:
                    obstacles, velocities, _half = objects.world_cover(cover, t_now)
                    controller.set_cover(obstacles, velocities if visible else None)
                    object_ids = set()
            if liuqp_type:
                controller.applied_velocity = applied_velocity.copy()
            elif accel_limit is not None:
                controller.neo.applied_velocity = applied_velocity.copy()
            try:
                qdot, metrics = controller.solve(command)
                if safety and liuqp_type and not str(metrics.status).lower().startswith("solved"):
                    # Cold retry (acceleration rows kept), then the least-violation fallback.
                    controller._previous_qp_dual = None
                    controller.previous_velocity = np.zeros_like(controller.previous_velocity)
                    qdot, metrics = controller.solve(command)
                    liuqp_cold_retries += 1
                    if not str(metrics.status).lower().startswith("solved"):
                        from fallback import liuqp_fallback

                        class _Escape:
                            def escape_ids(self_inner):
                                return rule.escape_ids() if rule is not None else set()
                        fallback = liuqp_fallback(controller, _Escape(), len(cover.proxy_ids),
                                                  use_escape=controller_kind == "combined" and rule is not None)
                        step = (accel_limit or 1e9) * DT
                        qdot = fallback if fallback is not None else applied_velocity - np.clip(applied_velocity, -step, step)
                        controller.previous_velocity = np.asarray(qdot, dtype=float).copy()
                        fallback_cycles += fallback is not None
                elif liuqp_type and not str(metrics.status).lower().startswith("solved"):
                    # A failed OSQP solve leaves its dual as the next warm start,
                    # which can keep later cycles failing; retry cold once.
                    controller._previous_qp_dual = None
                    controller.previous_velocity = np.zeros_like(controller.previous_velocity)
                    # Retry without the acceleration rows: the arm then ramps to
                    # the command (the output is still acceleration-clipped), as a
                    # real UR5 does with speedj; hard acceleration rows together
                    # with LiuQP's push-out rows can make every later cycle infeasible.
                    qdot, metrics = controller.solve(command)
                    liuqp_cold_retries += 1
                    escape_on = (os.environ.get("UR5_ESCAPE", "0") == "1" if controller_kind == "liuqp"
                                 else "escape" not in combined_off)
                    moving_ids = racket_ids if racket is not None else (
                        object_ids | rule.escape_ids() if rule is not None else object_ids)
                    if (not str(metrics.status).lower().startswith("solved") and escape_on and moving_ids):
                        from escape import escape_velocity
                        escape = escape_velocity(controller, moving_ids, dt=DT)
                        if escape is not None:
                            qdot = escape
                            controller.previous_velocity = escape.copy()
                            escape_cycles += 1
            except RuntimeError as error:
                # A failed controller stops the arm (zero velocity) and the run
                # goes on, so a moving obstacle still arrives, as it would on a
                # real robot.  The first error is kept, every one is counted.
                from neo_adapter import NEOMetrics
                controller_error = controller_error or f"cycle {cycle}: {error}"
                controller_failures += 1
                qdot = np.zeros(len(JOINT_NAMES))
                metrics = NEOMetrics({"status": f"controller error: {error}"[:200]})
            if protective["stopped"]:
                # Protective stop: brake at the acceleration limit, whatever the controller says.
                step = (accel_limit or 10.0) * DT
                qdot = applied_velocity - np.clip(applied_velocity, -step, step)
            if accel_limit is not None:
                # A real arm cannot change velocity faster than this, also not
                # when the controller fails and the arm stops.
                qdot = np.clip(qdot, applied_velocity - accel_limit * DT, applied_velocity + accel_limit * DT)
            if guidance is not None and hasattr(guidance,"holding") and guidance.holding():
                qdot=applied_velocity-np.clip(applied_velocity,-(accel_limit or 10.)*DT,(accel_limit or 10.)*DT)
            before_guard=np.asarray(qdot).copy()
            lo,hi=controller.joint_velocity_bounds()
            qdot=execution_guard.filter(certificate_guard,q_before,applied_velocity,np.asarray(qdot),lo,hi,cycle,0)
            if not np.array_equal(qdot,before_guard):controller.previous_velocity=np.asarray(qdot).copy()
            limits = np.array([1.0, 1.0, 1.0, 1.4, 1.4, 1.4])
            peak_joint_ratio = max(peak_joint_ratio, float(np.max(np.abs(qdot) / limits)))
            peak_joint_accel = max(peak_joint_accel, float(np.max(np.abs(qdot - applied_velocity))) / DT)
            applied_velocity = np.asarray(qdot, dtype=float).copy()
            if rule is not None and controller.task_scale < 1.0:
                yield_cycles += 1
            q_after = q_before + qdot * DT
            if racket is not None:
                racket.place(data, (cycle + 1) * DT)
            if objects is not None:
                objects.place(data, (cycle + 1) * DT)
            set_configuration(model, data, q_after)
            if objects is not None:
                object_distance = objects.measure(data, (cycle + 1) * DT)
                touching = [k for k in range(data.ncon) if data.contact[k].dist < -1e-8
                            and (data.contact[k].geom1 in object_geoms or data.contact[k].geom2 in object_geoms)]
                for k in touching:
                    c = data.contact[k]
                    name = model.body(model.geom_bodyid[c.geom2 if c.geom1 in object_geoms else c.geom1]).name
                    object_contact_bodies[name] = object_contact_bodies.get(name, 0) + 1
                if touching:
                    object_contact_cycles += 1
                    if first_object_contact_s is None:
                        first_object_contact_s = (cycle + 1) * DT
            if racket is not None:
                racket_distance = racket.measure(data, (cycle + 1) * DT)
                if any(data.contact[k].geom1 in racket_geoms or data.contact[k].geom2 in racket_geoms
                       for k in range(data.ncon) if data.contact[k].dist < -1e-8):
                    racket_contact_cycles += 1
            ee = attachment_position(model, data)
            error = float(np.linalg.norm(target - ee))
            penetrating = [
                index_contact
                for index_contact in range(data.ncon)
                if float(data.contact[index_contact].dist) < -1e-8
            ]
            minimum_contact = min(
                (float(data.contact[index_contact].dist) for index_contact in range(data.ncon)),
                default=float("inf"),
            )
            if penetrating:
                penetrating_cycles += 1
            if safety and penetrating:
                # Protective stop on the first contact of any kind; record what touched what.
                for k in penetrating:
                    c = data.contact[k]
                    b1, b2 = int(model.geom_bodyid[c.geom1]), int(model.geom_bodyid[c.geom2])
                    names = {model.geom(c.geom1).name, model.geom(c.geom2).name}
                    if c.geom1 in object_geoms or c.geom2 in object_geoms:
                        kind = "object"
                    elif "floor" in names:
                        kind = "floor"
                    elif b1 == 0 or b2 == 0:
                        kind = "scene"
                    else:
                        kind = "self"
                    protective["kinds"][kind] = protective["kinds"].get(kind, 0) + 1
                    pair = "/".join(sorted((model.body(b1).name, model.body(b2).name)))
                    protective["bodies"][pair] = protective["bodies"].get(pair, 0) + 1
                    protective["depth_m"] = min(protective["depth_m"], float(c.dist))
                if not protective["stopped"]:
                    protective["stopped"] = True
                    protective["time_s"] = (cycle + 1) * DT
            if any(data.contact[k].geom1 not in object_geoms and data.contact[k].geom2 not in object_geoms
                   for k in penetrating):
                static_penetrating_cycles += 1
            peak_tcp_speed = max(peak_tcp_speed, float(np.linalg.norm(attachment_position(model, data) - ee_history[-1])) / DT)
            maximum_penetration = min(maximum_penetration, minimum_contact)
            if error < SUCCESS_TOLERANCE and not penetrating:
                success_hold += 1
                maximum_success_hold = max(maximum_success_hold, success_hold)
                if success_hold == SUCCESS_HOLD_CYCLES and first_success_cycle is None:
                    first_success_cycle = cycle - SUCCESS_HOLD_CYCLES + 1
            else:
                success_hold = 0
            if racket is not None and racket.start is not None and racket.position((cycle + 1) * DT) is None:
                hold_after_racket = hold_after_racket + 1 if (error < SUCCESS_TOLERANCE and not penetrating) else 0
                success_after_racket = success_after_racket or hold_after_racket >= SUCCESS_HOLD_CYCLES
            if objects is not None and objects.all_done((cycle + 1) * DT):
                hold_after_objects = hold_after_objects + 1 if (error < SUCCESS_TOLERANCE and not penetrating) else 0
                if hold_after_objects >= SUCCESS_HOLD_CYCLES and not success_after_objects:
                    success_after_objects = True
                    success_after_objects_s = (cycle + 1 - SUCCESS_HOLD_CYCLES) * DT

            elapsed_ms = (time.perf_counter() - cycle_started) * 1000.0
            row = {
                "cycle": cycle,
                "time_s": cycle * DT,
                "representation": representation,
                "ee_x": float(ee[0]),
                "ee_y": float(ee[1]),
                "ee_z": float(ee[2]),
                "error_m": error,
                "status": metrics.status,
                "exact_contact_count": int(data.ncon),
                "exact_penetrating_contact_count": len(penetrating),
                "minimum_contact_distance_m": finite_or_none(minimum_contact),
                "control_wall_ms": elapsed_ms,
                "racket_distance_m": racket_distance,
                "object_distance_m": object_distance,
                "task_scale": float(getattr(controller, "task_scale", 1.0)),
                "moving_rows": None if rule is None else rule.moving_rows,
                "executed_qdot_norm": float(np.linalg.norm(qdot)),
                "pre_guard_qdot_norm": float(np.linalg.norm(before_guard)),
                **metrics.as_dict(),
            }
            cycles.append(row)
            q_history.append(q_after.copy())
            ee_history.append(ee.copy())
            if rl_hook is not None and rl_hook.after_step(cycle, error, bool(penetrating), protective,
                                                          fallback_cycles, object_distance):
                break
            if protective["stopped"] and not np.any(np.abs(applied_velocity) > 1e-9):
                break   # stopped after a collision: the run ends here
            if guidance is not None and not getattr(guidance,"pre_step",False):
                guidance.update(q_after, ee, cycle)
    finally:
        index.close()
        if racket is not None and racket_index is not None:
            racket_index.close()
        if object_index is not None:
            object_index.close()
    wall_duration = time.perf_counter() - started

    if guidance is not None and hasattr(guidance,"finish"):guidance.finish(output)
    np.save(output / "q_history.npy", np.asarray(q_history))
    if guidance is not None and not hasattr(guidance,"finish"):
        (output / "guidance.json").write_text(json.dumps(
            {"events": guidance.stats.events, "subgoals": guidance.stats.subgoals}, indent=2))
    np.save(output / "ee_history.npy", np.asarray(ee_history))
    np.savez_compressed(
        output / "proxies.npz",
        representation=np.asarray(representation),
        centers=cover.centers,
        cell_half_extents=cover.cell_half_extents,
        box_indices=cover.box_indices,
        proxy_ids=cover.proxy_ids,
        sphere_radii=cover.sphere_radii,
        ellipsoid_shapes=cover.ellipsoid_shapes,
        aabb_half_extents=cover.aabb_half_extents,
    )
    if not cycles:
        (output / "summary.json").write_text(json.dumps(dict(
            success=False, final_error_m=None, controller=controller_kind, controller_error=controller_error,
            scene_name=scene.name, representation=representation), indent=2), encoding="utf-8")
        print(json.dumps(dict(success=False, controller_error=controller_error)))
        return dict(success=False, final_error_m=float("nan"), controller_error=controller_error)
    write_csv(output / "cycles.csv", cycles)
    (output / "coverage.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (output / "scene.xml").write_bytes((ROOT / "assets" / "drawer.xml").read_bytes())

    errors = np.asarray([row["error_m"] for row in cycles])
    controller_ms = np.asarray([row["total_controller_ms"] for row in cycles])
    wall_ms = np.asarray([row["control_wall_ms"] for row in cycles])
    candidate_pairs = np.asarray([row["broadphase_candidate_pairs"] for row in cycles])
    qp_iterations = np.asarray([row["qp_iterations"] for row in cycles])
    summary = {
        "experiment": "known_environment_complete_solid_volume_cover_liuqp",
        "representation": representation,
        "environment_known": True,
        "depth_camera_used": False,
        "point_cloud_used": False,
        "online_voxel_map_used": False,
        "path_planner": None,
        "intermediate_targets": None,
        "random_dither": False,
        "truth_collision_backtracking": False,
        "scene_name": scene.name,
        "start_attempts": start_attempts,
        "initial_q": initial_q.tolist(),
        "maximum_cell_span_m": MAXIMUM_CELL_SPAN,
        "solid_partition_shared_between_representations": True,
        "proxy_count": len(cover.centers),
        "robot_certificate_spheres": len(robot),
        "complete_solid_cell_volume_covered": audit["complete_solid_cell_volume_covered"],
        "coverage_maximum_corner_measure": audit["maximum_corner_measure"],
        "primitive_to_box_volume_sum_ratio": audit["primitive_to_box_volume_sum_ratio"],
        "ellipsoid_axes_rule": "sqrt(3) times each solid sub-box half extent" if representation == "ellipsoid" else None,
        "sphere_radius_rule": "solid sub-box half diagonal" if representation == "sphere" else None,
        "mvt_multilevel_enabled": True,
        "mvt_simd_enabled": True,
        "mvt_level_count": index.stats.level_count,
        "mvt_index_references": index.stats.index_references,
        "mvt_cell_lookups_per_robot_query": index.stats.cell_lookups_per_query,
        "cycles": len(cycles),
        "simulated_duration_s": len(cycles) * DT,
        "wall_duration_s": wall_duration,
        "initial_ee_m": initial_ee.tolist(),
        "target_m": target.tolist(),
        "final_error_m": float(errors[-1]),
        "minimum_error_m": float(np.min(errors)),
        "maximum_ee_x_m": float(np.max(np.asarray(ee_history)[:, 0])),
        "success_tolerance_m": SUCCESS_TOLERANCE,
        "success_hold_cycles": SUCCESS_HOLD_CYCLES,
        "maximum_success_hold_cycles": maximum_success_hold,
        "success": maximum_success_hold >= SUCCESS_HOLD_CYCLES,
        "guidance_mode": guidance_mode,
        "attraction_mode": attraction_mode,
        "controller": controller_kind,
        "controller_error": controller_error,
        "liuqp_cold_retries": liuqp_cold_retries,
        "escape_cycles": escape_cycles,
        "racket_horizon_s": float(os.environ.get("UR5_RACKET_HORIZON") or "0"),
        "controller_failure_cycles": controller_failures,
        "pilot_safety": safety,
        "fallback_cycles": fallback_cycles + int(getattr(controller, "fallback_cycles", 0)),
        "protective_stop": dict(protective, stopped=bool(protective["stopped"])),
        "collision_free": not protective["stopped"] and penetrating_cycles == 0,
        "acceleration_limit": accel_limit,
        "peak_joint_speed_ratio": peak_joint_ratio,
        "peak_tcp_speed_mps": peak_tcp_speed,
        "peak_joint_accel": peak_joint_accel,
        "static_penetrating_cycles": static_penetrating_cycles,
        "combined": None if rule is None else dict(
            off=sorted(combined_off), reaction_s=rule.reaction_s, yield_s=rule.yield_s,
            horizon_s=float(os.environ.get("UR5_COMBINED_HORIZON") or "0"), yield_cycles=yield_cycles),
        "objects": None if objects is None else dict(
            count=object_count, speed_mps=float(os.environ.get("UR5_OBJECT_SPEED") or "0.25"),
            progress=objects.progress, trigger_s=objects.trigger_s, not_launched=objects.not_launched, rejected_no_room=objects.rejected_no_room,
            described=objects.describe(), contact_cycles=object_contact_cycles,
            first_contact_s=first_object_contact_s, contact_bodies=object_contact_bodies, min_distance_m=finite_or_none(objects.min_distance),
            all_done=bool(objects.all_done(len(cycles) * DT)),
            success_after=success_after_objects, success_after_s=success_after_objects_s),
        "racket": None if racket is None else dict(
            direction=racket.direction.tolist(), trigger_s=racket.trigger_s, speed_mps=racket.speed,
            min_distance_m=finite_or_none(racket.min_distance), contact_cycles=racket_contact_cycles,
            max_retreat_m=racket.max_retreat, max_dodge_m=racket.max_dodge,
            success_after_racket=success_after_racket),
        "whole_arm": os.environ.get("UR5_WHOLE_ARM", "0") == "1",
        "posture_goal": os.environ.get("UR5_POSTURE_GOAL"),
        "whole_arm_active_cycles": getattr(controller, "whole_arm_active_cycles", None),
        "attractor_build_ms": attractor_build_ms if attractor is not None else None,
        "link_regions": type(controller).__name__ == "LinkRegionLiuQPController",
        "obstacle_reduction": reduction or None,
        "reduction_counts": getattr(controller, "counts", None),
        "python_planes": os.environ.get("UR5_PYTHON_PLANES", "0") == "1",
        "shared_plane_solves": getattr(controller, "shared_plane_solves", None),
        "per_sphere_plane_solves": getattr(controller, "per_sphere_plane_solves", None),
        "active_obstacle_rows_total": int(sum(row["active_obstacle_rows"] for row in cycles)),
        "active_obstacle_rows_p50": float(np.median([row["active_obstacle_rows"] for row in cycles])),
        "geometry_ms_p50": float(np.median([row["geometry_ms"] for row in cycles])),
        "guidance_subgoals": None if guidance is None else guidance.subgoal_mode,
        "guidance_trigger": None if guidance is None else guidance.trigger,
        "guidance_calls": None if guidance is None else guidance.stats.calls,
        "guidance_failures": None if guidance is None else guidance.stats.failures,
        "guidance_plan_ms_total": None if guidance is None else float(sum(guidance.stats.plan_ms)),
        "guidance_plan_ms_max": None if guidance is None else float(max(guidance.stats.plan_ms, default=0.0)),
        "guidance_regions": None if guidance is None else guidance.stats.regions,
        "first_sustained_success_time_s": None if first_success_cycle is None else first_success_cycle * DT,
        "exact_penetrating_cycles": penetrating_cycles,
        "maximum_penetration_m": maximum_penetration,
        "controller_ms_p50": float(np.percentile(controller_ms, 50)),
        "controller_ms_p95": float(np.percentile(controller_ms, 95)),
        "controller_ms_p99": float(np.percentile(controller_ms, 99)),
        "control_wall_ms_p99": float(np.percentile(wall_ms, 99)),
        "broadphase_candidate_pairs_p50": float(np.percentile(candidate_pairs, 50)),
        "broadphase_candidate_pairs_p99": float(np.percentile(candidate_pairs, 99)),
        "qp_iterations_p50": float(np.percentile(qp_iterations, 50)),
        "qp_iterations_p99": float(np.percentile(qp_iterations, 99)),
        "safety_margin_m": SAFETY_MARGIN,
        "near_distance_m": NEAR_DISTANCE,
        "contact_distance_m": CONTACT_DISTANCE,
        "osqp_max_iterations": int(controller.osqp_max_iterations),
        "controller_origin": "frozen original v4.3/v4.4 shared LiuQP controller",
        "platform": platform.platform(),
        "python": platform.python_version(),
        "mujoco": mujoco.__version__,
        "source_hashes": source_hashes(),
    }
    summary["execution_guard"] = execution_guard.summary()
    summary["required_safety_margin_m"] = 0.006
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("representation", choices=("sphere", "ellipsoid"))
    parser.add_argument("--cycles", type=int, default=MAXIMUM_CYCLES)
    parser.add_argument("--osqp-max-iterations", type=int, default=6000)
    args = parser.parse_args()
    run(
        args.representation,
        maximum_cycles=args.cycles,
        osqp_max_iterations=args.osqp_max_iterations,
    )


if __name__ == "__main__":
    main()
