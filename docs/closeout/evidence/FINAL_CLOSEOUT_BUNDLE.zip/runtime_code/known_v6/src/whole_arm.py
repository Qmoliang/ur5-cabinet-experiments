"""Whole-arm geodesic objective: the gripper task plus pulls on chosen link points.

LiuQP's objective is |J_ee qdot - v_ee|^2 (weighted) plus regularization.  This
stacks extra rows for link points: each link point p_l is pulled toward the
geodesic field's lookahead point from p_l, so the links follow the same free
corridor the gripper does (e.g. over a wall top or through a window) instead of
pressing against its edge.  Constraints are untouched.  The link weight fades
to zero within `fade` of the target, so it cannot pull the gripper off it.
"""
from __future__ import annotations

import mujoco
import numpy as np

from robot import attachment_position


class WholeArmMixin:
    def init_whole_arm(self, attractor, target, robot_spheres, *, bodies=("forearm_link", "wrist_1_link"),
                       weight: float = 0.15, fade: float = 0.05):
        self.whole_arm_attractor = attractor
        self.whole_arm_target = np.asarray(target, dtype=float)
        self.whole_arm_weight = float(weight)
        self.whole_arm_fade = float(fade)
        self.whole_arm_points = []
        for name in bodies:
            body = self.model.body(name).id
            # the body's certificate sphere farthest along the link (its tip)
            candidates = [s for s in robot_spheres if s.body_id == body]
            tip = max(candidates, key=lambda s: float(np.linalg.norm(s.local_center)))
            self.whole_arm_points.append((body, np.asarray(tip.local_center, dtype=float)))
        self.whole_arm_active_cycles = 0

    def task_feedback(self, target):
        ee, jacobian, desired = super().task_feedback(target)
        error = float(np.linalg.norm(self.whole_arm_target - ee))
        weight = self.whole_arm_weight * min(1.0, error / self.whole_arm_fade)
        if weight <= 0.0:
            return ee, jacobian, desired
        self.whole_arm_active_cycles += 1
        scale = np.sqrt(weight)
        rows, wanted = [jacobian], [desired]
        jacp = np.zeros((3, self.model.nv))
        jacr = np.zeros((3, self.model.nv))
        for body, local in self.whole_arm_points:
            rotation = self.data.xmat[body].reshape(3, 3)
            point = self.data.xpos[body] + rotation @ local
            mujoco.mj_jac(self.model, self.data, jacp, jacr, point, body)
            velocity = self.task_gain * (self.whole_arm_attractor.command(point) - point)
            speed = float(np.linalg.norm(velocity))
            if speed > self.max_task_speed:
                velocity *= self.max_task_speed / speed
            rows.append(scale * jacp[:, :self.nv].copy())
            wanted.append(scale * velocity)
        return ee, np.vstack(rows), np.concatenate(wanted)


def enable_whole_arm(controller, attractor, target, robot_spheres, **kwargs):
    base = type(controller)
    controller.__class__ = type("WholeArm" + base.__name__, (WholeArmMixin, base), {})
    controller.init_whole_arm(attractor, target, robot_spheres, **kwargs)
    return controller


class PostureMixin:
    """A weak joint-space pull toward one known collision-free goal posture.

    Not a path: only a cost row sqrt(w) * (qdot - k (q_goal - q)), so LiuQP's
    constraints still decide every motion.  Tests whether the wall stall is a
    posture problem (elbow up, wrist pitched down) that position tasks cannot ask for.
    """

    def init_posture(self, q_goal, weight: float = 0.02, gain: float = 1.0, max_speed: float = 0.5):
        self.posture_goal = np.asarray(q_goal, dtype=float)
        self.posture_weight = float(weight)
        self.posture_gain = float(gain)
        self.posture_max_speed = float(max_speed)

    def task_feedback(self, target):
        ee, jacobian, desired = super().task_feedback(target)
        q = self.data.qpos[:self.nv]
        # Joints are periodic: head for the nearest equivalent of the goal angle.
        delta = (self.posture_goal - q + np.pi) % (2.0 * np.pi) - np.pi
        velocity = self.posture_gain * delta
        speed = float(np.max(np.abs(velocity)))
        if speed > self.posture_max_speed:
            velocity *= self.posture_max_speed / speed
        scale = np.sqrt(self.posture_weight)
        return ee, np.vstack([jacobian, scale * np.eye(self.nv)]), np.concatenate([desired, scale * velocity])


def enable_posture(controller, q_goal, **kwargs):
    base = type(controller)
    controller.__class__ = type("Posture" + base.__name__, (PostureMixin, base), {})
    controller.init_posture(q_goal, **kwargs)
    return controller
