"""Experiment B, graph mode: IRIS-ZO regions built once before motion; an escape is a graph search.

Before motion (known map, target known):
  goal postures (escape_point.goal_configurations), RRT-Connect routes from the start posture to the
  nearest goal postures, each covered by overlapping IRIS-ZO regions, plus regions grown around random
  free postures near the start for coverage.  Two regions are joined when their polytopes intersect;
  the edge point is the deepest point of the intersection (Chebyshev centre, one LP).
At a stall: find a region containing the stuck posture (or a region seed reachable by a free straight
segment), Dijkstra over the region graph to a region containing a goal posture.  Consecutive waypoints
share a convex region, so each straight joint segment stays in one region; it is still verified.
"""
from __future__ import annotations

import heapq
import time

import numpy as np
from scipy.optimize import linprog

from guidance import densify, iris_zo_region, rrt_connect, shortcut


def chebyshev_point(A, b):
    """Deepest point of {q : A q <= b} and its depth (negative / None when empty)."""
    norms = np.linalg.norm(A, axis=1)
    cost = np.zeros(A.shape[1] + 1)
    cost[-1] = -1.0
    result = linprog(cost, A_ub=np.hstack([A, norms[:, None]]), b_ub=b,
                     bounds=[(None, None)] * A.shape[1] + [(0.0, None)], method="highs")
    if result.status != 0:
        return None, None
    return result.x[:-1], float(result.x[-1])


class RegionGraph:
    def __init__(self, checker, rng, *, samples: int, iterations: int):
        self.checker, self.rng = checker, rng
        self.samples, self.iterations = samples, iterations
        self.regions = []
        self.edges: dict[int, dict[int, np.ndarray]] = {}
        self.stats = {}

    def add_region(self, seed, lower, upper):
        region = iris_zo_region(self.checker, np.asarray(seed, dtype=float), self.rng, lower, upper,
                                samples=self.samples, iterations=self.iterations)
        self.regions.append(region)
        self.edges[len(self.regions) - 1] = {}
        return region

    def cover_route(self, path, lower, upper):
        start = 0
        while start < len(path) - 1:
            region = self.add_region(path[start], lower, upper)
            last = start
            while last + 1 < len(path) and region.contains(path[last + 1]):
                last += 1
            start = max(last, start + 1)

    def connect(self, reach: float = 2.5, depth: float = 1e-3):
        count = 0
        for i in range(len(self.regions)):
            for j in range(i + 1, len(self.regions)):
                a, b = self.regions[i], self.regions[j]
                if np.linalg.norm(a.seed - b.seed) > reach:
                    continue
                point, d = chebyshev_point(np.vstack([a.A, b.A]), np.concatenate([a.b, b.b]))
                count += 1
                if point is not None and d > depth:
                    self.edges[i][j] = point
                    self.edges[j][i] = point
        self.stats["lp_checks"] = count
        self.stats["edges"] = sum(len(v) for v in self.edges.values()) // 2

    def containing(self, q):
        return [k for k, r in enumerate(self.regions) if r.contains(q, tolerance=1e-6)]

    def attach(self, seed, lower, upper, reach: float = 2.5, depth: float = 1e-3):
        """Grow one region at `seed` (e.g. where the arm got stuck) and join it to the graph."""
        region = self.add_region(seed, lower, upper)
        k = len(self.regions) - 1
        for j in range(k):
            other = self.regions[j]
            if np.linalg.norm(other.seed - region.seed) > reach:
                continue
            point, d = chebyshev_point(np.vstack([region.A, other.A]), np.concatenate([region.b, other.b]))
            if point is not None and d > depth:
                self.edges[k][j] = point
                self.edges[j][k] = point
        return k

    def verified_route(self, q_from, goals, attempts: int = 12):
        """route(), with every straight step checked; an edge whose step collides is banned and the
        search repeated.  Returns (waypoints or None, banned edge count)."""
        banned = set()
        for _ in range(attempts):
            result = self.route(q_from, goals, frozenset(banned), with_edges=True)
            if result is None:
                return None, len(banned)
            way, steps = result
            points = [q_from] + way
            bad = None
            for (a, b), edge in zip(zip(points[:-1], points[1:]), steps):
                if not self.checker.segment_free(a, b, step=0.01):
                    bad = edge
                    break
            if bad is None:
                return way, len(banned)
            if bad[0] is None:   # the joining step itself: drop that seed
                return None, len(banned)
            banned.add(bad)
            banned.add((bad[1], bad[0]))
        return None, len(banned)

    def route(self, q_from, goals, banned=frozenset(), segment_margin=None, with_edges=False):
        """Waypoints from q_from to a goal posture through the region graph, or None."""
        starts = [(k, []) for k in self.containing(q_from)]
        if not starts:   # join through the nearest region seeds reachable in a straight free segment
            order = sorted(range(len(self.regions)), key=lambda k: float(np.linalg.norm(self.regions[k].seed - q_from)))
            for k in order[:8]:
                if self.checker.segment_free(q_from, self.regions[k].seed, step=0.02):
                    starts.append((k, [self.regions[k].seed]))
                    break
        goal_regions = {}
        for g in goals:
            for k in self.containing(g):
                goal_regions.setdefault(k, g)
        if not starts or not goal_regions:
            return None
        heap, best = [], {}
        for k, prefix in starts:
            entry = prefix[-1] if prefix else q_from
            steps = ((None, k),) if prefix else ()
            heapq.heappush(heap, (float(np.linalg.norm(entry - q_from)), k, tuple(map(tuple, prefix)), steps, tuple(entry)))
        while heap:
            cost, k, way, steps, entry = heapq.heappop(heap)
            if best.get(k, np.inf) <= cost:
                continue
            best[k] = cost
            entry = np.asarray(entry)
            if k in goal_regions and (k, k) not in banned:
                goal = goal_regions[k]
                way = [np.asarray(p) for p in way] + [goal]
                return (way, list(steps) + [(k, k)]) if with_edges else way
            for n, point in self.edges[k].items():
                if (k, n) in banned:
                    continue
                step = float(np.linalg.norm(point - entry))
                heapq.heappush(heap, (cost + step, n, way + (tuple(point),), steps + ((k, n),), tuple(point)))
        return None


def build_graph(checker, start, goals, rng, *, samples, iterations, routes: int = 3, extra_seeds: int = 30):
    """Region graph for one task: routes start -> nearest goal postures, plus coverage near the start."""
    started = time.perf_counter()
    graph = RegionGraph(checker, rng, samples=samples, iterations=iterations)
    found = 0
    rrt_ms = 0.0
    for goal in sorted(goals, key=lambda g: float(np.linalg.norm(g - start))):
        phase = time.perf_counter()
        path = None
        for box in (1.0, 2.0, 3.5):
            path = rrt_connect(checker, start, goal, rng, iterations=8000, margin=box)
            if path is not None:
                break
        rrt_ms += 1000 * (time.perf_counter() - phase)
        if path is None:
            continue
        dense = densify(shortcut(checker, path, rng, rounds=60))
        lower = np.maximum(dense.min(axis=0) - 0.5, checker.lower)
        upper = np.minimum(dense.max(axis=0) + 0.5, checker.upper)
        graph.cover_route(dense, lower, upper)
        found += 1
        if found >= routes:
            break
    lower = np.maximum(start - 1.0, checker.lower)
    upper = np.minimum(start + 1.0, checker.upper)
    seeds = 0
    for _ in range(extra_seeds * 5):
        if seeds >= extra_seeds:
            break
        q = rng.uniform(lower, upper)
        if checker.free(q):
            graph.add_region(q, lower, upper)
            seeds += 1
    phase = time.perf_counter()
    graph.connect()
    graph.stats.update(routes=found, regions=len(graph.regions), rrt_ms=rrt_ms,
                       connect_ms=1000 * (time.perf_counter() - phase),
                       build_ms=1000 * (time.perf_counter() - started))
    return graph
