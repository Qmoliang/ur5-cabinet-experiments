from pathlib import Path
import os,sys,json
os.sched_setaffinity(0,set(map(int,sys.argv[2].split(','))) if len(sys.argv)>2 else {56,57,58,59})
import numpy as np,mujoco
from pilot_adapter import ROOT
folder=Path(sys.argv[1]);job=json.loads((folder/'job.json').read_text());result=json.loads((folder/'result.json').read_text());summary=result.get('policy_summary') or {};memories=json.loads((folder/'goalward_memories.json').read_text())
entry=json.loads((ROOT/'INPUTS.json').read_text())[0];model=mujoco.MjModel.from_xml_path(entry['scene']);data=mujoco.MjData(model);site=model.site('attachment_site').id
port=summary['goal_port'];P=np.asarray(port['posture_matrix']);qg=np.asarray(port['goal_q']);target=np.asarray(port['target']);q=np.load(folder/'trajectory.npz')['q']
body=int(model.site_bodyid[site]);length=float(np.linalg.norm(model.site_pos[site]))
while body:
    length+=float(np.linalg.norm(model.body_pos[body]));j0=model.body_jntadr[body]
    for j in range(j0,j0+model.body_jntnum[body]):length+=2*float(np.linalg.norm(model.jnt_pos[j]))
    body=int(model.body_parentid[body])
curvature=2*length
def feature(qi):
    data.qpos[:6]=qi;mujoco.mj_kinematics(model,data);return np.r_[data.site_xpos[site].copy(),P@(qi-qg)]
features=np.asarray([feature(qi) for qi in q]);records=[];bad=[];subdivisions=0
for index,m in enumerate(memories):
    normal=np.asarray(m['normal']);activation=m['activation_cycle'];values=features@normal-m['offset'];start=m['hit_cycle'];minimum=float(values[activation:].min());goal=float(np.r_[target,np.zeros(2)]@normal-m['offset']);hit_error=float(np.max(np.abs(features[start]-m['hit_feature'])))
    failures=[]
    def interval(a,b,fa,fb,depth=0):
        global subdivisions
        va=float(normal@fa-m['offset']);vb=float(normal@fb-m['offset']);bound=min(va,vb)-np.linalg.norm(normal[:3])*curvature*np.sum(np.abs(b-a))**2/8
        if bound>=-1e-9:return True
        if min(va,vb)<-1e-9 or depth>=12:return False
        subdivisions+=1;mid=(a+b)/2;fm=feature(mid)
        return interval(a,mid,fa,fm,depth+1) and interval(mid,b,fm,fb,depth+1)
    for k in range(activation,len(q)-1):
        if not interval(q[k],q[k+1],features[k],features[k+1]):failures.append(k)
    record=dict(memory_index=index,activation_cycle=activation,hit_cycle=start,minimum_value_m=minimum,goal_value_m=goal,hit_value_m=float(values[start]),hit_feature_reconstruction_error=hit_error,failed_intervals=failures)
    records.append(record)
    if failures or goal<=0 or hit_error>1e-8 or values[start]>=0:bad.append(index)
out=dict(passed=not bad,memory_count=len(memories),bad_memories=bad,records=records,subdivisions=subdivisions,scope='independent continuous low-dimensional memory check; zero memories means the mechanism was not exercised',runtime_memory_failures=summary.get('memory_certificate_failures'))
(folder/'memory_audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(dict(name=folder.name,passed=out['passed'],memories=len(memories),bad=bad)))
