import pathlib,sys,os,json,numpy as np,mujoco,time
S=pathlib.Path('/mnt/ssd2/hsjed/ur5_cabinet/v6runs/unified_static_20261102');R=S;case=pathlib.Path(sys.argv[1]);d=json.load(open(case/'summary.json'));K=pathlib.Path(json.loads((case/'job.json').read_text())['code_root'])/'known/known_v6';sys.path.insert(0,str(K));import run as kr
from pathlib import Path as _AuditPath; AUDIT=_AuditPath(os.environ.get('AUDIT_OUTPUT_DIR',str(R/'audits')));AUDIT.mkdir(parents=True,exist_ok=True)
from tight_static_guard import TightStaticGuard as StaticCertificateGuard
z=np.load(case/'proxies.npz');cover=type('Cover',(),{k:z[k] for k in z.files if k!='representation'})();model=mujoco.MjModel.from_xml_path(str(case/'runtime_scene.xml' if (case/'runtime_scene.xml').exists() else case/'scene.xml'));robot=[x for x in kr.build_robot_certificate(model) if model.body_mocapid[x.body_id]<0];data=mujoco.MjData(model);rad=np.array([s.radius for s in robot]);body=np.array([s.body_id for s in robot]);lc=np.array([s.local_center for s in robot]);q=np.load(case/'q_history.npy');g=StaticCertificateGuard(cover,d['representation']);g.kernel.set_pair_threads(1)
lever=[]
for b,l in zip(body,lc):
 depth=np.linalg.norm(l);b=int(b)
 while b:
  depth+=np.linalg.norm(model.body_pos[b]);start=model.body_jntadr[b]
  for j in range(start,start+model.body_jntnum[b]):depth+=2*np.linalg.norm(model.jnt_pos[j])
  b=int(model.body_parentid[b])
 lever.append(depth)
Kbound=2*max(lever);minimum=np.inf;worst_q=None;calls=0

def positions(qi):
 data.qpos[:6]=qi;mujoco.mj_kinematics(model,data);return data.xpos[body]+np.einsum('nij,nj->ni',data.xmat[body].reshape(-1,3,3),lc)
def gap(qi):
 global minimum,worst_q,calls
 calls+=1;p=positions(qi);value=min(.020,g.certify(p,p,rad+.020).minimum_clearance_m+.020)
 if value<minimum:minimum=value;worst_q=qi.copy()
 return value
bad=[];lower=np.inf;sub=0

def certify(a,b,ga,gb,depth=0):
 global lower,sub
 bound=g.certify(positions(a),positions(b),rad+.006+Kbound*np.sum(np.abs(b-a))**2/8+1e-10).minimum_clearance_m+.006
 if bound>=.006-1e-7:lower=min(lower,bound);return True
 if min(ga,gb)<.006-1e-7 or depth>=12:return False
 sub+=1;m=(a+b)*.5;gm=gap(m);return certify(a,m,ga,gm,depth+1) and certify(m,b,gm,gb,depth+1)
start=time.perf_counter();a=gap(q[0])
for i in range(len(q)-1):
 b=gap(q[i+1])
 if not certify(q[i],q[i+1],a,b):bad.append(i)
 a=b
# Independent vector bisection reference at the worst sampled state.
p=positions(worst_q);ids=g.tree.query_ball_point(p,rad+g.bound+.020);ri=np.repeat(np.arange(len(rad)),[len(a) for a in ids]);oi=np.array([j for a in ids for j in a],dtype=int);y=np.abs(p[ri]-cover.centers[oi])
if d['representation']=='sphere':dist=np.linalg.norm(y,axis=1)-cover.sphere_radii[oi]
else:
 a2=np.diagonal(cover.ellipsoid_shapes[oi],axis1=1,axis2=2);lo=np.zeros(len(oi));hi=np.linalg.norm(y,axis=1)*np.sqrt(a2.max(axis=1))+1e-12;inside=np.sum(y*y/a2,axis=1)<=1
 for _ in range(70):
  t=(lo+hi)/2;f=np.sum(a2*y*y/(a2+t[:,None])**2,axis=1)-1;lo=np.where(f>0,t,lo);hi=np.where(f>0,hi,t)
 closest=a2*y/(a2+hi[:,None]);dist=np.where(inside,0,np.linalg.norm(y-closest,axis=1))
reference=min(.020,float(np.min(dist-rad[ri],initial=.020)));v=np.diff(q,axis=0)/.02;acc=np.diff(np.vstack([np.zeros(6),v]),axis=0)/.02
result=dict(audit_method="support_planes_and_joint_arc_remainder",case=case.name,representation=d['representation'],goal_success=d['success'],cycles=d['cycles'],required_margin_m=.006,operating_margin_m=d['safety_margin_m'],continuous_proxy_passed=not bad,minimum_sampled_proxy_gap_mm=minimum*1000,certified_segment_lower_bound_mm=lower*1000,independent_reference_gap_mm=reference*1000,reference_difference_m=abs(reference-minimum),failed_intervals=bad,states_evaluated=calls,subdivisions=sub,peak_acceleration=float(np.abs(acc).max()),execution_guard=d.get('execution_guard'),audit_wall_s=time.perf_counter()-start)
(AUDIT/f'{sys.argv[2]}_proxy.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['failed_intervals','execution_guard']}),flush=True)
