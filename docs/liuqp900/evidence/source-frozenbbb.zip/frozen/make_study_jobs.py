from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_lowdim_pilot_20261106'
jobs=[]
for name,method,version in [('admission_only','full','admission'),('reserve_metric','metric','reserve'),('reserve_release','release','reserve'),('release_without_metric','release_only','reserve')]:
    jobs.append(dict(name=name,task='iris_4shelves_t2',method=method,policy_version=version,representation='ellipsoid',solver_profile='verified_common',max_cycles=15000,stop_after_stall=False,wall_limit_s=900))
snapshot=OLD/'confirm_original_shelf_t2_baseline_300s_final_snapshot.npz'
jobs.append(dict(name='release_from_real_stall',task='iris_4shelves_t2',method='release',policy_version='reserve',representation='ellipsoid',solver_profile='verified_common',start_snapshot=str(snapshot),max_cycles=15000,stop_after_stall=False,wall_limit_s=900))
(ROOT/'study_jobs.json').write_text(json.dumps(jobs,indent=2))
files=list(ROOT.glob('*.py'))+[ROOT/'study_jobs.json',ROOT/'INPUTS.json',ROOT/'code/online/protocol_liuqp_controller.py',ROOT/'code/common/policy.json']
freeze=dict(task='iris_4shelves_t2',seed=1,jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},new_objective='original LiuQP + one-sided squared rate of consuming remaining stopping-adjusted joint travel; optional scalar active-limit release',success_trace_in_runtime=False,no_scene_change=True,no_planner=True,no_new_goal_postures=True,all_failures_retained=True,interpretation='from-initial prevention and from-stall recovery reported separately')
(ROOT/'STUDY_FREEZE.json').write_text(json.dumps(freeze,indent=2));print(json.dumps([x['name'] for x in jobs]))
