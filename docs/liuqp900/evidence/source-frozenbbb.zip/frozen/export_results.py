from pathlib import Path
import json,hashlib,zipfile,shutil,datetime
from zoneinfo import ZoneInfo
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_goal_entry_study_20261106';OUT=ROOT/'delivery';OUT.mkdir(exist_ok=True)
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
protected=read(ROOT/'PROTECTED_PREVIOUS_STUDY.json');changed=[name for name,d in protected.items() if not Path(name).exists() or sha(Path(name))!=d];assert not changed,changed
inputs=read(ROOT/'INPUTS.json')
for item in inputs:
    assert sha(Path(item['input_file']))==item['input_sha256'];assert sha(Path(item['scene']))==item['scene_sha256']
source_index={}
for p in list(ROOT.glob('*.py'))+list((ROOT/'revisions').rglob('*.py'))+[ROOT/'code/online/protocol_liuqp_controller.py']:
    source_index.setdefault(sha(p),[]).append(str(p.relative_to(ROOT)))
records=[]
for folder in sorted((ROOT/'trials').iterdir()):
    if not (folder/'result.json').exists():continue
    r=read(folder/'result.json');job=read(folder/'job.json');a=read(folder/'audit.json') if (folder/'audit.json').exists() else None;m=read(folder/'memory_audit.json') if (folder/'memory_audit.json').exists() else None;ps=r.get('policy_summary') or {};tr=np.load(folder/'trajectory.npz');ev=ps.get('reheading_events',[])
    manifest=read(folder/'source_hashes.json');missing={name:d for name,d in manifest.items() if d not in source_index}
    rec=dict(name=folder.name,status=r['status'],version=job['policy_version'],sim_s=r['sim_s'],wall_s=r['wall_s'],error_mm=r['final_error_mm'],goal_hold=r['maximum_hold'],physical_safety=None if a is None else a['safety_passed'],memory_audit=None if m is None else m['passed'],goal_reached=bool(r['goal_hold_reached']),validated_arrival=bool(a and a['safe_arrival'] and m and m['passed'] and not ps.get('memory_certificate_failures',0)),memory_count=ps.get('memory_count',0),reheading_count=ps.get('reheading_count',0),reheading_braking_requests=ps.get('reheading_braking_requests',0),goal_side_dominance_reheadings=ps.get('goal_side_dominance_reheadings',0),first_reheading_s=None if not ev else ev[0]['cycle']*.02,reheading_events=ev,controller_p99_ms=r.get('controller_ms_p99'),guard_p99_ms=r['guard'].get('ms_p99'),latency_model=r.get('latency_model'),latency_trace_tail_uses=r.get('latency_trace_tail_uses'),qp_braking_steps=r.get('qp_certified_braking_steps',0),forbidden_calls=r['forbidden_calls'],source_unavailable=missing,job=job)
    if a is not None:rec.update(minimum_proxy_gap_mm=a['minimum_proxy_gap_mm'],minimum_self_gap_mm=1000*a['physical_motion']['minimum_self_m'],workspace_passed=a['workspace']['passed'],minimum_workspace_sampled_slack_m=a['workspace']['minimum_sampled_slack_m'],workspace_uncertified_intervals=len(a['workspace']['bad_intervals']))
    w=read(folder/'workspace_refinement.json') if (folder/'workspace_refinement.json').exists() else None
    rec['workspace_refinement']=w
    other=bool(a and a['physical_motion']['passed'] and not a['proxy_failed_intervals'] and a['minimum_proxy_gap_mm']>=5.9999 and a['joint_slack_rad']>=-1e-10 and a['braking_slack_rad']>=-1e-10 and a['peak_velocity_ratio']<=1+1e-8 and a['peak_acceleration']<=10.0001 and r['truth_penetrating_cycles']==0 and r['guard']['failed']==0)
    rec['non_workspace_safety']=other
    rec['supplementary_certified_arrival']=bool(other and w and w['passed'] and a['goal_passed'] and m and m['passed'] and not ps.get('memory_certificate_failures',0))
    if (folder/'error.json').exists():rec['error']=read(folder/'error.json')['error']
    records.append(rec)
lookup={r['name']:r for r in records}
group_names={'original_failure':['reference_failed_schedule'],'v1_fixed':[f'reheading_failed_schedule_{i}' for i in [1,2,3]],'v1_measured':[f'reheading_measured_{i}' for i in [1,2,3]],'v1_online':['reheading_original_start'],'v2_fixed':[f'reheading_v2_failed_schedule_{i}' for i in [1,2,3]],'v2_measured':[f'reheading_v2_measured_{i}' for i in [1,2,3]],'v2_online':['reheading_v2_original_start']}
groups={k:dict(names=names,attempted=sum(n in lookup for n in names),goal_arrivals=sum(n in lookup and lookup[n]['goal_reached'] for n in names),validated_arrivals=sum(n in lookup and lookup[n]['validated_arrival'] for n in names)) for k,names in group_names.items()}
for k,g in groups.items():g['supplementary_certified_arrivals']=sum(n in lookup and lookup[n]['supplementary_certified_arrival'] for n in g['names'])
data=dict(completed_local_time=datetime.datetime.now(datetime.timezone.utc).astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),scope='MuJoCo only, same original shelf and stalled state; no RRT or configuration-path search',groups=groups,records=records,counts=dict(runs=len(records),goal_arrivals=sum(r['goal_reached'] for r in records),validated_arrivals=sum(r['validated_arrival'] for r in records),supplementary_certified_arrivals=sum(r['supplementary_certified_arrival'] for r in records),supplementary_workspace_passed=sum(bool(r['workspace_refinement'] and r['workspace_refinement']['passed']) for r in records),audited=sum(r['physical_safety'] is not None for r in records),safety_not_passed=[r['name'] for r in records if r['physical_safety'] is False]),integrity=dict(previous_files_checked=len(protected),changed=changed,input_manifest=inputs),missing_sources={r['name']:r['source_unavailable'] for r in records if r['source_unavailable']})
(OUT/'RESULTS.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
lines=['目标端重新选向：同一货架复验','完成时间：'+data['completed_local_time'],'','所有试验均为 MuJoCo；用户已明确没有实体 UR5e。本轮没有连接或控制实体机器人。','同一目标、场景、停滞快照、安全阈值和 300 s 仿真预算保持不变。','', '分组结果（固定延迟重复是确定性复现，不能作为独立统计样本）：']
for group,v in groups.items():
    lines.append(f"{group}: 到达 {v['goal_arrivals']}/{v['attempted']}；经原安全与记忆审计的到达 {v['validated_arrivals']}/{v['attempted']}；使用补充工作空间界且其余审计通过的到达 {v['supplementary_certified_arrivals']}/{v['attempted']}")
    for name in v['names']:
        if name in lookup:
            r=lookup[name];lines.append(f"  {name}: {r['status']}, {r['sim_s']:.2f}s, {r['error_mm']}mm, 重选 {r['reheading_count']} 次, 首次 {r['first_reheading_s']}s, workspace={r.get('workspace_passed')}")
lines+=['','关键证据：',
'第二版固定失败延迟三次均在 244.04 s 到达；三次是同一确定性时序，不是三个独立成功样本。自然延迟只有 1/3 到达，从原始起点的整程检查失败。本轮尚未实现稳定脱困。',
'全部 15 条轨迹的障碍、自碰、关节/制动、速度/加速度及记忆检查均通过。原工作空间审计 10 条未通过；同容差补充界通过其中 4 条，另 6 条失败运行仍有未能认证的区间，不能宣称它们连续安全已获证明。全部 5 条到达轨迹在保留原审计结果的同时获得完整补充组合核验。',
'原安全审计保持原样。补充工作空间证书对全部 15 条轨迹统一执行，使用逐机器人球的活动关节界和端点一致抛物线下界，容差仍为 -1e-10 m；只补充工作空间，不替代障碍、自碰、关节、制动和记忆审计。端点运动学仍为 MuJoCo 浮点计算，不是精确实数或硬件保证。',
'原失败对照与上一轮 12139 个关节状态逐项一致。第一版的三次坏时序回放在 240.74 s 才换向约 29.04 度，三次均未在 300 s 内到达。这一失败没有删除。',
'第二版不再把“旧动作还能执行”当成继续沿用的充分理由。在实际没有净进展时，比较通过同一安全门后的目标侧速度；请求重选时，新方向必须严格优于旧方向。移动时先制动，再在停止状态重新求解和认证。',
'方向来自目标端的当前切向，以及由已认证局部回退段决定的正交侧；候选只有当前二维切平面的四个方向。目标端终态、QP 目标、硬安全及原有防回陷约束没有更换或删除。',
'局部记忆记录实际状态和已尝试的目标切向类别，避免在同一状态附近反复作相同选择；它不是路径图，也不优化未来构型。',
'单步候选可认证不算到达。所有成功、失败及原工作空间审计未通过的记录都分别列出。',
'固定延迟项只使用旧计算延迟数组，不使用旧关节轨迹作控制参考；实际计算时间仍记录。是否消耗延迟数组尾部见 RESULTS.json。',
'本轮没有验证实体机、持续新感知、跨 seed/场景或硬实时。局部方向重选也不构成全局可达性或所有局部极小可逃逸的证明。','',
'代码入口：reheading_policy_v2.py；底层仍使用原 LiuQP 当前速度求解与原安全门。',
'原有文件完整性：'+json.dumps(data['integrity'],ensure_ascii=False),
'全部运行统计：'+json.dumps(data['counts'],ensure_ascii=False)]
(OUT/'FINAL_REPORT.txt').write_text('\n'.join(lines),encoding='utf-8')
for name in ['DERIVATION.txt','HARDWARE_SCOPE.txt','STUDY_FREEZE.json','V2_FREEZE.json','REHEADING_EVIDENCE.json','HEADING_STATE_REPLAY.json','REFERENCE.json','FAILURE_DIAGNOSTICS.json','FAILURE_ANALYSIS.txt']:
    if (ROOT/name).exists():shutil.copy2(ROOT/name,OUT/name)
fig,axes=plt.subplots(1,2,figsize=(12,5),constrained_layout=True)
for name,label,style in [('reference_failed_schedule','Original failure','--'),('reheading_failed_schedule_1','Late-only reselection','-.'),('reheading_v2_failed_schedule_1','Goal-side reselection 1','-'),('reheading_v2_failed_schedule_2','Goal-side reselection 2',':'),('reheading_v2_failed_schedule_3','Goal-side reselection 3','--')]:
    path=ROOT/'trials'/name/'trajectory.npz'
    if path.exists():
        z=np.load(path);axes[0].plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,style,label=label,lw=1.5)
for i in [1,2,3]:
    name=f'reheading_v2_measured_{i}';path=ROOT/'trials'/name/'trajectory.npz'
    if path.exists():
        z=np.load(path);axes[1].plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,label=f'Measured delay {i}',lw=1.4)
path=ROOT/'trials/reheading_v2_original_start/trajectory.npz'
if path.exists():
    z=np.load(path);axes[1].plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,'--',label='Original-start integration',lw=1.3)
axes[0].set_title('Same failed delay sequence');axes[1].set_title('Measured latency and original start')
for ax in axes:ax.set_yscale('log');ax.axhline(1,color='.5',ls=':',lw=.7);ax.set_xlabel('Simulated time (s)');ax.set_ylabel('Goal error (mm, log)');ax.grid(alpha=.2);ax.legend(fontsize=7)
fig.savefig(OUT/'comparison.png',dpi=170);plt.close(fig)
(OUT/'REPRODUCE.txt').write_text(f'''Remote root: {ROOT}
Python: /home/hsjed/envs/ur5cab/bin/python
Use a NEW trial folder with a frozen job.json; never overwrite prior runs.
Worker: pilot_worker_reheading.py; policy_version=reheading_v2.
Environment: OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2 PYTHONDONTWRITEBYTECODE=1
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
Run: python pilot_worker_reheading.py trials/NEW_RUN
Audits: python audit_entry_batch.py NEW_RUN
Supplementary workspace: python audit_workspace_refined.py trials/NEW_RUN 60,61,62,63
The large observed map, model assets and native/runtime dependencies remain at
the server paths in INPUTS.json. This source/results archive is not standalone.
Original audits are retained even when conservative workspace certification fails.
''')
files=list(ROOT.glob('*.py'))+list(ROOT.glob('*.json'))+list(ROOT.glob('*.txt'))+list(ROOT.glob('*.npy'))
files+=list((ROOT/'revisions').rglob('*'))+list((ROOT/'trials').rglob('*'))
files += [p for p in (ROOT/'code').rglob('*') if p.suffix in ('.py','.json','.cpp','.h','.hpp','.sh','.xml','.txt')]
files += [p for p in OUT.iterdir() if p.suffix!='.zip' and p.name!='BUNDLE_MANIFEST.json']
manifest={};zpath=OUT/'reheading_sources_and_results.zip'
with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(set(files)):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=str(p.relative_to(ROOT));z.write(p,rel);manifest[rel]=dict(bytes=p.stat().st_size,sha256=sha(p))
(OUT/'BUNDLE_MANIFEST.json').write_text(json.dumps(dict(archive_sha256=sha(zpath),archive_bytes=zpath.stat().st_size,files=manifest),indent=2))
print(json.dumps(dict(groups=groups,counts=data['counts'],missing_sources=data['missing_sources'],archive_bytes=zpath.stat().st_size),ensure_ascii=False))
