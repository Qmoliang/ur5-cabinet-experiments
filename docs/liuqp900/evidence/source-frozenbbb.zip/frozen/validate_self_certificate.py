import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy_v4 import LowDimPolicy
out=[]
for name in ['entry_v3_only_stall','entry_v3_clearance_exit_stall']:
    folder=ROOT/'trials'/name;q=np.load(folder/'trajectory.npz')['q'][-1];job=json.loads((folder/'job.json').read_text());r=json.loads((folder/'result.json').read_text());ctx=build('iris_4shelves_t2',start=q);c=ctx.controller
    c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
    p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,np.zeros(6));s=c.pilot_nominal;arrays=c.last_qp_arrays
    record=dict(state=name,self_inward_reserve_m=2e-9+.02*1e-7,proposals=[])
    def check(label,release=None):
        answer=p._solve(c,s,arrays,release=release)
        if answer is None:record['proposals'].append(dict(label=label,solved=False));return
        v=np.clip(answer['velocity'],*c.joint_velocity_bounds());scales=[a for a in [1.,.75,.5,.25,.125,.0625,0.] if ctx.guard.braking_safe(ctx.proxy_guard,q,a*v)]
        record['proposals'].append(dict(label=label,solved=True,velocity=v.tolist(),safe_scales=scales))
    check('goal_objective')
    p.blocker_id=r['policy_summary'].get('blocker_id')
    if p.blocker_id is not None:
        p.mode='OPEN';point,n,J,gap=p._geometry();b=n@J;b/=np.linalg.norm(b);support=p._support(c,s,arrays,b)
        if support is not None:check('half_support_release',(b,.5*support))
    out.append(record);print(json.dumps(record),flush=True)
assert all(any(any(a>0 for a in p.get('safe_scales',[])) for p in r['proposals']) for r in out)
(ROOT/'SELF_CERTIFICATE_VALIDATION.json').write_text(json.dumps(out,indent=2))
