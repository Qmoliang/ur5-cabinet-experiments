"""No-object runs of the small validation: final / minimum error, where the gripper ends, statuses."""
import csv
from collections import Counter
from pathlib import Path

import numpy as np

for ctl in ("liuqp", "liuqphe", "combined", "neo_matched", "neo_paper"):
    for d in sorted(Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e4v").glob(f"{ctl}_k0_v0.0/seed*")):
        if not d.is_dir():
            continue
        inner = next(d.glob("A-CV-*"))
        rows = list(csv.DictReader(open(inner / "cycles.csv")))
        err = np.array([float(r["error_m"]) for r in rows])
        ee = np.array([[float(r["ee_x"]), float(r["ee_y"]), float(r["ee_z"])] for r in rows])
        status = Counter(r["status"][:16] for r in rows[-500:]).most_common(2)
        print(f"{ctl:12s} {d.name}  final {err[-1]*1000:6.1f} mm  min {err.min()*1000:6.1f} mm  end gripper {ee[-1].round(3)}  "
              f"min clearance end {float(rows[-1]['min_clearance']):.4f}  {status}")
