#!/bin/bash
# Reviewer batch, known map (approved 2026-10-27): does range explain NEO's racket advantage?
#   neo_split: NEO 0.046 m for static obstacles + 0.30 m for moving ones (UR5_NEO_MOVING_INFLUENCE)
#   liuqp_h06: LiuQP with the racket's future copies out to 0.6 s (UR5_RACKET_HORIZON; 0.30 m at 0.5 m/s)
# Same protocol as pilot_known20 (its runs are the baselines): 4 scenes x 3 racket conditions x
# straight / geodesic x seeds 1-20, far start, safety layer, accel 10.  8 workers x 2 CPUs (112-127).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/review_known
A=/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/assets
jobs=()
for seed in $(seq 1 20); do
  for scene in drawer cage cage_wide iris_ur3_shelf_t0; do
    case $scene in
      drawer) far=$A/far_start_q.npy ;; cage) far=$A/far_start_q_cage.npy ;;
      cage_wide) far=$A/far_start_q_cage_wide.npy ;; *) far=$A/far_start_q_shelf.npy ;;
    esac
    for attr in straight geodesic_native; do
      for ctl in neo_split liuqp_h06; do
        case $ctl in neo_split) base="UR5_CONTROLLER=neo_matched UR5_NEO_MOVING_INFLUENCE=0.30" ;;
                     liuqp_h06) base="UR5_CONTROLLER=liuqp UR5_RACKET_HORIZON=0.6" ;; esac
        for cond in "1 0.25" "1 0.5" "2 0.5"; do
          set -- $cond
          jobs+=("$P/${ctl}_${attr%_native}_k$1_v$2 $scene $attr $seed $base UR5_E4_SAFETY=1 UR5_E4_FAR_START_FILE=$far UR5_ACCEL_LIMIT=10 UR5_OBJECTS=$1 UR5_OBJECT_SPEED=$2")
        done
      done
    done
  done
done
echo "${#jobs[@]} jobs" > review_known.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 8)); do
    set -- ${jobs[$i]}
    out=$1; scene=$2; attr=$3; seed=$4; shift 4
    id=${scene}_ellipsoid_${attr}_seed$(printf "%02d" $seed)
    [ -f $out/$id/summary.json ] && continue
    ./known_job.sh $out $scene ellipsoid $attr $seed $((112 + w * 2)) "$@"
  done
}
for w in 0 1 2 3 4 5 6 7; do worker $w & done
wait
echo DONE > review_known.done
