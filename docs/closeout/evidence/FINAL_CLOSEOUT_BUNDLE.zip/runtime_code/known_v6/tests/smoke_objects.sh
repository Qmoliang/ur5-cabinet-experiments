#!/bin/bash
# Smoke: 4 controllers x {1 object 0.25 m/s, 3 objects 0.5 m/s} x {drawer, cage}, seeds given as $@ (default 1).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
OUT=/tmp/smoke_objects
rm -rf $OUT
seeds=${@:-1}
i=0
for seed in $seeds; do
for ctl in liuqp combined neo_matched liuqphe; do
  for k in 1 3; do
    sp=0.25; [ $k = 3 ] && sp=0.5
    extra="UR5_CONTROLLER=$ctl"
    [ $ctl = liuqphe ] && extra="UR5_CONTROLLER=liuqp UR5_RACKET_HORIZON=0.3 UR5_ESCAPE=1"
    for sc in drawer cage; do
      ./known_job.sh $OUT/${ctl}_k$k $sc ellipsoid geodesic_native $seed $((i * 2 % 80)) $extra \
        UR5_OBJECTS=$k UR5_OBJECT_SPEED=$sp UR5_ACCEL_LIMIT=10 &
      i=$((i + 1))
    done
  done
done
done
wait
for f in $OUT/*/*/summary.json; do
  ~/envs/ur5cab/bin/python - "$f" <<'EOF'
import json, sys
f = sys.argv[1]; s = json.load(open(f)); o = s["objects"]
name = "/".join(f.split("/")[3:5]).replace("_ellipsoid_geodesic_native", "")
print(f"{name:34s} after {str(o['success_after']):5s} contact {o['contact_cycles']:4d} static {s['static_penetrating_cycles']:4d} "
      f"pkJ {s['peak_joint_speed_ratio']:.2f} esc {s['escape_cycles']:3d} fail {s['controller_failure_cycles']:3d} "
      f"rej {o.get('rejected_no_room')} launched {[(d['behaviour'][:2], d['launched']) for d in o['described']]} "
      f"bodies {o.get('contact_bodies')}")
EOF
done
grep -l Traceback $OUT/*/*.log
