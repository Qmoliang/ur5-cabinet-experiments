"""Can RRT-Connect link the seed-2 trapped pose to an IK goal, and at what cost?"""
import sys
import time
from pathlib import Path

import numpy as np

KNOWN = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
sys.path[:0] = [str(KNOWN / "src"), str(KNOWN / "src" / "core"), str(KNOWN), str(KNOWN.parent / "online_v6")]

from ball_tree import NativeBallTree  # noqa: E402
import guidance as g  # noqa: E402
from known_volume import build_volume_cover  # noqa: E402
from robot import build_model, build_robot_certificate  # noqa: E402
from run import load_scene  # noqa: E402

scene = load_scene()
model = build_model(scene)
cover = build_volume_cover(scene.boxes, "ellipsoid", 0.075)
checker = g.ConfigurationChecker(model, build_robot_certificate(model), cover.centers, "ellipsoid",
                                 shapes=cover.ellipsoid_shapes, margin=0.006,
                                 index=NativeBallTree(cover.centers, cover.aabb_half_extents))
history = np.load("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e0/ellipsoid_075mm_seed02/q_history.npy")
success_history = np.load("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e0/ellipsoid_075mm_seed01/q_history.npy")
q_trapped, q_start = history[-1], history[0]
target = np.asarray(scene.waypoints[-1], dtype=float)
rng = np.random.default_rng(2)
goals, rejected = g.solve_goal_configurations(checker, target, q_trapped, rng, references=[q_start])
print("goals", len(goals), rejected)
print("successful run's final pose free at 6 mm:", checker.free(success_history[-1]),
      " distance to goals:", [round(float(np.linalg.norm(success_history[-1] - q)), 3) for q in goals])
# Is the successful run's own trajectory free under the planner's check?
blocked = [i for i in range(0, len(success_history), 25) if not checker.free(success_history[i])]
print("successful trajectory samples blocked by the 6 mm planner check:", len(blocked), "of", len(range(0, len(success_history), 25)))
for iterations, margin in ((6000, 0.8), (30000, 1.5)):
    for goal in goals[:2]:
        checker.checks = 0
        t = time.perf_counter()
        path = g.rrt_connect(checker, q_trapped, goal, rng, iterations=iterations, margin=margin)
        print(f"iterations={iterations} box=+-{margin}: found={path is not None} "
              f"time={time.perf_counter() - t:.1f}s checks={checker.checks}")
        if path is not None:
            break
