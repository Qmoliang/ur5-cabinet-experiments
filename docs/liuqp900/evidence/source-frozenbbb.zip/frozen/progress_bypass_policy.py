"""Short task-space bypass contracts driven by current continuation witnesses."""
import numpy as np
from progress_retreat_policy import LowDimPolicy as Previous
from goal_entry_policy_activated import LowDimPolicy as Solver
from continuation_certified_policy import LowDimPolicy as Certified
from goal_entry_policy import clipped

class LowDimPolicy(Previous):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.bypass=None;self.bypass_records=[];self.bypass_attempts=[];self.bypass_tangent=None;self.bypass_labels=[];self.bypass_last_move=0;self.bypass_best_move=0.
 def _terms(self,c,s):
  if self.mode!='ENTRY_BYPASS':return super()._terms(c,s)
  J=s['J'];v=c.max_task_speed*self.bypass_tangent;N=np.eye(6)-np.linalg.pinv(J,rcond=1e-8)@J;L=self.posture_lever*N;pose=clipped(-c.task_gain*L@(self.q-self.qg),c.max_task_speed)
  return c.task_weight*(L.T@L),c.task_weight*(J.T@(s['desired']-v)-L.T@pose)
 def _solve(self,c,s,arrays,release=None):
  if self.mode=='ENTRY_BYPASS':return Solver._solve(self,c,s,arrays,release)
  return super()._solve(c,s,arrays,release)
 def start_retreat(self):
  self.retreat_requested=False;self.mode='ENTRY_BYPASS';self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8;self.continuation_rows=np.empty((0,6));self.continuation_bounds=np.empty(0);self.solve_cache={};self.bypass=None;self.bypass_tangent=None;self.trust_radius=.04
 def choose_bypass(self,c,s,arrays):
  state=self.future_state;row=min(state['rows'],key=lambda r:r['slack']) if state['rows'] else None
  normal=self.outward.copy() if row is None else np.linalg.pinv(s['J'],rcond=1e-8).T@row['b']
  if np.linalg.norm(normal)<1e-8:normal=self.outward.copy()
  normal/=np.linalg.norm(normal);toward=self.ctx.target-self.ee;t=toward-normal*(normal@toward)
  if np.linalg.norm(t)<1e-8:t=self.outward-normal*(normal@self.outward)
  if np.linalg.norm(t)<1e-8:t=np.eye(3)[np.argmin(np.abs(normal))];t-=normal*(normal@t)
  t/=np.linalg.norm(t);b=np.cross(normal,t);feature=np.r_[self.ee,self.P@(self.q-self.qg)]
  for label,direction in [('goal_tangent',t),('entry_side',b),('other_side',-b),('reverse_tangent',-t)]:
   if any(a['label']==label and np.linalg.norm(a['feature']-feature)<=.001 for a in self.bypass_attempts):continue
   self.bypass_tangent=direction;self.solve_cache={};chosen=self._try_direction(c,s,arrays,direction@s['J'])
   if chosen is None:continue
   self.bypass_attempts.append(dict(label=label,feature=feature.copy()));self.bypass_best_move=0.;self.bypass_last_move=self.k
   self.bypass=dict(start_cycle=self.k,q=self.q.copy(),ee=self.ee.copy(),margin=-state['deficit'],posture=float(np.linalg.norm(self.P@(self.q-self.qg))),label=label,tangent=direction.copy(),source=None if row is None else {k:v for k,v in row.items() if k!='b'})
   self.emit('local_bypass_contract_started',label=label,tangent=direction.tolist(),entry_margin_m=self.bypass['margin'],posture_error_m=self.bypass['posture'],source=self.bypass['source']);return chosen
  return None
 def finish_bypass(self,reason):
  self.witness_anchor=None;state=Certified.continuation_witnesses(self,self.q);self.future_state=state;m=-state['deficit'];z=float(np.linalg.norm(self.P@(self.q-self.qg)));a=self.bypass
  improvement=m-a['margin'];pose_gain=a['posture']-z;accepted=improvement>=.0002 or (improvement>=-2e-7 and pose_gain>=.0002)
  record=dict(start_cycle=a['start_cycle'],end_cycle=self.k,label=a['label'],reason=reason,margin_gain_m=float(improvement),posture_gain_m=pose_gain,accepted=accepted,displacement_m=float(np.linalg.norm(self.ee-a['ee'])))
  self.bypass_records.append(record);self.emit('local_bypass_contract_assessed',**record)
  self.mode='CERT_PREP';self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8;self.best_ready_margin=m;self.last_ready_gain=self.k if accepted else self.k-100;self.macro_anchor=None;self.agreement_anchor=None;self.witness_anchor=None;self.solve_cache={};self.bypass=None
 def __call__(self,c,s,arrays):
  if self.mode!='ENTRY_BYPASS':return super().__call__(c,s,arrays)
  self.expected=None;self.last_delta=np.zeros(6);self.current_s=s;self.proposal_contract=None
  if self.brake_pending or self.terminal:return np.zeros(6)
  if self.bypass is None:
   self.witness_anchor=None;self.future_state=Certified.continuation_witnesses(self,self.q);chosen=self.choose_bypass(c,s,arrays)
   if chosen is None:
    self.failed_retreat_states.append(np.r_[self.ee,self.P@(self.q-self.qg)]);self.mode='CERT_PREP';self.last_ready_gain=self.k;self.brake_pending=True;self.command_epoch+=1;self.emit('no_current_lowdim_bypass_admitted');return np.zeros(6)
   return self._publish(c,chosen[0])
  movement=float(np.linalg.norm(self.ee-self.bypass['ee']))
  if movement>self.bypass_best_move+.0002:self.bypass_best_move=movement;self.bypass_last_move=self.k
  if movement>=c.near_distance or self.k-self.bypass_last_move>=100:
   self.finish_bypass('local_displacement_completed' if movement>=c.near_distance else 'actual_bypass_motion_stalled');return np.zeros(6)
  chosen=self._try_direction(c,s,arrays,self.bypass_tangent@s['J'])
  if chosen is not None:return self._publish(c,chosen[0])
  self.brake_pending=True;return np.zeros(6)
 def summary(self):
  out=super().summary();out.update(local_bypass_contracts=self.bypass_records,local_bypass_attempts=len(self.bypass_attempts),bypass_parameterization='four directions in current two-dimensional task tangent plane; only current velocity QP; each original-near-distance displacement is checked against refreshed continuation margin and posture progress',retreat_parameterization='no distant Cartesian gate; no goal-pose selection or future configuration search')
  return out
