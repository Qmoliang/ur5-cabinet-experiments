#!/bin/bash
# Geodesic attraction (X1), per-link planes (X2), both (X3), and the matching baseline (B0).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
COMMON="UR5_KNOWN_INDEX=ball_tree UR5_PYTHON_PLANES=1"
./launch_seeds.sh $PWD/x_b0_baseline  ellipsoid 0.075 64 $COMMON &
./launch_seeds.sh $PWD/x_x1_geodesic  ellipsoid 0.075 84 $COMMON UR5_ATTRACTION=geodesic &
./launch_seeds.sh $PWD/x_x2_linkplanes ellipsoid 0.075 104 $COMMON UR5_LINK_REGIONS=1 &
wait
./launch_seeds.sh $PWD/x_x3_both      ellipsoid 0.075 64 $COMMON UR5_ATTRACTION=geodesic UR5_LINK_REGIONS=1 &
wait
echo DONE > $PWD/X_DONE
