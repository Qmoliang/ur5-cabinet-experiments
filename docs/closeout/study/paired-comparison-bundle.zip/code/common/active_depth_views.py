"""Causal view selection from robot kinematics and the already published map.

This is a movable external depth-sensor simulation. It does not certify the
mechanical travel of an external camera carrier. No world geom is queried.
"""
import numpy as np,mujoco
from proxy_geometry import ExactProxyGuard,from_published

class ActiveDepthViews:
 def __init__(self,model,robot,camera_names,roi,representation="ellipsoid"):
  if representation not in {"sphere","ellipsoid"}:raise ValueError("invalid environment representation")
  self.representation=representation
  self.model=model;self.robot=robot;self.ids=[model.camera(n).id for n in camera_names if n.startswith("static_")];self.names=[model.camera(i).name for i in self.ids];self.roi=tuple(np.asarray(x) for x in roi);self.used=set();self.history=[];self.steps=0;self.goal_surveyed=False
  if any(model.cam_bodyid[i]!=0 for i in self.ids):raise ValueError("active external cameras must be world-attached")
 def set_pose(self,camera_id,position,focus):
  forward=focus-position;forward=forward/np.linalg.norm(forward);up=np.array([0.,0.,1.])
  if abs(forward@up)>.98:up=np.array([0.,1.,0.])
  right=np.cross(forward,up);right/=np.linalg.norm(right);vertical=np.cross(right,forward);rotation=np.column_stack([right,vertical,-forward]);quat=np.empty(4);mujoco.mju_mat2Quat(quat,rotation.ravel());self.model.cam_pos[camera_id]=position;self.model.cam_quat[camera_id]=quat
 def choose(self,proxies,positions,radii,occupancy,target=None,sensing_points=None):
  arrays=from_published(proxies,self.representation);g=ExactProxyGuard(arrays);ri,oi=g.pairs(positions,positions,radii+.035)
  dist,normal=g.point_geometry(positions[ri],oi);gap=dist-radii[ri]
  unseen_pairs=np.flatnonzero(g.isbox[oi]);order=unseen_pairs[np.argsort(gap[unseen_pairs],kind="stable")] if len(unseen_pairs) else np.argsort(gap,kind="stable");selected=[]
  # Cover distinct blocking cells, rather than selecting many proxies for one body.
  for k in order:
   i=int(ri[k]);j=int(oi[k]);focus=g.centers[j].copy()
   if any(np.linalg.norm(focus-x[0])<.025 for x in selected):continue
   selected.append((focus,normal[k],float(gap[k])))
   if len(selected)==len(self.ids):break
  if not selected:
   if sensing_points is not None and len(sensing_points):
    requested=np.asarray(sensing_points,dtype=float);selected=[(requested[i%len(requested)],np.zeros(3),.03) for i in range(len(self.ids))]
   elif target is not None and not self.goal_surveyed:
    selected=[(np.asarray(target,dtype=float),np.zeros(3),.03) for _ in self.ids]
   else:return []
  unseen_gap=float(np.min(gap[unseen_pairs])) if len(unseen_pairs) else float("inf")
  need_goal_views=sensing_points is not None and len(sensing_points)>0
  if unseen_gap>=.010 and not need_goal_views and self.goal_surveyed:return []
  if unseen_gap>=.010 and target is not None and len(self.ids)>=4:
   target=np.asarray(target,dtype=float);near=positions[int(np.argmin(np.linalg.norm(positions-target,axis=1)))];mid=.5*(near+target)
   if need_goal_views:
    targets=np.asarray(sensing_points,dtype=float)
    selected=[(targets[(len(self.ids)*self.steps+i)%len(targets)],np.zeros(3),.03) for i in range(len(self.ids))]
   else:
    selected=selected[:2]+[(target,np.zeros(3),.03),(mid,np.zeros(3),.03)]
    self.goal_surveyed=True
  if need_goal_views:interest=np.asarray(sensing_points,dtype=float)
  elif len(unseen_pairs):
   points=g.centers[oi[unseen_pairs]];_,indices=np.unique(np.round(points/.02).astype(int),axis=0,return_index=True);interest=points[indices]
   if len(interest)>128:interest=interest[np.linspace(0,len(interest)-1,128,dtype=int)]
  else:interest=np.array([x[0] for x in selected])
  n=64;t=np.arange(n)+.5;z=1-2*t/n;theta=np.pi*(3-np.sqrt(5))*t;dirs=np.c_[np.sqrt(1-z*z)*np.cos(theta),np.sqrt(1-z*z)*np.sin(theta),z]
  measured=~g.isbox;oa={k:(v[measured] if isinstance(v,np.ndarray) and len(v)==len(measured) else v) for k,v in arrays.items()};observed=ExactProxyGuard(oa);updates=[]
  for slot,cid in enumerate(self.ids):
   focus,norm,worst=selected[slot%len(selected)];old=self.model.cam_pos[cid].copy();pool=np.vstack([old]+[focus+radius*dirs for radius in [.10,.20,.35,.60,.90]])
   candidates=[]
   for pos in pool:
    if pos[2]<.04 or pos[2]>1.65 or np.any(np.abs(pos[:2])>1.6):continue
    if np.min(np.linalg.norm(positions-pos,axis=1)-radii)<.03:continue
    key=tuple(np.round(np.r_[pos,focus]/.02).astype(int))
    if key in self.used:continue
    outside=not np.all((pos>=self.roi[0])&(pos<=self.roi[1]))
    inherited=np.array_equal(pos,old)
    if not outside and not inherited:
     if not occupancy.certify_swept_spheres(pos[None],pos[None],np.array([.01]),margin=.006).safe:continue
    v=focus-pos;length=np.linalg.norm(v);unit=v/length
    tau=np.clip((positions-pos)@v/max(v@v,1e-15),0,1);clear=np.linalg.norm(positions-(pos+tau[:,None]*v),axis=1)-radii
    robot_block=float(np.minimum(clear,0).sum())
    # Only observed geometry affects this heuristic; unseen space remains unseen.
    # Predict coverage from public camera intrinsics, not scene truth.
    up=np.array([0.,0.,1.]) if abs(unit[2])<.98 else np.array([0.,1.,0.]);right=np.cross(unit,up);right/=np.linalg.norm(right);vertical=np.cross(right,unit);relative=interest-pos;depth=relative@unit;tangent=np.tan(np.deg2rad(self.model.cam_fovy[cid])/2)
    visible=(depth>=.07)&(depth<=1.6)&(np.abs(relative@right)<=depth*tangent*(320/180))&(np.abs(relative@vertical)<=depth*tangent)
    gain=int(np.count_nonzero(visible))
    travel=np.linalg.norm(pos-old)
    upper=8*gain/max(1,len(interest))-(100 if robot_block<-1e-6 else 0)-.15*length-.03*travel
    candidates.append((upper,pos,key,outside,inherited,gain,len(candidates),robot_block,length,travel))
   if not candidates:continue
   # Visibility/known-obstacle penalties cannot improve the score. Evaluate in
   # descending upper-bound order and stop once no remaining pose can win.
   # This selects the same pose as the exhaustive loop, with fewer queries.
   candidates.sort(key=lambda x:-x[0]);best=None
   for upper,pos,key,outside,inherited,gain,order_index,robot_block,length,travel in candidates:
    if best is not None and upper<best[0]:break
    if observed.certify(pos[None],pos[None],np.array([.016])).minimum_clearance_m<0:continue
    v=focus-pos;_,obstacles=observed.pairs(pos[None],focus[None],np.zeros(1));blocked=False
    if len(obstacles):
     if self.representation=="sphere":
      local=pos-observed.centers[obstacles];direction=np.broadcast_to(v,local.shape);values=np.maximum(np.repeat(observed.sphere[obstacles,None]**2,3,axis=1),1e-18)
     else:
      local=np.einsum("nji,nj->ni",observed.rotations[obstacles],pos-observed.centers[obstacles]);direction=np.einsum("nji,j->ni",observed.rotations[obstacles],v);values=np.maximum(observed.values[obstacles],1e-18)
     parameter=np.clip(-np.sum(local*direction/values,axis=1)/np.maximum(np.sum(direction*direction/values,axis=1),1e-30),0,1);rho=np.sum((local+parameter[:,None]*direction)**2/values,axis=1);blocked=bool(np.any(rho<=1+1e-9))
    score=8*gain/max(1,len(interest))-(100 if robot_block<-1e-6 else 0)-(100 if blocked else 0)-.15*length-.03*travel
    if best is None or score>best[0] or (score==best[0] and order_index<best[-1]):best=(score,pos,key,outside,inherited,gain,order_index)
   if best is None:continue
   score,pos,key,outside,inherited,gain,_=best;self.used.add(key);self.set_pose(cid,pos,focus)
   updates.append(dict(camera=self.model.camera(cid).name,position=pos.tolist(),focus=focus.tolist(),blocking_gap_m=worst,score=float(score),expected_visible_interest_points=gain,interest_points=len(interest),pose_basis="original_sensor_pose" if inherited else "existing_calibrated_outside_roi" if outside else "observed_free_16mm_ball",step=self.steps))
  self.steps+=1;self.history.extend(updates);return updates
