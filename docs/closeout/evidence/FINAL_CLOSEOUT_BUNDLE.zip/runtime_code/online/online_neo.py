"""NEO (Haviland & Corke 2021) on the online map, for the E4 LiuQP / NEO comparison.

Same QP as known_v6/external_neo/neo_controller.py (position-only MuJoCo
adaptation): the end-effector task J u + delta = v with slack weight 1/e, joint
velocity regularisation, manipulability gradient, joint-limit dampers, workspace
rows, and one velocity-damper row per robot sphere / obstacle within the
influence distance d_i:

    n^T J_i u <= xi (d - d_s) / (d_i - d_s) + n^T v_obstacle      (xi = 1, d_s = 6 mm)

Static obstacles are the online map's certificates, each the outer ellipsoid
(base shape with its measurement uncertainty, as the map's own guard uses)
grown by its offset radius; candidates come from a KD-tree over the
certificate centres (the known-map NEO tested every certificate, too slow for
the online map's 5-40k).  Moving objects are the detector's sphere
certificates with their velocities (dynamic_channel.py: the same
latency-compensated input LiuQP gets).  Same safety layer as the LiuQP
variants: self-collision dampers (safety_rows.py) and the
constraint-respecting fallback (fallback.py) when quadprog / SLSQP fail; the
acceleration limit is part of the joint rows.
"""
from __future__ import annotations

import time
from dataclasses import fields

import mujoco
import numpy as np
import quadprog
from scipy.optimize import LinearConstraint, minimize
from scipy.spatial import cKDTree

from fallback import W_MOVING, W_STATIC, least_violation
from model import DT, attachment_position, certificate_world_state, set_configuration
from native_ellipsoid_support import NativeEllipsoidSupport
from protocol_liuqp_controller import ProtocolStepMetrics

INFLUENCE = {"neo_matched": 0.046, "neo_paper": 0.30}
SAFETY = 0.006
SELF_INFLUENCE = 0.05
MAX_PER_SPHERE = 8   # nearest map certificates per robot sphere (real-time bound, see _static_pairs)
PRE_CANDIDATES = 32  # nearest certificate centres per robot sphere passed to the exact distance
VELOCITY_LIMITS = np.array([1.0, 1.0, 1.0, 1.4, 1.4, 1.4])
WA = np.array([[-1.0, 0, 0], [1.0, 0, 0], [0, -1.0, 0], [0, 1.0, 0], [0, 0, -1.0], [0, 0, 1.0]])
WB = np.array([0.95, 0.95, 0.95, 0.95, 0.0, 1.35])


def _metrics(**values):
    defaults = {}
    for f in fields(ProtocolStepMetrics):
        defaults[f.name] = {"str": "", "float": 0.0, "int": 0, "bool": False}.get(str(f.type), 0)
    defaults.update(values)
    return ProtocolStepMetrics(**defaults)


class OnlineNEO:
    def __init__(self, model, data, robot, kind, channel, self_rows):
        self.model, self.data, self.robot = model, data, robot
        self.kind, self.influence = kind, INFLUENCE[kind]
        self.channel, self.self_rows = channel, self_rows
        self.probe = mujoco.MjData(model)
        self.site = model.site("attachment_site").id
        from model import JOINT_NAMES
        self.qmin = np.array([model.jnt_range[model.joint(n).id, 0] for n in JOINT_NAMES])
        self.qmax = np.array([model.jnt_range[model.joint(n).id, 1] for n in JOINT_NAMES])
        self.kernel = NativeEllipsoidSupport()
        self.kernel.set_pair_threads(4)
        self.dt = DT
        # Interface the online runner expects from its controller.
        self.velocity_limits = VELOCITY_LIMITS.copy()
        self.safety_margin, self.repulsive_speed, self.contact_distance = SAFETY, 0.035, 0.0
        self.acceleration_limit = None
        self.applied_velocity = np.zeros(6)
        self.task_scale = 1.0
        self.extra_rows = None
        self.last_pair_records = ()
        self.previous_velocity = np.zeros(6)
        self._previous_qp_dual = None
        self.last = np.zeros(6)
        self.fallback_cycles = 0
        self.centers = np.empty((0, 3))
        # Fields the runner's summary reports for LiuQP (not used by NEO).
        self.near_distance, self.task_gain, self.max_task_speed = self.influence, 2.0, 0.18
        self.ellipsoid_pair_threads, self.ellipsoid_pair_affinity_mask = 4, 0
        self.osqp_absolute_tolerance = self.osqp_relative_tolerance = 0.0
        self.osqp_adaptive_rho, self.osqp_adaptive_row_threshold = False, 0
        self.osqp_max_iterations, self.osqp_rho = 0, 0.0
        self.persistent_qp_workspace, self._qp_row_capacity = False, 0

    # ---- map --------------------------------------------------------------------------
    def update_map(self, proxies):
        self.centers = np.asarray(proxies.centers, float)
        shapes = np.asarray(proxies.ellipsoid_outer_shapes, float)
        values, rotations = np.linalg.eigh(shapes)
        self.values = np.maximum(values, 1e-10)
        self.rotations = rotations
        self.offsets = np.asarray(proxies.proxy_offset_radii, float)
        self.ids = np.asarray(proxies.proxy_ids)
        self.reach = float(np.sqrt(self.values.max()) + self.offsets.max()) if len(self.centers) else 0.0
        self.tree = cKDTree(self.centers) if len(self.centers) else None

    def _static_pairs(self, positions, radii):
        if self.tree is None:
            return np.empty(0, int), np.empty(0, int), np.empty(0), np.empty((0, 3))
        # PRE_CANDIDATES nearest certificate centres per robot sphere within reach.
        count = min(PRE_CANDIDATES, len(self.centers))
        dist, index = self.tree.query(positions, k=count, distance_upper_bound=radii.max() + self.influence + self.reach)
        dist, index = np.asarray(dist).reshape(len(positions), -1), np.asarray(index).reshape(len(positions), -1)
        valid = np.isfinite(dist)
        ri = np.nonzero(valid)[0]
        oi = index[valid]
        if not len(ri):
            return ri, oi, np.empty(0), np.empty((0, 3))
        normals, surfaces, _mult, _n, _b, _res = self.kernel.closest_points_pairs_warm(
            positions[ri], self.centers[oi], self.values[oi], self.rotations[oi], np.full(len(ri), np.nan))
        delta = positions[ri] - self.centers[oi]
        local = np.einsum("nji,nj->ni", self.rotations[oi], delta)
        inside = np.sum(local ** 2 / self.values[oi], axis=1) < 1.0 - 1e-9
        distance = np.linalg.norm(surfaces - positions[ri], axis=1) - radii[ri] - self.offsets[oi]
        # Centre inside the ellipsoid: deep contact; push straight out from the centre.
        distance = np.where(inside, -radii[ri], distance)
        out = -delta / np.maximum(np.linalg.norm(delta, axis=1, keepdims=True), 1e-12)
        normals = np.where(inside[:, None], out, normals)
        keep = np.nonzero(distance < self.influence)[0]
        # NEO has no redundant-constraint pruning: with the online map's dense 5 mm
        # certificates a 0.30 m influence gives ~10^5 damper rows (180 ms per cycle).
        # Keep the MAX_PER_SPHERE nearest certificates per robot sphere.
        order = keep[np.lexsort((distance[keep], ri[keep]))]
        rank = np.zeros(len(order), dtype=int)
        if len(order):
            starts = np.r_[0, np.nonzero(np.diff(ri[order]))[0] + 1]
            for a, b in zip(starts, np.r_[starts[1:], len(order)]):
                rank[a:b] = np.arange(b - a)
        keep = order[rank < MAX_PER_SPHERE]
        return ri[keep], oi[keep], distance[keep], normals[keep]

    # ---- control --------------------------------------------------------------------------
    def _jacobian(self, data):
        jp, jr = np.zeros((3, self.model.nv)), np.zeros((3, self.model.nv))
        mujoco.mj_jacSite(self.model, data, jp, jr, self.site)
        return jp[:, :6]

    def _manipulability_gradient(self, q, step=1e-5):
        grad = np.empty(6)
        for k in range(6):
            values = []
            for sign in (1.0, -1.0):
                p = q.copy()
                p[k] += sign * step
                set_configuration(self.model, self.probe, p)
                values.append(float(np.prod(np.linalg.svd(self._jacobian(self.probe), compute_uv=False))))
            grad[k] = (values[0] - values[1]) / (2 * step)
        return grad

    def solve(self, target):
        started = time.perf_counter()
        q = self.data.qpos[:6].copy()
        J = self._jacobian(self.data)
        ee = attachment_position(self.model, self.data)
        error = np.asarray(target, float) - ee
        v = 2.0 * error
        if np.linalg.norm(v) > 0.18:
            v *= 0.18 / np.linalg.norm(v)
        v = v * self.task_scale
        e = max(float(np.sum(np.abs(error))), 1e-6)
        jm = self._manipulability_gradient(q)
        H = J.T @ J + 0.01 * e * np.eye(6)
        g = -J.T @ v - e * jm
        lb = np.maximum(-VELOCITY_LIMITS, (self.qmin + 0.015 - q) / DT)
        ub = np.minimum(VELOCITY_LIMITS, (self.qmax - 0.015 - q) / DT)
        dl, du = q - self.qmin, self.qmax - q
        lb = np.maximum(lb, np.where(dl < 0.9, -(dl - 0.015) / (0.9 - 0.015), -np.inf))
        ub = np.minimum(ub, np.where(du < 0.9, (du - 0.015) / (0.9 - 0.015), np.inf))
        if self.acceleration_limit is not None:
            step = self.acceleration_limit * DT
            alb, aub = np.maximum(lb, self.applied_velocity - step), np.minimum(ub, self.applied_velocity + step)
            ok = alb <= aub
            lb, ub = np.where(ok, alb, lb), np.where(ok, aub, ub)
        positions, jac, radii = certificate_world_state(self.model, self.data, self.robot)
        jac = jac[:, :, :6]
        rows = [np.eye(6), J, np.einsum("wi,rij->rwj", WA, jac).reshape(-1, 6)]
        lows = [lb, v - 10.0, np.full(len(positions) * 6, -np.inf)]
        highs = [ub, v + 10.0, ((WB[None, :] - radii[:, None] - positions @ WA.T) / DT).ravel()]
        kinds = ["joint"] * 6 + ["task"] * 3 + ["workspace"] * (len(positions) * 6)
        damper = 1.0 / (self.influence - SAFETY)
        ri, oi, dist, normals = self._static_pairs(positions, radii)
        if len(ri):
            rows.append(np.einsum("pi,pij->pj", normals, jac[ri]))
            lows.append(np.full(len(ri), -np.inf))
            highs.append((dist - SAFETY) * damper)
            kinds += ["static"] * len(ri)
        min_clear, limiting = (float(dist.min()), int(self.ids[oi[np.argmin(dist)]])) if len(ri) else (np.inf, -1)
        ch = self.channel
        if ch is not None and len(ch.centers):
            delta = ch.centers[None, :, :] - positions[:, None, :]
            length = np.linalg.norm(delta, axis=2)
            d = length - radii[:, None] - ch.radii[None, :]
            pi, pj = np.nonzero(d < self.influence)
            if len(pi):
                n = delta[pi, pj] / np.maximum(length[pi, pj], 1e-12)[:, None]
                rows.append(np.einsum("pi,pij->pj", n, jac[pi]))
                lows.append(np.full(len(pi), -np.inf))
                highs.append((d[pi, pj] - SAFETY) * damper + np.einsum("pi,pi->p", n, ch.velocities[pj]))
                kinds += ["moving"] * len(pi)
        if self.self_rows is not None:
            pairs = self.self_rows.geometry(positions, jac, radii)
            if pairs:
                rows.append(np.array([row for _a, _b, _gap, row in pairs]))
                lows.append(np.full(len(pairs), -np.inf))
                highs.append(np.array([(gap - 0.0) / SELF_INFLUENCE for _a, _b, gap, _row in pairs]))
                kinds += ["self"] * len(pairs)
        A, lo, hi = np.vstack(rows), np.concatenate(lows), np.concatenate(highs)
        kinds = np.array(kinds)
        status, x = self._solve_qp(H, g, A, lo, hi)
        if x is None:
            weights = np.where(kinds == "moving", W_MOVING, W_STATIC)
            hard = kinds == "joint"
            keep = kinds != "task"
            x = least_violation(A[keep], lo[keep], hi[keep], hard[keep], weights[keep])
            status = "fallback"
            self.fallback_cycles += 1
            if x is None:
                x = np.clip(np.zeros(6), lb, ub)
                status = "fallback failed"
        self.last = x.copy()
        self.previous_velocity = x.copy()
        total_ms = (time.perf_counter() - started) * 1000.0
        return x, _metrics(status=status, representation="ellipsoid", total_controller_ms=total_ms,
                           ee_error=float(np.linalg.norm(error)), task_speed=float(np.linalg.norm(v)),
                           qdot_norm=float(np.linalg.norm(x)), min_clearance=min_clear,
                           active_obstacle_rows=int(np.isin(kinds, ["static", "moving"]).sum()),
                           broadphase_candidate_pairs=int(len(ri)), limiting_proxy_id=limiting)

    def _solve_qp(self, H, g, A, lo, hi):
        nonzero = np.linalg.norm(A, axis=1) > 1e-14
        a, l, u = A[nonzero], lo[nonzero], hi[nonzero]
        upper, lower = np.isfinite(u), np.isfinite(l)
        C = np.vstack([-a[upper], a[lower]]).T
        b = np.r_[-u[upper], l[lower]]

        def violation(x):
            return float(max(0.0, np.max(lo - A @ x), np.max(A @ x - hi)))
        try:
            x = quadprog.solve_qp(H, -g, C, b)[0]
            if violation(x) <= 2e-6:
                return "quadprog solved", x
        except ValueError:
            pass
        sol = minimize(lambda z: 0.5 * z @ H @ z + g @ z, self.last, jac=lambda z: H @ z + g, method="SLSQP",
                       constraints=[LinearConstraint(A, lo, hi)], options=dict(ftol=1e-12, maxiter=200))
        if sol.success and violation(sol.x) <= 2e-6:
            return "slsqp solved", sol.x
        return "infeasible", None
