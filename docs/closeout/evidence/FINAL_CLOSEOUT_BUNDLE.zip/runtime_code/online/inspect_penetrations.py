"""Which robot geometry touches which cabinet part in penetrating online cycles,
and had the camera map seen that part at the time?"""
import csv
import glob
import json
import os
import sys
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
import mujoco  # noqa: E402
import run_protocol_v3_async_online as online  # noqa: E402
from model import build_model, set_configuration  # noqa: E402

OUT = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/online_improved")
model = build_model(online._protocol_scene("camera_quarter"))
data = mujoco.MjData(model)
name = lambda g: mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, g) or f"geom{g}"
for case in sys.argv[1:]:
    d = OUT / case
    run = next(p for p in d.iterdir() if p.is_dir())
    rows = list(csv.DictReader(open(run / "cycles.csv")))
    q = np.load(run / "q_history.npy")
    pen = [int(r["cycle"]) for r in rows if int(r["exact_penetrating_contact_count"]) > 0]
    snapshots = np.load(run / "causal_proxy_snapshots.npz")
    publish = snapshots["publish_cycles"]
    offsets = snapshots["offsets"]
    print(f"== {case}: {len(pen)} penetrating cycles, first {pen[0]}")
    for cycle in (pen[0], pen[len(pen) // 2]):
        set_configuration(model, data, q[cycle + 1] if cycle + 1 < len(q) else q[-1])
        mujoco.mj_forward(model, data)
        # Proxies available to the controller at that cycle.
        generation = int(np.searchsorted(publish, cycle, side="right") - 1)
        centers = snapshots["centers"][offsets[generation]:offsets[generation + 1]]
        for c in data.contact[: data.ncon]:
            if c.dist >= -1e-8:
                continue
            point = np.array(c.pos)
            nearest = float(np.min(np.linalg.norm(centers - point, axis=1))) if len(centers) else np.inf
            print(f"  cycle {cycle}: {name(c.geom1)} x {name(c.geom2)} depth {-1000 * c.dist:.1f} mm at "
                  f"{np.round(point, 3)}; nearest published proxy centre {1000 * nearest:.0f} mm away "
                  f"(map generation {generation}, published at cycle {publish[generation]})")
