"""Re-evaluate held commands at their actual application state."""
import time,numpy as np
from progress_bypass_policy import LowDimPolicy as Previous
from progress_policy import values
class LowDimPolicy(Previous):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.application_progress_checks=0;self.application_progress_rejections=0;self.application_progress_scaled=0;self.application_progress_ms=[];self.application_records=[];self.application_physical_rejections=0;self.application_memory_rejections=0
 def __call__(self,c,s,arrays):
  delta=super().__call__(c,s,arrays)
  if self.proposal_contract is not None and self.future_state is not None:
   self.proposal_contract['witnesses']=[{k:v for k,v in r.items() if k!='b'} for r in self.future_state['rows']]
  return delta
 def filter_progress(self,q,previous,command,lo,hi,contract):
  started=time.perf_counter()
  try:
   result=super().filter_progress(q,previous,command,lo,hi,contract)
   if self.brake_pending or contract is None or contract['mode']!='CERT_PREP' or not contract.get('witnesses'):return result
   self.application_progress_checks+=1;rows=contract['witnesses'];before=min(0.,values(self,q,rows));v=np.clip(result,lo,hi);brake=np.clip(previous-np.clip(previous,-self.acceleration*self.dt,self.acceleration*self.dt),lo,hi)
   for scale in [1.,.75,.5,.25,.125,.0625,0.]:
    candidate=brake+scale*(v-brake)
    if not self.memory_safe(q,candidate):self.application_memory_rejections+=1;continue
    if not self.ctx.guard.braking_safe(self.ctx.proxy_guard,q,candidate):self.application_physical_rejections+=1;continue
    after=min(0.,values(self,q+self.dt*candidate,rows))
    if after>=before-2e-7:
     if scale<1:
      self.application_progress_scaled+=1;self.command_epoch+=1
      if len(self.application_records)<400:self.application_records.append(dict(cycle=self.k,source_cycle=contract['cycle'],before=before,after=after,scale=scale))
     return candidate
    self.application_progress_rejections+=1
   self.command_epoch+=1;self.brake_pending=True;self.witness_anchor=None
   if len(self.application_records)<400:self.application_records.append(dict(cycle=self.k,source_cycle=contract['cycle'],before=before,action='certified_brake_and_recompute'))
   return brake
  finally:self.application_progress_ms.append((time.perf_counter()-started)*1000)
 def summary(self):
  out=super().summary();out.update(application_progress_checks=self.application_progress_checks,application_progress_rejected_candidates=self.application_progress_rejections,application_progress_scaled_commands=self.application_progress_scaled,application_progress_ms_p99=None if not self.application_progress_ms else float(np.percentile(self.application_progress_ms,99)),application_progress_total_s=sum(self.application_progress_ms)/1000,application_progress_records=self.application_records,application_physical_rejections=self.application_physical_rejections,application_memory_rejections=self.application_memory_rejections,application_progress_scope='nonlinear one-step check at actual application state on the command witness set; full-map stage refresh still detects omitted witnesses; deliberate low-dimensional bypass exempt; safety braking takes priority',timing_scope='controller solve latency charged as before; execution-stage progress guard timing reported separately like the original execution safety guard; not whole-loop hard-real-time validation')
  return out
