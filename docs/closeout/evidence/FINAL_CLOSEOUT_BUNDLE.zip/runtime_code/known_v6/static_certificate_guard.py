"""Independent exact static proxy certificate, without MVT pruning or plane reuse."""
import numpy as np
from scipy.spatial import cKDTree
from types import SimpleNamespace
from native_support import NativeEllipsoidSupport

class StaticCertificateGuard:
    def __init__(self,cover,representation):
        self.cover=cover;self.representation=representation;self.tree=cKDTree(cover.centers);self.kernel=NativeEllipsoidSupport()
        self.values,self.rotations=np.linalg.eigh(cover.ellipsoid_shapes)
        self.bound=float(np.max(cover.sphere_radii if representation=='sphere' else np.sqrt(self.values[:,-1])))
    def certify(self,starts,ends,radii):
        starts=np.asarray(starts);ends=np.asarray(ends);radii=np.asarray(radii);length=np.linalg.norm(ends-starts,axis=1)
        candidates=self.tree.query_ball_point((starts+ends)*.5,length*.5+radii+self.bound+1e-9)
        ri=np.repeat(np.arange(len(starts)),[len(x) for x in candidates]);oi=np.array([j for ids in candidates for j in ids],dtype=int)
        if not len(oi):return SimpleNamespace(minimum_clearance_m=np.inf)
        a=starts[ri];b=ends[ri];c=self.cover.centers[oi]
        if self.representation=='sphere':
            ab=b-a;den=np.sum(ab*ab,axis=1);t=np.clip(np.sum((c-a)*ab,axis=1)/np.maximum(den,1e-30),0,1);dist=np.linalg.norm(a+t[:,None]*ab-c,axis=1)-self.cover.sphere_radii[oi]
        else:
            x=self.kernel.closest_points_pairs_warm(a,c,self.values[oi],self.rotations[oi],np.full(len(oi),np.nan));y=self.kernel.closest_points_pairs_warm(b,c,self.values[oi],self.rotations[oi],x[2]);dist=(np.linalg.norm(x[1]-a,axis=1)+np.linalg.norm(y[1]-b,axis=1)-length[ri])*.5
        return SimpleNamespace(minimum_clearance_m=float(np.min(dist-radii[ri])))
