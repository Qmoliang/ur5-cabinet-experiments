import pickle, sys, time
import numpy as np
sys.path.insert(0, '/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6')
from pointcloud_proxy import fit_matched_voxel_proxies
import bucket_fit
b = pickle.load(open('/tmp/hsjed_fit_batch.pkl', 'rb'))
kw = dict(b['kwargs'], filtered_point_offsets=b['offsets'], filtered_point_uncertainty_shapes=b['uncertainty'])
t = time.perf_counter(); py = fit_matched_voxel_proxies(b['points'], **kw); tp = time.perf_counter() - t
t = time.perf_counter(); nat = bucket_fit.fit(b['points'], **kw); tn = time.perf_counter() - t
print(f'python {1000*tp:.0f} ms, native (incl. Python coverage proof) {1000*tn:.0f} ms; proxies {len(py.centers)} vs {len(nat.centers)}')
same_partition = np.array_equal(py.filtered_cluster_indices, nat.filtered_cluster_indices)
print('same cell -> proxy partition:', same_partition)
if len(py.centers) == len(nat.centers):
    for name in ('centers', 'sphere_radii', 'ellipsoid_shapes', 'rotations', 'proxy_offset_radii', 'proxy_uncertainty_shapes', 'base_sphere_radii', 'ellipsoid_outer_shapes'):
        a, c = np.asarray(getattr(py, name)), np.asarray(getattr(nat, name))
        print(f'  {name}: max abs diff {float(np.max(np.abs(a - c))):.2e} (scale {float(np.max(np.abs(a))):.2e})')
for name in ('maximum_ellipsoid_overshoot', 'surface_cover_radius', 'maximum_uncertainty_union_inflation'):
    print(f'  {name}: {getattr(py, name)!r} vs {getattr(nat, name)!r}')
ra, rn = np.asarray(py.rotations), np.asarray(nat.rotations)
col_same = np.all(np.isclose(ra, rn, atol=1e-9), axis=1)
col_flip = np.all(np.isclose(ra, -rn, atol=1e-9), axis=1)
print('rotation columns: equal', int(col_same.sum()), 'sign-flipped', int((col_flip & ~col_same).sum()), 'other', int((~col_same & ~col_flip).sum()), 'of', col_same.size)
print('proxies with a flip:', int(np.any(col_flip & ~col_same, axis=1).sum()), '| det native min', float(np.min(np.linalg.det(rn))))
from pointcloud_proxy import assert_proxy_coverage
t = time.perf_counter(); assert_proxy_coverage(nat, 0.003); print(f'coverage proof alone {1000*(time.perf_counter()-t):.0f} ms')
import os; os.environ['UR5_NATIVE_FIT'] = '1'
import ctypes
t = time.perf_counter()
for _ in range(3): bucket_fit.fit(b['points'], **kw)
print(f'native fit + proof per call {1000*(time.perf_counter()-t)/3:.0f} ms')
