#!/bin/bash
# One known-map run.  Usage: known_job.sh <out_root> <scene> <rep> <attraction> <seed> <first_cpu> [KEY=VALUE ...]
OUT=$1; scene=$2; rep=$3; attr=$4; seed=$5; cpu=$6; shift 6
K=/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6
id=${scene}_${rep}_${attr}_seed$(printf "%02d" $seed)
mkdir -p $OUT
extra="UR5_START_CHECK=1"
[ $scene = exit ] && extra="UR5_START_Q_FILE=$K/assets/scenes/exit_starts.npy"
[ $scene = drawer ] && scene_json=$K/assets/scene.json || scene_json=$K/assets/scenes/$scene.json
cd $K
env $extra "$@" UR5_SCENE_JSON=$scene_json UR5_ATTRACTION=$attr UR5_KNOWN_OUT=$OUT/$id UR5_START_SEED=$seed \
    OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MUJOCO_GL=egl \
  systemd-run --user --scope -q -p MemoryMax=8G -E UR5_SCENE_JSON -E UR5_ATTRACTION -E UR5_KNOWN_OUT -E UR5_START_SEED \
    -E UR5_START_CHECK -E UR5_START_Q_FILE -E UR5_WHOLE_ARM -E UR5_POSTURE_GOAL -E UR5_POSTURE_WEIGHT -E UR5_CONTROLLER -E UR5_SUCCESS_TOL -E UR5_RACKET -E UR5_RACKET_DIR -E UR5_RACKET_TRIGGER -E UR5_RACKET_SPEED -E UR5_RACKET_HORIZON -E UR5_ESCAPE -E UR5_OBJECTS -E UR5_OBJECT_SPEED -E UR5_ACCEL_LIMIT -E UR5_COMBINED_OFF -E UR5_COMBINED_HORIZON -E UR5_COMBINED_REACTION -E UR5_E4_SAFETY -E UR5_E4_FAR_START_FILE -E UR5_NEO_MOVING_INFLUENCE -E UR5_GUIDANCE -E UR5_GUIDANCE_SUBGOALS -E UR5_GUIDANCE_TRIGGER -E UR5_MAX_CYCLES -E UR5_ESCAPE_TRACK -E UR5_ESCAPE_FAST -E UR5_GRAPH_REGIONS -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS \
  taskset -c $cpu-$((cpu+${UR5_JOB_CPUS:-2}-1)) timeout 3600 ~/envs/ur5cab/bin/python -c "
import sys, json, time, os
sys.path[:0] = ['src', 'src/core', '.']
import run
t = time.time()
s = run.run('$rep', maximum_cycles=int(os.environ.get('UR5_MAX_CYCLES') or 3000))
keys = ('success', 'final_error_m', 'proxy_count', 'controller_ms_p99', 'exact_penetrating_cycles', 'start_attempts')
print('RESULT', json.dumps({k: s.get(k) for k in keys}), 'wall_s', round(time.time() - t, 1))
" > $OUT/$id.log 2>&1
