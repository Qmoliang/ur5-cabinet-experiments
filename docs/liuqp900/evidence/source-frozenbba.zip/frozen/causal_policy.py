"""Prespecified one-component interventions; original physical/QP guards retained."""
from goal_fiber_policy import LowDimPolicy as Fiber
from local_memory_policy import LowDimPolicy as Compact
from executed_frame_policy import LowDimPolicy as Terminal
class NoFrameTransfer(Fiber):
 def _current_binding_rows(self,s,arrays):
  rows=super()._current_binding_rows(s,arrays)
  if self.blocker_id is None:return rows
  return [x for x in rows if self._frame(x[2])==self._frame(self.blocker_id)]
def LowDimPolicy(ctx,job,event):
 arm=job.get('causal_arm','fiber')
 return dict(compact=Compact,fiber=Fiber,no_frame_transfer=NoFrameTransfer,terminal_only=Terminal)[arm](ctx,job,event)
