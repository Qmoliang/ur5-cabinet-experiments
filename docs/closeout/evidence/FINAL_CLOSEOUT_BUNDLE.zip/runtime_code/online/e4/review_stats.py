"""Shared statistics for the reviewer summaries."""
import math


def wilson(k, n, z=1.96):
    if n == 0:
        return float("nan"), float("nan")
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return max(0.0, c - h), min(1.0, c + h)


def mcnemar(b, c):
    """Exact two-sided McNemar p for discordant counts b, c."""
    n = b + c
    if n == 0:
        return 1.0
    tail = sum(math.comb(n, i) for i in range(min(b, c) + 1)) / 2 ** n
    return min(1.0, 2 * tail)


def rate(k, n):
    lo, hi = wilson(k, n)
    pct = 100 * k / n if n else float("nan")
    return f"{k:3d}/{n:<3d} ({pct:3.0f}% [{100*lo:3.0f}-{100*hi:3.0f}])"
