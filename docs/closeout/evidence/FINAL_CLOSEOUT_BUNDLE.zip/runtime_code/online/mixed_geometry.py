"""Shared exact frontier-box geometry for sphere and ellipsoid pipelines."""
from dataclasses import replace
import time
from types import SimpleNamespace
import numpy as np
from scipy.spatial import cKDTree
from run_protocol_v3_async_online import ContinuousProxyGuard as BaseGuard, ProxySweepCertificate, _build_mvt_only
from protocol_liuqp_controller import ProtocolLiuQPController
from native_frontier_rows import select_planes

FIELDS=('centers','sphere_radii','ellipsoid_shapes','rotations','cluster_keys','proxy_offset_radii','proxy_uncertainty_shapes','base_sphere_radii','base_ellipsoid_shapes','ellipsoid_outer_shapes','proxy_ids','box_half_extents')
def split_count(ps):
    h=getattr(ps,'box_half_extents',None)
    if h is None:return len(ps.centers)
    mask=np.any(np.asarray(h)>0,axis=1);ids=np.flatnonzero(mask)
    n=int(ids[0]) if len(ids) else len(mask)
    if np.any(~mask[n:]):raise ValueError('frontier boxes must follow observed certificates')
    return n

def observed(ps,n):
    return replace(ps,**{name:np.asarray(getattr(ps,name))[:n] for name in FIELDS if getattr(ps,name,None) is not None})

class ObservedIndex:
    simd=False
    def __init__(self,index,n):self.index=index;self.n=n;self.query_padding=index.query_padding if index is not None else 0
    def query_aabb(self,c,h):
        a=np.asarray(self.index.query_aabb(c,h),dtype=np.int64);return a[a<self.n]
    def query_sphere(self,c,r):
        a=np.asarray(self.index.query_sphere(c,r),dtype=np.int64);return a[a<self.n]
    def query_spheres(self,c,r):return [np.asarray(a,dtype=np.int64)[np.asarray(a)<self.n] for a in self.index.query_spheres(c,r)]

def observed_index(index,ps,n,representation,robot_radii=None):
    if index is None:return None
    cached=getattr(index,'_observed_mvt',None)
    if cached is not None:return cached
    if robot_radii is None:return ObservedIndex(index,n)
    cached=_build_mvt_only(observed(ps,n),representation,np.asarray(robot_radii),simd=True)
    index._observed_mvt=cached
    return cached

class FrontierBoxes:
    def __init__(self,ps,n):
        self.start=n;self.centers=np.asarray(ps.centers)[n:];self.half=np.asarray(ps.box_half_extents)[n:] if getattr(ps,'box_half_extents',None) is not None else np.empty((0,3));self.ids=np.asarray(ps.proxy_ids)[n:]
        self.tree=cKDTree(self.centers) if len(self.centers) else None;self.bound=float(np.max(np.linalg.norm(self.half,axis=1))) if len(self.half) else 0;self.minimum=np.inf;self.limiting=(-1,-1,-1)
    def candidates(self,starts,ends,radii):
        if self.tree is None:return np.empty(0,dtype=int),np.empty(0,dtype=int)
        ids=self.tree.query_ball_point((starts+ends)*.5,np.linalg.norm(ends-starts,axis=1)*.5+radii+self.bound+1e-9)
        return np.repeat(np.arange(len(starts)),[len(a) for a in ids]),np.asarray([j for a in ids for j in a],dtype=int)
    def certify(self,starts,ends,radii):
        ri,oi=self.candidates(starts,ends,radii)
        if not len(oi):return ProxySweepCertificate(True,0,0,0,0,np.inf)
        c=self.centers[oi];h=self.half[oi];d0=np.linalg.norm(np.maximum(np.abs(starts[ri]-c)-h,0),axis=1);d1=np.linalg.norm(np.maximum(np.abs(ends[ri]-c)-h,0),axis=1);gap=.5*(d0+d1-np.linalg.norm(ends[ri]-starts[ri],axis=1))-radii[ri];a=d0-radii[ri];b=d1-radii[ri];hit=gap<=0;recover=hit&(a<=0)&(b>a+1e-10);worse=hit&~recover
        return ProxySweepCertificate(not bool(np.any(worse)),int(hit.sum()),int(recover.sum()),int(worse.sum()),len(oi),float(gap.min()))
    def rows(self,positions,jacobians,radii,margin,dt):
        self.minimum=np.inf;self.limiting=(-1,-1,-1);self.near_rows=[];self.contact_rows=0;self.active_rows=0;out=[]
        if self.tree is None:return out
        for i,p in enumerate(positions):
            ids=np.asarray(self.tree.query_ball_point(p,radii[i]+margin+.04+self.bound),dtype=int)
            if not len(ids):continue
            c=self.centers[ids];h=self.half[ids];near=np.clip(p,c-h,c+h);delta=near-p;length=np.linalg.norm(delta,axis=1);normals=delta/np.maximum(length[:,None],1e-15);gap=length-radii[i]-margin
            inside=length<1e-12
            for k in np.flatnonzero(inside):
                dep=h[k]-np.abs(p-c[k]);axis=int(np.argmin(dep));sign=1. if p[axis]>=c[k,axis] else -1.;normals[k]=0;normals[k,axis]=-sign;gap[k]=-dep[axis]-radii[i]-margin;near[k]=p;near[k,axis]=c[k,axis]+sign*h[k,axis]
            best=int(np.argmin(gap))
            if gap[best]<self.minimum:self.minimum=float(gap[best]);self.limiting=(i,int(ids[best]+self.start),int(self.ids[ids[best]]))
            selected=select_planes(c,h,normals,near,np.argsort(gap))
            for k in selected:
                n=normals[k];projected=n@jacobians[i];pid=int(self.ids[ids[k]]);out.append((projected,float(gap[k]/dt),('frontier',i,pid)));self.active_rows+=1
                rawgap=gap[k]+margin
                if 0<rawgap<.04:self.near_rows.append(projected)
                elif rawgap<=0:
                    repulsion=.035*min(1.,.25+max(0.,-rawgap)/max(margin,1e-12));out.append((projected,-repulsion,('frontier_contact',i,pid)));self.contact_rows+=1
        return out

class HybridProxyGuard(BaseGuard):
    def __init__(self,packet,representation):
        super().__init__(packet,representation);n=split_count(packet.proxies);self.boxes=FrontierBoxes(packet.proxies,n)
        ip=SimpleNamespace(proxies=observed(packet.proxies,n),mvt=observed_index(packet.mvt,packet.proxies,n,representation,getattr(packet,"robot_radii",None)),ellipsoid_eigenvalues=self.eigenvalues[:n] if self.eigenvalues is not None else None,ellipsoid_rotations=self.rotations[:n] if self.rotations is not None else None,uncertainty_eigenvalues=self.uncertainty_eigenvalues[:n] if self.uncertainty_eigenvalues is not None else None)
        self.observed_guard=BaseGuard(ip,representation)
    def sphere_observed_certificate(self,starts,ends,radii):
        ri=[];oi=[]
        for i,(a,b,r) in enumerate(zip(starts,ends,radii)):
            ids=self.observed_guard._candidates(a,b,float(r));ri.extend([i]*len(ids));oi.extend(ids)
        if not oi:return ProxySweepCertificate(True,0,0,0,0,np.inf)
        ri=np.asarray(ri,dtype=int);oi=np.asarray(oi,dtype=int);ps=self.observed_guard.proxies;a=starts[ri];b=ends[ri];c=ps.centers[oi];ab=b-a;den=np.sum(ab*ab,axis=1);t=np.clip(np.divide(np.sum((c-a)*ab,axis=1),den,out=np.zeros(len(oi)),where=den>1e-30),0,1);reach=radii[ri]+ps.sphere_radii[oi]+ps.proxy_offset_radii[oi]
        gap=np.linalg.norm(a+t[:,None]*ab-c,axis=1)-reach;g0=np.linalg.norm(a-c,axis=1)-reach;g1=np.linalg.norm(b-c,axis=1)-reach;hit=gap<=0;recovery=hit&(g0<=0)&(g1>g0+1e-10);worse=hit&~recovery
        return ProxySweepCertificate(not bool(np.any(worse)),int(hit.sum()),int(recovery.sum()),int(worse.sum()),len(oi),float(gap.min()))
    def certify(self,starts,ends,radii):
        starts=np.asarray(starts);ends=np.asarray(ends);radii=np.asarray(radii);a=self.sphere_observed_certificate(starts,ends,radii) if self.representation=='sphere' else self.observed_guard.certify(starts,ends,radii);b=self.boxes.certify(starts,ends,radii)
        return ProxySweepCertificate(a.safe and b.safe,a.colliding_pairs+b.colliding_pairs,a.recovery_pairs+b.recovery_pairs,a.worsening_pairs+b.worsening_pairs,a.candidate_pairs+b.candidate_pairs,min(a.minimum_clearance_m,b.minimum_clearance_m))

class MixedController(ProtocolLiuQPController):
    def solve(self,target):
        started=time.perf_counter()
        from model import certificate_world_state
        p,j,r=certificate_world_state(self.model,self.data,self.robot_spheres)
        frontier=self.frontier_boxes.rows(p,j[:,:,:self.nv],r,self.safety_margin,self.dt)
        frontier_ms=1000*(time.perf_counter()-started)
        previous=self.extra_rows;previous_near=getattr(self,'extra_near_rows',None)
        self.extra_rows=lambda p,j,r:([] if previous is None else list(previous(p,j,r)))+frontier
        self.extra_near_rows=([] if previous_near is None else list(previous_near))+self.frontier_boxes.near_rows
        try:v,m=super().solve(target)
        finally:self.extra_rows=previous;self.extra_near_rows=previous_near
        changes=dict(total_controller_ms=1000*(time.perf_counter()-started),geometry_ms=m.geometry_ms+frontier_ms,active_obstacle_rows=m.active_obstacle_rows+self.frontier_boxes.active_rows,near_penalty_terms=m.near_penalty_terms+len(self.frontier_boxes.near_rows),contact_repulsion_rows=m.contact_repulsion_rows+self.frontier_boxes.contact_rows)
        if self.frontier_boxes.minimum<m.min_clearance:
            i,j,pid=self.frontier_boxes.limiting;changes.update(min_clearance=self.frontier_boxes.minimum,limiting_robot_index=i,limiting_obstacle_index=j,limiting_proxy_id=pid)
        return v,replace(m,**changes)

def install(online):
    if getattr(online,'_exact_boxes_installed',False):return
    original=online._new_controller
    def factory(representation,model,data,scene,robot,proxies,obstacle_index,**kw):
        n=split_count(proxies);ctl=original(representation,model,data,scene,robot,observed(proxies,n),observed_index(obstacle_index,proxies,n,representation,[r.radius for r in robot]),**kw);ctl.__class__=MixedController;ctl.frontier_boxes=FrontierBoxes(proxies,n);return ctl
    def update(ctl,packet,representation,prepared_guard=None):
        n=split_count(packet.proxies);p=observed(packet.proxies,n);kw=dict(obstacle_offsets=p.proxy_offset_radii,proxy_ids=p.proxy_ids,obstacle_index=observed_index(packet.mvt,packet.proxies,n,representation,[r.radius for r in ctl.robot_spheres]))
        if representation=='sphere':kw['obstacle_radii']=p.sphere_radii
        else:
            kw.update(obstacle_shapes=p.base_ellipsoid_shapes,obstacle_uncertainty_shapes=online._controller_uncertainty_shapes(p))
            if prepared_guard is not None:kw.update(obstacle_eigenvalues=prepared_guard.eigenvalues[:n],obstacle_rotations=prepared_guard.rotations[:n],obstacle_uncertainty_eigenvalues=None)
        ctl.update_obstacles(p.centers,**kw);ctl.frontier_boxes=FrontierBoxes(packet.proxies,n);ctl._previous_qp_dual=None
    online.ContinuousProxyGuard=HybridProxyGuard;online._new_controller=factory;online._update_controller=update;online._exact_boxes_installed=True
