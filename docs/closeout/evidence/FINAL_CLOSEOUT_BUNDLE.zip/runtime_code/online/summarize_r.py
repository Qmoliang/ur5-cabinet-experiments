"""Compare obstacle-side reduction variants with the baseline on the 20 start poses."""
import csv
import glob
import json
import os
from pathlib import Path

import numpy as np

RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
VARIANTS = [("x_b0_baseline", "LiuQP (per-sphere erase-remove)"), ("r_tree", "+ tree deletion"),
            ("r_reuse", "+ plane reuse"), ("r_treereuse", "+ tree + reuse"),
            ("x_x1_geodesic", "+ geodesic"), ("r_geo_reuse", "+ geodesic + reuse")]
TRAPPED = {2, 3, 5, 6, 8, 9, 10, 13, 14, 15, 18}


def run_dirs(folder):
    return {int(p.split("seed")[1][:2]): Path(p) for p in glob.glob(str(RUNS / folder / "ellipsoid_075mm_seed*"))
            if os.path.isdir(p)}


for folder, name in VARIANTS:
    runs = {}
    for seed, d in run_dirs(folder).items():
        s = json.loads((d / "summary.json").read_text())
        counts = s.get("reduction_counts") or {}
        cycles = s.get("cycles") or 3000
        runs[seed] = dict(success=s["success"], time=s.get("first_sustained_success_time_s"),
                          penetrating=s["exact_penetrating_cycles"],
                          exact=counts.get("exact_planes", 0) / 3000 if counts else None,
                          reused=counts.get("reused_spheres", 0) / 3000 if counts else None)
    if len(runs) != 20:
        print(f"{name}: {len(runs)} of 20 finished")
        continue
    trapped = [runs[s] for s in TRAPPED]
    easy = [runs[s] for s in set(runs) - TRAPPED]
    med = lambda xs: float(np.median(xs)) if xs else None
    print(json.dumps({
        "variant": name, "reached": sum(r["success"] for r in runs.values()),
        "penetrating_cycles": sum(r["penetrating"] for r in runs.values()),
        "easy_time_s": med([r["time"] for r in easy if r["success"]]),
        "trapped_time_s": med([r["time"] for r in trapped if r["success"]]),
        "exact_planes_per_cycle": med([r["exact"] for r in runs.values()]) if runs[1]["exact"] is not None else None,
        "spheres_reused_per_cycle": med([r["reused"] for r in runs.values()]) if runs[1]["reused"] is not None else None,
    }))

# Tree deletion must reproduce the baseline exactly.
base, tree = run_dirs("x_b0_baseline"), run_dirs("r_tree")
worst = max(float(np.abs(np.load(base[s] / "q_history.npy") - np.load(tree[s] / "q_history.npy")).max()) for s in base)
print(f"tree deletion vs baseline, worst joint difference over 20 runs: {worst}")

print("isolated timing (median controller ms / p99 / geometry ms):")
for folder in ("xt_b0", "xt_x1", "rt_reuse", "rt_treereuse", "rt_geo_reuse"):
    for seed, d in sorted(run_dirs(folder).items()):
        rows = list(csv.DictReader(open(d / "cycles.csv")))
        get = lambda k: np.array([float(r[k]) for r in rows])
        s = json.loads((d / "summary.json").read_text())
        print(f"  {folder:13s} seed {seed}: reached={s['success']!s:5} controller {np.median(get('total_controller_ms')):6.2f} "
              f"/ {np.percentile(get('total_controller_ms'), 99):6.2f}  geometry {np.median(get('geometry_ms')):6.2f}")
