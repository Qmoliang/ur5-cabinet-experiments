import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy_v6 import LowDimPolicy
out=[]
for name in ['entry_v6_only_stall','entry_v6_clearance_exit_stall']:
    folder=ROOT/'trials'/name
    if not (folder/'result.json').exists():continue
    q=np.load(folder/'trajectory.npz')['q'][-1];job=json.loads((folder/'job.json').read_text());ctx=build('iris_4shelves_t2',start=q);c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
    p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,np.zeros(6));p.k=1000;p.feature_last_progress=0;s=c.pilot_nominal;arrays=c.last_qp_arrays;A=arrays[2];u=arrays[4];a=p._tracking_solution(c,s,arrays);assert a is not None
    rows,bounds=p._extras(c,s);indices=[i for i,r in enumerate(s['row_ids']) if r[0]=='self' and u[i]*.02<c.near_distance and np.linalg.norm(A[i])>1e-12]
    physical=a['original_dual'].copy();multipliers=a['raw'].y[len(A)+len(rows)-len(indices):len(A)+len(rows)]
    physical[indices]+=multipliers
    before=p._select_blocker(s,arrays,a);after=p._select_blocker(s,arrays,dict(a,original_dual=physical))
    force=np.abs(physical)*np.linalg.norm(A,axis=1)
    rec=dict(name=name,q=q.tolist(),goal_q=p.qg.tolist(),velocity=a['velocity'].tolist(),before=before,after=after,largest_physical=[dict(row=s['row_ids'][i],multiplier=float(physical[i]),force=float(force[i]),original_multiplier=float(a['original_dual'][i]),gap_dt=float(u[i]*.02)) for i in np.argsort(-force)[:5]],gradient_reconstruction_error=float(np.max(np.abs(A.T@(physical-a['original_dual'])-A[indices].T@multipliers))))
    assert rec['gradient_reconstruction_error']<1e-10;out.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'DUAL_PROVENANCE_DIAGNOSIS.json').write_text(json.dumps(out,indent=2))
