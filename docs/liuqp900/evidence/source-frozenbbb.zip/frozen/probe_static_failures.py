from pathlib import Path
import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from scipy.optimize import linprog
from pilot_adapter import ROOT,build,online
from continuation_certified_policy import LowDimPolicy
from continuation_policy import LowDimPolicy as Full
R=ROOT;ctx=build('iris_4shelves_t2');c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;out=[]
for name in ['exact_failure_trace','old_zero_delay']:
 f=R/'trials'/name;tr=dict(np.load(f/'trajectory.npz'));q=tr['q'][-1];prev=tr['velocity'][-1];job=json.loads((f/'job.json').read_text());online.set_configuration(ctx.model,ctx.data,q);c.applied_velocity=prev.copy();c.pilot_objective_hook=None;c.solve(ctx.target)
 p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,prev);p.mode='CERT_PREP';p.future_state=Full.continuation_witnesses(p,q);state=p.future_state;H,g,A,l,u=c.last_qp_arrays;extra,eb=p._extras(c,c.pilot_nominal);up=np.isfinite(u);lo=np.isfinite(l);P=np.vstack([A[up],-A[lo],extra]);pu=np.r_[u[up],-l[lo],eb];B=np.asarray([x['b'] for x in state['rows']]);h=np.asarray([x['slack'] for x in state['rows']]);m=float(h.min());lp=linprog(np.r_[np.zeros(6),-1.],A_ub=np.vstack([np.c_[P,np.zeros(len(P))],np.c_[-.02*B,np.ones(len(B))]]),b_ub=np.r_[pu,h],bounds=[(None,None)]*6+[(None,.0002)],method='highs')
 proposal=p._solve(c,c.pilot_nominal,c.last_qp_arrays);ad=None if proposal is None else p._admit(c,c.last_qp_arrays,proposal)
 rec=dict(name=name,final_q=q.tolist(),full_refreshed_margin_m=m,lp_success=bool(lp.success),lp_max_predicted_gain_m=None if not lp.success else float(lp.x[-1]-m),lp_velocity=None if not lp.success else lp.x[:6].tolist(),actual_qp_velocity=None if proposal is None else proposal['velocity'].tolist(),admitted_velocity=None if ad is None else ad[0].tolist(),admission_rejections=p.admission_detail.copy())
 if ad is not None:
  nxt=Full.continuation_witnesses(p,q+.02*ad[0]);rec['qp_actual_full_map_one_step_gain_m']=-nxt['deficit']-m
  rec['predicted_same_witness_one_step_gain_m']=float(min(h+.02*B@ad[0])-m)
  rec['old_worst']=[{k:v for k,v in x.items() if k!='b'} for x in sorted(state['rows'],key=lambda x:x['slack'])[:2]];rec['new_worst']=[{k:v for k,v in x.items() if k!='b'} for x in sorted(nxt['rows'],key=lambda x:x['slack'])[:2]]
 out.append(rec);print(json.dumps(rec),flush=True)
(R/'STATIC_FAILURE_PROBES.json').write_text(json.dumps(out,indent=2))
