#!/bin/bash
# Frozen-map test: rebuild each 120 s run's final map, then run LiuQP + geodesic on it
# from the same start pose, with and without the unseen-space cells.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
OUT=v6runs/frozen; mkdir -p $OUT/maps $OUT/with_unseen $OUT/no_unseen
ONLINE=repo/experiment/runtimes/online_v6
lim="systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS"
for ((start = 1; start <= 20; start += 7)); do
  for slot in 0 1 2 3 4 5 6; do
    seed=$((start + slot)); [ $seed -le 20 ] || break; id=seed$(printf "%02d" $seed)
    [ -f $OUT/maps/$id.pkl ] || $lim taskset -c $(($slot*16))-$(($slot*16+15)) timeout 2400 ~/envs/ur5cab/bin/python $ONLINE/build_frozen_map.py v6runs/online_long/look_$id $OUT/maps/$id.pkl >> $OUT/maps/build.log 2>&1 &
  done
  wait
done
jobs=()
for seed in $(seq 1 20); do for v in with_unseen no_unseen; do jobs+=("$v $seed"); done; done
for ((start = 0; start < ${#jobs[@]}; start += 7)); do
  for slot in 0 1 2 3 4 5 6; do
    index=$((start + slot)); [ $index -lt ${#jobs[@]} ] || break
    set -- ${jobs[$index]}; v=$1; id=seed$(printf "%02d" $2); f=""; [ $v = no_unseen ] && f="--drop-frontier"
    [ -f $OUT/$v/$id/summary.json ] && continue
    $lim timeout 2400 ~/envs/ur5cab/bin/python $ONLINE/run_v6_case.py ellipsoid --map incremental --timing paced \
      --cpus $(($slot*16)):16 --start-seed $2 --geodesic --frozen-map $OUT/maps/$id.pkl $f --out $OUT/$v/$id > $OUT/$v/$id.log 2>&1 &
  done
  wait
done
echo DONE > $OUT/FROZEN_DONE
