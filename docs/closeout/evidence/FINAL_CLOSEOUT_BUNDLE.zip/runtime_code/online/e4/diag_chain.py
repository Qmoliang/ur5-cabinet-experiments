"""Why LiuQP abandons escape chains in the drawer.  For every chain of the given runs: is the planned chain
legal at LiuQP's 6 mm margin (densified to 0.01 rad, incl. the first leg from the stuck pose)?  How far does
the arm get, does it still move, and what does LiuQP report while it stalls (QP status, active collision
rows, near-penalty terms, limiting robot sphere / obstacle, clearance)?"""
import collections
import csv
import json
import sys

runs = sys.argv[1:]
sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/feasibility.py").read().split("variants = []")[0])
sys.path.insert(0, "/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
from escape_point import with_arm_limits  # noqa: E402

payload = json.load(open(f"{K}/assets/scene.json"))
scene = scene_of(payload)
model = build_model(scene)
robot = build_robot_certificate(model)
cover = build_volume_cover(scene.boxes, "ellipsoid", 0.075)
radii = np.array([s.radius for s in robot])
index = NativeBallTree(cover.centers, cover.aabb_half_extents, query_padding=float(radii.max() + 0.06))
checker = ConfigurationChecker(model, robot, cover.centers, "ellipsoid", radii=cover.sphere_radii,
                               shapes=cover.ellipsoid_shapes, margin=MARGIN, index=index)
checker = with_arm_limits(checker, np.asarray(scene.q0))
body = lambda i: model.body(int(checker.body_ids[i])).name.replace("_link", "")  # noqa: E731
boxes = [b.name for b in scene.boxes]


def proxy_box(j):
    c = cover.centers[int(j)]
    d = [np.max(np.abs(c - np.array(b.center)) - np.array(b.half_size)) for b in scene.boxes]
    return boxes[int(np.argmin(d))]


for run in runs:
    g = json.load(open(f"{run}/guidance.json"))
    q_hist = np.load(f"{run}/q_history.npy")[:, :6]
    rows = list(csv.DictReader(open(f"{run}/cycles.csv")))
    events = g["events"]
    searches = [e for e in events if e["event"] == "escape_search" and e.get("result") == "chain"]
    ends = [e for e in events if e["event"] in ("chain_done", "chain_abort")]
    print(f"\n=== {run.split('/')[-3]} {run.split('_')[-1]}  q_history {q_hist.shape}, cycles {len(rows)}")
    for k, (s, chain) in enumerate(zip(searches, g["subgoals"])):
        chain = np.asarray(chain)
        end = next((e for e in ends if e["cycle"] > s["cycle"]), None)
        c0, c1 = s["cycle"], end["cycle"] if end else len(rows) - 1
        q0 = q_hist[min(c0, len(q_hist) - 1)]
        # legality of the planned chain at 6 mm (finely densified), first leg from the stuck pose included
        pts = [q0] + list(chain)
        worst, worst_at = np.inf, None
        for a in range(len(pts) - 1):
            n = max(2, int(np.ceil(np.max(np.abs(pts[a + 1] - pts[a])) / 0.01)))
            for t in np.linspace(0, 1, n):
                c = checker.clearance(pts[a] + t * (pts[a + 1] - pts[a]))
                if c < worst:
                    worst, worst_at = c, a
        # progress: nearest chain point over the window
        near = [int(np.argmin(np.max(np.abs(chain - q_hist[c]), axis=1))) for c in range(c0, min(c1, len(q_hist) - 1))]
        last = rows[c1 - 50:c1]
        moved = np.max(np.abs(q_hist[c1] - q_hist[c1 - 50])) if c1 < len(q_hist) else float("nan")
        status = collections.Counter(r["status"] for r in last)
        lim = collections.Counter(f"{body(int(r['limiting_robot_index']))}/{proxy_box(r['limiting_obstacle_index'])}"
                                  for r in last if int(r["limiting_robot_index"]) >= 0)
        f = lambda key: np.median([float(r[key]) for r in last])  # noqa: E731
        print(f" chain {k}: {len(chain)} pts, route {s['route_rad']:.1f} rad, plan margin {1000*s['plan_margin_m']:.0f} mm |"
              f" legal at 6 mm: min clr {1000*worst:+.1f} mm (leg {worst_at}) | {end['event'] if end else 'open'} at {c1},"
              f" furthest pt reached {max(near) if near else 0}/{len(chain)-1}")
        print(f"   last 50 cycles: moved {moved:.3f} rad, |qdot| {f('qdot_norm'):.3f}, task speed {f('task_speed'):.3f},"
              f" min clr {1000*f('min_clearance'):+.1f} mm, active rows {f('active_obstacle_rows'):.0f}, near terms"
              f" {f('near_penalty_terms'):.0f}, contact rows {f('contact_repulsion_rows'):.0f}, status {dict(status)},"
              f" limiting {dict(lim.most_common(3))}")
        nxt = chain[min(max(near) + 1 if near else 0, len(chain) - 1)]
        print(f"   gap to next point (rad, per joint): {np.round(nxt - q_hist[min(c1, len(q_hist)-1)], 2).tolist()}")
index.close()
