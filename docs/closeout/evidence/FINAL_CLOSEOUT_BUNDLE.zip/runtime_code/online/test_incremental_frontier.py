"""The journal-driven frontier must equal the full-export frontier, frame by frame."""
import sys
import time
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
from frontier import IncrementalFrontier, frontier_cells, region_of_interest  # noqa: E402
from native_occupancy import NativeIncrementalOccupancyMap  # noqa: E402
import run_protocol_v3_async_online as online  # noqa: E402

worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=0.0075, maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm"), scene_version="camera_quarter",
    track_map_deltas=True)
lower, upper = region_of_interest(worker.scene.boxes)
incremental = IncrementalFrontier(lower, upper, online.MAP_VOXEL_SIZE)
run = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/online_improved/base_seed02")
q_history = np.load(next(p for p in run.iterdir() if p.is_dir()) / "q_history.npy")
for frame, cycle in enumerate(range(0, 450, 75)):
    worker.process(q_history[cycle], frame, cycle, cycle * 0.02, transferable=True, include_dense_snapshot=False)
    t = time.perf_counter()
    delta_keys, delta_states = worker.occupancy.snapshot_delta_arrays()
    incremental.apply(delta_keys, delta_states)
    inc_centres, _, _ = incremental.cells()
    inc_ms = 1000 * (time.perf_counter() - t)
    t = time.perf_counter()
    keys, states = worker.occupancy.snapshot_arrays()
    full_centres, _, _ = frontier_cells(keys, states, online.MAP_VOXEL_SIZE, lower, upper)
    full_ms = 1000 * (time.perf_counter() - t)
    same = (len(inc_centres) == len(full_centres) and
            np.array_equal(np.round(np.sort(inc_centres, axis=0), 9), np.round(np.sort(full_centres, axis=0), 9)))
    print(f"frame {frame:2d}: changed voxels {len(delta_keys):7d}; frontier {len(inc_centres):6d} incremental "
          f"({inc_ms:5.1f} ms) vs {len(full_centres):6d} full export ({full_ms:6.1f} ms); identical: {same}")
worker.close()
