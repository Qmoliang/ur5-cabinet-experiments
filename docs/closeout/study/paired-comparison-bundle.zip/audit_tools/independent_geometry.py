import numpy as np
from scipy.spatial import cKDTree
from native_ellipsoid_support import NativeEllipsoidSupport
class IndependentGuard:
    def __init__(self,centers,Q,offsets,sphere_radii,boxes,representation):
        self.c=np.asarray(centers);self.Q=np.asarray(Q);self.off=np.asarray(offsets);self.sphere=np.asarray(sphere_radii);self.box=np.asarray(boxes);self.rep=representation;self.mask=np.any(self.box>0,axis=1)
        self.val,self.rot=np.linalg.eigh(self.Q);self.kernel=NativeEllipsoidSupport();self.kernel.set_pair_threads(1)
        self.half=np.where(self.mask[:,None],self.box,np.repeat(self.sphere[:,None],3,axis=1) if representation=='sphere' else np.sqrt(np.maximum(np.diagonal(self.Q,axis1=1,axis2=2),0)))+self.off[:,None]
        self.bound=float(np.max(np.linalg.norm(self.half,axis=1)));self.tree=cKDTree(self.c)
    def pairs(self,a,b,r):
        center=(a+b)*.5;half=np.abs(b-a)*.5+r[:,None];ids=self.tree.query_ball_point(center,np.linalg.norm(b-a,axis=1)*.5+r+self.bound+1e-9);ri=np.repeat(np.arange(len(a)),[len(x) for x in ids]);oi=np.array([j for x in ids for j in x],dtype=int)
        if not len(oi):return ri,oi
        yes=np.all(np.abs(self.c[oi]-center[ri])<=self.half[oi]+half[ri]+1e-12,axis=1);return ri[yes],oi[yes]
    def certify(self,a,b,r):
        a=np.asarray(a);b=np.asarray(b);r=np.asarray(r);ri,oi=self.pairs(a,b,r)
        if not len(oi):return np.inf
        aa=a[ri];bb=b[ri];cc=self.c[oi];d0=np.empty(len(oi));d1=np.empty(len(oi));mask=self.mask[oi]
        if np.any(mask):
            h=self.box[oi[mask]];d0[mask]=np.linalg.norm(np.maximum(np.abs(aa[mask]-cc[mask])-h,0),axis=1);d1[mask]=np.linalg.norm(np.maximum(np.abs(bb[mask]-cc[mask])-h,0),axis=1)
        obs=~mask
        if np.any(obs):
            j=oi[obs]
            if self.rep=='sphere':d0[obs]=np.linalg.norm(aa[obs]-cc[obs],axis=1)-self.sphere[j];d1[obs]=np.linalg.norm(bb[obs]-cc[obs],axis=1)-self.sphere[j]
            else:
                x=self.kernel.closest_points_pairs_warm(aa[obs],cc[obs],self.val[j],self.rot[j],np.full(len(j),np.nan));y=self.kernel.closest_points_pairs_warm(bb[obs],cc[obs],self.val[j],self.rot[j],x[2]);d0[obs]=np.linalg.norm(x[1]-aa[obs],axis=1);d1[obs]=np.linalg.norm(y[1]-bb[obs],axis=1)
        return float(np.min((d0+d1-np.linalg.norm(bb-aa,axis=1))*.5-self.off[oi]-r[ri]))
    def reference_gap(self,p,r,reach=.020):
        ri,oi=self.pairs(p,p,r+reach)
        if not len(oi):return reach
        delta=p[ri]-self.c[oi];dist=np.empty(len(oi));box=self.mask[oi]
        if np.any(box):dist[box]=np.linalg.norm(np.maximum(np.abs(delta[box])-self.box[oi[box]],0),axis=1)
        obs=~box
        if np.any(obs):
            j=oi[obs]
            if self.rep=='sphere':dist[obs]=np.linalg.norm(delta[obs],axis=1)-self.sphere[j]
            else:
                y=np.einsum('nji,nj->ni',self.rot[j],delta[obs]);a2=np.maximum(self.val[j],1e-18);lo=np.zeros(len(j));hi=np.linalg.norm(y,axis=1)*np.sqrt(a2.max(axis=1))+1e-12;inside=np.sum(y*y/a2,axis=1)<=1
                for _ in range(70):
                    t=(lo+hi)/2;f=np.sum(a2*y*y/(a2+t[:,None])**2,axis=1)-1;lo=np.where(f>0,t,lo);hi=np.where(f>0,hi,t)
                closest=a2*y/(a2+hi[:,None]);dist[obs]=np.where(inside,0,np.linalg.norm(y-closest,axis=1))
        return min(reach,float(np.min(dist-self.off[oi]-r[ri])))
