from pathlib import Path
ROOT=Path(__file__).resolve().parent
p=ROOT/'verified_qp.py';source=p.read_text();source=source.replace('np.zeros(6)','np.zeros(len(g))').replace('[(None,None)]*6','[(None,None)]*len(g)').replace('np.eye(6)','np.eye(len(g))');p.write_text(source)
p=ROOT/'pilot_worker.py';source=p.read_text();old="        if job.get('policy_version')=='trace_v4':";new="        if job.get('policy_version')=='admission':\n            from admission_policy import LowDimPolicy\n        elif job.get('policy_version')=='reserve':\n            from release_policy import LowDimPolicy\n        elif job.get('policy_version')=='trace_v4':"
assert old in source;source=source.replace(old,new);p.write_text(source)
print('same-scene objective and numerical adapter prepared')
