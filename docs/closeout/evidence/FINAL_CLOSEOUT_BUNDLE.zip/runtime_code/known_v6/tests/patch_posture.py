"""known_v6/run.py: UR5_POSTURE_GOAL=<npy> adds a weak pull toward that goal posture."""
from pathlib import Path
p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
s = p.read_text()
old = """    controller.task_gain = 2.0
"""
assert s.count(old) == 1
s = s.replace(old, """    if os.environ.get("UR5_POSTURE_GOAL"):
        from whole_arm import enable_posture
        enable_posture(controller, np.load(os.environ["UR5_POSTURE_GOAL"]),
                       weight=float(os.environ.get("UR5_POSTURE_WEIGHT", "0.02")))
""" + old)
old = """        "whole_arm": os.environ.get("UR5_WHOLE_ARM", "0") == "1",
"""
assert s.count(old) == 1
s = s.replace(old, old + """        "posture_goal": os.environ.get("UR5_POSTURE_GOAL"),
""")
p.write_text(s)
print("patched")
