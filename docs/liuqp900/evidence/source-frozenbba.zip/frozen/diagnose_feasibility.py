from pathlib import Path
import os,json,sys
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
from scipy.optimize import linprog
from pilot_adapter import ROOT,build,online
from reserve_objective_contract import solve_reserve
from verified_qp import solve_verified
out=[]
for name in sys.argv[1:]:
    folder=ROOT/'trials'/name
    if not (folder/'result.json').exists():continue
    q=np.load(folder/'trajectory.npz')['q'][-1];ctx=build('iris_4shelves_t2',start=q,previous=np.zeros(6));c=ctx.controller
    c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.pilot_verified_fallback=True
    c.solve(ctx.target);H,g,A,l,u=c.last_qp_arrays;s=c.pilot_nominal
    ui=np.isfinite(u);li=np.isfinite(l);B=np.vstack([A[ui],-A[li]]);d=np.r_[u[ui],-l[li]]
    opt=dict(primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9)
    feasible=linprog(np.zeros(6),A_ub=B,b_ub=d,bounds=[(None,None)]*6,method='highs',options=opt)
    phase=linprog(np.r_[np.zeros(6),1.],A_ub=np.c_[B,-np.ones(len(B))],b_ub=d,bounds=[(None,None)]*6+[(0,None)],method='highs',options=opt)
    direct=solve_verified(H,g,A,l,u);error=float(np.linalg.norm(s['target']-online.attachment_position(ctx.model,ctx.data)))
    modified=solve_reserve(H,g,A,l,u,q,np.zeros(6),ctx.model.jnt_range[:6,0]+c.joint_padding,ctx.model.jnt_range[:6,1]-c.joint_padding,c.task_weight,error,c.dt,c.acceleration_limit,joint_metric=True)
    r=dict(name=name,error_mm=1000*error,nominal_status=s['status'],nominal_max_violation=float(max(np.max(l-A@s['x']),np.max(A@s['x']-u),0)),lp_feasible=bool(feasible.success),lp_status=feasible.message,minimum_uniform_row_slack=None if not phase.success else float(phase.fun),independent_original_qp_solved=direct is not None,joint_metric_qp_solved=modified is not None)
    if phase.success:
        ids=[s['row_ids'][i] for i in np.flatnonzero(ui)]+[s['row_ids'][i] for i in np.flatnonzero(li)]
        order=np.argsort(phase.ineqlin.marginals)[:8];r['infeasibility_witness_rows']=[dict(id=ids[i],rhs=float(d[i]),phase_dual=float(phase.ineqlin.marginals[i])) for i in order]
    out.append(r);print(json.dumps(r),flush=True)
(ROOT/'FEASIBILITY_DIAGNOSIS.json').write_text(json.dumps(out,indent=2))
