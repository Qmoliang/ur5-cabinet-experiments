from pathlib import Path
R=Path(__file__).resolve().parent
source=(R/'continuation_policy.py').read_text();start=source.index(' def continuation_witnesses(self,q):');end=source.index(' def continuation_certificate(self):',start);method=source[start:end].replace('pg.point_geometry(p[ri],oi,optimizer=True)','self._bounded_geometry(p,ri,oi)')
head='''"""Exact negative-witness selection using analytic distance lower bounds.
No obstacle is removed from the published map or safety oracle. Only exact
point-distance evaluations unable to attain the negative minimum are skipped.
"""
import time,numpy as np
from diagnostic_uncached_policy import LowDimPolicy as Previous
class LowDimPolicy(Previous):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);pg=self.ctx.proxy_guard
  outer=pg.sphere.copy() if pg.representation=='sphere' else np.sqrt(np.max(pg.values,axis=1))
  outer=np.where(pg.isbox,np.linalg.norm(pg.box,axis=1),outer)
  self.distance_outer_radius=outer+pg.offset;self.bound_candidates=0;self.exact_candidates=0
 def _bounded_geometry(self,points,ri,oi):
  pg=self.ctx.proxy_guard;distance=np.full(len(oi),np.inf);normals=np.zeros((len(oi),3));self.bound_candidates+=len(oi)
  for robot in np.unique(ri):
   indices=np.flatnonzero(ri==robot);ids=oi[indices];point=points[int(robot)];lower=np.linalg.norm(pg.centers[ids]-point,axis=1)-self.distance_outer_radius[ids]
   first=int(np.argmin(lower));probe,_=pg.point_geometry(point[None,:],ids[first:first+1],optimizer=True);self.exact_candidates+=1
   threshold=min(float(probe[0]),float(self.future_guard.radii[int(robot)]+self.ctx.controller.safety_margin))
   keep=indices[lower<=threshold+1e-12]
   if len(keep):
    dd,nn=pg.point_geometry(np.repeat(point[None,:],len(keep),axis=0),oi[keep],optimizer=True);distance[keep]=dd;normals[keep]=nn;self.exact_candidates+=len(keep)
  return distance,normals
'''
tail=''' def summary(self):
  out=super().summary();out.update(exact_bound_candidates=self.bound_candidates,exact_distance_evaluations=self.exact_candidates,witness_optimization='analytic enclosing-sphere signed-distance lower bounds; original exact distance and normal retained for all possible negative minimizers; original full map and execution safety unchanged')
  return out
'''
(R/'diagnostic_exact_pruned_policy.py').write_text(head+method+tail)
