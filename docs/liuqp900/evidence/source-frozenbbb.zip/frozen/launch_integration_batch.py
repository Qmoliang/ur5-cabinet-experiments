from pathlib import Path
import os,sys,json,subprocess,time,concurrent.futures,hashlib,queue
ROOT=Path(__file__).resolve().parent;PY='/home/hsjed/envs/ur5cab/bin/python'
jobs=json.loads(Path(sys.argv[1]).read_text())
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libstdc++.so.6',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',OMP_NUM_THREADS='2',MUJOCO_GL='egl')
cpu_slots=queue.Queue();cpu_slots.put([48,49,50,51]);cpu_slots.put([52,53,54,55])
def run(item):
    item=dict(item);assigned=cpu_slots.get();item['cpus']=assigned
    name=item.pop('name');folder=ROOT/'trials'/name;folder.mkdir(parents=True,exist_ok=False);(folder/'job.json').write_text(json.dumps(item,indent=2))
    manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')}
    manifest['code/online/protocol_liuqp_controller.py']=hashlib.sha256((ROOT/'code/online/protocol_liuqp_controller.py').read_bytes()).hexdigest()
    (folder/'source_hashes.json').write_text(json.dumps(manifest,indent=2))
    with (folder/'worker.log').open('w') as out:
        try:done=subprocess.run([PY,'-u',str(ROOT/'pilot_worker_integration.py'),str(folder)],env=env,stdout=out,stderr=subprocess.STDOUT,timeout=item.get('wall_limit_s',600)+120);code=done.returncode
        except subprocess.TimeoutExpired:code='timeout'
    summary=dict(name=name,exit_code=code,result_exists=(folder/'result.json').exists())
    if summary['result_exists']:
        r=json.loads((folder/'result.json').read_text());summary.update(status=r['status'],sim_s=r['sim_s'],error_mm=r['final_error_mm'])
    (folder/'launcher.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True);cpu_slots.put(assigned);return summary
results=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    for result in pool.map(run,jobs):
        results.append(result);(ROOT/(Path(sys.argv[1]).stem+'_STATUS.json')).write_text(json.dumps(results,indent=2))
