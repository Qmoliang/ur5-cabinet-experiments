"""Fixed-camera dedup on vs off over the same recorded frames: time, certificates, occupancy.

Usage: test_static_dedup.py CASE_DIR FRAMES on|off OUT.npz
"""
import os
import sys
import time
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
import run_v6_case  # noqa: E402

case, frames, mode, out = Path(sys.argv[1]), int(sys.argv[2]), sys.argv[3], sys.argv[4]
os.environ["UR5_STATIC_CAMERAS"] = run_v6_case.STATIC_CAMERA_PRESETS["low_side"]
os.environ["UR5_STATIC_DEDUP"] = "1" if mode == "on" else "0"
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
os.environ["UR5_FRONTIER"] = "1"
os.environ["UR5_FRONTIER_CELL_VOXELS"] = "1"
import run_protocol_v3_async_online as online  # noqa: E402

run = next(p for p in case.iterdir() if p.is_dir())
qs = np.load(run / "causal_source_configurations.npz")["q"][:frames]
worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=0.005, maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm", "static_low", "static_side"),
    scene_version="camera_quarter")
rows = []
for i, q in enumerate(qs):
    packet = worker.process(q, i, i, 0.0, include_dense_snapshot=False)
    rows.append(packet.frame_row)
later = rows[1:]
med = lambda k: float(np.median([float(r[k]) for r in later]))
p = packet.proxies
count = len(p.centers) - int(packet.frame_row.get("frontier_cells", 0))
unc = np.sqrt(np.maximum(np.linalg.eigvalsh(np.asarray(p.proxy_uncertainty_shapes)[:count])[:, -1], 0))
keys, states = worker.occupancy.snapshot_arrays()
np.savez_compressed(out, keys=keys, states=states, centers=np.asarray(p.centers)[:count],
                    outer=np.asarray(p.ellipsoid_outer_shapes)[:count])
print(f"dedup {mode}: per frame map {med('map_update_ms'):.0f} ms, proxy {med('proxy_update_ms'):.0f} ms, "
      f"pipeline {med('frame_pipeline_ms'):.0f} ms; surface certificates {count}, "
      f"uncertainty median {1000*np.median(unc):.2f} mm; frontier {packet.frame_row.get('frontier_cells')}")
for k in ("capture_ms", "map_update_ms", "proxy_frame_centervox_ms", "proxy_history_union_ms", "proxy_cell_merge_ms", "proxy_bucket_fit_ms", "proxy_publish_ids_hash_ms", "proxy_coverage_audit_ms", "frontier_ms", "mvt_update_ms", "snapshot_clone_ms", "frame_pipeline_ms"):
    print("  ", k, round(med(k), 1) if k in later[0] else None)
worker.close()
