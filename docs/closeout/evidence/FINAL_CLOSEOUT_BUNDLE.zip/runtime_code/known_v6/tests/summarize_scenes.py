"""Known-map scenario batch: reached / within 5 mm / penetrations per scene x representation x objective."""
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

root = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/scenes")
table = defaultdict(list)
for summary in sorted(root.glob("*_seed*/summary.json")):
    name = summary.parent.name
    stem, seed = name.rsplit("_seed", 1)
    s = json.loads(summary.read_text())
    table[stem].append(dict(seed=int(seed), success=s["success"], final_mm=1000 * s["final_error_m"],
                            time=s.get("first_sustained_success_time_s"), pen=s.get("exact_penetrating_cycles", 0),
                            depth=-1000 * float(s.get("maximum_penetration_m") or 0), attempts=s.get("start_attempts"),
                            p99=s.get("controller_ms_p99")))
missing = [p.name for p in root.glob("*_seed*") if p.is_dir() and not (p / "summary.json").exists()]
for stem in sorted(table):
    rows = table[stem]
    reached = [r for r in rows if r["success"]]
    print(f"{stem:38s} n={len(rows):2d} reached {len(reached):2d} within5mm {sum(r['final_mm'] < 5 for r in rows):2d} "
          f"pen_runs {sum(bool(r['pen']) for r in rows)} deepest {max(r['depth'] for r in rows):.1f}mm "
          f"reach_t {np.median([r['time'] for r in reached]) if reached else float('nan'):.1f}s "
          f"p99 {np.median([r['p99'] for r in rows]):.1f}ms "
          f"failed {sorted((r['seed'], round(r['final_mm'])) for r in rows if not r['success'])}")
print("missing:", missing)
