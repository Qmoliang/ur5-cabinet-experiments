"""Racket batch (controller errors stop the arm, run continues): safety and recovery per config."""
import collections
import glob
import json
from pathlib import Path

import numpy as np

rows = collections.defaultdict(list)
for f in glob.glob("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/racket/*/*_seed*/summary.json"):
    p = Path(f)
    rows[(p.parent.name.rsplit("_seed", 1)[0], p.parent.parent.name)].append(json.load(open(f)))
print("scene_rep | controller_speed | runs hit | median min clearance mm | runs with controller failures | reached after")
for (stem, cfg), rs in sorted(rows.items()):
    info = [r.get("racket") or {} for r in rs]
    mins = [i["min_distance_m"] for i in info if i.get("min_distance_m") is not None]
    hit = sum(bool(i.get("contact_cycles")) for i in info)
    fails = sum(bool(r.get("controller_failure_cycles")) for r in rs)
    after = sum(bool(i.get("success_after_racket")) for i in info)
    median = 1000 * np.median(mins) if mins else float("nan")
    print(f"{stem:38s} {cfg:18s} hit {hit:2d}/{len(rs)}  min {median:6.1f}  failures {fails:2d}  after {after:2d}")
