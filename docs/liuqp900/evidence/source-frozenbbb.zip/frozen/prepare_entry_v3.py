from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='goal_entry_v2':";new="        if job.get('policy_version')=='goal_entry_v3':\n            from goal_entry_policy_v3 import LowDimPolicy\n        elif job.get('policy_version')=='goal_entry_v2':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'entry_v2_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('entry_v2','entry_v3');j['policy_version']='goal_entry_v3'
(ROOT/'entry_v3_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_v3';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
(ROOT/'ENTRY_V3_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},goal_data_sha256=hashlib.sha256((ROOT/'GOAL_BRANCH_PORTS.json').read_bytes()).hexdigest(),changes=['replace locally equivalent SVD features by globally distinct base/elbow kinematic branch coordinates','cap voluntary bypass clearance by the measured terminal-posture clearance so that terminal posture is not excluded'],target_pose_unchanged=True,physical_safety_unchanged=True,no_route=True),indent=2))
print(json.dumps(jobs))
