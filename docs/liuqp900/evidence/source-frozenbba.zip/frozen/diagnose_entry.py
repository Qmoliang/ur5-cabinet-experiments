import os,json,sys
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy import LowDimPolicy
from verified_qp import solve_verified
out=[]
for name in sys.argv[1:]:
    folder=ROOT/'trials'/name
    if not (folder/'result.json').exists():continue
    q=np.load(folder/'trajectory.npz')['q'][-1];job=json.loads((folder/'job.json').read_text());ctx=build('iris_4shelves_t2',start=q);c=ctx.controller
    c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
    p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,np.zeros(6));s=c.pilot_nominal;arrays=c.last_qp_arrays;H,g,A,l,u=arrays;HH,gg=p._terms(c,s)
    answer=p._solve(c,s,arrays);shadow=solve_verified(H+HH,g+gg,A,l,u)
    def rows(y):
        force=np.abs(y)*np.linalg.norm(A,axis=1);return [dict(id=s['row_ids'][i],dual=float(y[i]),gap_dt=float(u[i]*.02),force=float(force[i])) for i in np.argsort(-force)[:5]]
    r=dict(name=name,error_mm=p.error*1000,feature_distance=float(np.linalg.norm(p.feature(q)-p.goal_feature)),augmented_solved=answer is not None,goal_quadratic_solved=shadow is not None,original_top=rows(s['y']),augmented_feature_singular_values=np.linalg.svd(np.vstack([s['J'],p.P]),compute_uv=False).tolist(),original_velocity=s['x'].tolist())
    if answer is not None:r.update(velocity=answer['velocity'].tolist(),modified_top=rows(answer['original_dual']),admitted=None if (a:=p._admit(c,arrays,answer)) is None else a[1])
    if shadow is not None:r.update(quadratic_velocity=shadow.x.tolist(),quadratic_top=rows(shadow.y))
    out.append(r);print(json.dumps(r),flush=True)
(ROOT/'ENTRY_FAILURE_DIAGNOSIS.json').write_text(json.dumps(out,indent=2))
