"""What limits an online run at its end: the limiting certificate (observed surface or unseen-space cell),
its position relative to the scene's true boxes, and where the gripper is."""
import csv
import json
import sys
from pathlib import Path

import numpy as np

run = Path(sys.argv[1])
scene_json = sys.argv[2]
inner = next(run.glob("A-CV-*"))
rows = list(csv.DictReader(open(inner / "cycles.csv")))
proxies = np.load(inner / "final_causal_proxies.npz")
ids = proxies["proxy_ids"]
boxes = json.load(open(scene_json))["boxes"]
lo = np.array([np.array(b["center"]) - np.array(b["half_size"]) for b in boxes])
hi = np.array([np.array(b["center"]) + np.array(b["half_size"]) for b in boxes])
unc = proxies["proxy_uncertainty_shapes"]
frontier_like = np.all(np.abs(unc.reshape(len(ids), -1)) < 1e-15, axis=1)
print("final certificates", len(ids), "of which unseen-space (zero uncertainty)", int(frontier_like.sum()))
for r in rows[-1:]:
    lim = int(float(r["limiting_proxy_id"]))
    ee = np.array([float(r["ee_x"]), float(r["ee_y"]), float(r["ee_z"])])
    print("end gripper", ee.round(3), "error mm", round(float(r["error_m"]) * 1000, 1), "status", r["status"])
    if lim in set(ids.tolist()):
        i = list(ids).index(lim)
        c = proxies["centers"][i]
        d_box = np.min(np.linalg.norm(np.maximum(0, np.maximum(lo - c, c - hi)), axis=1))
        print("limiting certificate", lim, "centre", c.round(3), "unseen-space cell" if frontier_like[i] else "observed surface",
              "distance from its centre to the nearest true box", round(float(d_box), 3), "m")
# How much of the space between the gripper and the target is unseen-space cells?
target = np.array(json.load(open(scene_json))["waypoints"][-1])
seg = ee[None, :] + np.linspace(0, 1, 20)[:, None] * (target - ee)[None, :]
cent = proxies["centers"][frontier_like]
if len(cent):
    near = [int(np.sum(np.linalg.norm(cent - p, axis=1) < 0.03)) for p in seg]
    print("unseen-space cells within 3 cm of points on the gripper->target segment:", near)
