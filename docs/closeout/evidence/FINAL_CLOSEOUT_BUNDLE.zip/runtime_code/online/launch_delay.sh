#!/bin/bash
# Delay matrix: legacy vs incremental map, real-time vs synchronous (no-delay) camera.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
run() { # id representation map timing cpu_first
  systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS \
    timeout 14400 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py $2 --map $3 --timing $4 --cpus $5:16 --out v6runs/delay/$1 > v6runs/delay/$1.log 2>&1
}
mkdir -p v6runs/delay
run D1_ell_legacy_paced  ellipsoid legacy      paced 0  &
run D2_sph_legacy_paced  sphere    legacy      paced 16 &
run D3_ell_incr_paced    ellipsoid incremental paced 32 &
run D4_sph_incr_paced    sphere    incremental paced 48 &
run D5_ell_incr_sync     ellipsoid incremental sync  64 &
run D6_sph_incr_sync     sphere    incremental sync  80 &
wait
echo ALL_DONE > v6runs/delay/ALL_DONE
