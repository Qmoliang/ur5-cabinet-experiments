from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
archive=ROOT/'revisions/blocker_v4';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='blocker_v4':";new="        if job.get('policy_version')=='blocker_v5':\n            from blocker_policy_v5 import LowDimPolicy\n        elif job.get('policy_version')=='blocker_v4':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'blocker_v4_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('blocker_v4','blocker_v5');j['policy_version']='blocker_v5'
(ROOT/'blocker_v5_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'BLOCKER_V5_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='use improvement of actual executed best goal distance, rather than error-window range, to detect stagnation including oscillations; unchanged 100-cycle and 0.2mm thresholds, objective and safety'),indent=2))
print(json.dumps(jobs))
