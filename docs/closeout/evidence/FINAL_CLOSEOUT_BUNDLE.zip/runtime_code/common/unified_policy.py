from pathlib import Path
import json,hashlib
POLICY_PATH=Path(__file__).with_name("policy.json")
POLICY=json.loads(POLICY_PATH.read_text())
POLICY_SHA256=hashlib.sha256(POLICY_PATH.read_bytes()).hexdigest()

if not (0<POLICY["environment_margin_m"]<=POLICY["operating_margin_m"]<=POLICY["goal_margin_m"]):
 raise ValueError("invalid hard/operating/goal clearance contract")
if POLICY.get("active_depth_views",False) and POLICY["active_initial_required_margin_m"]<POLICY["operating_margin_m"]:
 raise ValueError("initial readiness cannot be weaker than normal controller clearance")
