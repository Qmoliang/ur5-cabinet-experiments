from pathlib import Path
import shutil
R=Path(__file__).resolve().parent;p=R/'diagnostic_exact_pruned_policy.py';a=R/'revisions/exact_pruning_v1';a.mkdir(parents=True,exist_ok=True);shutil.copy2(p,a/p.name);shutil.copy2(R/'EXACT_PRUNING_EQUIVALENCE.json',a/'equivalence.json')
s=p.read_text().replace('g.radii+self.ctx.controller.near_distance','g.radii+self.ctx.controller.safety_margin+2e-7')
s=s.replace("  for robot in np.unique(ri):\n   indices=np.flatnonzero(ri==robot);ids=oi[indices];point=points[int(robot)];lower=", "  order=np.arange(len(ri)) if np.all(ri[1:]>=ri[:-1]) else np.argsort(ri,kind='stable');ordered=ri[order];cuts=np.r_[0,np.flatnonzero(ordered[1:]!=ordered[:-1])+1,len(ri)]\n  for start,end in zip(cuts[:-1],cuts[1:]):\n   indices=order[start:end];robot=ri[indices[0]];ids=oi[indices];point=points[int(robot)];lower=")
p.write_text(s)
