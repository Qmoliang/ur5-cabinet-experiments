// Native geodesic distance field for LiuQP's attraction direction.
// A voxel is blocked when its centre lies inside an obstacle proxy grown by the
// inflation radius (ellipsoid: each semi-axis + r).  That grown ellipsoid lies
// slightly inside the exact r-neighbourhood (Minkowski inequality), which is
// acceptable here: the field only chooses LiuQP's pull direction, and LiuQP's
// own constraints keep the robot safe.  A 26-connected breadth-first
// wavefront from the goal gives every free voxel its route length; descending
// it from any reachable voxel always reaches the goal.
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <vector>

#ifdef _WIN32
#define GD_API extern "C" __declspec(dllexport)
#else
#define GD_API extern "C"
#endif

namespace {

constexpr int32_t kUnreached = std::numeric_limits<int32_t>::max();

struct Field {
    double lower[3];
    double voxel;
    int32_t dims[3];
    std::vector<uint8_t> blocked;
    std::vector<int32_t> distance;
    double goal[3] = {0, 0, 0};

    int64_t index(int32_t i, int32_t j, int32_t k) const {
        return (static_cast<int64_t>(i) * dims[1] + j) * dims[2] + k;
    }
    bool cell(const double* p, int32_t* c) const {
        for (int a = 0; a < 3; ++a) {
            c[a] = static_cast<int32_t>(std::floor((p[a] - lower[a]) / voxel));
            if (c[a] < 0 || c[a] >= dims[a]) return false;
        }
        return true;
    }
    void centre(const int32_t* c, double* p) const {
        for (int a = 0; a < 3; ++a) p[a] = lower[a] + (c[a] + 0.5) * voxel;
    }
};

// Mark voxels inside the box [lo, hi] for which inside(p) holds.
template <typename Inside>
void mark_box(Field& f, const double* lo, const double* hi, Inside inside) {
    int32_t a[3], b[3];
    for (int d = 0; d < 3; ++d) {
        a[d] = std::max(0, static_cast<int32_t>(std::floor((lo[d] - f.lower[d]) / f.voxel)));
        b[d] = std::min(f.dims[d] - 1, static_cast<int32_t>(std::ceil((hi[d] - f.lower[d]) / f.voxel)));
    }
    double p[3];
    for (int32_t i = a[0]; i <= b[0]; ++i)
        for (int32_t j = a[1]; j <= b[1]; ++j)
            for (int32_t k = a[2]; k <= b[2]; ++k) {
                const int64_t n = f.index(i, j, k);
                if (f.blocked[n]) continue;
                int32_t c[3] = {i, j, k};
                f.centre(c, p);
                if (inside(p)) f.blocked[n] = 1;
            }
}

}  // namespace

GD_API void* gd_create(const double* lower, double voxel, const int32_t* dims) {
    auto* f = new Field();
    for (int a = 0; a < 3; ++a) {
        f->lower[a] = lower[a];
        f->dims[a] = dims[a];
    }
    f->voxel = voxel;
    const int64_t total = static_cast<int64_t>(dims[0]) * dims[1] * dims[2];
    f->blocked.assign(total, 0);
    f->distance.assign(total, kUnreached);
    return f;
}

GD_API void gd_destroy(void* handle) { delete static_cast<Field*>(handle); }

GD_API void gd_clear(void* handle) {
    auto& f = *static_cast<Field*>(handle);
    std::fill(f.blocked.begin(), f.blocked.end(), 0);
    std::fill(f.distance.begin(), f.distance.end(), kUnreached);
}

// rotations: n x 3 x 3 row-major with eigenvector columns; axes: n x 3 semi-axes.
GD_API void gd_block_ellipsoids(void* handle, const double* centers, const double* rotations,
                                const double* axes, int32_t count, double inflation) {
    auto& f = *static_cast<Field*>(handle);
    for (int32_t e = 0; e < count; ++e) {
        const double* c = centers + 3 * e;
        const double* r = rotations + 9 * e;
        double grown[3], half[3], lo[3], hi[3];
        for (int a = 0; a < 3; ++a) grown[a] = axes[3 * e + a] + inflation;
        // Axis-aligned half-extent of the grown ellipsoid: sqrt(sum_j R_aj^2 g_j^2).
        for (int a = 0; a < 3; ++a) {
            double s = 0.0;
            for (int j = 0; j < 3; ++j) s += r[3 * a + j] * r[3 * a + j] * grown[j] * grown[j];
            half[a] = std::sqrt(s);
            lo[a] = c[a] - half[a];
            hi[a] = c[a] + half[a];
        }
        mark_box(f, lo, hi, [&](const double* p) {
            double sum = 0.0;
            for (int j = 0; j < 3; ++j) {
                double local = 0.0;
                for (int a = 0; a < 3; ++a) local += (p[a] - c[a]) * r[3 * a + j];
                sum += local * local / (grown[j] * grown[j]);
            }
            return sum <= 1.0;
        });
    }
}

GD_API void gd_block_spheres(void* handle, const double* centers, const double* radii, int32_t count,
                             double inflation) {
    auto& f = *static_cast<Field*>(handle);
    for (int32_t e = 0; e < count; ++e) {
        const double* c = centers + 3 * e;
        const double reach = radii[e] + inflation;
        double lo[3], hi[3];
        for (int a = 0; a < 3; ++a) {
            lo[a] = c[a] - reach;
            hi[a] = c[a] + reach;
        }
        mark_box(f, lo, hi, [&](const double* p) {
            double s = 0.0;
            for (int a = 0; a < 3; ++a) s += (p[a] - c[a]) * (p[a] - c[a]);
            return s <= reach * reach;
        });
    }
}

// Breadth-first wavefront from the goal.  Returns the number of reached
// voxels, or -1 if the goal voxel is outside the grid or blocked.
GD_API int64_t gd_solve(void* handle, const double* goal) {
    auto& f = *static_cast<Field*>(handle);
    std::fill(f.distance.begin(), f.distance.end(), kUnreached);
    int32_t g[3];
    if (!f.cell(goal, g) || f.blocked[f.index(g[0], g[1], g[2])]) return -1;
    for (int a = 0; a < 3; ++a) f.goal[a] = goal[a];
    std::vector<int64_t> queue;
    queue.reserve(f.blocked.size() / 4);
    const int64_t start = f.index(g[0], g[1], g[2]);
    f.distance[start] = 0;
    queue.push_back(start);
    const int64_t s0 = static_cast<int64_t>(f.dims[1]) * f.dims[2], s1 = f.dims[2];
    for (size_t head = 0; head < queue.size(); ++head) {
        const int64_t n = queue[head];
        const int32_t i = static_cast<int32_t>(n / s0), j = static_cast<int32_t>((n / s1) % f.dims[1]),
                      k = static_cast<int32_t>(n % s1);
        const int32_t next = f.distance[n] + 1;
        for (int di = -1; di <= 1; ++di)
            for (int dj = -1; dj <= 1; ++dj)
                for (int dk = -1; dk <= 1; ++dk) {
                    if (!di && !dj && !dk) continue;
                    const int32_t a = i + di, b = j + dj, c = k + dk;
                    if (a < 0 || b < 0 || c < 0 || a >= f.dims[0] || b >= f.dims[1] || c >= f.dims[2]) continue;
                    const int64_t m = f.index(a, b, c);
                    if (f.blocked[m] || f.distance[m] != kUnreached) continue;
                    f.distance[m] = next;
                    queue.push_back(m);
                }
    }
    return static_cast<int64_t>(queue.size());
}

// Target to hand LiuQP: a point in the direction of the route `lookahead`
// metres ahead, at the remaining route length.  Returns 1 when out[] holds a
// guided target, 0 when the caller should use the goal itself.
GD_API int32_t gd_command(void* handle, const double* gripper, double lookahead, double* out) {
    const auto& f = *static_cast<Field*>(handle);
    int32_t c[3];
    if (!f.cell(gripper, c)) return 0;
    int64_t n = f.index(c[0], c[1], c[2]);
    if (f.distance[n] == kUnreached) {
        // The gripper sits in an inflated voxel: use the nearest reached voxel.
        bool found = false;
        for (int32_t radius = 1; radius <= 8 && !found; ++radius) {
            double best = std::numeric_limits<double>::infinity();
            int32_t pick[3] = {0, 0, 0};
            for (int32_t i = c[0] - radius; i <= c[0] + radius; ++i)
                for (int32_t j = c[1] - radius; j <= c[1] + radius; ++j)
                    for (int32_t k = c[2] - radius; k <= c[2] + radius; ++k) {
                        if (i < 0 || j < 0 || k < 0 || i >= f.dims[0] || j >= f.dims[1] || k >= f.dims[2]) continue;
                        if (f.distance[f.index(i, j, k)] == kUnreached) continue;
                        const double d = std::hypot(std::hypot(i - c[0], j - c[1]), k - c[2]);
                        if (d < best) {
                            best = d;
                            pick[0] = i; pick[1] = j; pick[2] = k;
                        }
                    }
            if (std::isfinite(best)) {
                for (int a = 0; a < 3; ++a) c[a] = pick[a];
                found = true;
            }
        }
        if (!found) return 0;
        n = f.index(c[0], c[1], c[2]);
    }
    const double route = f.distance[n] * f.voxel;
    if (route <= lookahead) return 0;
    double walked = 0.0;
    while (walked < lookahead && f.distance[f.index(c[0], c[1], c[2])] > 0) {
        const int32_t here = f.distance[f.index(c[0], c[1], c[2])];
        int32_t best = here, pick[3] = {c[0], c[1], c[2]};
        double best_goal = std::numeric_limits<double>::infinity();
        for (int di = -1; di <= 1; ++di)
            for (int dj = -1; dj <= 1; ++dj)
                for (int dk = -1; dk <= 1; ++dk) {
                    if (!di && !dj && !dk) continue;
                    const int32_t a = c[0] + di, b = c[1] + dj, k = c[2] + dk;
                    if (a < 0 || b < 0 || k < 0 || a >= f.dims[0] || b >= f.dims[1] || k >= f.dims[2]) continue;
                    const int32_t v = f.distance[f.index(a, b, k)];
                    if (v == kUnreached || v >= here) continue;
                    // Lowest route length first; among equals, closest to the goal.
                    int32_t cell_ab[3] = {a, b, k};
                    double p[3];
                    f.centre(cell_ab, p);
                    const double g = std::hypot(std::hypot(p[0] - f.goal[0], p[1] - f.goal[1]), p[2] - f.goal[2]);
                    if (v < best || (v == best && g < best_goal)) {
                        best = v;
                        best_goal = g;
                        pick[0] = a; pick[1] = b; pick[2] = k;
                    }
                }
        if (best >= here) break;
        walked += f.voxel * std::sqrt(static_cast<double>((pick[0] - c[0]) * (pick[0] - c[0]) +
                                                          (pick[1] - c[1]) * (pick[1] - c[1]) +
                                                          (pick[2] - c[2]) * (pick[2] - c[2])));
        for (int a = 0; a < 3; ++a) c[a] = pick[a];
    }
    double p[3];
    f.centre(c, p);
    double dir[3], length = 0.0;
    for (int a = 0; a < 3; ++a) {
        dir[a] = p[a] - gripper[a];
        length += dir[a] * dir[a];
    }
    length = std::sqrt(length);
    if (length < 1e-9) return 0;
    const double scale = std::max(route, length) / length;
    for (int a = 0; a < 3; ++a) out[a] = gripper[a] + dir[a] * scale;
    return 1;
}
