"""Constraint-respecting fallback for an infeasible QP (every E4 controller).

Replaces "retry without acceleration rows, escape, then clip the result": the
clipped velocity no longer satisfied any row, and those cycles produced every
floor contact in E4.  Here the velocity is the solution of

    min  (eps/2)|qdot|^2 + c^T qdot + sum_k w_k s_k
    s.t. joint velocity / acceleration / position rows   hard
         safety row k:  a_k^T qdot - s_k <= u_k,  s_k >= 0

so it always exists, never exceeds the velocity or acceleration limits, and
violates the safety rows as little as possible: walls, floor (workspace) and
self-collision rows weigh W_STATIC, moving-object rows W_MOVING.  c is LiuQP's
escape direction (away from approaching moving objects) for the variants with
escape, zero otherwise (then the result is the least-violating slow-down).
The executed velocity is exactly this solution.
"""
from __future__ import annotations

import numpy as np
import osqp
from scipy import sparse

W_STATIC = 1.0e4
W_MOVING = 1.0e3
EPSILON = 1.0
MAX_ITER = 1500


def least_violation(A, lower, upper, hard, weights, direction=None, epsilon=EPSILON):
    """Rows with hard[k] are kept as l <= a q <= u; the others are softened (upper side only)."""
    A = np.asarray(A, float)
    n = A.shape[1]
    hard = np.asarray(hard, bool)
    soft = ~hard & np.isfinite(upper)
    m = int(soft.sum())
    P = sparse.diags(np.r_[np.full(n, epsilon), np.full(m, 1e-6)]).tocsc()
    q = np.r_[np.zeros(n) if direction is None else np.asarray(direction, float), np.asarray(weights, float)[soft]]
    blocks = [sparse.hstack([sparse.csc_matrix(A[hard]), sparse.csc_matrix((int(hard.sum()), m))]),
              sparse.hstack([sparse.csc_matrix(A[soft]), -sparse.eye(m)]),
              sparse.hstack([sparse.csc_matrix((m, n)), sparse.eye(m)])]
    C = sparse.vstack(blocks).tocsc()
    lo = np.r_[np.asarray(lower, float)[hard], np.full(m, -np.inf), np.zeros(m)]
    hi = np.r_[np.maximum(np.asarray(upper, float)[hard], np.asarray(lower, float)[hard]),
               np.asarray(upper, float)[soft], np.full(m, np.inf)]
    try:
        solver = osqp.OSQP()
        # Bounded effort: it runs inside the 20 ms control cycle (None -> the caller brakes).
        solver.setup(P=P, q=q, A=C, l=lo, u=hi, verbose=False, polishing=False, max_iter=MAX_ITER,
                     eps_abs=1e-4, eps_rel=1e-4, adaptive_rho=True)
        result = solver.solve()
    except Exception:
        return None
    if result.x is None or not str(result.info.status).lower().startswith("solved"):
        return None
    x = np.asarray(result.x[:n], float)
    # Hard rows (joint velocity / acceleration) exactly, despite the loose tolerance.
    hard_rows = np.asarray(A, float)[hard]
    if hard_rows.shape[0] == n and np.allclose(hard_rows, np.eye(n)):
        x = np.clip(x, np.asarray(lower, float)[hard], np.asarray(upper, float)[hard])
    return x


def escape_direction(A, upper, moving_rows, dt):
    """LiuQP escape objective: sum of the approaching-object rows, weighted by 1 / clearance."""
    if not np.any(moving_rows):
        return None
    rows = A[moving_rows]
    clearance = np.maximum(np.asarray(upper)[moving_rows] * dt, 0.005)
    direction = ((1.0 / clearance)[:, None] * rows).sum(axis=0)
    norm = float(np.linalg.norm(direction))
    return None if norm < 1e-12 else direction / norm


def liuqp_fallback(controller, channel, dynamic_id_base, use_escape):
    """Fallback for the online LiuQP variants from the last (infeasible) QP and its row identities."""
    arrays = getattr(controller, "last_qp_arrays", None)
    identity = getattr(controller, "_previous_qp_full_row_identity", None)
    if arrays is None or identity is None:
        return None
    _H, _g, A, lower, upper = arrays
    kinds = np.array([row[0] for row in identity])
    proxies = np.array([row[2] for row in identity])
    hard = kinds == "joint_velocity"
    moving = np.isin(kinds, ["collision", "contact_recovery"]) & (proxies >= dynamic_id_base)
    weights = np.where(moving, W_MOVING, W_STATIC)
    direction = None
    if use_escape:
        approaching = channel.escape_ids()
        rows = moving & (kinds == "collision") & np.isin(proxies, list(approaching))
        direction = escape_direction(A, upper, rows, controller.dt)
    return least_violation(A, lower, upper, hard, weights, direction)
