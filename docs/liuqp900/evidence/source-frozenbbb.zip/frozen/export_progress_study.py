from pathlib import Path
import json,hashlib,zipfile,shutil,datetime
from zoneinfo import ZoneInfo
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;O=R.parent/'liuqp_entry_certificate_20261107';OUT=R/'delivery';OUT.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
index={}
for p in list(R.glob('*.py'))+list((R/'revisions').rglob('*.py'))+[R/'code/online/protocol_liuqp_controller.py']:index.setdefault(sha(p),[]).append(str(p.relative_to(R)))
records=[]
for f in sorted((R/'trials').iterdir()):
 assert (f/'result.json').exists(),f
 r=read(f/'result.json');j=read(f/'job.json');p=r.get('policy_summary') or {};a=read(f/'audit.json');m=read(f/'memory_audit.json');source=read(f/'source_hashes.json');missing={n:h for n,h in source.items() if h not in index}
 interruption=read(f/'DIAGNOSTIC_INTERRUPTION.json') if (f/'DIAGNOSTIC_INTERRUPTION.json').exists() else None
 rec=dict(name=f.name,version=j['policy_version'],status='diagnostic_prefix_interrupted' if interruption else r['status'],raw_result_status=r['status'],interruption=interruption,sim_s=r['sim_s'],wall_s=r['wall_s'],error_mm=r['final_error_mm'],goal_reached=bool(r['goal_hold_reached']),goal_hold=r['maximum_hold'],safety_passed=a['safety_passed'],memory_passed=m['passed'],validated_arrival=bool(a['safe_arrival'] and m['passed'] and not p.get('memory_certificate_failures',0)),workspace_passed=a['workspace']['passed'],minimum_proxy_gap_mm=a['minimum_proxy_gap_mm'],minimum_self_gap_mm=a['physical_motion']['minimum_self_m']*1000,memory_count=p.get('memory_count',0),inherited_memory_count=m.get('inherited_count',0),controller_p99_ms=r['controller_ms_p99'],latency_model=r['latency_model'],latency_tail_uses=r['latency_trace_tail_uses'],stage_acceptances=p.get('actual_progress_accepted'),stage_rejections=p.get('actual_progress_rejected'),bypass_contracts=len(p.get('local_bypass_contracts',[])),entry_certificate_calls=p.get('continuation_certificates'),entry_certificate_passes=p.get('continuation_passes'),application_progress_rejections=p.get('application_progress_rejected_candidates'),application_progress_scaled=p.get('application_progress_scaled_commands'),application_progress_ms_p99=p.get('application_progress_ms_p99'),application_progress_total_s=p.get('application_progress_total_s'),persistent_continuations=p.get('persistent_bypass_continuations'),readiness_frontier_m=p.get('readiness_frontier_m'),forbidden_calls=r['forbidden_calls'],source_unavailable=missing,job=j)
 if (f/'error.json').exists():rec['error']=read(f/'error.json')
 records.append(rec)
lookup={r['name']:r for r in records};assert all(not r['source_unavailable'] for r in records)
groups={
 'diagnostics':['exact_failure_trace','old_cycle_schedule','old_zero_delay','old_full_refresh_cycle','old_full_refresh_zero_delay_exact'],
 'retained_diagnostic_prefix':['old_full_refresh_zero_delay'],
 'development_v1_to_v4':[f'progress_original_{mode}_v{i}' for i in [1,2,3,4] for mode in ['cycle','measured']],
 'frozen_v4_original':['final_original_cycle_1','final_original_cycle_repeat','final_original_measured_1','final_original_measured_2'],
 'frozen_v4_regression':[j['name'] for j in read(R/'final_jobs.json') if j['name'].startswith('regression_')],
 'application_v5':['progress_original_cycle_v5','progress_original_measured_v5'],
 'persistent_v6_original':['progress_original_cycle_v6','progress_original_measured_v6'],
 'persistent_v6_regression':[j['name'] for j in read(R/'persistent_regression_jobs.json')],
}
cohorts={k:dict(names=ns,runs=len(ns),arrivals=sum(lookup[n]['goal_reached'] for n in ns),validated_arrivals=sum(lookup[n]['validated_arrival'] for n in ns),failed=[n for n in ns if not lookup[n]['goal_reached']]) for k,ns in groups.items()}
protected=read(R/'PROTECTED_PREVIOUS_STUDY.json');changed=[n for n,h in protected.items() if sha(Path(n))!=h];assert not changed
freeze_checks={}
for n in ['FINAL_FREEZE.json','EXECUTION_PROGRESS_FREEZE.json','PERSISTENT_PROGRESS_FREEZE.json','PERSISTENT_REGRESSION_FREEZE.json','UNCACHED_FREEZE.json','COMBINED_DIAGNOSTIC_FREEZE.json','EXACT_COMBINED_FREEZE.json']:
 f=read(R/n);hashes=f.get('source_hashes',f.get('sources',{}));bad=[name for name,h in hashes.items() if sha(R/name)!=h];assert not bad,(n,bad);freeze_checks[n]=dict(files=len(hashes),changed=bad)
inputs=read(R/'INPUTS.json')
for it in inputs:assert sha(Path(it['input_file']))==it['input_sha256'] and sha(Path(it['scene']))==it['scene_sha256']
evidence=read(R/'EXACT_REPRODUCTION.json');decomp=read(R/'FAILURE_DECOMPOSITION.json')['summary'];ledger=read(R/'PROGRESS_LEDGER_DIAGNOSIS.json');probes=read(R/'STATIC_FAILURE_PROBES.json')
summary=dict(completed_at=datetime.datetime.now(datetime.timezone.utc).astimezone(ZoneInfo('Asia/Shanghai')).isoformat(),scope='same MuJoCo UR5e shelf and frozen causal published map; no RRT or six-dimensional path search',adoption='experimental implementations only; original reproducible failure not repaired robustly, do not replace the preceding controller on these results',cohorts=cohorts,records=records,counts=dict(attempts=len(records),audited=len(records),goal_arrivals=sum(r['goal_reached'] for r in records),validated_arrivals=sum(r['validated_arrival'] for r in records),audit_not_passed=[r['name'] for r in records if not r['safety_passed'] or not r['memory_passed']]),causal_evidence=decomp,exact_reproduction=evidence,static_failure_probes=probes,progress_ledger=ledger,integrity=dict(protected_files=len(protected),changed=changed,freeze_checks=freeze_checks,source_coverage_complete=True),inputs=inputs)
(OUT/'RESULTS.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
lines=['实际进展验收与同货架回归：完整记录','完成时间：'+summary['completed_at'],'','结论：已经完成完整失败复现、诊断对照、实际进展验收实现与旧成功案例回归，但未获得可替换上一版的稳定修复。固定失败仍在；实验分支保留，旧控制器与旧实验文件未覆盖。','所有试验仍为同一货架、同一目标终态、相同安全阈值和300秒运动预算；无RRT调用、无航点链或未来六维构型优化。不同计算预算的诊断组单列。','','诊断对照（不把计算延迟关闭的试验当作实时系统）：']
for n in groups['diagnostics']:
 r=lookup[n];lines.append(f"{n}: {r['status']}, {r['sim_s']:.2f}s, {r['error_mm']:.9f}mm, wall={r['wall_s']:.2f}s, safety={r['safety_passed']}")
lines+=['','组合诊断的慢实现保留中止前缀，完整试验使用等价负间隙见证筛选：36个实际轨迹状态的见证标识、值、梯度逐位一致，并对原已执行前缀另作逐关节状态核查。该优化减少距离计算，不删除原地图或改变执行安全门。',
'完整复现：原来3043次求解实际使用旧延迟文件2106项及其末尾937次重复。本轮按原执行规则重建完整有效序列，15001个关节状态逐元素一致，新回放补尾0次。按周期映射后再次逐状态一致。','延迟不是唯一解释：关闭旧策略计算延迟也没有到达。','见证切换确实存在：137个全图刷新检查点中11个遗漏更差见证超过0.2mm，最大2.3929mm。取消缓存对照的完整结果列在上表，不能仅凭这些统计断言它是唯一根因。','2561次有见证决策中，2498次预测改善；其中637次实际下一步的线性改善没有兑现，622次同见证非线性重算没有改善。不同指标有重叠，不能相加当作因果贡献比例。','两个失败末态的静态重算均有原安全门接受的非零速度，全图刷新后的单步裕度分别改善约0.3874mm和0.1451mm。不能把失败解释为末态完全无可行动作。','','各冻结组及补充组：']
for k,c in cohorts.items():
 if k=='diagnostics':continue
 lines.append(f"{k}: 到达 {c['arrivals']}/{c['runs']}，经独立审计到达 {c['validated_arrivals']}/{c['runs']}")
 for n in c['names']:
  r=lookup[n];lines.append(f"  {n}: {r['status']}, {r['sim_s']:.2f}s, error={r['error_mm']:.6f}mm, safety={r['safety_passed']}, memory={r['memory_passed']}, tail={r['latency_tail_uses']}")
lines+=['','实现与被否定的设计：','v1：实际阶段验收、非线性预测核验、延迟命令状态有效区。把宏观进展阈值用于很短的模型更新导致过度保守，失败保留。','v2/v3：把模型一致性和实际阶段验收分开，增加目标入口方向上的退让与两维姿态准备。远距离外推及逐步外推均未修复原失败，部分运行末端远离目标约1.5m，方案不采用。','v4：改为当前进入阻塞对应的二维切向动作，每一段实际执行后验收。原始起点固定时序仍失败，旧成功案例回归出现失败。','v5：执行瞬间重算同见证非线性进展，缩放或制动后重算。固定时序仍失败；一条自然延迟到达不能替代重复稳定性证据。执行门额外耗时单独记录，未声称整环硬实时。','v6：保持跨阶段最高已达到的准备裕度，不把局部回补计为新能力，持续运输绕行方向直到新进展、停滞、局部绕回或预算边界。它保留了记账不下降，但这本身不保证物理状态持续接近可进入区域。最新版本回归结果单独列出。','','最重要的数学限制：','构造进入可行性指标m(q)，不等于构造了能把状态送进其可行域的控制律。单步预测、局部真实改善、最好值记账单调，都不能替代闭环可达性证明。','v4固定失败中14次接受的阶段改善，有11次未超过此前最好裕度；v5对应为24次中的21次。记录表明局部回补可反复发生而不累积成新的进入能力。','相同原始起点、终态和固定进入反馈存在自然延迟成功执行，不能说该反馈族结构上绝对不可达；但也不能据少数成功断言准备策略可靠。','缓存/延迟诊断是算法干预，不等同于对所有物理原因完成定量归因；对照结果与剩余不确定性必须一起解释。','','证据与限制：','所有成功、失败、运行预算耗尽均保留。重复固定时序不是独立统计样本；自然延迟受计算环境影响，不能把不同版本的单次耗时直接当作算法速度排名。','继承的防回退半空间从续跑第0周期独立审计，没有为成功删约束。输入场景、地图及485个前轮受保护文件无变化。','地图冻结、运动学反馈，无实体机或动态接触验证；没有持续扩展感知地图。','源码与全部实际闭环轨迹在sources_and_trajectories.zip。所有逐请求见证诊断在另一个raw_decision_traces.zip，服务器原文件和逐文件哈希同时保留。']
(OUT/'FINAL_REPORT.txt').write_text('\n'.join(lines),encoding='utf-8')
for n in ['DERIVATION_AND_CAUSAL_SCOPE.txt','EXACT_REPRODUCTION.json','DELAY_PROVENANCE.json','FAILURE_DECOMPOSITION.json','LINEAR_DELAY_ATTRIBUTION.json','STATIC_FAILURE_PROBES.json','PROGRESS_LEDGER_DIAGNOSIS.json','INTEGRITY_AND_REPEAT.json','FINAL_FREEZE.json','EXECUTION_PROGRESS_FREEZE.json','PERSISTENT_PROGRESS_FREEZE.json','PERSISTENT_REGRESSION_FREEZE.json','UNCACHED_FREEZE.json','COMBINED_DIAGNOSTIC_FREEZE.json','EXACT_COMBINED_FREEZE.json']:
 if (R/n).exists():shutil.copy2(R/n,OUT/n)
for n in ['EXACT_PRUNING_EQUIVALENCE.json','COMBINED_PREFIX_REPLAY.json']:
 if (R/n).exists():shutil.copy2(R/n,OUT/n)
fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
def curve(ax,name,label,style='-'):
 z=np.load(R/'trials'/name/'trajectory.npz');ax.plot(np.arange(1,len(z['goal_error'])+1)*.02,z['goal_error']*1000,style,lw=1.3,label=label)
for n,l,s in [('exact_failure_trace','Original failure','--'),('old_zero_delay','No delay','-'),('old_full_refresh_cycle','Full refresh','-'),('old_full_refresh_zero_delay_exact','Full refresh + no delay','-')]:curve(axes[0,0],n,l,s)
for n,l in [('final_original_cycle_1','Stage acceptance + local bypass'),('progress_original_cycle_v5','Application-time acceptance'),('progress_original_cycle_v6','Persistent readiness ledger')]:curve(axes[0,1],n,l)
for ax,title in [(axes[0,0],'Controlled failure diagnostics'),(axes[0,1],'Same complete failed timing schedule')]:
 ax.set_yscale('log');ax.axhline(1,color='.5',ls=':');ax.set_xlabel('Simulated time (s)');ax.set_ylabel('Goal error (mm)');ax.set_title(title);ax.legend(fontsize=7);ax.grid(alpha=.2)
vals=[6,cohorts['frozen_v4_regression']['validated_arrivals'],cohorts['persistent_v6_regression']['validated_arrivals']];axes[1,0].bar(['Previous record','v4 regression','v6 regression'],vals,color=['.55','#c17a32','#4777a0']);axes[1,0].set_ylim(0,6.8);axes[1,0].set_ylabel('Audited arrivals / 6 cases');axes[1,0].set_title('All six previously successful cases')
for i,v in enumerate(vals):axes[1,0].text(i,v+.12,str(v)+'/6',ha='center')
p=read(R/'trials/progress_original_cycle_v6/result.json')['policy_summary'];check=p.get('persistent_bypass_checkpoints',[])
if check:
 t=np.array([x['cycle'] for x in check])*.02;axes[1,1].plot(t,[x['margin']*1000 for x in check],label='Actual refreshed sampled margin');axes[1,1].plot(t,[x['frontier_before']*1000 for x in check],'--',label='Best readiness ledger')
axes[1,1].set_title('Ledger progress is not physical progress');axes[1,1].set_xlabel('Simulated time (s)');axes[1,1].set_ylabel('Sampled continuation margin (mm)');axes[1,1].legend(fontsize=7);axes[1,1].grid(alpha=.2)
fig.savefig(OUT/'comparison.png',dpi=160);plt.close(fig)
(OUT/'REPRODUCE.txt').write_text(f'''Remote root: {R}
Python: /home/hsjed/envs/ur5cab/bin/python
Use NEW run folders; never overwrite archived runs.
Main v4 worker: pilot_worker_progress.py, policy_version=progress_bypass.
v5 worker: pilot_worker_execution_progress.py, policy_version=progress_execution.
v6 worker: pilot_worker_persistent_progress.py, policy_version=progress_persistent.
Diagnostic worker: pilot_worker_diagnostic.py, policy_version=diagnostic_uncached.
Use the frozen job files and their recorded delay inputs.
Environment: PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
Run: python WORKER trials/NEW_RUN
Audit: python audit_progress_batch.py NEW_RUN
Large maps, robot assets and native dependencies remain at INPUTS.json paths.
This source/results archive is not standalone and is not a hardware package.
''')
raw_files=list((R/'trials').glob('*/decision_trace.npz'));raw_manifest={};raw_zip=OUT/'raw_decision_traces.zip'
with zipfile.ZipFile(raw_zip,'w',zipfile.ZIP_STORED) as z:
 for p in sorted(raw_files):
  rel=str(p.relative_to(R));z.write(p,rel);raw_manifest[rel]=dict(bytes=p.stat().st_size,sha256=sha(p))
(OUT/'RAW_TRACE_MANIFEST.json').write_text(json.dumps(dict(archive_path=str(raw_zip),archive_sha256=sha(raw_zip),archive_bytes=raw_zip.stat().st_size,files=raw_manifest),indent=2))
files=list(R.glob('*.py'))+list(R.glob('*.json'))+list(R.glob('*.txt'))+list(R.glob('*.npy'))+list((R/'revisions').rglob('*'))
files += [p for p in (R/'trials').rglob('*') if p.name!='decision_trace.npz']+[R/'trials/exact_failure_trace/decision_trace.npz']
files += [p for p in (R/'code').rglob('*') if p.suffix in ['.py','.json','.cpp','.h','.hpp','.xml','.txt','.sh']]
files += [p for p in OUT.iterdir() if p.suffix!='.zip' and p.name!='BUNDLE_MANIFEST.json']
manifest={};archive=OUT/'sources_and_trajectories.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(files)):
  if p.is_file() and '__pycache__' not in p.parts:
   rel=str(p.relative_to(R));z.write(p,rel);manifest[rel]=dict(bytes=p.stat().st_size,sha256=sha(p))
(OUT/'BUNDLE_MANIFEST.json').write_text(json.dumps(dict(archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,files=manifest),indent=2))
print(json.dumps(dict(counts=summary['counts'],cohorts={k:{x:v for x,v in c.items() if x!='names'} for k,c in cohorts.items()},archive_bytes=archive.stat().st_size,raw_trace_bytes=raw_zip.stat().st_size),ensure_ascii=False))
