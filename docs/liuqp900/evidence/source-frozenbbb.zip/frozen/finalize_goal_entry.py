from pathlib import Path
import json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
for batch in ['entry_final_jobs.json','integration_jobs.json']:
    jobs=json.loads((ROOT/batch).read_text())
    assert all((ROOT/'trials'/j['name']/'result.json').exists() for j in jobs),batch
subprocess.run([sys.executable,str(ROOT/'audit_entry_batch.py'),'entry*','online_activation_reset*','failed_latency*'],check=True)
missing=[p.parent.name for p in (ROOT/'trials').glob('*/result.json') if not (p.parent/'audit.json').exists() or not (p.parent/'memory_audit.json').exists()]
assert not missing,missing
subprocess.run([sys.executable,str(ROOT/'export_goal_entry.py')],check=True)
