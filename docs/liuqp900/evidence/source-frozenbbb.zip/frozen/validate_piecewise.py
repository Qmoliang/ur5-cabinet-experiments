import os,json
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy_v2 import LowDimPolicy
from reserve_objective_contract import solve_reserve as augmented
from piecewise_reserve import solve_reserve as eliminated
old=ROOT.parent/'liuqp_release_study_20261106'
states=[('initial',None),('real_stall',np.load(ROOT.parent/'liuqp_lowdim_pilot_20261106/confirm_original_shelf_t2_baseline_300s_final_snapshot.npz')['q']),('old_near_trap',np.load(old/'trials/release_only_v2_from_stall/trajectory.npz')['q'][-1]),('new_numeric_stall',np.load(ROOT/'trials/entry_only_stall/trajectory.npz')['q'][-1])]
out=[]
for name,q in states:
    ctx=build('iris_4shelves_t2',start=q);c=ctx.controller;c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
    p=LowDimPolicy(ctx,dict(method='release',operating_gate=False),lambda **kw:None);p.observe(0,ctx.q0,np.zeros(6));s=c.pilot_nominal;H,g,A,l,u=c.last_qp_arrays;HH,gg=p._terms(c,s)
    args=(H+HH,g+gg,A,l,u,p.q,p.previous,p.low,p.high,c.task_weight,p.error,c.dt,p.acceleration)
    a=augmented(*args);b=eliminated(*args);assert b is not None
    record=dict(state=name,augmented_solved=a is not None,eliminated_solved=True,stationarity=b['convex_stationarity'],region_iterations=b['region_iterations'],velocity=b['velocity'].tolist(),comparison_difference=None if a is None else float(np.max(np.abs(a['velocity']-b['velocity']))))
    if a is not None:assert record['comparison_difference']<1e-4
    answer=p._solve(c,s,c.last_qp_arrays);assert answer is not None;record['forward_certified']=True;admission=p._admit(c,c.last_qp_arrays,answer);record['safe_scale']=None if admission is None else admission[1]
    out.append(record);print(json.dumps(record),flush=True)
(ROOT/'PIECEWISE_VALIDATION.json').write_text(json.dumps(out,indent=2))
