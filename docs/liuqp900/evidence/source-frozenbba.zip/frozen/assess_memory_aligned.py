from pathlib import Path
import json,numpy as np,hashlib
R=Path(__file__).resolve().parent;records=[]
for j in json.loads((R/'memory_aligned_jobs.json').read_text()):
 f=R/'trials'/j['name']
 if not (f/'result.json').exists():continue
 r=json.loads((f/'result.json').read_text());p=r['policy_summary'];z=dict(np.load(f/'trajectory.npz'));q=z['q'];m=z['control_mode'];prepare=np.flatnonzero(m=='CERT_PREP');enter=np.flatnonzero(m=='CERT_ENTER');qg=np.array(p['goal_port']['goal_q']);res=[]
 for k in enter:
  d=qg-q[k];v=z['velocity'][k];a=float(d@v/max(d@d,1e-30));res.append(float(np.linalg.norm(v-a*d)))
 events=[json.loads(x) for x in (f/'events.jsonl').read_text().splitlines()];activation=next((e['cycle'] for e in events if e['event']=='actual_stall_activates_continuation_certificate'),0)
 first=None if not len(enter) else int(enter[0]);end=len(z['goal_error']) if first is None else first
 records.append(dict(name=f.name,status=r['status'],sim_s=r['sim_s'],error_mm=r['final_error_mm'],activation_s=activation*.02,error_at_activation_mm=float(z['goal_error'][activation]*1000),peak_preparation_error_mm=float(np.max(z['goal_error'][activation:max(activation+1,end)])*1000),first_executed_entry_s=None if first is None else first*.02,preparation_joint_change_rad=(q[end]-q[activation]).tolist(),memory_certificate_refinements=p.get('memory_certificate_refinements',0),goal_plane_count=p['goal_side_planes'],minimum_terminal_plane_slack_m=p['minimum_terminal_support_slack_m'],actual_progress_checks=len(p['goal_plane_actual_progress']),rejected_actual_stages=p['goal_plane_rejected_stages'],entry_ray_residual_rad_s=max(res,default=None),memory_count=p['memory_count'],latency_tail_uses=r['latency_trace_tail_uses'],controller_p99_ms=r['controller_ms_p99']))
repeat={}
base=R/'trials/memory_aligned_final_cycle_1/trajectory.npz'
if base.exists():
 a=np.load(base)['q']
 for i in [2,3]:
  path=R/'trials'/('memory_aligned_final_cycle_'+str(i))/'trajectory.npz'
  if path.exists():
   b=np.load(path)['q'];repeat[str(i)]=dict(same_shape=a.shape==b.shape,max_joint_difference=float(np.max(np.abs(a-b))) if a.shape==b.shape else None)
(R/'MEMORY_ALIGNED_EVIDENCE.json').write_text(json.dumps(dict(records=records,repeats=repeat),indent=2));print(json.dumps(dict(records=records,repeats=repeat),indent=2))
