#!/bin/bash
# Online no-object check of the no-return free-space carving (UR5_NO_RETURN_FREE=1):
# drawer (geodesic, as in E4) / 20 cm cage / 24 cm cage / IRIS shelf (straight), far start, seeds 1-3.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
O=$PWD/map_check
export UR5_NO_RETURN_FREE=1
run() { local scene=$1 seed=$2 cpu=$3; [ -f $O/${scene}_s$seed/case.json ] && return
  if [ $scene = drawer ]; then E4_GEODESIC=1 E4_SCENE=$scene ./e4_map.sh $O/${scene}_s$seed $seed $cpu combined 0 0.0
  else E4_SCENE=$scene ./e4_map.sh $O/${scene}_s$seed $seed $cpu combined 0 0.0; fi; }
i=0; for seed in 1 2 3; do for scene in cage shelf; do run $scene $seed $((i*16)) & i=$((i+1)); done; done; wait
i=0; for seed in 1 2 3; do for scene in drawer cage_wide; do run $scene $seed $((i*16)) & i=$((i+1)); done; done; wait
echo DONE > $O.done
