"""Offline checks for geodesic attraction and per-link planes on the known cabinet."""
import sys
import time
from pathlib import Path

import numpy as np

KNOWN = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
sys.path[:0] = [str(KNOWN / "src"), str(KNOWN / "src" / "core"), str(KNOWN), str(KNOWN.parent / "online_v6")]

import mujoco  # noqa: E402
from ball_tree import NativeBallTree  # noqa: E402
from controller import ProtocolLiuQPController  # noqa: E402
from geodesic import GeodesicAttractor  # noqa: E402
from known_volume import build_volume_cover  # noqa: E402
from link_regions import LinkRegionLiuQPController, closest_points_on_ellipsoid  # noqa: E402
from robot import build_model, build_robot_certificate, certificate_world_state, set_configuration  # noqa: E402
from run import MVT_OUTWARD_PADDING, NEAR_DISTANCE, SAFETY_MARGIN, load_scene  # noqa: E402

scene = load_scene()
target = np.asarray(scene.waypoints[-1], dtype=float)
cover = build_volume_cover(scene.boxes, "ellipsoid", 0.075)

# 1. Geodesic attraction: follow the commands as a free point.
t = time.perf_counter()
attractor = GeodesicAttractor(cover.centers, target, "ellipsoid", shapes=cover.ellipsoid_shapes)
print(f"geodesic field built in {time.perf_counter() - t:.1f} s; reachable cells {attractor.reachable_cells}")
for name, run in (("trapped seed 2", "e0/ellipsoid_075mm_seed02"), ("easy seed 1", "e0/ellipsoid_075mm_seed01")):
    ee = np.load(RUNS / run / "ee_history.npy")
    for label, start in (("start", ee[0]), ("final", ee[-1])):
        p = start.copy()
        for step in range(3000):
            command = attractor.command(p)
            direction = command - p
            distance = np.linalg.norm(direction)
            if np.linalg.norm(p - target) < 1e-3 or distance < 1e-9:
                break
            p = p + direction / distance * min(0.004, distance)
        first = attractor.command(start) - start
        print(f"  {name} from {label} {np.round(start, 3)}: first direction {np.round(first / np.linalg.norm(first), 2)}, "
              f"point reaches target: {np.linalg.norm(p - target) < 1e-3} after {step} steps")

# 2. Per-link planes vs LiuQP's per-sphere planes at recorded states.
model = build_model(scene)
data = mujoco.MjData(model)
robot = build_robot_certificate(model)
radii = np.array([s.radius for s in robot])
padding = NEAR_DISTANCE + SAFETY_MARGIN + MVT_OUTWARD_PADDING
common = dict(model=model, data=data, scene=scene, robot_spheres=robot, obstacle_centers=cover.centers,
              representation="ellipsoid", obstacle_offsets=np.zeros(len(cover.centers)), proxy_ids=cover.proxy_ids,
              safety_margin=SAFETY_MARGIN, near_distance=NEAR_DISTANCE, contact_distance=0.0,
              obstacle_index=NativeBallTree(cover.centers, cover.aabb_half_extents + MVT_OUTWARD_PADDING, query_padding=padding),
              redundant_plane_pruning=True, ellipsoid_pair_threads=8, ellipsoid_pair_affinity_mask=0)
per_sphere = ProtocolLiuQPController(**common, obstacle_shapes=cover.ellipsoid_shapes)
per_sphere.native_exact_pair_batch = False
shared = LinkRegionLiuQPController(**common, obstacle_shapes=cover.ellipsoid_shapes)
print(f"capsule groups: {len(shared.capsule_groups)} covering {sum(len(g) for g in shared.capsule_groups)} spheres; "
      f"box spheres kept per-sphere: {len(shared.box_spheres)}")
q_history = np.load(RUNS / "e0/ellipsoid_075mm_seed01/q_history.npy")
worst_overstatement = -np.inf
for step_index, q in enumerate(q_history[::150]):
    set_configuration(model, data, q)
    positions, jacobians, _ = certificate_world_state(model, data, robot)
    shared.shared_plane_solves = 0
    shared._build_shared_planes(positions, radii)
    lower, upper = shared.joint_velocity_bounds()
    limits = np.maximum(np.abs(lower), np.abs(upper))
    shared._reach_per_step = (np.linalg.norm(jacobians[:, :, : shared.nv], axis=1) @ limits) * shared.dt
    shared.dropped_inactive_rows = 0
    rows_shared = rows_sphere = solves_sphere = rows_sphere_bound = 0
    for i, (p, r) in enumerate(zip(positions, radii)):
        planes_s, _, _, _, _ = per_sphere.active_planes_for_robot_sphere(i, p, float(r))
        rows_sphere += len(planes_s)
        solves_sphere += len(planes_s)
        rows_sphere_bound += sum(shared._row_can_bind(i, plane.clearance) for plane in planes_s)
        planes_l, _, _, _, _ = shared.active_planes_for_robot_sphere(i, p, float(r))
        rows_shared += len(planes_l)
        # Safety: a shared plane's clearance must not exceed the true clearance.
        for plane in planes_l:
            k = plane.obstacle_index
            _, true_distance = closest_points_on_ellipsoid(p[None, :], cover.centers[k],
                                                           shared.obstacle_rotations[k],
                                                           np.sqrt(shared.obstacle_eigenvalues[k]))
            true_clearance = true_distance[0] - r - SAFETY_MARGIN
            worst_overstatement = max(worst_overstatement, plane.clearance - true_clearance)
    print(f"  t={step_index * 150 * 0.02:4.0f}s: per-sphere: exact solves {solves_sphere}, rows {rows_sphere} "
          f"({rows_sphere_bound} after speed bound) | per-link: solves {shared.shared_plane_solves}, "
          f"rows {rows_shared} (after speed bound; {shared.dropped_inactive_rows} dropped)")
print(f"worst amount a shared plane overstated clearance: {worst_overstatement * 1000:.4f} mm (must be <= 0)")
