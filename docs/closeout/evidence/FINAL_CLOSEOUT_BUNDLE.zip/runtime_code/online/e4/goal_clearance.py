"""Experiment A: best goal-pose clearance (beyond LiuQP's 6 mm margin; >= 0 means a valid goal pose
exists) for each swept target, spheres and ellipsoids.  One scene per call (run in parallel)."""
import json
import sys

name = sys.argv[1]
sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/goal_search.py").read().split("if __name__")[0])
p = json.load(open(f"/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/assets/scenes/{name}.json"))
out = {"scene": name, "target": p["waypoints"][-1]}
for rep in ("ellipsoid", "sphere"):
    best, _q = search(p, rep, attempts=200, seed=1)
    out[rep + "_mm"] = round(1000 * float(best), 1)
print(json.dumps(out), flush=True)
