from pathlib import Path
import os,signal,json,time,hashlib
R=Path(__file__).resolve().parent;folder=R/'trials/old_full_refresh_zero_delay';selected=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:args=(p/'cmdline').read_bytes().decode().split('\0');cwd=(p/'cwd').resolve()
 except (OSError,UnicodeDecodeError):continue
 if cwd!=R:continue
 if 'launch_uncached.py' in args and 'combined_diagnostic_jobs.json' in args:selected.append((int(p.name),'launcher'))
 if str(R/'pilot_worker_diagnostic.py') in args and str(folder) in args:selected.append((int(p.name),'worker'))
(folder/'DIAGNOSTIC_INTERRUPTION.json').write_text(json.dumps(dict(reason='computational replacement by exact negative-witness pruning after 36 bitwise-equal field/gradient checks; prefix retained and must be compared against accelerated full rerun; not a completed 300s trial',time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())),indent=2))
for pid,kind in sorted(selected,key=lambda x:x[1]):os.kill(pid,signal.SIGTERM if kind=='launcher' else signal.SIGINT);print(pid,kind)
s=(R/'pilot_worker_diagnostic.py').read_text().replace("        if job.get('policy_version')=='diagnostic_uncached':","        if job.get('policy_version')=='diagnostic_exact_pruned':\n            from diagnostic_exact_pruned_policy import LowDimPolicy\n        elif job.get('policy_version')=='diagnostic_uncached':");(R/'pilot_worker_exact_diagnostic.py').write_text(s)
s=(R/'launch_uncached.py').read_text().replace("ROOT/'pilot_worker_diagnostic.py'","ROOT/'pilot_worker_exact_diagnostic.py'");(R/'launch_exact_diagnostic.py').write_text(s)
j=json.loads((R/'combined_diagnostic_jobs.json').read_text())[0];j.update(name='old_full_refresh_zero_delay_exact',policy_version='diagnostic_exact_pruned')
(R/'exact_combined_jobs.json').write_text(json.dumps([j],indent=2));(R/'EXACT_COMBINED_FREEZE.json').write_text(json.dumps(dict(job=j,scope='same no-cache no-delay diagnostic with exact negative-witness selection optimization; full old prefix must be replayed',equivalence=json.loads((R/'EXACT_PRUNING_EQUIVALENCE.json').read_text()),sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['diagnostic_exact_pruned_policy.py','pilot_worker_exact_diagnostic.py']}),indent=2))
