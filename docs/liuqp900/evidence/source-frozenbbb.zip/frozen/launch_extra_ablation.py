from pathlib import Path
import os,json,hashlib,subprocess
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_lowdim_pilot_20261106'
name='release_only_from_real_stall';folder=ROOT/'trials'/name;folder.mkdir(parents=True,exist_ok=False)
job=dict(task='iris_4shelves_t2',method='release_only',policy_version='reserve',representation='ellipsoid',solver_profile='verified_common',start_snapshot=str(OLD/'confirm_original_shelf_t2_baseline_300s_final_snapshot.npz'),max_cycles=15000,stop_after_stall=False,wall_limit_s=900,cpus=[56,57,58,59])
(folder/'job.json').write_text(json.dumps(job,indent=2));manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')};(folder/'source_hashes.json').write_text(json.dumps(manifest,indent=2))
(ROOT/'EXTRA_ABLATION_FREEZE.json').write_text(json.dumps(dict(name=name,job=job,source_manifest=manifest,purpose='same actual stalled state: isolate targeted release with versus without reserve-consumption cost; no path input'),indent=2))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='2',MKL_NUM_THREADS='1',LD_PRELOAD='/usr/lib/x86_64-linux-gnu/libstdc++.so.6',MUJOCO_GL='egl')
with (folder/'worker.log').open('w') as log:
    try:code=subprocess.run(['/home/hsjed/envs/ur5cab/bin/python','-u',str(ROOT/'pilot_worker.py'),str(folder)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1020).returncode
    except subprocess.TimeoutExpired:code='timeout'
print(json.dumps(dict(name=name,exit_code=code,result_exists=(folder/'result.json').exists())))
