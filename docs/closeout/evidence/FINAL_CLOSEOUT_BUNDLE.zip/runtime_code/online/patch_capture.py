"""Camera capture: fixed-camera dedup before point/uncertainty construction, cameras in parallel.

UR5MountedDepthCamera(static_dedup=True) drops a fixed camera's pixels whose
depth equals the last depth sent for that pixel right after the range test,
so their points and uncertainty shapes are never built (the same rule as
PerceptionWorker._new_static_pixels, which then has nothing left to drop).
UR5_PARALLEL_CAPTURE=1 (default) gives each camera its own camera object and
captures them in threads; observations keep the configured camera order.
"""
from pathlib import Path

root = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")


def sub(path, old, new):
    s = path.read_text()
    assert s.count(old) == 1, (path.name, old[:70])
    path.write_text(s.replace(old, new))


cam = root / "depth_camera_perception.py"
sub(cam, """        native_raycast: bool = True,
""", """        native_raycast: bool = True,
        static_dedup: bool = False,
""")
sub(cam, """        self.minimum_range = float(minimum_range)
""", """        self.minimum_range = float(minimum_range)
        self.static_dedup = bool(static_dedup)
        self._static_sent: dict = {}
""")
sub(cam, """            geom_ids = geom_ids[keep]
""", """            geom_ids = geom_ids[keep]
            if self.static_dedup and name.startswith("static_"):
                # A fixed, noise-free camera repeats an observation exactly
                # when a pixel's depth is unchanged; skip it before building
                # its point and uncertainty shape.
                pixels = flat_v * self.width + flat_u
                sent = self._static_sent.setdefault(name, np.full(self.width * self.height, np.nan))
                changed = ~(sent[pixels] == optical_depths)
                sent[pixels[changed]] = optical_depths[changed]
                flat_u = flat_u[changed]
                flat_v = flat_v[changed]
                optical_depths = optical_depths[changed]
                local_directions = local_directions[changed]
                geom_ids = geom_ids[changed]
""")

run = root / "run_protocol_v3_async_online.py"
sub(run, """        self.camera = UR5MountedDepthCamera(
            self.model,
            camera_names=self.camera_names,
            width=self.camera_width,
            height=self.camera_height,
            pixel_stride=self.camera_pixel_stride,
            minimum_range=CAMERA_MINIMUM_RANGE,
            optical_depth_error_bound=0.003,
            occluding_self_filter=True,
        )
""", """        camera_kwargs = dict(
            width=self.camera_width,
            height=self.camera_height,
            pixel_stride=self.camera_pixel_stride,
            minimum_range=CAMERA_MINIMUM_RANGE,
            optical_depth_error_bound=0.003,
            occluding_self_filter=True,
            static_dedup=os.environ.get("UR5_STATIC_DEDUP", "1") == "1",
        )
        self.camera = UR5MountedDepthCamera(
            self.model, camera_names=self.camera_names, **camera_kwargs
        )
        # One camera object per camera, captured in parallel threads (the
        # native ray casts release the GIL); same observations, same order.
        self._camera_pool = None
        if os.environ.get("UR5_PARALLEL_CAPTURE", "1") == "1" and len(self.camera_names) > 1:
            self.camera.close()
            self._single_cameras = [
                UR5MountedDepthCamera(self.model, camera_names=(name,), **camera_kwargs)
                for name in self.camera_names
            ]
            self._camera_pool = ThreadPoolExecutor(
                max_workers=len(self._single_cameras), thread_name_prefix="capture")
""")
sub(run, """        observations = self.camera.capture(self.data)
        if os.environ.get("UR5_STATIC_DEDUP", "1") == "1":
            observations = [self._new_static_pixels(o) for o in observations]
""", """        if self._camera_pool is not None:
            observations = [
                o for part in self._camera_pool.map(lambda c: c.capture(self.data), self._single_cameras)
                for o in part
            ]
        else:
            observations = self.camera.capture(self.data)
        if os.environ.get("UR5_STATIC_DEDUP", "1") == "1":
            observations = [self._new_static_pixels(o) for o in observations]
""")
print("patched")
