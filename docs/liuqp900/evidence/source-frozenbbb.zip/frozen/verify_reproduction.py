from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent;O=R.parent/'liuqp_entry_certificate_20261107'
f=R/'trials/exact_failure_trace';a=np.load(f/'trajectory.npz');b=np.load(O/'trials/certified_original_start/trajectory.npz');d=np.load(f/'decision_trace.npz');res=json.loads((f/'result.json').read_text());delta=float(np.max(np.abs(a['q']-b['q'])))
assert a['q'].shape==b['q'].shape and delta==0 and res['latency_trace_tail_uses']==0
cycle=np.empty(len(a['velocity']),dtype=np.int64)
for i,k in enumerate(d['cycles']):cycle[k:(d['cycles'][i+1] if i+1<len(d['cycles']) else len(cycle))]=d['ticks'][i]
np.save(R/'FAILURE_CYCLE_DELAY.npy',cycle)
out=dict(q_states=len(a['q']),maximum_q_difference=delta,controller_calls=len(d['cycles']),complete_effective_tape=True,new_tail_uses=0,cycle_schedule='Piecewise-constant in simulated cycle: a changed controller receives the delay of the latest original request at that cycle. This is a declared exogenous diagnostic, not its measured compute time.')
(R/'EXACT_REPRODUCTION.json').write_text(json.dumps(out,indent=2))
j=json.loads((R/'reproduction_jobs.json').read_text())[0];j.pop('latency_ticks_file');j.pop('strict_latency_trace');j['wall_limit_s']=1200
jobs=[dict(j,name='old_zero_delay',compute_delay=False),dict(j,name='old_cycle_schedule',latency_cycle_file=str(R/'FAILURE_CYCLE_DELAY.npy'))]
(R/'diagnostic_jobs.json').write_text(json.dumps(jobs,indent=2));print(json.dumps(out))
