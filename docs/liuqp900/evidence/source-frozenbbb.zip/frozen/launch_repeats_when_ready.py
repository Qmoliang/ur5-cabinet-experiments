from pathlib import Path
import time,subprocess
ROOT=Path(__file__).resolve().parent
while not ((ROOT/'trials/retained_blocker_gate/result.json').exists() and (ROOT/'trials/retained_blocker_from_stall/audit.json').exists()):time.sleep(15)
print('Prior control and priority audit finished; launching frozen repeats.',flush=True)
subprocess.run(['/home/hsjed/envs/ur5cab/bin/python','-u',str(ROOT/'launch_batch.py'),str(ROOT/'retained_repeats.json')],check=True)
