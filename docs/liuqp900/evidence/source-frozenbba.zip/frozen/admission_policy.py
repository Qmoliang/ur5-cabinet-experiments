"""Old v4 policy with only its admission pipeline corrected."""
import numpy as np
from lowdim_policy_v4 import LowDimPolicy as Previous

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.admission_stats=dict(clipped=0,row_rejected=0,accepted_after_clipping=0)

    def _accept(self,v,delta,desired_eff,pose=False):
        raw=np.asarray(v).copy();lo,hi=self.ctx.controller.joint_velocity_bounds();bounded=np.clip(raw,lo,hi)
        changed=bool(np.any(raw!=bounded));self.admission_stats['clipped']+=int(changed)
        H,g,A,l,u=self.ctx.controller.last_qp_arrays
        violation=max(np.max(l-A@bounded),np.max(A@bounded-u),0.)
        if violation>1e-7:
            self.admission_stats['row_rejected']+=1;self.rejections['postclip_original_rows']+=1;return False
        accepted=super()._accept(bounded,delta,desired_eff,pose)
        if accepted:
            self.expected=raw
            self.admission_stats['accepted_after_clipping']+=int(changed)
        return accepted

    def summary(self):
        result=super().summary();result['admission_correction']=self.admission_stats;return result
