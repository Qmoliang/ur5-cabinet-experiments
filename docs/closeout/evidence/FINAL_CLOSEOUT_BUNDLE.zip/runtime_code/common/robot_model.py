from pathlib import Path
import numpy as np,mujoco
def planning_model(runtime_model):
 model=mujoco.MjModel.from_xml_path(str(Path(__file__).with_name("robot_only.xml")))
 for name in ["body_pos","body_quat","body_parentid","jnt_pos","jnt_axis","jnt_type","jnt_range","qpos0"]:
  a=np.asarray(getattr(model,name));b=np.asarray(getattr(runtime_model,name))
  if a.shape!=b.shape or not np.allclose(a,b,atol=1e-12,rtol=0):raise ValueError("robot kinematics differ from frozen planning model: "+name)
 if not np.allclose(model.site("attachment_site").pos,runtime_model.site("attachment_site").pos,atol=1e-12,rtol=0):raise ValueError("task site mismatch")
 assert not np.any(model.geom_bodyid==0)
 return model
