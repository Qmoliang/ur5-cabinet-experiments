"""known_v6/run.py: with UR5_SCENE_JSON, the MuJoCo model gets the scene's boxes."""
from pathlib import Path

p = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
s = p.read_text()
start = s.find("import robot as _robot_module")
if start >= 0:  # remove a previous, broken attempt
    end = s.index("_robot_module.build_xml = _scene_xml\n", start) + len("_robot_module.build_xml = _scene_xml\n")
    s = s[:start] + s[end:]

BLOCK = r'''import robot as _robot_module  # noqa: E402

if os.environ.get("UR5_SCENE_JSON"):
    import re as _re

    def _scene_xml(scene):
        """The drawer model with its cabinet geoms replaced by this scene's boxes."""
        xml = (ROOT / "assets" / "drawer.xml").read_text(encoding="utf-8")
        xml = _re.sub(r'\n\s*<geom name="(drawer_|cabinet_)[^"]*" type="box"[^>]*/>', "", xml)
        geoms = "".join(
            '\n    <geom name="{}" type="box" pos="{}" size="{}" material="shelf" contype="1" conaffinity="1" />'.format(
                b.name, " ".join(map(repr, b.center)), " ".join(map(repr, b.half_size)))
            for b in scene.boxes)
        marker = '<geom name="floor"'
        head, tail = xml.split(marker, 1)
        line_end = tail.index("/>") + 2
        return head + marker + tail[:line_end] + geoms + tail[line_end:]

    _robot_module.build_xml = _scene_xml
'''
anchor = "from voxel_index import NativeMultilevelMVT  # noqa: E402\n"
assert s.count(anchor) == 1
s = s.replace(anchor, anchor + BLOCK)
p.write_text(s)
print("patched")
