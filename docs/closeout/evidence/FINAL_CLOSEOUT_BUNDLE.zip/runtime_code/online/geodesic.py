"""Geodesic attraction for LiuQP.

LiuQP pulls the gripper straight at the target: v_g = K (p_goal - p).  That
straight line can point into an obstacle and leave the gripper stuck under it.
Here the pull instead follows the shortest *free* route to the target.

A voxel grid marks every cell within `inflation` of an obstacle proxy as
blocked; a breadth-first wavefront from the target gives each free cell its
route length to the target.  Such a distance field has no local minima for a
point: from any free cell, stepping to the lowest neighbour always reaches the
target if any route exists.  Each control cycle the gripper looks `lookahead`
metres down that route and LiuQP is given a target in that direction, at the
remaining route length, so LiuQP's speed law is unchanged.  LiuQP's constraints
and certificates are untouched; only the target it receives changes.
"""
from __future__ import annotations

import numpy as np
from scipy import ndimage

NEIGHBOURS = np.array([(i, j, k) for i in (-1, 0, 1) for j in (-1, 0, 1) for k in (-1, 0, 1)
                       if (i, j, k) != (0, 0, 0)])


def ellipsoid_local_frame(points, center, rotation, axes):
    """Distance from points to one ellipsoid given its rotation and semi-axes."""
    local = np.abs((points - center) @ rotation)
    a2 = axes * axes
    inside = np.sum(local * local / a2, axis=1) <= 1.0
    low = np.zeros(len(local))
    high = np.linalg.norm(local, axis=1) * axes.max() + 1e-12
    for _ in range(50):
        t = 0.5 * (low + high)
        value = np.sum(a2 * local * local / (a2 + t[:, None]) ** 2, axis=1) - 1.0
        low = np.where(value > 0.0, t, low)
        high = np.where(value > 0.0, high, t)
    closest = a2 * local / (a2 + high[:, None])
    return np.where(inside, -1.0, np.linalg.norm(local - closest, axis=1))


class GeodesicAttractor:
    def __init__(self, centers, target, representation, *, radii=None, shapes=None,
                 inflation: float = 0.03, voxel: float = 0.0075, lookahead: float = 0.08,
                 lower=(-0.10, -0.10, 0.25), upper=(0.95, 0.95, 1.15)):
        self.voxel = float(voxel)
        self.lookahead = float(lookahead)
        self.lower = np.asarray(lower, dtype=float)
        self.target = np.asarray(target, dtype=float)
        shape = np.ceil((np.asarray(upper) - self.lower) / self.voxel).astype(int)
        axes = [self.lower[i] + (np.arange(shape[i]) + 0.5) * self.voxel for i in range(3)]
        blocked = np.zeros(shape, dtype=bool)
        centers = np.asarray(centers, dtype=float)
        for index, center in enumerate(centers):
            if representation == "sphere":
                extent = np.full(3, radii[index] + inflation)
            else:
                values, vectors = np.linalg.eigh(shapes[index])
                semi = np.sqrt(np.maximum(values, 0.0))
                extent = np.sqrt(np.diag(shapes[index])) + inflation
            low = np.clip(np.floor((center - extent - self.lower) / self.voxel).astype(int), 0, shape - 1)
            high = np.clip(np.ceil((center + extent - self.lower) / self.voxel).astype(int) + 1, 0, shape)
            if np.any(high <= low):
                continue
            grid = np.stack(np.meshgrid(*[axes[i][low[i]:high[i]] for i in range(3)], indexing="ij"), axis=-1)
            points = grid.reshape(-1, 3)
            if representation == "sphere":
                distance = np.linalg.norm(points - center, axis=1) - radii[index]
            else:
                distance = ellipsoid_local_frame(points, center, vectors, semi)
            near = (distance <= inflation).reshape(grid.shape[:3])
            blocked[low[0]:high[0], low[1]:high[1], low[2]:high[2]] |= near
        self.blocked = blocked
        goal = self._cell(self.target)
        if goal is None or blocked[goal]:
            raise ValueError("the target cell is blocked at this inflation")
        # Breadth-first wavefront over free cells, 26-connected.
        distance = np.full(shape, np.iinfo(np.int32).max, dtype=np.int32)
        distance[goal] = 0
        frontier = np.zeros(shape, dtype=bool)
        frontier[goal] = True
        reached = frontier.copy()
        structure = np.ones((3, 3, 3), dtype=bool)
        step = 0
        while frontier.any():
            step += 1
            frontier = ndimage.binary_dilation(frontier, structure) & ~reached & ~blocked
            distance[frontier] = step
            reached |= frontier
        self.distance = distance
        self.unreachable = np.iinfo(np.int32).max
        self.reachable_cells = int(reached.sum())

    def _cell(self, point):
        index = np.floor((np.asarray(point) - self.lower) / self.voxel).astype(int)
        if np.any(index < 0) or np.any(index >= np.asarray(self.blocked.shape)):
            return None
        return tuple(int(i) for i in index)

    def _centre(self, cell):
        return self.lower + (np.asarray(cell) + 0.5) * self.voxel

    def _nearest_reachable(self, cell, radius: int = 8):
        """Closest reachable cell when the gripper sits in an inflated cell."""
        best, best_distance = None, np.inf
        for r in range(1, radius + 1):
            lo = np.maximum(np.asarray(cell) - r, 0)
            hi = np.minimum(np.asarray(cell) + r + 1, self.distance.shape)
            block = self.distance[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]]
            candidates = np.argwhere(block != self.unreachable)
            if len(candidates):
                cells = candidates + lo
                offsets = np.linalg.norm(cells - np.asarray(cell), axis=1)
                choice = int(np.argmin(offsets))
                if offsets[choice] < best_distance:
                    best, best_distance = tuple(int(i) for i in cells[choice]), offsets[choice]
                return best
        return None

    def command(self, gripper: np.ndarray) -> np.ndarray:
        """Target to hand LiuQP this cycle."""
        cell = self._cell(gripper)
        if cell is None:
            return self.target
        if self.distance[cell] == self.unreachable:
            cell = self._nearest_reachable(cell)
            if cell is None:
                return self.target
        route = float(self.distance[cell]) * self.voxel
        if route <= self.lookahead:
            return self.target
        # Walk down the wavefront until `lookahead` metres of route are covered.
        current = np.asarray(cell)
        walked = 0.0
        shape = np.asarray(self.distance.shape)
        while walked < self.lookahead and self.distance[tuple(current)] > 0:
            neighbours = current + NEIGHBOURS
            valid = np.all((neighbours >= 0) & (neighbours < shape), axis=1)
            neighbours = neighbours[valid]
            values = self.distance[tuple(neighbours.T)]
            best = values.min()
            if best >= self.distance[tuple(current)]:
                break
            options = neighbours[values == best]
            # Among equal steps prefer the one closest to the target.
            centres = self.lower + (options + 0.5) * self.voxel
            choice = options[int(np.argmin(np.linalg.norm(centres - self.target, axis=1)))]
            walked += self.voxel * float(np.linalg.norm(choice - current))
            current = choice
        direction = self._centre(current) - np.asarray(gripper)
        length = np.linalg.norm(direction)
        if length < 1e-9:
            return self.target
        return np.asarray(gripper) + direction / length * max(route, length)
