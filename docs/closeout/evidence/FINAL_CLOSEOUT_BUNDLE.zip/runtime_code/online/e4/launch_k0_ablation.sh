#!/bin/bash
# Which E4 change hurts the no-object online drawer?  Same seeds, one change at a time:
#   orig     the earlier best live configuration (low_side cameras), no E4
#   accel    + joint acceleration limit 10 rad/s^2
#   top      + overview camera (low_side_top)
#   e4noconf full E4 pipeline (top camera, detector, accel, dynamic rows) without the confirmation rule
#   e4       full E4 pipeline (the E4 k=0 runs)
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export UR5_CENTERVOX=0.005 UR5_STATIC_DEDUP=1 UR5_FIT_WORKERS=8 UR5_FRONTIER_MERGE=1 UR5_FRONTIER_FINE_RADIUS=0.15 UR5_FRONTIER_CELL_VOXELS=1
OUT=v6runs/e4_k0_ablation
jobs=()
for seed in 1 4 5 6 8 9 10 11 2 3; do
  for v in orig accel top e4noconf e4; do jobs+=("$v $seed"); done
done
run() {  # variant seed slot
  local v=$1 seed=$2 cpu=$(($3 * 16)) cams=low_side extra="" noconf=0
  case $v in
    accel) extra="--accel 10" ;;
    top) cams=low_side_top ;;
    e4noconf) cams=low_side_top; extra="--e4-controller combined --accel 10 --e4-seed $((seed + 100))"; noconf=1 ;;
    e4) cams=low_side_top; extra="--e4-controller combined --accel 10 --e4-seed $((seed + 100))" ;;
  esac
  local out=$OUT/$v/seed$(printf %02d $seed)
  mkdir -p $OUT/$v
  UR5_E4_NO_CONFIRM=$noconf systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID \
    -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_CENTERVOX -E UR5_FRONTIER_CELL_VOXELS \
    -E UR5_STATIC_DEDUP -E UR5_FIT_WORKERS -E UR5_FRONTIER_MERGE -E UR5_FRONTIER_FINE_RADIUS -E UR5_E4_NO_CONFIRM \
    timeout 2400 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py ellipsoid --map incremental \
    --timing paced --cpus $cpu:16 --start-seed $seed --frontier --geodesic --look --static-cameras $cams $extra \
    --out $out > $out.log 2>&1
  rm -f "$out"/A-CV-*/causal_*_snapshots.npz
}
for ((start = 0; start < ${#jobs[@]}; start += 7)); do
  for slot in 0 1 2 3 4 5 6; do
    index=$((start + slot)); [ $index -lt ${#jobs[@]} ] || break
    run ${jobs[$index]} $slot &
  done
  wait
done
echo DONE > $OUT.done
