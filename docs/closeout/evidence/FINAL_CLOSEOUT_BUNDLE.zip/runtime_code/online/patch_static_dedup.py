"""Fixed cameras: feed only pixels whose depth changed since that pixel was last sent.

A world-fixed, noise-free camera maps each (pixel, depth) to exactly one point
and one uncertainty shape, so a pixel with an unchanged depth repeats an
observation the map already holds.  Occupancy carving and the running-bound
certificates are unions over observations, so repeats add nothing; dropping
them leaves only the pixels the moving arm occludes or reveals.
UR5_STATIC_DEDUP=0 turns it off.
"""
from pathlib import Path

root = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")


def sub(path, old, new):
    s = path.read_text()
    assert s.count(old) == 1, (path.name, old[:70])
    path.write_text(s.replace(old, new))


cam = root / "depth_camera_perception.py"
sub(cam, """    endpoint_is_occupied: np.ndarray | None = None

""", """    endpoint_is_occupied: np.ndarray | None = None
    # Flat image index (v * width + u) of each sample, for per-pixel bookkeeping.
    pixel_index: np.ndarray | None = None

""")
sub(cam, """                    endpoint_is_occupied=np.asarray(endpoint_is_occupied, dtype=bool),
                )""", """                    endpoint_is_occupied=np.asarray(endpoint_is_occupied, dtype=bool),
                    pixel_index=np.asarray(flat_v * self.width + flat_u, dtype=np.int64),
                )""")

run = root / "run_protocol_v3_async_online.py"
sub(run, """        observations = self.camera.capture(self.data)
        capture_ms = (time.perf_counter() - capture_started) * 1000.0
""", """        observations = self.camera.capture(self.data)
        if os.environ.get("UR5_STATIC_DEDUP", "1") == "1":
            observations = [self._new_static_pixels(o) for o in observations]
        capture_ms = (time.perf_counter() - capture_started) * 1000.0
""")
sub(run, """    def process(
        self,
        q: np.ndarray,""", """    def _new_static_pixels(self, observation):
        \"\"\"A fixed camera's samples whose pixel depth differs from the last one sent.\"\"\"
        if not observation.camera_name.startswith("static_") or observation.pixel_index is None:
            return observation
        if not hasattr(self, "_static_sent"):
            self._static_sent = {}
        sent = self._static_sent.setdefault(
            observation.camera_name, np.full(self.camera_width * self.camera_height, np.nan))
        index = observation.pixel_index
        depth = np.asarray(observation.optical_depths, dtype=float)
        changed = ~(sent[index] == depth)
        sent[index[changed]] = depth[changed]
        from dataclasses import replace as _replace
        pick = lambda values: None if values is None else np.asarray(values)[changed]
        return _replace(
            observation, points=observation.points[changed], geom_ids=pick(observation.geom_ids),
            optical_depths=depth[changed], sample_radii=pick(observation.sample_radii),
            sample_uncertainty_shapes=pick(observation.sample_uncertainty_shapes),
            endpoint_is_occupied=pick(observation.endpoint_is_occupied), pixel_index=index[changed])

    def process(
        self,
        q: np.ndarray,""")
print("patched")
