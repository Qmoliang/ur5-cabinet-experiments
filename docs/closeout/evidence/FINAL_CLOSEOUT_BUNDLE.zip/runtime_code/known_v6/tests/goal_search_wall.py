import sys
sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/goal_search.py").read().split("if __name__")[0])
for top in (0.50, 0.60):
    for behind in (0.20, 0.28):
        for depth in (0.05, 0.12, 0.20):
            p = make_scenes.wall_scene(top, depth, 0.30, behind)
            best, q = search(p, "ellipsoid", attempts=200)
            s = search(p, "sphere", attempts=200)[0] if best >= 0 else float("nan")
            print(f"wall x=0.30 top {top}, target {behind} behind, {depth} below top, at {[round(v,3) for v in p["waypoints"][-1]]}: ellipsoid {1000*best:.1f} mm, sphere {1000*s:.1f} mm", flush=True)
