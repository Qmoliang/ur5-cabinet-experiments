"""Find and save a collision-free goal posture for the wall scene (both representations)."""
import json
import sys

sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/goal_search.py").read().split("if __name__")[0])
payload = json.load(open("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/assets/scenes/wall.json"))
for rep in ("ellipsoid", "sphere"):
    for seed in range(6):
        best, q = search(payload, rep, attempts=200, seed=seed)
        if best >= 0:
            break
    print(rep, "goal posture clearance", round(1000 * best, 1), "mm", None if q is None else q.round(3).tolist(), flush=True)
    if best >= 0:
        np.save(f"/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/assets/scenes/wall_goal_{rep}.npy", q)
