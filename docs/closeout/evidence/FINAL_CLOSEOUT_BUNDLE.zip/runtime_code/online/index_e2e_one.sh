#!/bin/bash
# One end-to-end known-cabinet run: representation span index_mode first_cpu
cd /mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6
id=${1}_$(printf "%03d" $(python3 -c "print(round($2*1000))"))mm_$3
OUT=/mnt/ssd2/hsjed/ur5_cabinet/v6runs/index_e2e
mkdir -p $OUT
UR5_KNOWN_CELL_SPAN=$2 UR5_KNOWN_OUT=$OUT/$id UR5_KNOWN_INDEX=$3 OMP_NUM_THREADS=4 MUJOCO_GL=egl \
  taskset -c $4-$(($4+3)) timeout 3600 ~/envs/ur5cab/bin/python -c "
import sys, json, time
sys.path[:0] = ['src', 'src/core', '.']
import run
t = time.time()
s = run.run('$1', maximum_cycles=3000)
keys = ('success', 'final_error_m', 'proxy_count', 'controller_ms_p50', 'controller_ms_p99')
print(json.dumps({k: s.get(k) for k in keys}), 'wall_s', round(time.time() - t, 1))
" > $OUT/$id.log 2>&1
