from pathlib import Path
import os,signal,json,time
ROOT=Path(__file__).resolve().parent
selected=[]
for p in Path('/proc').iterdir():
 if not p.name.isdigit():continue
 try:args=(p/'cmdline').read_bytes().decode().split('\0')
 except (OSError,UnicodeDecodeError):continue
 if len(args)<3:continue
 if args[1]=='-u' and args[2]=='launch_maximin.py':
  try:
   if (p/'cwd').resolve()==ROOT:selected.append((int(p.name),'launcher',None))
  except OSError:pass
 if str(ROOT/'pilot_worker_continuation.py') in args:
  folder=Path(args[args.index(str(ROOT/'pilot_worker_continuation.py'))+1])
  if folder.parent==ROOT/'trials' and folder.name.endswith('_maximin'):selected.append((int(p.name),'worker',folder))
for pid,kind,folder in sorted(selected,key=lambda x:x[1]):
 if folder:
  record=dict(reason='development run interrupted after identifying unpartitioned full-contraction certification compute blowup; final version certifies bounded intervals; not a completed 300s outcome',signal='SIGINT',pid=pid,time_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
  (folder/'DEVELOPMENT_INTERRUPT.json').write_text(json.dumps(record,indent=2))
 os.kill(pid,signal.SIGTERM if kind=='launcher' else signal.SIGINT)
 print(pid,kind)
