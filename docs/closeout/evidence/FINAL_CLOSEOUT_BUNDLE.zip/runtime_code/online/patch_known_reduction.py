"""Add UR5_OBSTACLE_REDUCTION (tree | reuse | tree+reuse) to known_v6/run.py (idempotent)."""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
source = path.read_text()
if "UR5_OBSTACLE_REDUCTION" in source:
    print("already patched")
    raise SystemExit
edits = [
    (
        "        controller_class = LinkRegionLiuQPController\n",
        "        controller_class = LinkRegionLiuQPController\n"
        "    reduction = os.environ.get(\"UR5_OBSTACLE_REDUCTION\", \"\")\n"
        "    if reduction:\n"
        "        from functools import partial\n"
        "        from obstacle_reduction import ObstacleReductionLiuQPController\n"
        "        controller_class = partial(ObstacleReductionLiuQPController, reduction=reduction)\n",
    ),
    (
        "        \"link_regions\": controller_class.__name__ != \"ProtocolLiuQPController\",\n",
        "        \"link_regions\": type(controller).__name__ == \"LinkRegionLiuQPController\",\n"
        "        \"obstacle_reduction\": reduction or None,\n"
        "        \"reduction_counts\": getattr(controller, \"counts\", None),\n",
    ),
]
for old, new in edits:
    assert source.count(old) == 1, old[:80]
    source = source.replace(old, new)
path.write_text(source)
print("patched")
