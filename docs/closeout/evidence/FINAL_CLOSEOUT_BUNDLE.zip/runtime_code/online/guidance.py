"""Stall-triggered IRIS-ZO guidance for LiuQP.

LiuQP is unchanged; this module only changes the target LiuQP is given.
When LiuQP stops making progress, guidance

1. solves inverse kinematics for collision-free goal configurations,
2. connects the current and goal configurations with RRT-Connect,
3. covers that path with IRIS-ZO convex regions in joint space,
4. turns the region junctions into gripper subgoals for LiuQP.

Every collision check uses the same certificate as LiuQP (robot certificate
spheres against the obstacle proxies), found through the sphere tree.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import time

import mujoco
import numpy as np
from scipy.optimize import least_squares


def point_axis_ellipsoid_distance(points: np.ndarray, centers: np.ndarray, axes: np.ndarray) -> np.ndarray:
    """Euclidean distance from points to axis-aligned ellipsoid surfaces.

    Negative (-1) marks a point inside the ellipsoid.  Solves the standard
    Lagrange condition sum(a^2 y^2 / (a^2 + t)^2) = 1 by bisection on t >= 0.
    """
    y = np.abs(points - centers)
    a2 = axes * axes
    inside = np.sum(y * y / a2, axis=1) <= 1.0
    low = np.zeros(len(y))
    high = np.linalg.norm(y, axis=1) * axes.max(axis=1) + 1e-12
    for _ in range(60):
        t = 0.5 * (low + high)
        value = np.sum(a2 * y * y / (a2 + t[:, None]) ** 2, axis=1) - 1.0
        low = np.where(value > 0.0, t, low)
        high = np.where(value > 0.0, high, t)
    closest = a2 * y / (a2 + high[:, None])
    distance = np.linalg.norm(y - closest, axis=1)
    return np.where(inside, -1.0, distance)


class ConfigurationChecker:
    """Is a joint configuration clear of every proxy by at least `margin`?"""

    def __init__(self, model, certificate, centers, representation, *, radii=None, shapes=None,
                 margin: float, index):
        self.model = model
        self.data = mujoco.MjData(model)
        self.body_ids = np.array([sphere.body_id for sphere in certificate])
        self.local_centers = np.array([sphere.local_center for sphere in certificate])
        self.radii = np.array([sphere.radius for sphere in certificate])
        self.centers = np.asarray(centers, dtype=float)
        self.representation = representation
        if representation == "sphere":
            self.proxy_radii = np.asarray(radii, dtype=float)
        else:
            shapes = np.asarray(shapes, dtype=float)
            off_diagonal = shapes - np.einsum("nii->ni", shapes)[:, :, None] * np.eye(3)
            if np.max(np.abs(off_diagonal)) > 1e-12:
                raise ValueError("the known-cabinet checker expects axis-aligned ellipsoids")
            self.axes = np.sqrt(np.einsum("nii->ni", shapes))
        self.margin = float(margin)
        self.index = index
        self.lower = model.jnt_range[:6, 0].copy()
        self.upper = model.jnt_range[:6, 1].copy()
        self.site = model.site("attachment_site").id
        self.checks = 0

    def sphere_positions(self, q: np.ndarray) -> np.ndarray:
        self.data.qpos[:6] = q
        mujoco.mj_kinematics(self.model, self.data)
        rotations = self.data.xmat[self.body_ids].reshape(-1, 3, 3)
        return self.data.xpos[self.body_ids] + np.einsum("nij,nj->ni", rotations, self.local_centers)

    def gripper_position(self, q: np.ndarray) -> np.ndarray:
        self.data.qpos[:6] = q
        mujoco.mj_kinematics(self.model, self.data)
        return self.data.site_xpos[self.site].copy()

    def clearance(self, q: np.ndarray) -> float:
        """Smallest (surface gap - margin) over all robot spheres; >= 0 is free."""
        self.checks += 1
        if np.any(q < self.lower) or np.any(q > self.upper):
            return -np.inf
        positions = self.sphere_positions(q)
        reach = self.radii + self.margin
        spheres, proxies = self.index.query_pairs(positions, reach)
        if not len(spheres):
            return np.inf
        if self.representation == "sphere":
            gaps = np.linalg.norm(positions[spheres] - self.centers[proxies], axis=1) - self.proxy_radii[proxies]
            return float(np.min(gaps - reach[spheres]))
        # For x in the ellipsoid, |y - x| >= a_min (|y|_Q - |x|_Q) >= a_min (|y|_Q - 1),
        # so pairs whose bound already clears the reach need no exact distance.
        delta = positions[spheres] - self.centers[proxies]
        axes = self.axes[proxies]
        bound = axes.min(axis=1) * (np.sqrt(np.sum((delta / axes) ** 2, axis=1)) - 1.0)
        slack = bound - reach[spheres]
        close = slack < 0.0
        if not np.any(close):
            return float(np.min(slack))
        gaps = point_axis_ellipsoid_distance(positions[spheres][close], self.centers[proxies][close], axes[close])
        exact = np.where(gaps < 0.0, -np.inf, gaps - reach[spheres][close])
        return float(min(np.min(exact), np.min(slack[~close], initial=np.inf)))

    def free(self, q: np.ndarray) -> bool:
        # The returned clearance is a lower bound for far pairs and exact for
        # close ones, so a non-negative value proves the configuration free.
        return self.clearance(q) >= 0.0

    def segment_free(self, q0: np.ndarray, q1: np.ndarray, step: float = 0.01) -> bool:
        count = int(np.ceil(np.max(np.abs(q1 - q0)) / step))
        return all(self.free(q0 + (q1 - q0) * s) for s in np.linspace(0.0, 1.0, count + 1)[1:])


def solve_goal_configurations(checker: ConfigurationChecker, target: np.ndarray, q_now: np.ndarray,
                              rng: np.random.Generator, references=(), attempts: int = 160, keep: int = 6):
    """Collision-free IK solutions for the gripper position, nearest first.

    Seeds: the current pose, any reference poses (e.g. the run's start pose),
    then small and large random perturbations of them.  Returns the solutions
    and a count of why rejected seeds failed.
    """
    anchors = [np.asarray(q_now, dtype=float)] + [np.asarray(r, dtype=float) for r in references]
    solutions = []
    rejected = {"not_converged": 0, "in_collision": 0, "duplicate": 0}
    for attempt in range(attempts):
        anchor = anchors[attempt % len(anchors)]
        spread = 0.0 if attempt < len(anchors) else (0.3 if attempt % 2 else 1.2)
        seed = np.clip(anchor + rng.normal(0.0, spread, 6), checker.lower, checker.upper)
        result = least_squares(
            lambda q: np.concatenate([checker.gripper_position(q) - target, 1e-3 * (q - seed)]),
            seed, bounds=(checker.lower, checker.upper), xtol=1e-10, ftol=1e-10)
        q = result.x
        if np.linalg.norm(checker.gripper_position(q) - target) > 1e-4:
            rejected["not_converged"] += 1
            continue
        if not checker.free(q):
            rejected["in_collision"] += 1
            continue
        if any(np.max(np.abs(q - other)) <= 0.05 for other in solutions):
            rejected["duplicate"] += 1
            continue
        solutions.append(q)
        if len(solutions) >= keep:
            break
    solutions.sort(key=lambda q: np.linalg.norm(q - q_now))
    return solutions, rejected


def rrt_connect(checker: ConfigurationChecker, start: np.ndarray, goal: np.ndarray,
                rng: np.random.Generator, step: float = 0.08, iterations: int = 6000, margin: float = 0.8):
    """Bidirectional RRT in joint space; returns a list of configurations or None."""
    lower = np.maximum(np.minimum(start, goal) - margin, checker.lower)
    upper = np.minimum(np.maximum(start, goal) + margin, checker.upper)
    trees = [([start.copy()], [-1]), ([goal.copy()], [-1])]

    def extend(tree, target):
        nodes, parents = tree
        nearest = int(np.argmin(np.linalg.norm(np.asarray(nodes) - target, axis=1)))
        direction = target - nodes[nearest]
        distance = np.linalg.norm(direction)
        new = target if distance <= step else nodes[nearest] + direction * (step / distance)
        if not checker.segment_free(nodes[nearest], new):
            return None
        nodes.append(new)
        parents.append(nearest)
        return len(nodes) - 1

    def path(tree, index):
        nodes, parents = tree
        out = []
        while index >= 0:
            out.append(nodes[index])
            index = parents[index]
        return out[::-1]

    for iteration in range(iterations):
        sample = rng.uniform(lower, upper) if iteration % 10 else trees[1][0][0]
        grown = extend(trees[0], sample)
        if grown is not None:
            reached = trees[0][0][grown]
            # Greedily connect the other tree toward the new node.
            while True:
                connected = extend(trees[1], reached)
                if connected is None:
                    break
                if np.linalg.norm(trees[1][0][connected] - reached) < 1e-9:
                    first = path(trees[0], grown)
                    second = path(trees[1], connected)[::-1]
                    if iteration % 2:  # trees were swapped an odd number of times
                        first, second = second[::-1], first[::-1]
                    return first + second[1:]
        trees.reverse()
    return None


def shortcut(checker: ConfigurationChecker, path: list, rng: np.random.Generator, rounds: int = 150) -> list:
    path = list(path)
    for _ in range(rounds):
        if len(path) < 3:
            break
        i, j = sorted(rng.choice(len(path), 2, replace=False))
        if j - i < 2:
            continue
        if checker.segment_free(path[i], path[j]):
            path = path[: i + 1] + path[j:]
    return path


def densify(path: list, step: float = 0.05) -> np.ndarray:
    out = [path[0]]
    for a, b in zip(path[:-1], path[1:]):
        count = max(1, int(np.ceil(np.max(np.abs(b - a)) / step)))
        out.extend(a + (b - a) * s for s in np.linspace(0.0, 1.0, count + 1)[1:])
    return np.asarray(out)


@dataclass
class Region:
    seed: np.ndarray
    A: np.ndarray
    b: np.ndarray

    def contains(self, q: np.ndarray, tolerance: float = 1e-9) -> bool:
        return bool(np.all(self.A @ q <= self.b + tolerance))


def iris_zo_region(checker: ConfigurationChecker, seed: np.ndarray, rng: np.random.Generator,
                   lower: np.ndarray, upper: np.ndarray, samples: int = 120, iterations: int = 6,
                   bisection_steps: int = 10) -> Region:
    """Zero-order IRIS: grow a convex collision-free polytope around `seed`.

    Repeatedly samples the current polytope (hit-and-run), finds colliding
    samples, bisects toward the seed to locate the collision boundary, and adds
    a separating hyperplane there (isotropic metric centred on the seed).  Stops
    when a full batch of samples is collision-free.
    """
    A = [np.eye(6), -np.eye(6)]
    b = [upper, -lower]
    A_rows = np.vstack(A)
    b_rows = np.concatenate(b)

    def hit_and_run(count):
        points = []
        x = seed.copy()
        for _ in range(count):
            direction = rng.normal(size=6)
            direction /= np.linalg.norm(direction)
            denominators = A_rows @ direction
            slack = b_rows - A_rows @ x
            with np.errstate(divide="ignore"):
                ratios = slack / denominators
            t_max = np.min(ratios[denominators > 1e-12], initial=1.0)
            t_min = np.max(ratios[denominators < -1e-12], initial=-1.0)
            if t_max > t_min:
                # Stay strictly inside so rounding never leaves the polytope.
                x = x + direction * rng.uniform(0.999 * t_min, 0.999 * t_max)
            else:
                x = seed.copy()  # rounding put the chain on a new plane; restart
            points.append(x.copy())
        return points

    for _ in range(iterations):
        colliding = [p for p in hit_and_run(samples) if not checker.free(p)]
        if not colliding:
            break
        colliding.sort(key=lambda p: np.linalg.norm(p - seed))
        for point in colliding:
            if np.any(A_rows @ point > b_rows):
                continue  # already cut off by an earlier plane
            inside, outside = seed, point
            for _ in range(bisection_steps):
                middle = 0.5 * (inside + outside)
                if checker.free(middle):
                    inside = middle
                else:
                    outside = middle
            normal = outside - seed
            length = np.linalg.norm(normal)
            if length < 1e-9:
                continue  # the seed itself is at the boundary; no usable plane
            normal /= length
            A_rows = np.vstack([A_rows, normal])
            b_rows = np.append(b_rows, normal @ inside)
    return Region(seed=seed.copy(), A=A_rows, b=b_rows)


def iris_corridor(checker, path: np.ndarray, rng, lower, upper, maximum_regions: int = 80):
    """Cover a free joint path with overlapping IRIS-ZO regions.

    Each region is seeded at the last path point the previous region still
    contains, so consecutive regions share that point.  Returns the regions and
    the junction configurations (subgoals), ending with the goal.
    """
    regions = []
    junctions = []
    start = 0
    while start < len(path) - 1 and len(regions) < maximum_regions:
        region = iris_zo_region(checker, path[start], rng, lower, upper)
        regions.append(region)
        last = start
        while last + 1 < len(path) and region.contains(path[last + 1]):
            last += 1
        if last == start:
            last = start + 1  # region failed to grow along the path; step on
        junctions.append(path[last])
        start = last
    return regions, junctions


@dataclass
class GuidanceStats:
    calls: int = 0
    failures: int = 0
    plan_ms: list = field(default_factory=list)
    regions: list = field(default_factory=list)
    subgoals: list = field(default_factory=list)
    events: list = field(default_factory=list)


class StallTriggeredGuidance:
    """Feeds LiuQP either the final target or the next IRIS-ZO subgoal."""

    def __init__(self, checker: ConfigurationChecker, target: np.ndarray, *, seed: int = 0,
                 window: int = 50, minimum_progress: float = 0.002, converged: float = 0.005,
                 subgoal_tolerance: float = 0.02, maximum_calls: int = 5,
                 minimum_margin: float = 0.006, references=(),
                 subgoal_mode: str = "iris", trigger: str = "stall"):
        if subgoal_mode not in {"iris", "rrt", "rrt_dense"}:
            raise ValueError("subgoal_mode must be iris, rrt or rrt_dense")
        if trigger not in {"stall", "always"}:
            raise ValueError("trigger must be stall or always")
        # iris: region junctions; rrt: vertices of the shortcut RRT path;
        # rrt_dense: that path resampled every 0.05 rad (the spacing small
        # IRIS regions produce), to separate "regions" from "denser waypoints".
        self.subgoal_mode = subgoal_mode
        # always: plan once before moving, then still replan on stalls.
        self.trigger = trigger
        self.checker = checker
        self.references = [np.asarray(r, dtype=float) for r in references]
        self.planning_margin = checker.margin
        self.minimum_margin = minimum_margin
        self.target = np.asarray(target, dtype=float)
        self.rng = np.random.default_rng(seed)
        self.window = window
        self.minimum_progress = minimum_progress
        self.converged = converged
        self.subgoal_tolerance = subgoal_tolerance
        self.maximum_calls = maximum_calls
        self.subgoals: list[np.ndarray] = []
        self.history: list[float] = []
        self.stats = GuidanceStats()

    def current_target(self) -> np.ndarray:
        return self.subgoals[0] if self.subgoals else self.target

    def _stalled(self, error: float) -> bool:
        self.history.append(error)
        if len(self.history) <= self.window or error < self.converged:
            return False
        return self.history[-self.window - 1] - min(self.history[-self.window:]) < self.minimum_progress

    def plan(self, q_now: np.ndarray, cycle: int) -> bool:
        # Plan with the largest margin that works.  Start from the planning
        # margin, lowered just enough to admit the current pose (a stalled arm
        # rests near LiuQP's margin), then step down to LiuQP's own margin if
        # no goal posture or path exists.  The drawer leaves too little room
        # for wide margins at the goal, so the ladder is needed even from free
        # starts.  The planning margin is restored afterwards.
        self.checker.margin = self.planning_margin
        start_clearance = self.checker.clearance(q_now)
        first = self.planning_margin
        if start_clearance < 0.0:
            first = max(self.minimum_margin, self.planning_margin + start_clearance - 1e-4)
        ladder = sorted({first, 0.5 * (first + self.minimum_margin), self.minimum_margin}, reverse=True)
        started = time.perf_counter()
        self.stats.calls += 1
        try:
            for margin in ladder:
                self.checker.margin = margin
                if self._plan(q_now, cycle):
                    return True
            self.stats.failures += 1
            return False
        finally:
            self.checker.margin = self.planning_margin
            self.stats.plan_ms.append(1000 * (time.perf_counter() - started))

    def _plan(self, q_now: np.ndarray, cycle: int) -> bool:
        """One planning attempt at the checker's current margin."""
        started = time.perf_counter()
        checks_before = self.checker.checks
        goals, rejected = solve_goal_configurations(
            self.checker, self.target, q_now, self.rng, references=self.references)
        path = None
        # Escaping usually needs a detour well outside the start-goal box, so
        # widen the sampling box until a goal connects.
        for box in (1.0, 1.6, 2.5):
            for goal in goals:
                path = rrt_connect(self.checker, q_now, goal, self.rng, iterations=10000, margin=box)
                if path is not None:
                    break
            if path is not None:
                break
        if path is None:
            self.stats.events.append({"cycle": cycle, "event": "attempt_failed", "goals": len(goals),
                                      "planning_margin_m": self.checker.margin, "ik_rejected": rejected,
                                      "attempt_ms": 1000 * (time.perf_counter() - started)})
            return False
        vertices = shortcut(self.checker, path, self.rng)
        path = densify(vertices)
        regions = []
        if self.subgoal_mode == "iris":
            lower = np.maximum(path.min(axis=0) - 0.5, self.checker.lower)
            upper = np.minimum(path.max(axis=0) + 0.5, self.checker.upper)
            regions, junctions = iris_corridor(self.checker, path, self.rng, lower, upper)
        elif self.subgoal_mode == "rrt":
            junctions = list(vertices[1:])
        else:
            junctions = list(path[1:])
        # Intermediate junctions become gripper subgoals; the last junction is
        # the goal configuration, whose gripper position is the target itself.
        self.subgoals = [self.checker.gripper_position(q) for q in junctions[:-1]]
        elapsed = 1000 * (time.perf_counter() - started)
        self.stats.regions.append(len(regions))
        self.stats.subgoals.append([s.tolist() for s in self.subgoals])
        self.stats.events.append({"cycle": cycle, "event": "planned", "goals": len(goals),
                                  "planning_margin_m": self.checker.margin,
                                  "subgoal_mode": self.subgoal_mode, "trigger": self.trigger,
                                  "path_vertices": int(len(vertices)),
                                  "path_points": int(len(path)), "regions": len(regions),
                                  "subgoals": len(self.subgoals), "plan_ms": elapsed,
                                  "collision_checks": self.checker.checks - checks_before})
        self.history.clear()
        return True

    def update(self, q_now: np.ndarray, gripper: np.ndarray, cycle: int) -> np.ndarray:
        """Call once per control cycle after the state update."""
        while self.subgoals and np.linalg.norm(gripper - self.subgoals[0]) < self.subgoal_tolerance:
            self.subgoals.pop(0)
            self.history.clear()
            self.stats.events.append({"cycle": cycle, "event": "subgoal_reached"})
        if self.trigger == "always" and self.stats.calls == 0:
            self.stats.events.append({"cycle": cycle, "event": "initial_plan"})
            self.plan(q_now, cycle)
            return self.current_target()
        error = float(np.linalg.norm(gripper - self.current_target()))
        if self._stalled(error) and self.stats.calls < self.maximum_calls:
            self.stats.events.append({"cycle": cycle, "event": "stall", "error_m": error})
            self.plan(q_now, cycle)
        return self.current_target()
