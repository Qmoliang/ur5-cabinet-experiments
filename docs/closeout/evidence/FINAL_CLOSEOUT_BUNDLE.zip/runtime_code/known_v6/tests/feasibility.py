"""Does any collision-free final pose exist?  Cage window sizes and bin target depths.

For each scene variant and representation, search inverse kinematics from many
seeds for a pose that puts the gripper on the target with every robot sphere
clear of the obstacle cover by LiuQP's 6 mm margin.  No path is checked: this
only says whether the target can be reached at all.
"""
import json
import sys
from pathlib import Path

import numpy as np

K = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
sys.path[:0] = [str(K), str(K / "src" / "core"), str(K / "src"), str(K / "assets"), str(K.parent / "online_v6")]
import mujoco  # noqa: E402
import make_scenes  # noqa: E402
import run as known_run  # noqa: E402,F401  (installs the scene-box model builder when UR5_SCENE_JSON is set)
from ball_tree import NativeBallTree  # noqa: E402
from guidance import ConfigurationChecker, solve_goal_configurations  # noqa: E402
from known_volume import build_volume_cover  # noqa: E402
from robot import BoxObstacle, SceneDefinition, build_model, build_robot_certificate  # noqa: E402

MARGIN = 0.006


def scene_of(payload):
    return SceneDefinition(
        name=payload["name"], description="", duration=45.0,
        boxes=tuple(BoxObstacle(name=b["name"], center=tuple(b["center"]), half_size=tuple(b["half_size"]),
                                material="shelf") for b in payload["boxes"]),
        q0=tuple(payload["q0"]), waypoints=tuple(tuple(w) for w in payload["waypoints"]))


def feasible(payload, representation, attempts):
    scene = scene_of(payload)
    model = build_model(scene)
    robot = build_robot_certificate(model)
    cover = build_volume_cover(scene.boxes, representation, 0.075)
    radii = np.array([s.radius for s in robot])
    index = NativeBallTree(cover.centers, cover.aabb_half_extents, query_padding=float(radii.max() + MARGIN + 0.05))
    checker = ConfigurationChecker(model, robot, cover.centers, representation, radii=cover.sphere_radii,
                                   shapes=cover.ellipsoid_shapes, margin=MARGIN, index=index)
    solutions, rejected = solve_goal_configurations(
        checker, np.asarray(scene.waypoints[-1]), np.asarray(scene.q0), np.random.default_rng(0),
        attempts=attempts, keep=3)
    index.close()
    return len(solutions), rejected


variants = []
for gap in (0.12, 0.16, 0.20, 0.24):
    for height in (0.148, 0.20, 0.26):
        variants.append((f"cage gap {gap * 100:.0f} cm x {height * 100:.1f} cm", make_scenes.cage(gap, height)))
for depth in (0.05, 0.10, 0.15, 0.20):
    scene = make_scenes.bin_scene(0.66)
    scene["waypoints"] = [[0.60, 0.406, 0.66 - depth]]
    variants.append((f"bin target {depth * 100:.0f} cm below rim", scene))
attempts = int(sys.argv[1]) if len(sys.argv) > 1 else 400
for label, payload in variants:
    row = {rep: feasible(payload, rep, attempts) for rep in ("ellipsoid", "sphere")}
    print(label, "| ellipsoid", row["ellipsoid"][0], "poses", row["ellipsoid"][1],
          "| sphere", row["sphere"][0], "poses", row["sphere"][1], flush=True)
