"""Native-path comparison on the 20 start poses, plus isolated timing."""
import csv
import glob
import json
import os
from pathlib import Path

import numpy as np

RUNS = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
TRAPPED = {2, 3, 5, 6, 8, 9, 10, 13, 14, 15, 18}


def run_dirs(folder):
    return {int(p.split("seed")[1][:2]): Path(p) for p in glob.glob(str(RUNS / folder / "ellipsoid_075mm_seed*"))
            if os.path.isdir(p)}


for folder, name in (("n0_original", "original native LiuQP"), ("n1_reuse", "+ reuse"),
                     ("n2_geodesic", "+ geodesic"), ("n3_both", "+ geodesic + reuse")):
    runs = {}
    for seed, d in run_dirs(folder).items():
        s = json.loads((d / "summary.json").read_text())
        rows = list(csv.DictReader(open(d / "cycles.csv")))
        runs[seed] = dict(success=s["success"], time=s.get("first_sustained_success_time_s"),
                          penetrating=s["exact_penetrating_cycles"],
                          controller=float(np.median([float(r["total_controller_ms"]) for r in rows])))
    if len(runs) != 20:
        print(f"{name}: {len(runs)} of 20")
        continue
    med = lambda xs: float(np.median(xs)) if xs else None
    print(json.dumps({"variant": name, "reached": sum(r["success"] for r in runs.values()),
                      "penetrating_cycles": sum(r["penetrating"] for r in runs.values()),
                      "easy_time_s": med([runs[s]["time"] for s in runs if s not in TRAPPED and runs[s]["success"]]),
                      "trapped_time_s": med([runs[s]["time"] for s in TRAPPED if runs[s]["success"]]),
                      "controller_ms_median_under_load": med([r["controller"] for r in runs.values()])}))

print("isolated timing, controller ms median / p99:")
for folder in ("nt_original", "nt_reuse", "nt_geodesic", "nt_both"):
    for seed, d in sorted(run_dirs(folder).items()):
        rows = list(csv.DictReader(open(d / "cycles.csv")))
        c = np.array([float(r["total_controller_ms"]) for r in rows])
        s = json.loads((d / "summary.json").read_text())
        build = s.get("attractor_build_ms")
        print(f"  {folder:12s} seed {seed}: reached={s['success']!s:5} {np.median(c):5.2f} / {np.percentile(c, 99):5.2f}"
              + (f"   field build {build:.0f} ms" if build else ""))
