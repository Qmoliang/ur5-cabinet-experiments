#!/bin/bash
# Known map with the safety layer (self rows, floor, accel 10, least-violation fallback, protective stop):
# (1) pilot_known20: drawer / cage / cage_wide / IRIS shelf t0 x LiuQP-E, +combined, NEO-E 0.30, NEO-E 0.046
#     x no racket | 1@0.25 | 1@0.5 | 2@0.5 x straight / geodesic x seeds 1-20, far start.
# (2) bench_safe: the original benchmark (14 scenes, original starts) x LiuQP / NEO-m / NEO-p x sphere / ellipsoid
#     x straight / geodesic x 20 starts.
# 16 workers x 2 CPUs on CPUs 96-127 (the online pilot uses 0-95).
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
P=$PWD/pilot_known20; B=$PWD/bench_safe
A=/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6/assets
jobs=()
for seed in $(seq 1 20); do
  for scene in drawer cage cage_wide iris_ur3_shelf_t0; do
    case $scene in
      drawer) far=$A/far_start_q.npy ;; cage) far=$A/far_start_q_cage.npy ;;
      cage_wide) far=$A/far_start_q_cage_wide.npy ;; *) far=$A/far_start_q_shelf.npy ;;
    esac
    for attr in straight geodesic_native; do
      for ctl in liuqp combined neo_paper neo_matched; do
        for cond in "0 0.0" "1 0.25" "1 0.5" "2 0.5"; do
          set -- $cond
          jobs+=("$P/${ctl}_${attr%_native}_k$1_v$2 $scene ellipsoid $attr $seed UR5_CONTROLLER=$ctl UR5_E4_SAFETY=1 UR5_E4_FAR_START_FILE=$far UR5_ACCEL_LIMIT=10 UR5_OBJECTS=$1 UR5_OBJECT_SPEED=$2")
        done
      done
    done
  done
done
SCENES="drawer cage cage_wide exit wall2 iris_4shelves_t0 iris_4shelves_t2 iris_bins_t0 iris_bins_t1 iris_bins_t2 iris_bins_t3 iris_ur3_shelf_t0 iris_ur3_shelf_t1 iris_ur3_shelf_t2"
for seed in $(seq 1 20); do
  for scene in $SCENES; do
    for ctl in liuqp neo_matched neo_paper; do
      for rep in ellipsoid sphere; do
        [ $scene = exit ] && [ $rep = sphere ] && continue
        for attr in straight geodesic_native; do
          jobs+=("$B/$ctl $scene $rep $attr $seed UR5_CONTROLLER=$ctl UR5_E4_SAFETY=1 UR5_ACCEL_LIMIT=10")
        done
      done
    done
  done
done
echo "${#jobs[@]} jobs" > known_overnight.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 16)); do
    set -- ${jobs[$i]}
    out=$1; scene=$2; rep=$3; attr=$4; seed=$5; shift 5
    id=${scene}_${rep}_${attr}_seed$(printf "%02d" $seed)
    [ -f $out/$id/summary.json ] && continue
    ./known_job.sh $out $scene $rep $attr $seed $((96 + w * 2)) "$@" > /dev/null 2>&1
  done
}
for w in $(seq 0 15); do worker $w & done
wait
echo DONE > known_overnight.done
