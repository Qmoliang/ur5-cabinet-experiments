#!/bin/bash
# 5 mm frontier cells (UR5_FRONTIER_CELL_VOXELS=1) on the recorded online runs: rebuild each
# final map, then LiuQP + geodesic on it WITH the unseen cells.  CPUs 0-79.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=6 CUDA_VISIBLE_DEVICES=6 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export UR5_FRONTIER_CELL_VOXELS=1
OUT=v6runs/frontier5; ONLINE=repo/experiment/runtimes/online_v6
lim="systemd-run --user --scope -q -p MemoryMax=24G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_FRONTIER_CELL_VOXELS"
mkdir -p $OUT/maps $OUT/with_unseen
for seed in $(seq 1 20); do
  id=seed$(printf "%02d" $seed); slot=$((seed - 1))
  [ -f $OUT/maps/$id.pkl ] || $lim taskset -c $((slot * 4))-$((slot * 4 + 3)) timeout 3600 \
    ~/envs/ur5cab/bin/python $ONLINE/build_frozen_map.py v6runs/online_long/look_$id $OUT/maps/$id.pkl >> $OUT/maps/build.log 2>&1 &
done
wait
for ((start = 1; start <= 20; start += 6)); do
  for slot in $(seq 0 5); do
    seed=$((start + slot)); [ $seed -le 20 ] || break; id=seed$(printf "%02d" $seed)
    [ -f $OUT/with_unseen/$id/summary.json ] && continue
    $lim timeout 2400 ~/envs/ur5cab/bin/python $ONLINE/run_v6_case.py ellipsoid --map incremental --timing paced \
      --cpus $((slot * 12)):12 --start-seed $seed --geodesic --frozen-map $OUT/maps/$id.pkl \
      --out $OUT/with_unseen/$id > $OUT/with_unseen/$id.log 2>&1 &
  done
  wait
done
echo DONE > $OUT/FRONTIER5_DONE
