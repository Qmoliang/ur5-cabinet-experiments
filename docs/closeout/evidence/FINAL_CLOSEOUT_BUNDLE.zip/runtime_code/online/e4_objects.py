"""Bridge: the moving objects of known_v6/src/objects.py inside the online runtime (E4).

known_v6's object generator imports `robot`; the online runtime's equivalent
module is `model` (same BoxObstacle, DT and certificate_world_positions).
known_v6/src is appended to sys.path so online modules keep priority.
"""
import sys
from pathlib import Path

import model as _model

sys.modules.setdefault("robot", _model)
_KNOWN_SRC = Path(__file__).resolve().parents[1] / "known_v6" / "src"
if str(_KNOWN_SRC) not in sys.path:
    sys.path.append(str(_KNOWN_SRC))

from objects import MovingObjects, mjcf_bodies  # noqa: E402,F401
