"""Build the single-file HTML results report from the v6 experiment outputs."""
from __future__ import annotations

import csv
import html
import io
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path("/mnt/ssd2/hsjed/ur5_cabinet")
RUNS = ROOT / "v6runs"
OUT = ROOT / "report"

ELLIPSOID = "#2a78d6"
SPHERE = "#eb6834"
NEW = "#1baf7a"
OLD = "#8a8984"
INK = "#0b0b0b"
INK2 = "#52514e"
GRID = "#e4e3df"

plt.rcParams.update({
    "font.size": 10, "axes.edgecolor": GRID, "axes.labelcolor": INK2,
    "xtick.color": INK2, "ytick.color": INK2, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.8, "axes.spines.top": False,
    "axes.spines.right": False, "lines.linewidth": 2.0, "svg.fonttype": "path",
    "figure.facecolor": "white", "axes.facecolor": "white",
})


FIGURE_COUNT = [0]


def svg(fig) -> str:
    # A PNG copy of every figure is kept for checking the layout by eye.
    FIGURE_COUNT[0] += 1
    (OUT / "figs").mkdir(parents=True, exist_ok=True)
    fig.savefig(OUT / "figs" / f"figure_{FIGURE_COUNT[0]}.png", dpi=110, bbox_inches="tight")
    buffer = io.StringIO()
    fig.savefig(buffer, format="svg", bbox_inches="tight")
    plt.close(fig)
    text = buffer.getvalue()
    return text[text.index("<svg"):]


def read_csv(path: Path) -> list[dict]:
    with path.open() as handle:
        return list(csv.DictReader(handle))


def run_dir(case: Path) -> Path:
    return next(path for path in case.iterdir() if path.is_dir() and path.name.startswith("A-CV"))


def label(ax, x, y, text, color):
    ax.annotate(text, (x, y), xytext=(4, 0), textcoords="offset points",
                color=INK, fontsize=9, va="center")
    ax.plot([x], [y], "o", color=color, markersize=5)


# ---------------------------------------------------------------- figure 1
def fig_update_cost() -> str:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.4), sharey=True)
    for ax, case, name in zip(axes, ("O02", "O01"), ("Ellipsoid map (O02 trajectory)", "Sphere map (O01 trajectory)")):
        for folder, color, text in (("profile", OLD, "old map"), ("profile_v6_full", NEW, "new map")):
            rows = read_csv(ROOT / folder / f"{case}_frames.csv")
            t = np.array([int(r["cycle"]) * 0.02 for r in rows])
            ms = np.array([float(r["proxy_update_ms"]) for r in rows]) / 1000.0
            ax.plot(t, ms, color=color)
            label(ax, t[-1], ms[-1], f"{text}: {ms[-1]:.2f} s", color)
        ax.set_title(name, color=INK, fontsize=10, loc="left")
        ax.set_xlabel("time along the recorded run (s)")
        ax.set_xlim(0, 75)
    axes[0].set_ylabel("map update time per frame (s)")
    return svg(fig)


# ---------------------------------------------------------------- figure 2
def fig_history() -> str:
    old = read_csv(ROOT / "profile_changes" / "O02_frames.csv")
    new = read_csv(ROOT / "profile_v6_quick" / "O02_frames.csv")
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.2))
    for rows, color, text in ((old, OLD, "old map"), (new, NEW, "new map")):
        t = np.array([int(r["cycle"]) * 0.02 for r in rows])
        changed = np.array([float(r["changed"]) for r in rows])
        samples = np.array([float(r["samples"]) for r in rows]) / 1000.0
        axes[0].plot(t, changed, color=color)
        label(axes[0], t[-1], changed[-1], f"{text}: {changed[-1]:.0f}", color)
        axes[1].plot(t, samples, color=color)
        label(axes[1], t[-1], samples[-1], f"{text}: {samples[-1]:.1f}k", color)
    axes[0].set_yscale("log")
    axes[0].set_title("Cells recomputed per map update", color=INK, fontsize=10, loc="left")
    axes[1].set_title("Stored observation history (thousands)", color=INK, fontsize=10, loc="left")
    for ax in axes:
        ax.set_xlabel("time (s)")
        ax.set_xlim(0, 75)
    return svg(fig)


# ---------------------------------------------------------------- figure 3
def ages(case: Path) -> tuple[np.ndarray, np.ndarray]:
    rows = read_csv(run_dir(case) / "cycles.csv")
    return (np.array([float(r["time_s"]) for r in rows]),
            np.array([float(r["snapshot_age_ms"]) for r in rows]) / 1000.0)


def fig_map_age(cases: dict) -> str:
    fig, axes = plt.subplots(2, 1, figsize=(9, 5.6), sharex=True, sharey=True)
    for ax, rep, name in zip(axes, ("ell", "sph"), ("Ellipsoid run", "Sphere run")):
        for key, color, text in (("old", OLD, "old map, real time"), ("new", NEW, "new map, real time"),
                                 ("sync", INK, "no-delay reference")):
            case = cases.get((rep, key))
            if case is None or not (case / "summary.json").exists():
                continue
            t, age = ages(case)
            ax.plot(t, age, color=color, linewidth=1.2 if key != "sync" else 1.6)
            label(ax, t[-1], float(np.median(age)), f"{text} (median {np.median(age):.2f} s)", color)
        ax.set_title(name, color=INK, fontsize=10, loc="left")
        ax.set_xlim(0, 100)
        ax.set_ylabel("map age (s)")
    axes[1].set_xlabel("simulated time (s)")
    return svg(fig)


# ---------------------------------------------------------------- figure 4
def fig_known_sweep(geometry: list[dict], sweep: dict) -> str:
    fig, axes = plt.subplots(1, 2, figsize=(10, 3.6))
    for rep, color, text in (("ellipsoid", ELLIPSOID, "ellipsoids"), ("sphere", SPHERE, "spheres")):
        rows = sorted((g for g in geometry if g["label"].startswith(f"known_{rep}_")), key=lambda g: g["proxies"])
        n = np.array([g["proxies"] for g in rows])
        blocked = np.array([100 * g["cavity_blocked_fraction"] for g in rows])
        reached = [sweep.get(g["label"].replace("known_", "")) for g in rows]
        axes[0].plot(n, blocked, color=color)
        for x, y, ok in zip(n, blocked, reached):
            axes[0].plot([x], [y], "o" if ok else "x", color=color, markersize=7,
                         markerfacecolor=color if ok else "none", markeredgewidth=2)
        axes[0].plot([], [], color=color, label=text)
        free_h = np.array([g["narrowest_free_height_mm"] for g in rows])
        axes[1].plot(n, free_h, color=color)
        for x, y, ok in zip(n, free_h, reached):
            axes[1].plot([x], [y], "o" if ok else "x", color=color, markersize=7,
                         markerfacecolor=color if ok else "none", markeredgewidth=2)
    axes[0].set_title("Free drawer space swallowed by the cover (%)", color=INK, fontsize=10, loc="left")
    axes[1].set_title("Narrowest free height on the way to the target (mm)", color=INK, fontsize=10, loc="left")
    axes[1].axhline(140, color=INK2, linewidth=1, linestyle=":")
    axes[1].annotate("real opening 140 mm", (40, 140), xytext=(0, 4), textcoords="offset points", fontsize=8, color=INK2)
    axes[0].legend(frameon=False, loc="upper right", labelcolor=INK)
    for ax in axes:
        ax.set_xscale("log")
        ax.set_xlabel("number of proxies (log scale)   o reached   x did not reach")
    return svg(fig)


# ---------------------------------------------------------------- figure 5
def fig_slices() -> str:
    slices = {}
    for path in sorted((RUNS / "geometry").glob("slices_*.npz")):
        data = np.load(path)
        slices.update({key: data[key] for key in data.files})
    panels = [("known_sphere_075mm", "Known · spheres, 388\ndid not reach"),
              ("known_ellipsoid_075mm", "Known · ellipsoids, 388\nreached"),
              ("known_sphere_035mm", "Known · spheres, 2,357\nreached"),
              ("D4_online_sphere", "Online · spheres, 4,177\ndid not reach"),
              ("D3_online_ellipsoid", "Online · ellipsoids, 2,368\nreached")]
    panels = [(k, t) for k, t in panels if k in slices]
    fig, axes = plt.subplots(1, len(panels), figsize=(2.5 * len(panels), 2.9), sharey=True)
    for ax, (key, title) in zip(np.atleast_1d(axes), panels):
        mask = slices[key].T  # rows = z, cols = x
        ax.imshow(mask, origin="lower", extent=(350, 800, 510, 650), aspect="auto",
                  cmap=matplotlib.colors.ListedColormap(["white", "#c3c2b7"]), vmin=0, vmax=1)
        ax.plot([630], [580], marker="*", color=INK, markersize=9)
        ax.set_title(title, color=INK, fontsize=8, loc="left")
        ax.set_xlabel("depth x (mm)")
        ax.grid(False)
    np.atleast_1d(axes)[0].set_ylabel("height z (mm)")
    return svg(fig)


# ---------------------------------------------------------------- tables
def table(headers: list[str], rows: list[list]) -> str:
    head = "".join(f"<th>{html.escape(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{html.escape(str(c))}</td>" for c in row) + "</tr>" for row in rows)
    return f"<div class='table'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"


def fmt(value, digits=2):
    if value is None:
        return "-"
    if isinstance(value, bool):
        return "yes" if value else "no"
    if isinstance(value, float):
        return f"{value:.{digits}f}"
    return str(value)


def online_rows(summary: list[dict], names: dict) -> list[list]:
    rows = []
    for row in summary:
        if row["case"] not in names:
            continue
        rows.append([names[row["case"]], fmt(row["success"]), fmt(row["final_error_mm"], 3),
                     fmt(row["first_success_time_s"], 1), row["published_maps"],
                     fmt(row["map_age_p50_ms"] / 1000), fmt(row["map_age_p95_ms"] / 1000),
                     fmt(row["pipeline_p50_ms"] / 1000 if row["pipeline_p50_ms"] else None),
                     row["final_proxy_count"], row["penetrating_cycles"]])
    return rows


def last_json(path: Path) -> dict:
    line = path.read_text().strip().splitlines()[-1]
    return json.loads(line.split(" wall_s")[0])


def known_results() -> tuple[dict, list[list], list[list]]:
    sweep = {}
    rows = []
    for log in sorted((RUNS / "known_sweep").glob("*.log")):
        result = last_json(log)
        sweep[log.stem] = bool(result["success"])
        rep, span = log.stem.split("_")
        rows.append([rep, span, result["proxy_count"], fmt(bool(result["success"])),
                     fmt(1000 * result["final_error_m"], 3)])
    rows.sort(key=lambda r: (r[0], r[2]))
    robust: dict[str, list] = {}
    for log in sorted((RUNS / "known_robust").glob("*.log")):
        config = log.stem.rsplit("_seed", 1)[0]
        robust.setdefault(config, []).append(last_json(log))
    robust_rows = []
    for config, results in sorted(robust.items(), key=lambda kv: kv[1][0]["proxy_count"]):
        rep, span = config.split("_")
        ok = [r for r in results if r["success"]]
        trapped = [r for r in results if not r["success"]]
        robust_rows.append([rep, span, results[0]["proxy_count"], f"{len(ok)}/{len(results)}",
                            fmt(1000 * float(np.median([r["final_error_m"] for r in trapped])), 1)
                            if trapped else "-"])
    return sweep, rows, robust_rows


def main() -> None:
    OUT.mkdir(exist_ok=True)
    geometry = json.loads((RUNS / "geometry" / "geometry.json").read_text())
    sweep, sweep_rows, robust_rows = known_results()
    summaries = []
    for folder in ("delay", "realtime", "sphere_sweep", "online_seeds"):
        path = RUNS / folder / "summary_table.json"
        if path.exists():
            summaries += json.loads(path.read_text())
    names = {
        "D1_ell_legacy_paced": "Ellipsoid · old map · real time",
        "R1_ell_incr_paced": "Ellipsoid · new map · real time",
        "D5_ell_incr_sync": "Ellipsoid · new map · no-delay reference",
        "D2_sph_legacy_paced": "Sphere · old map · real time",
        "R2_sph_incr_paced": "Sphere · new map · real time",
        "D6_sph_incr_sync": "Sphere · new map · no-delay reference",
        "S050_sph_sync": "Sphere, tighter ×0.5 · no-delay",
        "S025_sph_sync": "Sphere, tighter ×0.25 · no-delay",
        "S010_sph_sync": "Sphere, tighter ×0.1 · no-delay",
        "ell_seed1": "Ellipsoid · start seed 1 · real time",
        "ell_seed2": "Ellipsoid · start seed 2 · real time",
        "ell_seed4": "Ellipsoid · start seed 4 · real time",
        "sph_seed1": "Sphere · start seed 1 · real time",
        "sph_seed2": "Sphere · start seed 2 · real time",
        "sph_seed4": "Sphere · start seed 4 · real time",
    }
    seed_cases = {key for key in names if "seed" in key}
    sweep_cases = {key for key in names if key.startswith("S0")}
    order = {name: index for index, name in enumerate(names)}
    summaries.sort(key=lambda row: order.get(row["case"], 99))
    online_headers = ["Run", "Reached", "Final error (mm)", "Reached at (s)", "Maps published",
                      "Map age median (s)", "Map age p95 (s)", "Update time median (s)", "Proxies",
                      "Penetrating cycles"]
    main_names = {k: v for k, v in names.items() if k not in seed_cases | sweep_cases}
    online_table = table(online_headers, online_rows(summaries, main_names))
    sweep_table = table(online_headers, online_rows(
        summaries, {k: v for k, v in names.items() if k in sweep_cases or k == "D5_ell_incr_sync" or k == "D6_sph_incr_sync"}))
    seed_table = table(online_headers, online_rows(summaries, {k: names[k] for k in seed_cases}))
    tightness = json.loads((RUNS / "tightness.json").read_text())
    tightness_table = table(
        ["Trajectory", "Cells", "Cell size ratio new/old (median)", "Cell size ratio (99th pct)",
         "Old: cavity blocked (%)", "New: cavity blocked (%)", "Old: free height (mm)", "New: free height (mm)"],
        [[t["case"], t["new_cells"], fmt(t["longest_axis_ratio_p50"], 3), fmt(t["longest_axis_ratio_p99"], 3),
          fmt(100 * t["legacy_cavity_blocked"], 1), fmt(100 * t["new_cavity_blocked"], 1),
          fmt(t["legacy_narrowest_free_height_mm"], 1), fmt(t["new_narrowest_free_height_mm"], 1)]
         for t in tightness])
    geometry_rows = [[g["label"].replace("known_", "known ").replace("_", " "), g["proxies"],
                      fmt(100 * g["cavity_blocked_fraction"], 1), fmt(100 * g["approach_blocked_fraction"], 1),
                      fmt(100 * g["front_blocked_fraction"], 1), fmt(g["narrowest_free_height_mm"], 1)]
                     for g in sorted(geometry, key=lambda g: (g["label"].split("_")[1], g["proxies"]))]
    data = {"known_sweep": sweep, "html": {
        "table_online": online_table,
        "table_sphere_sweep": sweep_table,
        "table_seeds": seed_table,
        "table_tightness": tightness_table,
        "table_known": table(["Shape", "Cell size", "Proxies", "Reached", "Final error (mm)"], sweep_rows),
        "table_robust": table(["Shape", "Cell size", "Proxies", "Reached from 20 start poses",
                               "Trapped runs: median error (mm)"], robust_rows),
        "table_geometry": table(["Cover", "Proxies", "Cavity blocked (%)", "Approach corridor blocked (%)",
                                 "In front of opening blocked (%)", "Narrowest free height (mm)"], geometry_rows),
    }}
    cases = {("ell", "old"): RUNS / "delay" / "D1_ell_legacy_paced",
             ("sph", "old"): RUNS / "delay" / "D2_sph_legacy_paced",
             ("ell", "new"): RUNS / "realtime" / "R1_ell_incr_paced",
             ("sph", "new"): RUNS / "realtime" / "R2_sph_incr_paced",
             ("ell", "sync"): RUNS / "delay" / "D5_ell_incr_sync",
             ("sph", "sync"): RUNS / "delay" / "D6_sph_incr_sync"}
    figures = {
        "cost": fig_update_cost(), "history": fig_history(), "age": fig_map_age(cases),
        "sweep": fig_known_sweep(geometry, data["known_sweep"]), "slices": fig_slices(),
    }
    here = Path(__file__).resolve().parent
    template = (here / "report_template.html").read_text(encoding="utf-8").replace(
        "{{body}}", (here / "report_body.html").read_text(encoding="utf-8")
    )
    replacements = {f"{{{{fig_{k}}}}}": v for k, v in figures.items()}
    replacements.update({f"{{{{{k}}}}}": v for k, v in data["html"].items()})
    for key, value in replacements.items():
        template = template.replace(key, value)
    (OUT / "index.html").write_text(template, encoding="utf-8")
    print(OUT / "index.html")


if __name__ == "__main__":
    main()
