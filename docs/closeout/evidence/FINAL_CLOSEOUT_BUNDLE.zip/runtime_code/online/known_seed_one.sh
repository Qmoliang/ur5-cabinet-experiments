#!/bin/bash
# One known-cabinet run from a perturbed start pose.
# Usage: known_seed_one.sh <out_dir> <representation> <span> <seed> <first_cpu> [KEY=VALUE ...]
OUT=$1; rep=$2; span=$3; seed=$4; cpu=$5; shift 5
cd /mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6
id=${rep}_$(printf "%03d" $(python3 -c "print(round($span*1000))"))mm_seed$(printf "%02d" $seed)
mkdir -p $OUT
env "$@" UR5_KNOWN_CELL_SPAN=$span UR5_KNOWN_OUT=$OUT/$id UR5_START_SEED=$seed \
    OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MUJOCO_GL=egl \
  taskset -c $cpu-$((cpu+1)) timeout 7200 ~/envs/ur5cab/bin/python -c "
import sys, json, time
sys.path[:0] = ['src', 'src/core', '.']
import run
t = time.time()
s = run.run('$rep', maximum_cycles=3000)
keys = ('success', 'final_error_m', 'proxy_count', 'controller_ms_p50', 'controller_ms_p99',
        'penetrating_cycles', 'guidance_calls', 'guidance_plan_ms_total', 'guidance_failures')
print(json.dumps({k: s.get(k) for k in keys}), 'wall_s', round(time.time() - t, 1))
" > $OUT/$id.log 2>&1
