"""Exact per-cell publication. Every c+E(U)+B(r) input remains covered."""
from dataclasses import replace
import numpy as np

def cell_certificates(proxies):
    c=np.asarray(proxies.filtered_points,dtype=float);U=np.asarray(proxies.filtered_uncertainty_shapes,dtype=float);r=np.asarray(proxies.filtered_point_offsets,dtype=float)
    if U.shape!=(len(c),3,3) or r.shape!=(len(c),):raise ValueError('incomplete cell certificate data')
    if not np.all(np.isfinite(c)) or not np.all(np.isfinite(U)) or np.any(r<0):raise ValueError('invalid cell certificate')
    U=.5*(U+np.swapaxes(U,1,2));vals=np.linalg.eigvalsh(U);pad=np.maximum(1e-18-vals[:,0],0);Q=U+pad[:,None,None]*np.eye(3)[None]
    radius=np.sqrt(np.maximum(vals[:,-1]+pad,0));n=len(c);_,rot=np.linalg.eigh(Q)
    # No observation is removed; cell identity is the coverage proof, not a point-only approximation.
    result=replace(proxies,centers=c.copy(),sphere_radii=radius,base_sphere_radii=radius.copy(),ellipsoid_shapes=Q,base_ellipsoid_shapes=Q.copy(),ellipsoid_outer_shapes=Q.copy(),rotations=rot,cluster_keys=np.arange(n)[:,None],filtered_cluster_indices=np.arange(n),proxy_offset_radii=r.copy(),proxy_uncertainty_shapes=np.zeros_like(Q),proxy_ids=np.arange(n,dtype=np.int64),maximum_ellipsoid_overshoot=0.0,maximum_uncertainty_union_inflation=1.0,certificate_cover_mode='exact_cell_certificates',box_half_extents=np.zeros((n,3)))
    assert np.array_equal(result.centers,proxies.filtered_points) and np.array_equal(result.proxy_offset_radii,proxies.filtered_point_offsets)
    assert np.linalg.eigvalsh(Q-U).min(initial=0)>=-1e-20
    from automatic_partition import online_identity_quality
    online_identity_quality(result)
    return result
