"""E4 summary: online drawer, moving objects seen only by the fixed cameras.

Clean = reached within 5 mm (held 1 s) after every object has gone, no object
contact, no static penetration, joint speeds within limits.  k = 0 rows are the
paired no-object runs (same pipeline, detector running).  Counts use runs with
at least one launched object.  E3 causes for pairs that reach without objects
but fail with them:
  hit               an object touched the arm
  ghost             the arm ends limited by a map certificate outside the cabinet box
                    (object points that entered the static map)
  map on arm        a map publication put a certificate on the arm; infeasible to the end
  stall < 2 cm      not infeasible, within 2 cm of the target (the online last-mm stall)
  other
"""
import collections
import csv
import json
import sys
from pathlib import Path

import numpy as np

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else "/mnt/ssd2/hsjed/ur5_cabinet/v6runs/e4")
sys.path[:0] = ["/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6"]
from frontier import region_of_interest  # noqa: E402
import run_protocol_v3_async_online as online  # noqa: E402

ROI = region_of_interest(online._protocol_scene("camera_quarter").boxes)

runs = {}
for f in ROOT.glob("*_k*_v*/seed*/summary.json"):
    variant, count, speed = f.parent.parent.name.rsplit("_", 2)
    seed = int(f.parent.name[4:])
    s = json.load(open(f))
    if "e4" not in s:
        continue
    runs[(variant, int(count[1:]), float(speed[1:]), seed)] = (s, f.parent)


def launched(s):
    return any(d["launched"] for d in (s["e4"].get("objects") or {}).get("described", []))


def clean(s):
    e = s["e4"]
    ok = e["static_penetrating_cycles"] == 0 and e["peak_joint_ratio"] <= 1 + 1e-6
    if e["object_count"] == 0:
        return ok and e["first_success_5mm_s"] is not None
    return ok and bool(e["success_after"]) and e["object_contact_cycles"] == 0


def cause(s, run_dir):
    e = s["e4"]
    if e["object_contact_cycles"]:
        return "hit"
    inner = next(run_dir.glob("A-CV-*"))
    rows = list(csv.DictReader(open(inner / "cycles.csv")))
    tail = rows[-50:]
    infeasible = sum(not r["status"].lower().startswith("solved") for r in tail) > 25
    limiting = int(float(tail[-1]["limiting_proxy_id"]))
    if limiting >= 0:
        proxies = np.load(inner / "final_causal_proxies.npz")
        ids = proxies["proxy_ids"]
        hit = np.nonzero(ids == limiting)[0]
        if len(hit):
            c = proxies["centers"][hit[0]]
            if not np.all((c >= ROI[0]) & (c <= ROI[1])):
                return "ghost"
    if infeasible:
        start = next((i for i in range(len(rows)) if all(
            not rows[j]["status"].lower().startswith("solved") for j in range(i, min(i + 50, len(rows))))), None)
        if start is not None and rows[start]["perception_published"] == "True":
            return "map on arm"
        return "infeasible (other)"
    if float(tail[-1]["error_m"]) < 0.02:
        return "stall < 2 cm"
    return "other"


variants = sorted({k[0] for k in runs})
conditions = [(k, v) for k in (1, 2, 3) for v in (0.25, 0.5, 1.0)]
print(f"{ROOT}: {len(runs)} runs\n")
print("clean / runs with a launched object (k=0: reached / runs):")
print("  controller   " + "  ".join(["   k=0  "] + [f"k{k}@{v:4.2f}" for k, v in conditions]) + "   all k>0")
for var in variants:
    base = [clean(s) for (vv, k, v, sd), (s, _) in runs.items() if vv == var and k == 0]
    cells = [f"{sum(base):3d}/{len(base):<3d}"]
    total = [0, 0]
    for k, v in conditions:
        sel = [clean(s) for (vv, kk, vs, sd), (s, _) in runs.items() if vv == var and kk == k and vs == v and launched(s)]
        cells.append(f"{sum(sel):3d}/{len(sel):<3d}")
        total[0] += sum(sel)
        total[1] += len(sel)
    print(f"  {var:11s}  " + "  ".join(cells) + f"   {total[0]}/{total[1]}")

common = collections.defaultdict(dict)
for (vv, k, v, sd), (s, _) in runs.items():
    if k > 0:
        common[(k, v, sd)][vv] = (launched(s), clean(s))
shared = [key for key, d in common.items() if len(d) == len(variants) and all(x[0] for x in d.values())]
print(f"\ncases where every controller had a launched object: {len(shared)}")
for var in variants:
    print(f"  {var:11s} clean {sum(common[key][var][1] for key in shared)}/{len(shared)}")

print("\nhit-free (launched) / static penetration runs / peak joint speed ratio / peak TCP m/s / escape runs:")
for var in variants:
    sel = [s for (vv, k, v, sd), (s, _) in runs.items() if vv == var and k > 0 and launched(s)]
    if sel:
        print(f"  {var:11s} hit-free {sum(s['e4']['object_contact_cycles'] == 0 for s in sel)}/{len(sel)}  "
              f"static-pen {sum(s['e4']['static_penetrating_cycles'] > 0 for s in sel)}  "
              f"peakJ {max(s['e4']['peak_joint_ratio'] for s in sel):.2f}  "
              f"TCP {max(s['e4']['peak_tcp_speed'] for s in sel):.2f}  "
              f"escape {sum(s['e4']['escape_cycles'] > 0 for s in sel)}")

print("\nE3: reaches without objects (same controller and seed), fails with them -> cause:")
for var in variants:
    causes = collections.Counter()
    for (vv, k, v, sd), (s, d) in runs.items():
        if vv != var or k == 0 or not launched(s) or clean(s):
            continue
        base = runs.get((vv, 0, 0.0, sd))
        if base is None or not clean(base[0]):
            continue
        causes[cause(s, d)] += 1
    print(f"  {var:11s} " + ", ".join(f"{c}: {n}" for c, n in causes.most_common()))
print("  no-object failures:", {var: [sd for (vv, k, v, sd), (s, _) in runs.items()
                                     if vv == var and k == 0 and not clean(s)] for var in variants})

print("\nperception (fixed cameras only), all launched objects of all runs:")
objects = [po for (vv, k, v, sd), (s, _) in runs.items() if k > 0 for po in s["e4"]["per_object"] if po["launched"]]
delays = [po["detection_delay_s"] for po in objects if po["detection_delay_s"] is not None]
print(f"  launched objects {len(objects)}; never visible to the fixed cameras {sum(po['blind'] for po in objects)}; "
      f"visible but never detected {sum(po['missed'] for po in objects)}")
if delays:
    print(f"  detection delay (first visible -> first certificate at the controller): median {np.median(delays)*1000:.0f} ms, "
          f"p90 {np.percentile(delays, 90)*1000:.0f} ms, max {max(delays)*1000:.0f} ms")
rate = [po["matched_frames"] / po["visible_frames"] for po in objects if po["visible_frames"]]
print(f"  frames detected / frames visible: median {np.median(rate):.2f}")
for part in ("head", "handle"):
    values = [po[f"capture_coverage_{part}"] for po in objects if po.get(f"capture_coverage_{part}") is not None]
    print(f"  true {part} covered by certificates at capture time: mean {np.mean(values):.2f}")
by_behaviour = collections.defaultdict(list)
for po in objects:
    if po["detection_delay_s"] is not None:
        by_behaviour[po["behaviour"]].append(po["detection_delay_s"])
print("  median delay by behaviour:", {b: f"{np.median(v)*1000:.0f} ms" for b, v in by_behaviour.items()})
latency = [s["e4"]["detector_latency_ms_p50"] for (s, _) in runs.values() if s["e4"].get("detector_latency_ms_p50")]
compute = [s["e4"]["detector_compute_ms_p50"] for (s, _) in runs.values() if s["e4"].get("detector_compute_ms_p50")]
print(f"  detector latency capture->controller median {np.median(latency):.0f} ms; compute per frame median {np.median(compute):.0f} ms")
false = [(vv, sd) for (vv, k, v, sd), (s, _) in runs.items() if k == 0 and s["e4"]["frames_with_unmatched_tracks"] > 0]
print(f"  no-object runs with any false track: {len(false)}/{sum(1 for key in runs if key[1] == 0)}")
p99 = [s.get("controller_ms_p99") for (s, _) in runs.values() if s.get("controller_ms_p99")]
print(f"  controller p99 ms median {np.median(p99):.1f}")
