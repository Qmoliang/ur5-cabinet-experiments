"""E0: combined rule on the static benchmark vs LiuQP and NEO (ellipsoid, geodesic, 5 mm, same 280 tasks)."""
import collections
import glob
import json
from pathlib import Path

import numpy as np

V = Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs")
sources = {
    "liuqp (bench)": V / "bench" / "liuqp",
    "neo_matched (bench)": V / "bench" / "neo_matched",
    "neo_paper (bench)": V / "bench" / "neo_paper",
    "combined": V / "e0" / "combined",
    "combined fixed tau": V / "e0" / "combined_fixedtau",
}
table = collections.defaultdict(dict)
for name, root in sources.items():
    for f in glob.glob(str(root / "*_ellipsoid_geodesic_native_seed*" / "summary.json")):
        p = Path(f)
        scene = p.parent.name.split("_ellipsoid_")[0]
        seed = int(p.parent.name.rsplit("_seed", 1)[1])
        s = json.load(open(f))
        table[name][(scene, seed)] = (bool(s["success"]), s.get("exact_penetrating_cycles", 0), p.parent)
scenes = sorted({k[0] for k in table["liuqp (bench)"]})
print("reached /20 (5 mm), ellipsoid + geodesic:")
print(f"  {'scene':20s} " + " | ".join(f"{n[:18]:>18s}" for n in sources))
for scene in scenes:
    cells = []
    for name in sources:
        rows = [v for (sc, sd), v in table[name].items() if sc == scene]
        cells.append(f"{sum(r[0] for r in rows):>15d}/{len(rows):<2d}" if rows else f"{'-':>18s}")
    print(f"  {scene:20s} " + " | ".join(cells))
print("  " + "TOTAL".ljust(20) + " " + " | ".join(
    f"{sum(v[0] for v in table[n].values()):>14d}/{len(table[n]):<3d}" for n in sources))
print("\nruns with any penetrating contact:", {n: sum(v[1] > 0 for v in table[n].values()) for n in sources})
identical = 0
compared = 0
for key, (_ok, _pen, d) in table["combined"].items():
    ref = table["liuqp (bench)"].get(key)
    if ref is None:
        continue
    compared += 1
    a, b = np.load(d / "q_history.npy"), np.load(ref[2] / "q_history.npy")
    identical += a.shape == b.shape and np.array_equal(a, b)
print(f"combined trajectories bit-identical to LiuQP: {identical}/{compared}")
