from pathlib import Path
import json,numpy as np,hashlib,shutil
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_reheading_study_20261107'
s=(ROOT/'pilot_worker_reheading.py').read_text();token="        if job.get('policy_version')=='reheading_v2':";assert token in s;s=s.replace(token,"        if job.get('policy_version')=='continuation':\n            from continuation_policy import LowDimPolicy\n        elif job.get('policy_version')=='reheading_v2':");(ROOT/'pilot_worker_continuation.py').write_text(s)
s=(ROOT/'launch_batch.py').read_text().replace("ROOT/'pilot_worker.py'","ROOT/'pilot_worker_continuation.py'");(ROOT/'launch_continuation.py').write_text(s)
base=json.loads((OLD/'trials/reheading_v2_measured_2/job.json').read_text());base.pop('cpus',None)
jobs=[]
for name in ['reheading_v2_measured_1','reheading_v2_measured_2','reheading_v2_original_start']:
 f=OLD/'trials'/name;z=np.load(f/'trajectory.npz');ticks=np.maximum(1,np.ceil(z['controller_ms']/20-1e-9)).astype(np.int64);np.save(ROOT/(name+'_delay.npy'),ticks)
 j=json.loads((f/'job.json').read_text());j.pop('cpus',None);j.update(latency_ticks_file=str(ROOT/(name+'_delay.npy')),policy_version='continuation',name='continuation_'+name.replace('reheading_v2_',''))
 jobs.append(j)
(ROOT/'development_jobs.json').write_text(json.dumps(jobs[:2],indent=2))
(ROOT/'candidate_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'DELAY_PROVENANCE.json').write_text(json.dumps({n:str(OLD/'trials'/n/'trajectory.npz') for n in ['reheading_v2_measured_1','reheading_v2_measured_2','reheading_v2_original_start']},indent=2))
archive=ROOT/'revisions/continuation_v1';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
print(json.dumps(jobs,indent=2))
