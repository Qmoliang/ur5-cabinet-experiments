from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent;z=dict(np.load(R/'trials/exact_failure_trace/decision_trace.npz'));n=np.diff(z['offsets']);print('trace',len(n),'rows',len(z['h']),'row percentiles',np.percentile(n,[0,50,99,100]).tolist(),'largest fractions',len(np.unique(z['fraction'])))
# First-order attribution is exact arithmetic on recorded models and actual q.
t=dict(np.load(R/'trials/exact_failure_trace/trajectory.npz'));r=[]
for i,k in enumerate(z['cycles']):
 a,b=z['offsets'][i:i+2]
 if a==b:continue
 h=z['h'][a:b];B=z['b'][a:b];base=h.min();r.append(dict(cycle=int(k),pred=float(min(h+.02*B@z['proposed'][i])-base),actual_linear=float(min(h+B@(t['q'][k+1]-t['q'][k]))-base),same=bool(z['applied_ids'][k]==i)))
pos=[x for x in r if x['pred']>1e-9];out=dict(decisions=len(r),positive_predictions=len(pos),positive_prediction_applied_nonpositive=sum(x['actual_linear']<=1e-9 for x in pos),request_not_executed_immediately=sum(not x['same'] for x in r))
(R/'LINEAR_DELAY_ATTRIBUTION.json').write_text(json.dumps(out,indent=2));print(out)
