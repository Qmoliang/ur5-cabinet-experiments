#!/bin/bash
# Live online drawer with finer certificates: CenterVox 5 mm, with 5 mm
# unseen cells and two fixed external cameras; frontier + geodesic + active looking; 20 start poses; 7 at a time.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export UR5_CENTERVOX=0.005 UR5_STATIC_DEDUP=1 UR5_FIT_WORKERS=8 UR5_FRONTIER_MERGE=1 UR5_FRONTIER_FINE_RADIUS=0.15
OUT=v6runs/online_fast9; mkdir -p $OUT
jobs=()
for seed in $(seq 1 20); do jobs+=("f5s $seed"); done
run() { # variant seed slot
  local cells=1; [ $1 = f10 ] && cells=2
  local id=${1}_seed$(printf "%02d" $2)
  UR5_FRONTIER_CELL_VOXELS=$cells systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID \
    -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_CENTERVOX -E UR5_FRONTIER_CELL_VOXELS -E UR5_STATIC_DEDUP -E UR5_FIT_WORKERS -E UR5_FRONTIER_MERGE -E UR5_FRONTIER_FINE_RADIUS \
    timeout 2400 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py ellipsoid --map incremental \
    --timing paced --cpus $(($3 * 16)):16 --start-seed $2 --frontier --geodesic --look --static-cameras low_side --out $OUT/$id > $OUT/$id.log 2>&1
}
for ((start = 0; start < ${#jobs[@]}; start += 7)); do
  for slot in 0 1 2 3 4 5 6; do
    index=$((start + slot)); [ $index -lt ${#jobs[@]} ] || break
    run ${jobs[$index]} $slot &
  done
  wait
done
echo DONE > $OUT/FAST9_DONE
# then two runs alone on 32 CPUs each (deployment-like timing)
mkdir -p v6runs/online_fast9_alone
for s in 7 8; do slot=$((s-7)); UR5_FRONTIER_CELL_VOXELS=1 systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS -E UR5_CENTERVOX -E UR5_FRONTIER_CELL_VOXELS -E UR5_STATIC_DEDUP -E UR5_FIT_WORKERS -E UR5_FRONTIER_MERGE -E UR5_FRONTIER_FINE_RADIUS timeout 2400 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py ellipsoid --map incremental --timing paced --cpus $((slot*32)):32 --start-seed $s --frontier --geodesic --look --static-cameras low_side --out v6runs/online_fast9_alone/seed0$s > v6runs/online_fast9_alone/seed0$s.log 2>&1 & done
wait
echo DONE > v6runs/online_fast9_alone/ALONE_DONE
