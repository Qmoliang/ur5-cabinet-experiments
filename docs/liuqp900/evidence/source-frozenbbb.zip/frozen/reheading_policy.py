"""Re-anchor an exhausted transported heading to the target-side frame.

Candidates are instantaneous velocities in a local tangent plane. No future
configuration, path, tree, RRT call, or successful trajectory is used.
"""
import numpy as np
from goal_entry_policy_activated import LowDimPolicy as Previous

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        qb=np.asarray(self.port['backward_configuration_for_certificate_only'])
        self.entry_points=self.ctx.guard.positions(qb).copy()
        self.reheading_attempts=[];self.reheading_events=[];self.pending_reheading=None
        self.old_heading_rejections=0;self.taboo_rejections=0
    def _entry_point(self):
        kind,i,j=self.blocker_id
        return self.entry_points[j]-self.entry_points[i] if kind=='self' else self.entry_points[i]
    def _local_key(self,geometry):
        kind,i,j=self.blocker_id
        body_key=(kind,int(i),int(j)) if kind=='self' else ('environment' if kind in ('collision','frontier') else kind,int(i))
        episode=-1 if self.pending_memory is None else self.pending_memory['hit_cycle']
        return body_key,episode,np.r_[self.feature(self.q),geometry[0]]
    def _already_tried(self,label,key):
        body,episode,state=key
        # Same physical task resolution as the original arrival criterion.
        # This stores observed state/choice pairs, not a graph of configurations.
        for item in self.reheading_attempts:
            if item['body']==body and item['episode']==episode and item['label']==label and np.linalg.norm(state-item['state'])<=1e-3:return True
        return False
    def _surface_action(self,c,s,arrays,geometry):
        inherited=super()._surface_action(c,s,arrays,geometry)
        if inherited is not None:return inherited
        self.old_heading_rejections+=1
        if self.circulation_tangent is None or self.k-self.feature_last_progress<100 or np.max(np.abs(self.previous))>1e-8:return None
        point,n,Jpoint,gap=geometry;old=self._tangent(geometry).copy()
        toward=self._goal_point_for_blocker()-point;goal=toward-n*(n@toward)
        if np.linalg.norm(goal)<1e-8:
            toward=self._entry_point()-point;goal=toward-n*(n@toward)
        if np.linalg.norm(goal)<1e-8:return None
        goal/=np.linalg.norm(goal);orthogonal=np.cross(n,goal);orthogonal/=np.linalg.norm(orthogonal)
        entry_side=1. if orthogonal@(self._entry_point()-point)>=0 else -1.
        candidates=[('goal_tangent',goal),('entry_side',entry_side*orthogonal),('other_entry_side',-entry_side*orthogonal),('reverse_goal_tangent',-goal)]
        key=self._local_key(geometry);tests=[]
        for label,tangent in candidates:
            if self._already_tried(label,key):self.taboo_rejections+=1;continue
            # Do not simply retry the just-rejected vector at floating-point resolution.
            if np.linalg.norm(tangent-old)*c.max_task_speed*self.dt<=2e-7:
                tests.append(dict(label=label,reason='equivalent_to_rejected_heading'));continue
            self.tangent_override=tangent
            try:chosen=self._try_direction(c,s,arrays,tangent@Jpoint)
            finally:self.tangent_override=None
            tests.append(dict(label=label,certified=chosen is not None))
            if chosen is None:continue
            self.reheading_attempts.append(dict(body=key[0],episode=key[1],state=key[2].copy(),label=label))
            item=dict(cycle=self.k,episode=key[1],row_id=list(self.blocker_id),label=label,old_tangent=old.tolist(),new_tangent=tangent.tolist(),angle_deg=float(np.degrees(np.arccos(np.clip(old@tangent,-1,1)))),safe_scale=chosen[1][1],memory_count=len(self.memories),candidate_tests=tests)
            self.pending_reheading=item
            return chosen,tangent,1.
        return None
    def _use_tangent(self,tangent,sign):
        if self.pending_reheading is None:return super()._use_tangent(tangent,sign)
        item=self.pending_reheading;self.pending_reheading=None
        self.circulation_tangent=tangent.copy();self.reverse_used=False;self.no_action_start=None
        # This new directional trial must be judged by subsequent executed
        # progress; do not inherit the exhausted heading's timeout.
        self.full_posture_best=float(np.sqrt(self.error**2+self.posture_lever**2*np.sum((self.q-self.qg)**2)))
        self.full_posture_last_progress=self.k;self.feature_last_progress=self.k
        self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8
        self.reheading_events.append(item);self.emit('target_end_heading_reanchored',**{k:v for k,v in item.items() if k!='cycle'})
    def summary(self):
        out=super().summary();out.update(reheading_events=self.reheading_events,reheading_count=len(self.reheading_events),old_heading_rejections=self.old_heading_rejections,taboo_rejections=self.taboo_rejections,heading_memory='do not repeat the same target-frame choice at the same observed local state within an escape episode',reheading_scope='four directions in the current tangent plane, current-velocity QPs and original certificates only',no_return_constraints_discarded=0)
        return out
