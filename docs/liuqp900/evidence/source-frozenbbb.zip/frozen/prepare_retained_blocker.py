"""Persist the actual observed primitive when the QP pruner changes rows."""
from pathlib import Path
import json,hashlib,shutil,ast
ROOT=Path(__file__).resolve().parent
archive=ROOT/'revisions/blocker_v5';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
source=(ROOT/'blocker_policy_v4.py').read_text();tree=ast.parse(source)
cls=next(x for x in tree.body if isinstance(x,ast.ClassDef));node=next(x for x in cls.body if isinstance(x,ast.FunctionDef) and x.name=='__call__');method='    '+ast.get_source_segment(source,node)+'\n'
old='''        lookup={tuple(row):i for i,row in enumerate(s['row_ids'])}
        i=lookup.get(self.blocker_id)
        if i is None:
            self.emit('blocker_no_longer_active',row_id=list(self.blocker_id));self.switch('RESERVE_GOAL','selected_geometry_left_active_set');self.blocker_id=None
            return np.zeros(6) if self.brake_pending else OriginalControl.__call__(self,c,s,arrays)
        H,g,A,l,u=arrays;norm=np.linalg.norm(A[i]);b=-A[i]/max(norm,1e-12)'''
new='''        H,g,A,l,u=arrays
        geometry=self._retained_geometry(c,s,arrays)
        if geometry is None:
            self.rejections['retained_geometry_unavailable']+=1;self.brake_pending=True;return np.zeros(6)
        b,norm,gap=geometry
        if gap+c.safety_margin>=c.near_distance:
            self.emit('retained_geometry_cleared',row_id=list(self.blocker_id),surface_gap_m=gap+c.safety_margin,error_m=self.error)
            self.switch('RESERVE_GOAL','measured_clearance_reached_original_near_distance');self.blocker_id=None
            return np.zeros(6) if self.brake_pending else OriginalControl.__call__(self,c,s,arrays)'''
assert old in method;method=method.replace(old,new).replace('float(self.dt*u[i])','float(gap)')
prefix='''"""Current observed geometry survives pruning of its instantaneous QP row."""
import numpy as np
import mujoco
from scipy.optimize import linprog
from blocker_policy_v5 import LowDimPolicy as Previous
from polished_policy import LowDimPolicy as OriginalControl

class LowDimPolicy(Previous):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        # Read only already-observed proxy identifiers; never read archive path.
        with np.load(self.ctx.entry['input_file']) as z:ids=z['ids'].copy()
        self.proxy_index={int(key):i for i,key in enumerate(ids)}
        self.retained_geometry_queries=0;self.pruned_row_continuations=0
    def _retained_geometry(self,c,s,arrays):
        kind,robot,identifier=self.blocker_id
        lookup={tuple(row):i for i,row in enumerate(s['row_ids'])}
        row=lookup.get(self.blocker_id)
        if kind not in ('collision','frontier'):
            if row is None:return None
            a=arrays[2][row];norm=np.linalg.norm(a)
            return -a/max(norm,1e-12),norm,float(self.dt*arrays[4][row])
        index=self.proxy_index.get(int(identifier))
        if index is None:return None
        guard=self.ctx.guard;pg=self.ctx.proxy_guard;points=guard.positions(self.q);point=points[int(robot)].copy()
        distance,normal=pg.point_geometry(point[None,:],np.array([index]))
        mujoco.mj_comPos(guard.model,guard.data)
        jp=np.zeros((3,guard.model.nv));jr=np.zeros_like(jp)
        mujoco.mj_jac(guard.model,guard.data,jp,jr,point,int(guard.bodies[int(robot)]))
        a=normal[0]@jp[:,:6];norm=float(np.linalg.norm(a))
        if norm<1e-12:return None
        self.retained_geometry_queries+=1;self.pruned_row_continuations+=int(row is None)
        return -a/norm,norm,float(distance[0]-guard.radii[int(robot)]-c.safety_margin)
'''
suffix='''    def summary(self):
        out=super().summary();out.update(retained_geometry_queries=self.retained_geometry_queries,pruned_row_continuations=self.pruned_row_continuations,geometric_exit='measured original near-distance clearance, or task progress without reclosure; row disappearance is not an exit')
        return out
'''
(ROOT/'retained_blocker_policy.py').write_text(prefix+method+suffix)
compile(prefix+method+suffix,'retained_blocker_policy.py','exec')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='blocker_v5':";new="        if job.get('policy_version')=='retained_blocker':\n            from retained_blocker_policy import LowDimPolicy\n        elif job.get('policy_version')=='blocker_v5':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'blocker_v5_jobs.json').read_text())
for j in jobs:j['name']=j['name'].replace('blocker_v5_joint_only','retained_blocker');j['policy_version']='retained_blocker'
(ROOT/'retained_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'RETAINED_GEOMETRY_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='recompute selected primitive distance and Jacobian from the same observed map even if its row leaves the current pruned QP; exit by measured geometry/task progress, not row membership; no added future configuration variables'),indent=2))
print(json.dumps(jobs))
