"""A racket that swings at the arm: a moving obstacle for LiuQP and NEO.

The racket (26 x 26 x 2 cm head face-on to its motion, 30 cm handle trailing
behind it) is parked far away until
`trigger_s`.  It then starts `start_distance` from the arm's elbow on the side
`-direction`, moves along `direction` at `speed` until it is `overshoot` past
where the elbow was (so it would hit an arm that did not move), stays `dwell_s`,
and withdraws the same way.  Pure translation: its certificate cover is built
once in its own frame and shifted.

The controllers get the racket where it will be at the end of the control
step (t + dt).  With a separating plane n (robot -> obstacle) that adds the
relative-velocity term n.v_racket * dt to the clearance, so an approaching
racket forces the arm to move away; neither controller's core changes.
MuJoCo carries the racket as a mocap body, so contacts with it are detected.
"""
from __future__ import annotations

import os
from dataclasses import replace

import numpy as np

from known_volume import build_volume_cover
from robot import BoxObstacle, DT, certificate_world_positions

PARK = np.array([5.0, 5.0, 5.0])


def env_direction():
    d = np.array([float(v) for v in (os.environ.get("UR5_RACKET_DIR") or "0,0,-1").split(",")])
    return d / np.linalg.norm(d)


def _geometry(direction):
    """Head face-on to the motion (thin along the dominant motion axis), handle trailing behind it."""
    axis = int(np.argmax(np.abs(direction)))
    head = np.full(3, 0.13)
    head[axis] = 0.01
    handle = np.full(3, 0.015)
    handle[axis] = 0.15
    offset = np.zeros(3)
    offset[axis] = -np.sign(direction[axis]) * 0.28
    return tuple(head.tolist()), tuple(handle.tolist()), tuple(offset.tolist())


def local_boxes(direction=None):
    head, handle, offset = _geometry(env_direction() if direction is None else direction)
    return (BoxObstacle("racket_head", (0.0, 0.0, 0.0), head, "shelf"),
            BoxObstacle("racket_handle", offset, handle, "shelf"))


def mjcf_body() -> str:
    head, handle, offset = (" ".join(map(repr, v)) for v in _geometry(env_direction()))
    park = " ".join(map(repr, PARK))
    return (f'\n    <body name="racket" mocap="true" pos="{park}">'
            f'\n      <geom name="racket_head" type="box" size="{head}" rgba=".9 .3 .1 1" contype="1" conaffinity="1" />'
            f'\n      <geom name="racket_handle" type="box" pos="{offset}" size="{handle}" rgba=".3 .2 .1 1" contype="1" conaffinity="1" />'
            f'\n    </body>')


class Racket:
    def __init__(self, model, robot, representation, cell_span, *, direction, trigger_s=6.0, speed=0.5,
                 start_distance=0.45, overshoot=0.10, dwell_s=1.0, aim_body="forearm_link"):
        self.model = model
        self.robot = robot
        self.direction = np.asarray(direction, dtype=float) / np.linalg.norm(direction)
        self.cover = build_volume_cover(local_boxes(self.direction), representation, cell_span)
        self.trigger_s, self.speed = float(trigger_s), float(speed)
        self.start_distance, self.overshoot, self.dwell_s = float(start_distance), float(overshoot), float(dwell_s)
        self.aim_body = model.body(aim_body).id
        self.mocap = model.body("racket").mocapid[0]
        self.start = None
        self.travel = self.start_distance + self.overshoot
        self.move_s = self.travel / self.speed
        self.min_distance = np.inf
        self.event_reference = None
        self.max_retreat = 0.0
        self.max_dodge = 0.0  # largest move of any robot sphere along the racket's motion (out of its way)

    @classmethod
    def from_env(cls, model, robot, representation, cell_span):
        direction = env_direction().tolist()
        return cls(model, robot, representation, cell_span, direction=direction,
                   trigger_s=float(os.environ.get("UR5_RACKET_TRIGGER") or "6.0"),
                   speed=float(os.environ.get("UR5_RACKET_SPEED") or "0.5"))

    def position(self, t):
        if self.start is None or t < self.trigger_s:
            return None
        s = t - self.trigger_s
        if s < self.move_s:
            return self.start + self.direction * self.speed * s
        if s < self.move_s + self.dwell_s:
            return self.start + self.direction * self.travel
        s -= self.move_s + self.dwell_s
        if s < self.move_s:
            return self.start + self.direction * (self.travel - self.speed * s)
        return None

    def velocity(self, t):
        """Racket velocity at time t (zero while parked or dwelling)."""
        if self.start is None or t < self.trigger_s:
            return np.zeros(3)
        s = t - self.trigger_s
        if s < self.move_s:
            return self.direction * self.speed
        if s < self.move_s + self.dwell_s:
            return np.zeros(3)
        if s < 2 * self.move_s + self.dwell_s:
            return -self.direction * self.speed
        return np.zeros(3)

    def arm_at_trigger(self, data, t):
        if self.start is None and t >= self.trigger_s - 1e-9:
            aim = data.xpos[self.aim_body].copy()
            positions = certificate_world_positions(data, self.robot)
            # Start `start_distance` beyond the arm's farthest sphere on the
            # approach side (not just beyond the elbow), so the racket never
            # starts inside the arm; it still travels `overshoot` past the elbow.
            behind = max(0.0, float(np.max((aim - positions) @ self.direction)))
            reach = behind + self.start_distance
            self.start = aim - reach * self.direction
            self.travel = reach + self.overshoot
            self.move_s = self.travel / self.speed
            self.event_reference = positions.copy()

    def world_cover(self, t):
        """Racket certificates at time t (None while parked)."""
        p = self.position(t)
        if p is None:
            return None
        return replace(self.cover, centers=self.cover.centers + p)

    def place(self, data, t):
        p = self.position(t)
        data.mocap_pos[self.mocap] = PARK if p is None else p

    def measure(self, data, t):
        """True clearance from every robot certificate sphere to the racket boxes."""
        p = self.position(t)
        if p is None:
            return None
        positions = certificate_world_positions(data, self.robot)
        radii = np.array([s.radius for s in self.robot])
        best = np.inf
        for b in local_boxes(self.direction):
            lo = p + np.asarray(b.center) - np.asarray(b.half_size)
            hi = p + np.asarray(b.center) + np.asarray(b.half_size)
            d = np.linalg.norm(np.maximum(0, np.maximum(lo - positions, positions - hi)), axis=1) - radii
            best = min(best, float(d.min()))
        self.min_distance = min(self.min_distance, best)
        if self.event_reference is not None:
            self.max_retreat = max(self.max_retreat,
                                   float(np.max(np.linalg.norm(positions - self.event_reference, axis=1))))
            self.max_dodge = max(self.max_dodge,
                                 float(np.max((positions - self.event_reference) @ self.direction)))
        return best


def combined_cover(static_cover, racket_cover):
    """Static cover followed by the racket's certificates (racket last)."""
    fields = ("centers", "sphere_radii", "ellipsoid_shapes", "aabb_half_extents", "cell_half_extents", "box_indices")
    joined = {}
    for name in fields:
        a, b = getattr(static_cover, name), getattr(racket_cover, name)
        if a is not None and b is not None:
            joined[name] = np.concatenate([np.asarray(a), np.asarray(b)])
    first = int(np.max(static_cover.proxy_ids)) + 1
    joined["proxy_ids"] = np.concatenate([np.asarray(static_cover.proxy_ids),
                                          first + np.arange(len(racket_cover.centers))])
    return replace(static_cover, **joined)
