import pathlib,sys,os,json,csv,hashlib,time
os.environ.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
import numpy as np,mujoco
S=pathlib.Path('/mnt/ssd2/hsjed/ur5_cabinet/v6runs/unified_static_20261102');entry=json.loads((S/'entries'/(sys.argv[1]+'.json')).read_text());case=pathlib.Path(sys.argv[2]);code=pathlib.Path(json.loads((case/'job.json').read_text())['code_root'])/'online';sys.path[:0]=[str(code.parent/'common'),str(code)];import run_protocol_v3_async_online as online
from pathlib import Path as _AuditPath; AUDIT=_AuditPath(os.environ.get('AUDIT_OUTPUT_DIR',str(S/'audits')));AUDIT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from independent_geometry import IndependentGuard
run=next(case.glob('A-CV-*'));d=json.load(open(case/'summary.json'));cfg=json.load(open(case/'case.json'));q=np.vstack([cfg['initial_configuration'],np.load(run/'q_history.npy')]);model=mujoco.MjModel.from_xml_path(str(run/'scene.xml'));robot=[x for x in online.build_robot_certificate(model) if model.body_mocapid[x.body_id]<0];data=mujoco.MjData(model);body=np.array([x.body_id for x in robot]);lc=np.array([x.local_center for x in robot]);r=np.array([x.radius for x in robot]);target=np.asarray(entry['target']);scene=json.loads((S/'scenes'/(entry['task']+'.json')).read_text());bc=np.array([b['center'] for b in scene['boxes']]);bh=np.array([b['half_size'] for b in scene['boxes']]);parent=model.body_parentid
lever=[]
for b,x in zip(body,lc):
 length=np.linalg.norm(x);b=int(b)
 while b:
  length+=np.linalg.norm(model.body_pos[b]);j0=model.body_jntadr[b]
  for j in range(j0,j0+model.body_jntnum[b]):length+=2*np.linalg.norm(model.jnt_pos[j])
  b=int(parent[b])
 lever.append(length)
K=2*max(lever)
def pos(qi):
 data.qpos[:6]=qi;mujoco.mj_kinematics(model,data);return data.xpos[body]+np.einsum('nij,nj->ni',data.xmat[body].reshape(-1,3,3),lc)
positions=[];fk=[];site=model.site('attachment_site').id
for qi in q:
 positions.append(pos(qi));fk.append(data.site_xpos[site].copy())
positions=np.asarray(positions);fk=np.asarray(fk);ee=np.load(run/'ee_history.npy');assert ee.shape==fk[1:].shape
fk_difference=float(np.max(np.linalg.norm(ee-fk[1:],axis=1)));assert fk_difference<1e-9,'saved end-effector trace disagrees with independent FK'
errors=np.linalg.norm(fk[1:]-target,axis=1);hold=best=0;confirmed=None
for i,e in enumerate(errors):
 hold=hold+1 if e<.001 else 0;best=max(best,hold)
 if hold>=50 and confirmed is None:confirmed=(i+1)*.02
v=np.diff(q,axis=0)/.02;acc=np.diff(np.vstack([np.zeros(6),v]),axis=0)/.02
from continuous_robot_audit import audit_motion
p0=positions[0];pairs=np.array([(i,j) for i in range(len(r)) for j in range(i+1,len(r)) if body[i]!=body[j] and parent[body[i]]!=body[j] and parent[body[j]]!=body[i] and np.linalg.norm(p0[j]-p0[i])-r[i]-r[j]>=.005]);motion=audit_motion(q,positions,r,bc,bh,pairs,K,pos);physical_bad=motion['bad_intervals'];physical_min=motion['minimum_environment_m']
z=np.load(run/'causal_proxy_snapshots.npz');arr={k:z[k] for k in z.files};cz=np.load(run/'causal_centervox_snapshots.npz');cells={k:cz[k] for k in ('offsets','points','uncertainty_shapes','scalar_offsets')};frames=list(csv.DictReader(open(run/'perception_frames.csv')));assert d['representation']=='sphere' and cfg['representation']=='sphere';assert all(f['environment_representation']=='sphere' and f['active_view_representation']=='sphere' for f in frames);minimum=np.inf;bad=[];subdivisions=0;identity=True;refdiff=0.;start=time.perf_counter()
for k,c0 in enumerate(arr['publish_cycles']):
 lo,hi=arr['offsets'][k:k+2];sl=slice(lo,hi);c1=int(arr['publish_cycles'][k+1]) if k+1<len(arr['publish_cycles']) else len(q)-1;C=arr['centers'][sl];Q=arr['ellipsoid_shapes'][sl];off=arr['uncertainty_offsets'][sl];boxes=arr['box_half_extents'][sl];sphere=arr['sphere_radii'][sl];assert np.all(np.isfinite(sphere)) and np.all(sphere>=0);mask=np.any(boxes>0,axis=1);n=int(np.flatnonzero(mask)[0]) if np.any(mask) else len(C);cl,ch=cells['offsets'][k:k+2];assert np.allclose(sphere[:n],np.sqrt(np.maximum(np.linalg.eigvalsh(Q[:n])[:,-1],0)),rtol=1e-10,atol=1e-12),'sphere radius differs from matched enclosing ball'
 identity=identity and n==ch-cl and np.array_equal(C[:n],cells['points'][cl:ch]) and np.array_equal(off[:n],cells['scalar_offsets'][cl:ch]) and np.linalg.eigvalsh(Q[:n]-cells['uncertainty_shapes'][cl:ch]).min(initial=0)>=-1e-15 and np.all(sphere[:n]+1e-12>=np.sqrt(np.maximum(np.linalg.eigvalsh(Q[:n])[:,-1],0))) and np.allclose(boxes[n:],.0025,atol=1e-12) and int(frames[k]['frontier_cells'])==len(C)-n
 assert not np.any(arr['proxy_uncertainty_shapes'][sl]),'cell uncertainty must be folded into Q, not omitted'
 digest=hashlib.sha256(b''.join(np.ascontiguousarray(x).tobytes() for x in (C,Q,off,boxes))).hexdigest();assert digest==frames[k]['proxy_snapshot_sha256']
 g=IndependentGuard(C,Q,off,sphere,boxes,d['representation']);local_worst=np.inf;local_q=None
 def state(qi,p=None):
  global minimum,local_worst,local_q
  p=pos(qi) if p is None else p;value=min(.020,g.certify(p,p,r+.020)+.020);minimum=min(minimum,value)
  if value<local_worst:local_worst=value;local_q=qi.copy()
  return value
 def interval(a,b,pa,pb,depth=0):
  global subdivisions
  pad=K*np.sum(np.abs(b-a))**2/8+1e-10
  if g.certify(pa,pb,r+.006+pad)>=-1e-7:return True
  if depth>=10:return False
  subdivisions+=1;m=(a+b)*.5;pm=pos(m)
  if state(m,pm)<.006-1e-7:return False
  return interval(a,m,pa,pm,depth+1) and interval(m,b,pm,pb,depth+1)
 state(q[int(c0)],positions[int(c0)])
 for c in range(int(c0),c1):
  val=state(q[c+1],positions[c+1])
  if val<.006-1e-7 or not interval(q[c],q[c+1],positions[c],positions[c+1]):bad.append(dict(cycle=c,generation=k,gap_mm=val*1000))
 reference=g.reference_gap(pos(local_q),r);refdiff=max(refdiff,abs(reference-local_worst))
 if k%10==0:print('audit',case.name,k,'/',len(arr['publish_cycles']),'min_mm',minimum*1000,flush=True)
result=dict(case=str(case),representation=d['representation'],guidance=d['guidance']['mode'],cycles=len(q)-1,success_1mm_50=best>=50,first_completion_sim_s=confirmed,final_error_mm=float(errors[-1]*1000),max_hold=best,required_margin_m=.006,minimum_proxy_gap_mm=minimum*1000,continuous_proxy_passed=not bad and minimum>=.006-1e-7,failed_intervals=bad,physical_state_min_mm=physical_min*1000,physical_and_self_continuous_passed=not physical_bad,physical_failed_intervals=physical_bad,peak_acceleration=float(np.abs(acc).max()),cell_coverage_identity_passed=bool(identity),all_coverage_checks=d['all_centervox_coverage_checks_passed'],all_mvt_checks=d['all_mvt_oracle_checks_passed'],reference_max_difference_m=refdiff,execution_guard_failed=d['execution_guard']['failed'],subdivisions=subdivisions,audit_wall_s=time.perf_counter()-start)
result['goal_fk_verified']=True;result['goal_fk_max_difference_m']=fk_difference
result['strict_success']=result['success_1mm_50'] and result['cycles']<=int(cfg.get('policy',{}).get('maximum_cycles',6000)) and result['continuous_proxy_passed'] and result['physical_and_self_continuous_passed'] and d['exact_penetrating_cycles']==0 and result['peak_acceleration']<=10.0001 and result['cell_coverage_identity_passed'] and result['all_coverage_checks'] and result['all_mvt_checks'] and result['execution_guard_failed']==0
# Joint-position, velocity and discrete braking viability, from actual recorded commands.
qlow=model.jnt_range[:6,0]+.015;qhigh=model.jnt_range[:6,1]-.015;speed=np.abs(v).copy();travel=np.zeros_like(speed)
while np.max(speed)>1e-15:
 travel+=.02*speed;speed=np.maximum(speed-.2,0)
stop=q[:-1]+np.sign(v)*travel;joint_slack=float(np.min(np.r_[(q-qlow).ravel(),(qhigh-q).ravel()]));braking_slack=float(np.min(np.r_[(stop-qlow).ravel(),(qhigh-stop).ravel()]));velocity_ratio=float(np.max(np.abs(v)/np.array([1,1,1,1.4,1.4,1.4])));joint_ok=joint_slack>=-1e-10 and braking_slack>=-1e-10 and velocity_ratio<=1+1e-9
result.update(motion_audit_method=motion['method'],environment_continuous_passed=motion['environment_passed'],self_certificate_continuous_passed=motion['self_passed'],motion_failure_witnesses=motion['witnesses'],selected_self_state_min_mm=motion['minimum_self_m']*1000,joint_position_and_braking_passed=bool(joint_ok),minimum_joint_slack_rad=joint_slack,minimum_braking_slack_rad=braking_slack,peak_velocity_ratio=velocity_ratio)
from audit_shared_inputs import audit_workspace
workspace=audit_workspace(q,positions,r,K,pos)
result['workspace_audit']=workspace
result['strict_success']=bool(result['strict_success'] and joint_ok and workspace['passed'])
result['trajectory_safety_and_goal_passed_before_startup_time']=bool(result['strict_success'])
initial=json.loads((run/'active_initialization.json').read_text());extra_seconds=float(initial['extra_wall_s']);result['extra_initial_observation_s']=extra_seconds;result['completion_with_initial_observation_s']=None if confirmed is None else confirmed+extra_seconds
result['charged_time_passed']=confirmed is not None and confirmed+extra_seconds<=120.
result['initial_prior_unchanged']=initial['initial_free_padding_m']==.005 and initial['added_initial_information'] is False
publications=run/'map_publications.jsonl';maximum_source_motion=0.
if publications.exists():
 for line in publications.read_text().splitlines():
  publication=json.loads(line);a=int(publication['source_cycle']);b=int(publication['cycle']);source=np.array(publication['source_q']);maximum_source_motion=max(maximum_source_motion,float(np.max(np.abs(q[a:b+1]-source))))
result['maximum_joint_motion_while_map_pending_rad']=maximum_source_motion;result['stationary_map_updates_passed']=maximum_source_motion<=1e-6
# Independently reconstruct the boundary of historically observed voxels.
occ=np.load(run/'causal_occupancy_snapshots.npz');low=np.min(bc-bh,axis=0);low[2]=max(low[2],0.);high=np.max(bc+bh,axis=0);key_low=np.floor(low/.005).astype(int);dims=np.ceil(high/.005).astype(int)-key_low;seen=np.zeros(tuple(dims),dtype=bool);frontier_ok=True
assert np.array_equal(occ['publish_cycles'],arr['publish_cycles'])
for k in range(len(arr['publish_cycles'])):
 a,b=occ['offsets'][k:k+2];local=occ['voxel_keys'][a:b].astype(int)-key_low;inside=np.all((local>=0)&(local<dims),axis=1);local=local[inside];seen[local[:,0],local[:,1],local[:,2]]=True
 grown=seen.copy();grown[1:]|=seen[:-1];grown[:-1]|=seen[1:];grown[:,1:]|=seen[:,:-1];grown[:,:-1]|=seen[:,1:];grown[:,:,1:]|=seen[:,:,:-1];grown[:,:,:-1]|=seen[:,:,1:];expected=np.argwhere(grown & ~seen)+key_low
 a,b=arr['offsets'][k:k+2];boxes=arr['box_half_extents'][a:b];take=np.any(boxes>0,axis=1);actual=np.rint(arr['centers'][a:b][take]/.005-.5).astype(int)
 frontier_ok=frontier_ok and np.array_equal(expected,actual)
result['historical_visibility_frontier_replay_passed']=bool(frontier_ok)
# A virtual camera optical center must not be inside an obstacle solid.
camera_min=float('inf')
pose_records=[x['frame'] for x in initial['frames']]+frames
for frame in pose_records:
 for name,pose in json.loads(frame.get('sensor_poses_json','{}')).items():
  if not name.startswith('static_'):continue
  point=np.asarray(pose['position']);delta=np.abs(point-bc)-bh;gap=np.linalg.norm(np.maximum(delta,0),axis=1)+np.minimum(np.max(delta,axis=1),0);camera_min=min(camera_min,float(gap.min()))
result['minimum_external_camera_point_clearance_m']=camera_min;result['camera_origins_outside_obstacles']=camera_min>=-1e-9
result['external_camera_carrier_trajectory_certified']=False
result['strict_success']=bool(result['strict_success'] and result['charged_time_passed'] and result['initial_prior_unchanged'] and result['stationary_map_updates_passed'] and frontier_ok and result['camera_origins_outside_obstacles'] and (result['cycles']==int(cfg.get('policy',{}).get('maximum_cycles',6000)) or (cfg.get('policy',{}).get('stop_after_goal_hold',False) and result['success_1mm_50'])))

(AUDIT/(entry['id']+'_online.json')).write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='failed_intervals'}),flush=True)
