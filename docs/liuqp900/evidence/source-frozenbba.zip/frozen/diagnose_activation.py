import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np,mujoco
from pilot_adapter import ROOT
folder=ROOT/'trials/entry_final_memory_initial';r=json.loads((folder/'result.json').read_text());ps=r['policy_summary'];tr=np.load(folder/'trajectory.npz');events=ps['events'];activation=next(e for e in events if e['event']=='actual_cartesian_stall_activates_target_end_module');k=activation['cycle'];q=tr['q'];qg=np.array(ps['goal_port']['goal_q']);lever=ps['posture_scale_m']
entry=json.loads((ROOT/'INPUTS.json').read_text())[0];model=mujoco.MjModel.from_xml_path(entry['scene']);data=mujoco.MjData(model);data.qpos[:6]=q[0];mujoco.mj_kinematics(model,data);target=np.array(ps['goal_port']['target']);e0=np.linalg.norm(data.site_xpos[model.site('attachment_site').id]-target)
errors=np.r_[e0,tr['goal_error']];metric=np.sqrt(errors[:k+1]**2+lever**2*np.sum((q[:k+1]-qg)**2,axis=1));best=float(metric[0]);last=0
for i,value in enumerate(metric):
    if value<best-.0002:best=float(value);last=i
snapshot=ROOT.parent/'liuqp_lowdim_pilot_20261106/confirm_original_shelf_t2_baseline_300s_final_snapshot.npz';z=np.load(snapshot);qh=np.array(activation['q']);previous=np.array(activation['previous'])
np.savez_compressed(ROOT/'ONLINE_ACTIVATION_FAILURE_SNAPSHOT.npz',q=qh,previous=previous,target=target)
after=[e for e in events if e.get('cycle',-1)>=k and e['event'] in ('release_selected','target_directed_release','mode_changed','target_side_direction_committed','goalward_memory_committed')]
record=dict(activation=activation,activation_sim_s=k*.02,original_snapshot_q=z['q'].tolist(),maximum_joint_difference_from_original_snapshot=float(np.max(np.abs(qh-z['q']))),joint_difference=(qh-z['q']).tolist(),previous_speed=float(np.max(np.abs(previous))),reconstructed_pre_activation_last_posture_progress_cycle=last,progress_clock_age_at_activation=k-last,pre_activation_best_full_metric=best,activation_full_metric=float(metric[k]),first_escape_events=after[:12],scope='read-only causal diagnostic; new activation snapshot is not substituted into the primary repeated tests')
(ROOT/'ACTIVATION_DIAGNOSIS.json').write_text(json.dumps(record,indent=2));print(json.dumps(record,indent=2))
