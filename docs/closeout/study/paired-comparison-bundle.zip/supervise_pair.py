"""Durable frozen sphere ablation + paired reporting. Never modifies runtime code."""
from pathlib import Path
import os,sys,json,time,subprocess,datetime,hashlib,zipfile,collections
V=Path(__file__).resolve().parent;B=V.parent/'final_r17';U=V.parents[1];PY='/home/hsjed/envs/ur5cab/bin/python'
def read(p):
 try:return json.loads(p.read_text())
 except (OSError,ValueError):return None
def save(p,d):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8');t.replace(p)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def verify_baseline():
 for name,h in read(V/'BASELINE_REUSE_MANIFEST.json').items():
  assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==h,'baseline changed: '+name
def report(phase,closed=False):
 spec=read(V/'EVALUATION_SPEC.json');rows=[];groups={};counts=collections.Counter();failures=[]
 for key in spec['matrix_cases']:
  a=read(V/'outcomes'/(key+'.json'));base=read(B/'outcomes'/(key+'.json'));task=key.split('__')[1]
  g=groups.setdefault(task,dict(total=20,completed=0,sphere_safe_arrivals=0,ellipsoid_safe_arrivals=0,ordinary_nonarrivals=0,validity_or_safety_errors=0))
  g['ellipsoid_safe_arrivals']+=int(base['strict_pass'])
  if not a:continue
  valid=bool(a.get('continue_evaluation'));success=bool(a.get('strict_pass'));g['completed']+=1;g['sphere_safe_arrivals']+=int(success);g['ordinary_nonarrivals']+=int(valid and not success);g['validity_or_safety_errors']+=int(not valid)
  pair='invalid_sphere_evidence' if not valid else 'both_success' if success and base['strict_pass'] else 'sphere_only_success' if success else 'ellipsoid_only_success' if base['strict_pass'] else 'neither_success'
  counts[pair]+=1
  row=dict(id=key,task=task,seed=a.get('seed'),sphere_success=success,ellipsoid_success=base['strict_pass'],pair=pair,sphere_outcome=a.get('outcome'),sphere_reason=a.get('termination_reason',a.get('outcome')),sphere_valid=valid,sphere_audit=a.get('audit'),sphere_case=a.get('case'),ellipsoid_case=base['case'],sphere_completion_s=a.get('completion_charged_s'),ellipsoid_completion_s=base.get('completion_charged_s'),sphere_controller_p99_ms=a.get('controller_ms_p99'),ellipsoid_controller_p99_ms=base.get('controller_ms_p99'))
  rows.append(row)
  if not success:failures.append(row)
 progress=read(V/'MATRIX_PROGRESS.json') or read(V/'SMOKE_PROGRESS.json') or {};final=read(V/'FINAL_EVALUATION.json') or {}
 complete=bool(closed and len(rows)==300 and final.get('validity_passed'));sphere=sum(x['sphere_success'] for x in rows);invalid=counts['invalid_sphere_evidence']
 d=dict(version=V.name,phase=phase,updated_at=now(),closed=closed,expected=300,completed=len(rows),sphere_safe_arrivals=sphere,ordinary_nonarrivals=len(rows)-sphere-invalid,validity_or_safety_errors=invalid,baseline_version='final_r17',baseline_reused=True,ellipsoid_safe_arrivals=298,ellipsoid_total=300,paired_counts=dict(counts),by_task=groups,failures=failures,active=progress.get('active',{}),blocker=read(V/'MATRIX_BLOCKER.json') or read(V/'SMOKE_BLOCKER.json'),study_complete=complete,all_sphere_tasks_succeeded=complete and sphere==300,no_outcome_driven_tuning=True,known_reruns_started=False,ellipsoid_reruns_started=False,data_role='fixed development/regression matrix; not held-out generalization',timing_note='same hardware allocation and budgets, different execution dates; descriptive timing only',scope='measured cells use enclosing balls; unknown boxes and robot certificates unchanged')
 if closed:
  verify_baseline();d['baseline_integrity_verified']=True
  d['conclusion_zh']=f'球表示同条件对照完成：{sphere}/300安全到达；复用椭球298/300。仅椭球成功{counts["ellipsoid_only_success"]}项，仅球成功{counts["sphere_only_success"]}项。所有失败保留，未根据结果修改算法。' if complete else '本轮证据不完整，已停止扩展；不得将未完成的对照作为300项最终结论。'
 else:d['conclusion_zh']='球表示同条件对照正在运行；普通未到达保留并继续，尚无最终比较结论。'
 save(V/'CASE_PAIRS.json',rows);save(V/'CURRENT_REPORT.json',d)
 if closed:save(V/'CLOSEOUT_REPORT.json',d)
 return d
def package():
 with zipfile.ZipFile(V/'PAIRED_COMPARISON_BUNDLE.zip','w',zipfile.ZIP_DEFLATED) as z:
  for name in ['CLOSEOUT_REPORT.json','CASE_PAIRS.json','PROTOCOL.json','CHANGE_SCOPE.json','REPRESENTATION_PREFLIGHT.json','FROZEN_MANIFEST.json','FREEZE_RECORD.json','BASELINE_REUSE_MANIFEST.json','INPUT_MANIFEST.json','EVALUATION_SPEC.json','acceptance_policy.json','ENVIRONMENT.json','representation_only.patch','SMOKE_GATE.json','FINAL_EVALUATION.json','runner.py','evaluate.py','supervise_pair.py','test_sphere_contract.py']:
   p=V/name
   if p.exists():z.write(p,name)
  for folder in ['code','audit_tools','outcomes','audits']:
   for p in (V/folder).rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts and (folder in ['code','audit_tools'] or p.suffix=='.json'):z.write(p,str(p.relative_to(V)))
  for p in (B/'outcomes').glob('*.json'):z.write(p,'reused_ellipsoid_outcomes/'+p.name)
  for name in ['CLOSEOUT_REPORT.json','FREEZE_RECORD.json','acceptance_policy.json']:z.write(B/name,'reused_ellipsoid_metadata/'+name)
def main():
 os.sched_setaffinity(0,{63});verify_baseline();started=time.monotonic()
 save(V/'SUPERVISOR_STATUS.json',dict(phase='starting',pid=os.getpid(),updated_at=now()))
 try:
  for phase in ['smoke','matrix']:
   state=phase+'_running'
   with (V/(phase+'_runner.log')).open('a') as log:
    child=subprocess.Popen([PY,'-u',str(V/'evaluate.py'),'--phase',phase],stdout=log,stderr=subprocess.STDOUT)
    save(V/'SUPERVISOR_STATUS.json',dict(phase=state,pid=os.getpid(),evaluator_pid=child.pid,updated_at=now()))
    while child.poll() is None:report(state);time.sleep(10)
   result=read(V/('SMOKE_GATE.json' if phase=='smoke' else 'FINAL_EVALUATION.json')) or {}
   if child.returncode or not result.get('validity_passed'):
    save(V/'SUPERVISOR_STATUS.json',dict(phase='closed_incomplete',updated_at=now(),returncode=child.returncode));report('closed_incomplete',True);package();return
  verify_baseline();save(V/'SUPERVISOR_STATUS.json',dict(phase='closed_complete',updated_at=now(),elapsed_s=time.monotonic()-started));report('closed_complete',True);package()
 except Exception as exc:
  save(V/'SUPERVISOR_ERROR.json',dict(error=repr(exc),updated_at=now()));raise
if __name__=='__main__':main()
