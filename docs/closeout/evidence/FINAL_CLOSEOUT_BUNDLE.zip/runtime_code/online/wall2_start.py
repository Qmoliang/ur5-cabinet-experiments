import json, sys
sys.argv = sys.argv[:1]
exec(open('/mnt/ssd2/hsjed/ur5_cabinet/v6runs/goal_search.py').read().split('if __name__')[0])
from start_check import StartChecker
path = '/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/assets/scenes/wall2.json'
payload = json.load(open(path))
for point in ([0.08, 0.406, 0.50], [0.05, 0.406, 0.55], [0.10, 0.406, 0.60]):
    probe = dict(payload, waypoints=[point])
    best, q = search(probe, 'sphere', attempts=120, seed=1)
    if q is None or best < 0.01:
        print(point, 'sphere clearance', round(1000 * best, 1)); continue
    scene = scene_of(payload); m = build_model(scene); d = mujoco.MjData(m)
    c = StartChecker(scene.boxes, 0.075, 0.008)
    rate = sum(c.valid(m, d, q + np.random.default_rng(k).normal(0, 0.05, 6)) for k in range(1, 41))
    print(point, 'start clearance (sphere cover)', round(1000 * best, 1), 'mm; perturbed valid', rate, '/40')
    payload['q0'] = q.tolist(); json.dump(payload, open(path, 'w'), indent=1); print('saved'); break
