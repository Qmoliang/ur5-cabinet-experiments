from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='retained_blocker':";new="        if job.get('policy_version')=='goal_entry':\n            from goal_entry_policy import LowDimPolicy\n        elif job.get('policy_version')=='retained_blocker':";assert old in s;s=s.replace(old,new)
old="        actual=ctx.guard.filter(ctx.proxy_guard,q,previous,command,lo,hi,k,ctx.metadata['generation'])"
new="""        if policy is not None and hasattr(policy,'filter_memory'):
            memory_command=policy.filter_memory(q,previous,command,lo,hi)
            if np.max(np.abs(memory_command-command))>1e-10:
                delay=new_delay();ctl.previous_velocity=memory_command.copy()
            command=memory_command
        actual=ctx.guard.filter(ctx.proxy_guard,q,previous,command,lo,hi,k,ctx.metadata['generation'])"""
assert old in s;s=s.replace(old,new);p.write_text(s)
snapshot=ROOT.parent/'liuqp_lowdim_pilot_20261106/confirm_original_shelf_t2_baseline_300s_final_snapshot.npz'
base=dict(task='iris_4shelves_t2',method='release',policy_version='goal_entry',certified_auxiliary=True,representation='ellipsoid',solver_profile='verified_common',max_cycles=15000,stop_after_stall=False,wall_limit_s=900,operating_gate=False,entry_objective=True,port_rank=0,joint_metric=True,spatial_metric=False,targeted_release=True)
jobs=[]
for name,geo,memory in [('entry_only_stall',False,False),('entry_clearance_exit_stall',True,False),('entry_memory_stall_1',True,True),('entry_memory_stall_2',True,True),('entry_memory_stall_3',True,True),('entry_memory_initial',True,True)]:
    job=dict(base,name=name,geometric_release=geo,persistent_memory=memory)
    if not name.endswith('initial'):job['start_snapshot']=str(snapshot)
    jobs.append(job)
(ROOT/'entry_jobs.json').write_text(json.dumps(jobs,indent=2))
archive=ROOT/'revisions/entry_v1';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
files=list(ROOT.glob('*.py'))+[ROOT/'GOAL_PORTS.json',ROOT/'INPUTS.json',ROOT/'code/online/protocol_liuqp_controller.py',ROOT/'code/common/policy.json']
(ROOT/'ENTRY_STUDY_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},scope='same shelf and exact stalled snapshot; target-end static IK, 3 positional plus 2 posture features, current-velocity QP and persistent circulation/no-return certificates; no path planner, start-goal connection or witness access',unchanged_hard_safety=True,all_failures_retained=True),indent=2))
print(json.dumps(jobs))
