#!/bin/bash
# E4 small validation (online drawer, far start, objects only during the approach, self-collision rows,
# constraint-respecting fallback): liuqp / liuqphe / combined / neo_matched / neo_paper
# x seeds 1-5 x (no objects | 1 object 0.5 m/s | 2 objects 0.5 m/s); 7 runs at a time.
cd /mnt/ssd2/hsjed/ur5_cabinet/v6runs
E=$PWD/e4v
jobs=()
for seed in 1 2 3 4 5; do
  for ctl in combined liuqphe liuqp neo_matched neo_paper; do
    jobs+=("$E/${ctl}_k0_v0.0/seed$(printf %02d $seed) $seed $ctl 0 0.0")
    jobs+=("$E/${ctl}_k1_v0.5/seed$(printf %02d $seed) $seed $ctl 1 0.5")
    jobs+=("$E/${ctl}_k2_v0.5/seed$(printf %02d $seed) $seed $ctl 2 0.5")
  done
done
echo "${#jobs[@]} jobs" > $E.jobs
worker() {
  local w=$1
  for ((i = w; i < ${#jobs[@]}; i += 7)); do
    set -- ${jobs[$i]}
    [ -f $1/summary.json ] && continue
    rm -rf $1
    ./e4_one.sh $1 $2 $((w * 16)) $3 $4 $5
  done
}
for w in $(seq 0 6); do worker $w & done
wait
echo DONE > $E.done
