from pathlib import Path
import json,time,subprocess
ROOT=Path(__file__).resolve().parent;jobs=json.loads((ROOT/'jobs.json').read_text())
while not all((ROOT/'trials'/j['name']/'result.json').exists() for j in jobs):time.sleep(15)
subprocess.run(['/home/hsjed/envs/ur5cab/bin/python','-u',str(ROOT/'launch_reheading.py'),str(ROOT/'v2_jobs.json')],check=True)
