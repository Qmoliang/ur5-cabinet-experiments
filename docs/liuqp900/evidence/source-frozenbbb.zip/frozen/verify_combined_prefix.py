from pathlib import Path
import json,numpy as np
R=Path(__file__).resolve().parent;a=np.load(R/'trials/old_full_refresh_zero_delay/trajectory.npz')['q'];b=np.load(R/'trials/old_full_refresh_zero_delay_exact/trajectory.npz')['q'];assert len(a)<=len(b);difference=float(np.max(np.abs(a-b[:len(a)])));out=dict(retained_prefix_states=len(a),full_rerun_states=len(b),maximum_joint_difference=difference,bitwise_equal=bool(np.array_equal(a,b[:len(a)])),original_prefix_interrupted=True,full_rerun_motion_s=(len(b)-1)*.02)
(R/'COMBINED_PREFIX_REPLAY.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2));assert difference==0.
