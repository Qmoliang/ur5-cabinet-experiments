"""Constraint-aware known-map goal IK; same certificates, self pairs and joint limits."""
from pathlib import Path
import time,types
import numpy as np
import mujoco
from scipy.spatial import cKDTree
from scipy.optimize import minimize,least_squares
from native_support import NativeEllipsoidSupport
from static_certificate_guard import StaticCertificateGuard
from escape_point import WORKSPACE_A,WORKSPACE_B,SELF_MARGIN
class SearchDeadline(RuntimeError):pass
class KnownOracle:
    def __init__(self,checker):
        self.representation=checker.representation;self.model=checker.model;self.data=mujoco.MjData(self.model);self.body_ids=checker.body_ids;self.local=checker.local_centers;self.radii=checker.radii
        self.lower=self.model.jnt_range[:6,0]+.015;self.upper=self.model.jnt_range[:6,1]-.015;self.site=checker.site;self.margin=checker.margin;self.checks=0;self.deadline=float('inf')
        Q=np.array([np.diag(x*x) for x in checker.axes]) if self.representation=='ellipsoid' else np.array([np.eye(3)*x*x for x in checker.proxy_radii])
        sr=np.sqrt(np.max(np.linalg.eigvalsh(Q),axis=1));self.proxies=types.SimpleNamespace(centers=checker.centers,base_ellipsoid_shapes=Q,sphere_radii=sr,proxy_offset_radii=np.zeros(len(Q)))
        self.static_guard=StaticCertificateGuard(types.SimpleNamespace(centers=checker.centers,ellipsoid_shapes=Q,sphere_radii=sr),self.representation);self.static_guard.kernel.set_pair_threads(1)
        tree=cKDTree(checker.centers);bound=float(sr.max())
        self.guard=types.SimpleNamespace(support_kernel=self.static_guard.kernel,eigenvalues=self.static_guard.values,rotations=self.static_guard.rotations,_candidates=lambda a,b,r:tree.query_ball_point((a+b)*.5,float(np.linalg.norm(b-a)*.5+r+bound+1e-9)))
        self.pairs=np.asarray(checker.selected_self_pairs,dtype=int);self._q=None;self._cache=None
    def sphere_positions(self,q):
        self.data.qpos[:6]=q;mujoco.mj_kinematics(self.model,self.data)
        return self.data.xpos[self.body_ids]+np.einsum('nij,nj->ni',self.data.xmat[self.body_ids].reshape(-1,3,3),self.local)
    def gripper_position(self,q):
        self.sphere_positions(q);return self.data.site_xpos[self.site].copy()
    def evaluate(self,q):
        if time.perf_counter()>self.deadline:raise SearchDeadline()
        if self._q is not None and np.array_equal(q,self._q):return self._cache
        self.checks+=1;p=self.sphere_positions(q);mujoco.mj_comPos(self.model,self.data)
        jac=[]
        for i,pt in enumerate(p):
            jp=np.zeros((3,self.model.nv));mujoco.mj_jac(self.model,self.data,jp,None,pt,int(self.body_ids[i]));jac.append(jp[:,:6])
        jac=np.asarray(jac);ej=np.zeros((3,self.model.nv));mujoco.mj_jacSite(self.model,self.data,ej,None,self.site)
        ri=[];oi=[]
        for i,pt in enumerate(p):
            ids=self.guard._candidates(pt,pt,float(self.radii[i]+.030));ri.extend([i]*len(ids));oi.extend(ids)
        ri=np.asarray(ri,dtype=int);oi=np.asarray(oi,dtype=int);gaps=np.full(len(p),.030);gj=np.zeros((len(p),6))
        if len(oi):
            delta=self.proxies.centers[oi]-p[ri]
            if self.representation=='sphere':
                length=np.linalg.norm(delta,axis=1);normals=delta/np.maximum(length[:,None],1e-15)
                values=length-self.proxies.sphere_radii[oi]-self.radii[ri]-self.proxies.proxy_offset_radii[oi]
            else:
                Q=self.proxies.base_ellipsoid_shapes[oi]
                first=self.guard.support_kernel.closest_points_pairs_warm(p[ri],self.proxies.centers[oi],self.guard.eigenvalues[oi],self.guard.rotations[oi],np.full(len(oi),np.nan))
                normals=first[0]
                values=np.einsum('ni,ni->n',normals,delta)-np.sqrt(np.maximum(np.einsum('ni,nij,nj->n',normals,Q,normals),0))-self.radii[ri]-self.proxies.proxy_offset_radii[oi]
                local=np.einsum('nji,nj->ni',self.guard.rotations[oi],-delta);val=self.guard.eigenvalues[oi];rho=np.sqrt(np.sum(local*local/val,axis=1));inside=rho<1.
                if np.any(inside):
                    amin=np.sqrt(val[inside].min(axis=1));values[inside]=amin*(rho[inside]-1)-self.radii[ri[inside]]
                    gradlocal=amin[:,None]*local[inside]/val[inside]/np.maximum(rho[inside,None],1e-12)
                    normals[inside]=-np.einsum('nij,nj->ni',self.guard.rotations[oi[inside]],gradlocal)

            half=getattr(self.proxies,'box_half_extents',None)
            if half is not None:
                mask=np.any(np.asarray(half)[oi]>0,axis=1)
                if np.any(mask):
                    c=self.proxies.centers[oi[mask]];h=np.asarray(half)[oi[mask]];x=p[ri[mask]];closest=np.clip(x,c-h,c+h);diff=closest-x;length=np.linalg.norm(diff,axis=1);bn=diff/np.maximum(length[:,None],1e-15);bg=length-self.radii[ri[mask]]
                    for k in np.flatnonzero(length<1e-12):
                        depth=h[k]-np.abs(x[k]-c[k]);axis=int(np.argmin(depth));bn[k]=0;bn[k,axis]=-1. if x[k,axis]>=c[k,axis] else 1.;bg[k]=-depth[axis]-self.radii[ri[mask][k]]
                    normals[mask]=bn;values[mask]=bg
            for i in np.unique(ri):
                ks=np.flatnonzero(ri==i);k=ks[np.argmin(values[ks])]
                if values[k]<gaps[i]:gaps[i]=values[k];gj[i]=-normals[k]@jac[i]
        work=(WORKSPACE_B[None]-p@WORKSPACE_A.T-self.radii[:,None]).ravel()
        wj=-np.einsum('wi,rij->rwj',WORKSPACE_A,jac).reshape(-1,6)
        a,b=self.pairs.T;delta=p[b]-p[a];length=np.linalg.norm(delta,axis=1)
        selfgap=length-self.radii[a]-self.radii[b]-SELF_MARGIN
        sj=np.einsum('ni,nij->nj',delta/np.maximum(length[:,None],1e-12),jac[b]-jac[a])
        ee=self.data.site_xpos[self.site].copy()
        self._q=np.asarray(q).copy();self._cache=(ee,ej[:,:6].copy(),gaps,gj,np.r_[work,selfgap],np.vstack([wj,sj]));return self._cache
    def clearance(self,q):
        if np.any(q<self.lower) or np.any(q>self.upper):return -np.inf
        ee,ej,g,gj,w,wj=self.evaluate(q)
        return float(min(np.min(g)-self.margin,np.min(w)))
    def exact_clearance(self,q):
        p=self.sphere_positions(q)
        slack=self.static_guard.certify(p,p,self.radii+self.margin).minimum_clearance_m
        work=np.min(WORKSPACE_B[None]-p@WORKSPACE_A.T-self.radii[:,None])
        a,b=self.pairs.T;selfgap=np.linalg.norm(p[b]-p[a],axis=1)-self.radii[a]-self.radii[b]-SELF_MARGIN
        return float(min(slack,work,np.min(selfgap)))
    def free(self,q):return self.clearance(q)>=0
    def segment_free(self,q0,q1,step=.005):
        n=max(1,int(np.ceil(np.max(np.abs(q1-q0))/step)))
        return all(self.free(q0+(q1-q0)*x) for x in np.linspace(0,1,n+1))

def constrained_goal_configurations(checker,target,rng,*,keep=3,seeds=24,budget=8.):
    oracle=KnownOracle(checker);oracle.deadline=time.perf_counter()+budget;target=np.asarray(target);references=[np.asarray(q) for q in getattr(checker,'goal_references',[])];found=[];records=[]
    try:
        for k in range(seeds):
            seed=references[k] if k<len(references) else rng.uniform(oracle.lower,oracle.upper)
            seed=np.clip(seed,oracle.lower+1e-9,oracle.upper-1e-9)
            def ik(x):return np.r_[oracle.evaluate(x)[0]-target,1e-5*(x-seed)]
            def ikj(x):return np.vstack([oracle.evaluate(x)[1],1e-5*np.eye(6)])
            q=least_squares(ik,seed,jac=ikj,bounds=(oracle.lower,oracle.upper),max_nfev=80,ftol=1e-10,xtol=1e-10,gtol=1e-10).x
            # Simultaneously satisfy goal, environment, workspace and selected self pairs.
            def con(x):
                ee,ej,g,gj,w,wj=oracle.evaluate(x[:6]);return np.r_[g-checker.margin-x[6],w-x[6]]
            def conj(x):
                ee,ej,g,gj,w,wj=oracle.evaluate(x[:6]);error=ee-target;return np.vstack([np.c_[gj,-np.ones(len(g))],np.c_[wj,-np.ones(len(w))]])
            def objective(x):return -x[6]+1e-6*np.sum((x[:6]-q)**2)
            def gradient(x):return np.r_[2e-6*(x[:6]-q),-1.]
            initial=o_min=min(float(np.min(oracle.evaluate(q)[2])-checker.margin),float(np.min(oracle.evaluate(q)[4])))-1e-7
            r=minimize(objective,np.r_[q,max(-1.,initial)],jac=gradient,method='SLSQP',bounds=list(zip(oracle.lower,oracle.upper))+[(-1.,.003)],constraints=[dict(type='ineq',fun=con,jac=conj),dict(type='eq',fun=lambda x:oracle.evaluate(x[:6])[0]-target,jac=lambda x:np.c_[oracle.evaluate(x[:6])[1],np.zeros(3)])],options=dict(maxiter=140,ftol=1e-10))
            candidate=r.x[:6];error=float(np.linalg.norm(oracle.gripper_position(candidate)-target));clearance=checker.clearance(candidate);records.append(dict(attempt=k,error=error,clearance=clearance,optimizer=str(r.message),q=candidate.tolist(),max_slack=float(r.x[6])))
            if error<.0002 and clearance>=0 and not any(np.max(np.abs(candidate-q))<.1 for q in found):
                found.append(candidate.copy())
                if len(found)>=keep:break
    except SearchDeadline:pass
    checker.last_goal_diagnostics=records
    return found
