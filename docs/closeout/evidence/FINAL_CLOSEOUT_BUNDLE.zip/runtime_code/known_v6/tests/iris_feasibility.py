"""For each IRIS scene: a valid start pose and, per candidate target, the best goal-pose
clearance for ellipsoid and sphere covers.  Writes the final scene JSONs for
targets an ellipsoid goal pose clears by >= 1 mm (recording the sphere result).

Usage: iris_feasibility.py CANDIDATE_DIR OUT_SCENE_DIR
"""
import json
import sys
from pathlib import Path

cand_dir, out_dir = Path(sys.argv[1]), Path(sys.argv[2])
sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/goal_search.py").read().split("if __name__")[0])
from start_check import StartChecker  # noqa: E402

drawer = json.load(open("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/assets/scene.json"))
out_dir.mkdir(parents=True, exist_ok=True)
for path in sorted(cand_dir.glob("*_candidates.json")):
    cand = json.load(open(path))
    base = dict(name=cand["name"], description="IRIS-ZO benchmark environment (UR5 version)",
                boxes=cand["boxes"], q0=drawer["q0"], waypoints=[[0, 0, 0]], duration=45.0)
    scene = scene_of(base)
    model = build_model(scene)
    data = mujoco.MjData(model)
    checker = StartChecker(scene.boxes, 0.075, 0.010)
    q0 = np.asarray(drawer["q0"], dtype=float)  # valid in every IRIS scene (20/20 perturbed)
    for t_index, target in enumerate(cand["targets"]):
        trial = dict(base, q0=q0.tolist(), waypoints=[target])
        e = max(search(trial, "ellipsoid", attempts=200, seed=s)[0] for s in range(3))
        sph = max(search(trial, "sphere", attempts=200, seed=s)[0] for s in range(3))
        verdict = "use" if e >= 0.001 else "skip"
        print(f"  target {t_index} {target}: ellipsoid {1000*e:.1f} mm, sphere {1000*sph:.1f} mm -> {verdict}", flush=True)
        if verdict == "use":
            final = dict(trial, name=f"{cand['name']}_t{t_index}",
                         goal_clearance_mm=dict(ellipsoid=round(1000 * e, 1), sphere=round(1000 * sph, 1)))
            (out_dir / f"{cand['name']}_t{t_index}.json").write_text(json.dumps(final, indent=1))
