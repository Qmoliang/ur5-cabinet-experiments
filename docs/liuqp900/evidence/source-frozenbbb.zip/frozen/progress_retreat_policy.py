"""Separate model agreement from stage progress; use a task-space retreat gate for posture preparation."""
import numpy as np
from progress_policy import LowDimPolicy as Previous
from continuation_certified_policy import LowDimPolicy as Certified
from goal_entry_policy_activated import LowDimPolicy as Solver
from goal_entry_policy import clipped

class LowDimPolicy(Previous):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.agreement_anchor=None;self.macro_anchor=None;self.best_ready_margin=-float('inf');self.last_ready_gain=0;self.retreat_requested=False;self.retreat_gate=None;self.retreat_best=float('inf');self.retreat_last_gain=0;self.retreat_events=[];self.failed_retreat_states=[];self.active_retreat=None
 def continuation_witnesses(self,q):
  old=self.agreement_anchor
  if old is None or self.k-old['cycle']>=100 or np.max(np.abs(q-old['q']))>=self.trust_radius:self.witness_anchor=None
  before=self.refreshes;state=Certified.continuation_witnesses(self,q)
  if self.refreshes==before:return state
  m=-state['deficit']
  if old is not None and self.mode=='CERT_PREP':
   pred=min([r['slack']+r['b']@(q-old['q']) for r in old['rows']],default=0)-old['margin'];actual=m-old['margin']
   # Agreement has a numerical tolerance, not the macroscopic 0.2mm progress threshold.
   if pred>2e-7:
    if actual<.25*pred-2e-7:self.trust_radius=max(.04/4096,self.trust_radius/2)
    elif actual>=.75*pred:self.trust_radius=min(.04,self.trust_radius*2)
  self.agreement_anchor=dict(q=q.copy(),cycle=self.k,margin=m,rows=[dict(r,b=r['b'].copy()) for r in state['rows']])
  if self.mode not in ('CERT_PREP','RESERVE_GOAL'):return state
  if m>self.best_ready_margin+.0002:self.best_ready_margin=m;self.last_ready_gain=self.k
  macro=self.macro_anchor
  if macro is None:self.macro_anchor=dict(cycle=self.k,margin=m,q=q.copy())
  elif self.k-macro['cycle']>=100:
   gain=m-macro['margin'];accepted=gain>=.0002;rejected=gain<-.0002
   self.stage_acceptances+=int(accepted);self.stage_rejections+=int(rejected);self.progress_stagnations+=int(not accepted and not rejected)
   rec=dict(cycle=self.k,start_cycle=macro['cycle'],actual_gain_m=gain,before_m=macro['margin'],after_m=m,accepted=accepted,rejected=rejected,trust_radius_rad=self.trust_radius)
   self.acceptance_events.append(rec);self.emit('actual_progress_assessed',**{k:v for k,v in rec.items() if k!='cycle'});self.macro_anchor=dict(cycle=self.k,margin=m,q=q.copy())
  if self.k-self.last_ready_gain>=100 and np.linalg.norm(self.P@(q-self.qg))>self.radius:
   feature=np.r_[self.ee,self.P@(q-self.qg)]
   if not any(np.linalg.norm(feature-x)<=.001 for x in self.failed_retreat_states):self.retreat_requested=True
  return state
 def _terms(self,c,s):
  if self.mode!='RETREAT_POSTURE':return super()._terms(c,s)
  J=s['J'];desired=clipped(c.task_gain*(self.retreat_gate-self.ee),c.max_task_speed);inverse=np.linalg.pinv(J,rcond=1e-8);N=np.eye(6)-inverse@J;L=self.P@N;z=self.P@(self.q-self.qg)
  posture=clipped(-c.task_gain*z-self.P@inverse@desired,c.max_task_speed)
  return c.task_weight*(L.T@L),c.task_weight*(J.T@(s['desired']-desired)-L.T@posture)
 def _solve(self,c,s,arrays,release=None):
  if self.mode=='RETREAT_POSTURE':return Solver._solve(self,c,s,arrays,release)
  return super()._solve(c,s,arrays,release)
 def start_retreat(self):
  z=self.P@(self.q-self.qg);d=self.outward;target=self.ctx.target;radius=float(max(self.radius,d@(self.ee-target),np.linalg.norm(z)))
  pad=float(np.max(self.ctx.guard.radii));lo=self.ctx.guard.workspace_lower+pad;hi=self.ctx.guard.workspace_upper-pad;caps=[]
  for j in range(3):
   if d[j]>1e-12:caps.append((hi[j]-target[j])/d[j])
   elif d[j]<-1e-12:caps.append((lo[j]-target[j])/d[j])
  radius=min(radius,min(caps));self.retreat_gate=target+max(0.,radius)*d
  self.active_retreat=dict(start_cycle=self.k,start_q=self.q.tolist(),gate=self.retreat_gate.tolist(),retreat_distance_m=float(radius),initial_posture_error_m=float(np.linalg.norm(z)),initial_ready_margin_m=-self.future_state['deficit'],memory_count=len(self.memories))
  self.retreat_best=float(np.linalg.norm(self.ee-self.retreat_gate)+np.linalg.norm(z));self.retreat_last_gain=self.k;self.mode='RETREAT_POSTURE';self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8;self.retreat_requested=False;self.trust_radius=.04;self.continuation_rows=np.empty((0,6));self.continuation_bounds=np.empty(0);self.solve_cache={};self.emit('taskspace_retreat_contract_started',**self.active_retreat)
 def finish_retreat(self,reason,passed):
  rec=dict(self.active_retreat,end_cycle=self.k,reason=reason,passed=passed,final_posture_error_m=float(np.linalg.norm(self.P@(self.q-self.qg))),final_q=self.q.tolist(),final_ready_margin_m=None if self.future_state is None else -self.future_state['deficit'])
  self.retreat_events.append(rec);self.emit('taskspace_retreat_contract_finished',**rec)
  if not passed:self.failed_retreat_states.append(np.r_[self.ee,self.P@(self.q-self.qg)].copy())
  self.mode='CERT_PREP';self.command_epoch+=1;self.brake_pending=np.max(np.abs(self.previous))>1e-8;self.best_ready_margin=-float('inf');self.last_ready_gain=self.k;self.macro_anchor=None;self.agreement_anchor=None;self.witness_anchor=None;self.solve_cache={}
 def __call__(self,c,s,arrays):
  self.proposal_contract=None
  if self.mode=='RETREAT_POSTURE':
   self.expected=None;self.last_delta=np.zeros(6);self.current_s=s
   if self.terminal or self.brake_pending:return np.zeros(6)
   z=self.P@(self.q-self.qg);score=float(np.linalg.norm(self.ee-self.retreat_gate)+np.linalg.norm(z))
   if score<self.retreat_best-.0002:self.retreat_best=score;self.retreat_last_gain=self.k
   if np.linalg.norm(z)<=self.radius:self.finish_retreat('terminal_branch_posture_ready',True);return np.zeros(6)
   if self.k-self.retreat_last_gain>=100:self.finish_retreat('actual_gate_and_posture_progress_stalled',False);return np.zeros(6)
   answer=self._solve(c,s,arrays)
   if answer is not None and self._admit(c,arrays,answer) is not None:
    if self.k%50==0:self.emit('retreat_posture_progress',posture_error_m=float(np.linalg.norm(z)),gate_error_m=float(np.linalg.norm(self.ee-self.retreat_gate)),score=score)
    return self._publish(c,answer)
   self.brake_pending=True;return np.zeros(6)
  delta=super().__call__(c,s,arrays)
  if self.retreat_requested and self.mode=='CERT_PREP' and not self.brake_pending:
   self.start_retreat();self.expected=None;self.last_delta=np.zeros(6);c.pilot_supplied_solution=None;return np.zeros(6)
  return delta
 def summary(self):
  out=super().summary();out.update(retreat_contracts=self.retreat_events,active_retreat=self.active_retreat if self.mode=='RETREAT_POSTURE' else None,retreat_failed_state_memory=len(self.failed_retreat_states),retreat_parameterization='one Cartesian retreat distance along frozen target-entry outward axis plus two terminal branch coordinates in task nullspace; no future configuration search',progress_rule='separate model-agreement updates from 100-cycle actual progress; stalled readiness triggers bounded task-space posture preparation; all original safety and inherited memory retained')
  return out
