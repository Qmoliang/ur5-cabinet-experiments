from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent
archive=ROOT/'revisions/polished_objective';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='polished':";new="        if job.get('policy_version')=='blocker':\n            from blocker_policy import LowDimPolicy\n        elif job.get('policy_version')=='polished':";assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'polished_jobs.json').read_text())[1:]
for j in jobs:j['name']=j['name'].replace('polished_joint_spatial_hard','blocker_release');j['policy_version']='blocker'
(ROOT/'blocker_jobs.json').write_text(json.dumps(jobs,indent=2))
(ROOT/'BLOCKER_STUDY_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')},change='positive-dual geometry release after genuine persistent low goal progress; one selected clearance, no scene-specific body/joint or reference path',no_path=True),indent=2))
print(json.dumps(jobs))
