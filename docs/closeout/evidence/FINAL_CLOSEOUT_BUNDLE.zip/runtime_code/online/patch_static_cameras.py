"""online_v6: fixed external depth cameras (UR5_STATIC_CAMERAS) next to the arm cameras.

UR5_STATIC_CAMERAS="name:px,py,pz:tx,ty,tz[:fovy];..." adds world-fixed cameras
at p looking at t (no collision geometry: a sensor on its own mount).  The env
var reaches the perception worker process too, so both build the same model.
run_v6_case.py --static-cameras PRESET sets it and adds the names to the camera list.
"""
from pathlib import Path

root = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
p = root / "model.py"
s = p.read_text()
old = """    return ET.tostring(root, encoding="unicode")


def build_model(scene: SceneDefinition) -> mujoco.MjModel:"""
assert s.count(old) == 1
s = s.replace(old, """    _add_static_cameras(root)
    return ET.tostring(root, encoding="unicode")


def _add_static_cameras(root: ET.Element) -> None:
    \"\"\"World-fixed depth cameras from UR5_STATIC_CAMERAS (see run_v6_case.py --static-cameras).\"\"\"
    import os

    spec = os.environ.get("UR5_STATIC_CAMERAS", "").strip()
    if not spec:
        return
    worldbody = root.find("worldbody")
    for item in spec.split(";"):
        fields = item.split(":")
        name = fields[0]
        position = np.array([float(v) for v in fields[1].split(",")])
        look_at = np.array([float(v) for v in fields[2].split(",")])
        fovy = fields[3] if len(fields) > 3 else "58"
        forward = look_at - position
        forward /= np.linalg.norm(forward)
        # MuJoCo cameras look along -z with +y up in the image.
        x_axis = np.cross(forward, [0.0, 0.0, 1.0])
        x_axis /= np.linalg.norm(x_axis)
        y_axis = np.cross(x_axis, forward)
        ET.SubElement(worldbody, "camera", name=name, pos=" ".join(map(repr, position.tolist())),
                      xyaxes=" ".join(map(repr, np.r_[x_axis, y_axis].tolist())), fovy=fovy)


def build_model(scene: SceneDefinition) -> mujoco.MjModel:""")
p.write_text(s)

p = root / "run_v6_case.py"
s = p.read_text()
old = """            camera_names=("ur5_depth_wrist", "ur5_depth_forearm"),"""
assert s.count(old) == 1
s = s.replace(old, """            camera_names=("ur5_depth_wrist", "ur5_depth_forearm") + STATIC_CAMERA_NAMES,""")
old = """    os.environ["UR5_ACTIVE_LOOK"] = "1" if args.look else "0"
"""
assert s.count(old) == 1
s = s.replace(old, old + """    global STATIC_CAMERA_NAMES
    if args.static_cameras:
        spec = STATIC_CAMERA_PRESETS[args.static_cameras]
        os.environ["UR5_STATIC_CAMERAS"] = spec
        STATIC_CAMERA_NAMES = tuple(item.split(":")[0] for item in spec.split(";"))
""")
old = """    parser.add_argument("--frozen-map", default="","""
assert s.count(old) == 1
s = s.replace(old, """    parser.add_argument("--static-cameras", default="", choices=["", *STATIC_CAMERA_PRESETS],
                        help="add fixed external depth cameras (a preset)")
""" + old)
old = """import argparse
"""
assert s.count(old) == 1
s = s.replace(old, old + """
# Fixed external depth cameras, name:position:look-at[:fovy].  The drawer
# opening spans x = 0.35, y 0.24-0.58, z 0.51-0.65; the arm cameras never see
# the undersides of its front edges or the space just in front of them.
STATIC_CAMERA_PRESETS = {
    # one camera low in front, looking up into the opening
    "low": "static_low:0.05,0.40,0.30:0.42,0.40,0.58",
    # plus one high at the side, looking down across the opening and its edges
    "low_side": "static_low:0.05,0.40,0.30:0.42,0.40,0.58;static_side:0.15,-0.20,0.85:0.40,0.40,0.58",
}
STATIC_CAMERA_NAMES: tuple = ()
""")
p.write_text(s)
print("patched")
