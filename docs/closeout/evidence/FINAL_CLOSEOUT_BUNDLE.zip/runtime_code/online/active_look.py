"""Active looking: a temporary view goal when LiuQP is held by unseen space.

LiuQP's objective is a gripper position, so looking is expressed as one.  When
the gripper has stalled and LiuQP's limiting obstacle is a frontier proxy, the
wrist camera is moved (at its current orientation) to a point `standoff`
behind the blocking cell along its own viewing axis, which puts the cell on
the optical axis beyond the D405's ~7 cm near limit.  LiuQP stays the only
controller and keeps every constraint; the view goal only replaces its target.
The goal ends when the blocking cell is no longer frontier in the published
map, or after `max_cycles`; a cooldown then lets the original objective act.
"""
from __future__ import annotations

import numpy as np

import mujoco


class ActiveLook:
    def __init__(
        self,
        model,
        target,
        camera: str = "ur5_depth_wrist",
        minimum_error: float = 0.03,
        standoff: float = 0.15,
        stall_cycles: int = 75,
        stall_distance: float = 0.003,
        max_cycles: int = 200,
        cooldown_cycles: int = 100,
        cleared_distance: float = 0.001,
    ):
        self.camera_id = int(model.camera(camera).id)
        self.target = np.asarray(target, dtype=float)
        self.minimum_error = float(minimum_error)
        self.standoff = float(standoff)
        self.stall_cycles = int(stall_cycles)
        self.stall_distance = float(stall_distance)
        self.max_cycles = int(max_cycles)
        self.cooldown_cycles = int(cooldown_cycles)
        self.cleared_distance = float(cleared_distance)
        self.history: list[np.ndarray] = []
        self.limiting_proxy_id = -1
        self.goal = None
        self.cell = None
        self.started = -1
        self.resume_after = -1
        self.events: list[dict] = []

    @staticmethod
    def _frontier(packet):
        """(ids, centres) of the packet's frontier proxies (the last rows)."""
        count = int(packet.frame_row.get("frontier_cells", 0) or 0)
        proxies = packet.proxies
        if count <= 0:
            return np.empty(0, dtype=np.int64), np.empty((0, 3))
        return (np.asarray(proxies.proxy_ids)[-count:],
                np.asarray(proxies.centers, dtype=float)[-count:])

    def _end(self, cycle: int, reason: str) -> None:
        self.events[-1].update(end_cycle=cycle, reason=reason)
        self.goal = None
        self.cell = None
        self.history.clear()
        self.resume_after = cycle + self.cooldown_cycles

    def command(self, cycle: int, gripper: np.ndarray, data, packet, command: np.ndarray) -> np.ndarray:
        self.history.append(np.asarray(gripper, dtype=float).copy())
        if len(self.history) > self.stall_cycles:
            self.history.pop(0)
        ids, centres = self._frontier(packet)

        if self.goal is not None:
            seen = (not len(centres)
                    or np.min(np.linalg.norm(centres - self.cell, axis=1)) > self.cleared_distance)
            if seen:
                self._end(cycle, "observed")
            elif cycle - self.started >= self.max_cycles:
                self._end(cycle, "timeout")
            else:
                return self.goal
            return command

        # Near the target the gripper creeps along contact planes; looking
        # away there only undoes progress.
        stalled = (
            np.linalg.norm(np.asarray(gripper) - self.target) > self.minimum_error
            and cycle >= self.resume_after
            and len(self.history) == self.stall_cycles
            and np.linalg.norm(self.history[-1] - self.history[0]) < self.stall_distance
        )
        if not stalled or self.limiting_proxy_id < 0:
            return command
        hit = np.flatnonzero(ids == self.limiting_proxy_id)
        if not len(hit):
            return command
        self.cell = centres[hit[0]].copy()
        camera_position = data.cam_xpos[self.camera_id].copy()
        # MuJoCo cameras look along their frame's -z axis.
        forward = -data.cam_xmat[self.camera_id].reshape(3, 3)[:, 2]
        camera_goal = self.cell - self.standoff * forward
        self.goal = np.asarray(gripper, dtype=float) + (camera_goal - camera_position)
        self.started = cycle
        self.events.append(dict(start_cycle=cycle, cell=self.cell.round(4).tolist(),
                                goal=self.goal.round(4).tolist()))
        return self.goal

    def observe(self, metrics) -> None:
        self.limiting_proxy_id = int(getattr(metrics, "limiting_proxy_id", -1))
