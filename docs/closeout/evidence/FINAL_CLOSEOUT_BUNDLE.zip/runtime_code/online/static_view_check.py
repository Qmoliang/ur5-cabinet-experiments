"""How much of the drawer opening's edge region do the static cameras see at the start pose?

Usage: static_view_check.py PRESET|none  (run with UR5_STATIC_CAMERAS set by this script)
"""
import os
import sys
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
preset = sys.argv[1]
import run_v6_case  # noqa: E402

names = ()
if preset != "none":
    os.environ["UR5_STATIC_CAMERAS"] = run_v6_case.STATIC_CAMERA_PRESETS[preset]
    names = tuple(item.split(":")[0] for item in os.environ["UR5_STATIC_CAMERAS"].split(";"))
os.environ["UR5_FRONTIER"] = "0"
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
import run_protocol_v3_async_online as online  # noqa: E402

worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=0.0075, maximum_uncertainty_union_inflation=1.05,
    certificate_radius_limit=0.070, uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0,
    direct_tangent_subdivisions=1, direct_partition_mode="grid", sphere_cover_mode="matched",
    ellipsoid_cover_mode="matched", radius_limit_representation="both", camera_width=320, camera_height=180,
    camera_pixel_stride=1, camera_names=("ur5_depth_wrist", "ur5_depth_forearm") + names, scene_version="camera_quarter")
worker.process(np.asarray(worker.scene.q0, dtype=float), 0, 0, 0.0, include_dense_snapshot=False)
keys, states = worker.occupancy.snapshot_arrays()
voxel = online.MAP_VOXEL_SIZE
lo = np.floor(np.array([0.30, 0.24, 0.46]) / voxel).astype(int)
hi = np.ceil(np.array([0.40, 0.58, 0.70]) / voxel).astype(int)
total = int(np.prod(hi - lo))
inside = np.all((keys >= lo) & (keys < hi), axis=1) & (states != 0)
free = int(np.count_nonzero(inside & (states == 1)))
occupied = int(np.count_nonzero(inside & (states == 2)))
print(f"{preset}: opening slab x 0.30-0.40: {total} voxels, seen {free + occupied} "
      f"({100 * (free + occupied) / total:.1f}%: free {free}, occupied {occupied})")
worker.close()
