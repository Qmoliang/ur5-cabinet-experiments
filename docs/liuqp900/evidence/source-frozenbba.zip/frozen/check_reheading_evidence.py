from pathlib import Path
import json,numpy as np
ROOT=Path(__file__).resolve().parent;OLD=ROOT.parent/'liuqp_goal_entry_study_20261106'
reference=ROOT/'trials/reference_failed_schedule';old=OLD/'trials/failed_latency_schedule_replay'
a=np.load(reference/'trajectory.npz');b=np.load(old/'trajectory.npz');n=min(len(a['q']),len(b['q']))
out=dict(reference_reproduction=dict(same_length=len(a['q'])==len(b['q']),states_compared=n,maximum_joint_difference=float(np.max(np.abs(a['q'][:n]-b['q'][:n])))),runs=[])
assert out['reference_reproduction']['same_length'] and out['reference_reproduction']['maximum_joint_difference']<1e-12
for folder in sorted((ROOT/'trials').glob('reheading*')):
    if not (folder/'result.json').exists():continue
    r=json.loads((folder/'result.json').read_text());ps=r.get('policy_summary') or {};events=ps.get('reheading_events',[]);q=np.load(folder/'trajectory.npz')['q'];record=dict(name=folder.name,status=r['status'],final_error_mm=r['final_error_mm'],reheading_count=len(events))
    if events:
        first=events[0];k=first['cycle'];record.update(first_cycle=k,first_sim_s=k*.02,first_angle_deg=first['angle_deg'],first_category=first['label'],new_heading=first['new_tangent'])
        if 'failed_schedule' in folder.name and k<len(a['q']) and k<len(q):record['prefix_difference_through_reheading']=float(np.max(np.abs(q[:k+1]-a['q'][:k+1])))
    out['runs'].append(record)
(ROOT/'REHEADING_EVIDENCE.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
