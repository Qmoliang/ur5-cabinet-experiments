"""Replay penetrating static benchmark runs and classify every penetrating contact.

Categories: obstacle (a scene box geom), floor, self (robot-robot), other.
Prints, per scene x controller x representation x objective, how many runs
had each kind and the deepest obstacle penetration.
"""
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

K = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6")
sys.path[:0] = [str(K), str(K / "src" / "core"), str(K / "src")]
os.environ.setdefault("UR5_SCENE_JSON", "x")
import mujoco  # noqa: E402
import run as known_run  # noqa: E402  (scene-box model builder)
from robot import build_model, set_configuration  # noqa: E402

ROOT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/bench")
models = {}


def model_for(scene_name):
    if scene_name not in models:
        path = K / "assets" / ("scene.json" if scene_name == "drawer" else f"scenes/{scene_name}.json")
        os.environ["UR5_SCENE_JSON"] = str(path)
        scene = known_run.load_scene()
        m = build_model(scene)
        boxes = {b.name for b in scene.boxes}
        models[scene_name] = (m, mujoco.MjData(m), boxes)
    return models[scene_name]


table = defaultdict(lambda: defaultdict(int))
deepest = defaultdict(float)
for summary in sorted(ROOT.glob("*/*_seed*/summary.json")):
    s = json.loads(summary.read_text())
    if not s.get("exact_penetrating_cycles") or (len(sys.argv) > 2 and sys.argv[2] not in summary.parent.parent.name):
        continue
    run_dir = summary.parent
    stem = run_dir.name.rsplit("_seed", 1)[0]
    scene_name = next(n for n in ("iris_4shelves_t0", "iris_4shelves_t2", "iris_bins_t0", "iris_bins_t1",
                                  "iris_bins_t2", "iris_bins_t3", "iris_ur3_shelf_t0", "iris_ur3_shelf_t1",
                                  "iris_ur3_shelf_t2", "cage_wide", "cage", "drawer", "exit", "wall2")
                      if stem.startswith(n + "_"))
    m, d, boxes = model_for(scene_name)
    kinds = set()
    for q in np.load(run_dir / "q_history.npy")[::5]:
        set_configuration(m, d, q)
        for k in range(d.ncon):
            c = d.contact[k]
            if c.dist >= -1e-8:
                continue
            names = {m.geom(c.geom1).name, m.geom(c.geom2).name}
            bodies = {m.geom_bodyid[c.geom1], m.geom_bodyid[c.geom2]}
            if names & boxes:
                kinds.add("obstacle")
                key = (summary.parent.parent.name, stem)
                deepest[key] = min(deepest[key], float(c.dist))
            elif "floor" in names:
                kinds.add("floor")
            elif 0 not in bodies:
                kinds.add("self")
            else:
                kinds.add("other")
    for kind in kinds:
        table[(summary.parent.parent.name, stem)][kind] += 1

for (ctl, stem), kinds in sorted(table.items(), key=lambda kv: (kv[0][1], kv[0][0])):
    extra = f" deepest obstacle {1000*deepest[(ctl, stem)]:.1f} mm" if (ctl, stem) in deepest else ""
    print(f"{stem:44s} {ctl:12s} " + ", ".join(f"{k} {v}" for k, v in sorted(kinds.items())) + extra)
