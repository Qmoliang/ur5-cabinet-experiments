"""One target/escape state machine; only job scheduling differs by adapter."""
import time,json,hashlib
from types import SimpleNamespace
import numpy as np
from unified_policy import POLICY,POLICY_SHA256
from collision_oracle import CollisionOracle,SearchDeadline
from planner_core import search,geometry_key
class UnifiedGuidance:
 def __init__(self,model,robot,controller,target,initial_q,arrays,generation,executor=None,blocking=False):
  from robot_model import planning_model
  model=planning_model(model)
  self.model=model;self.robot=robot;self.controller=controller;self.target=np.asarray(target);self.initial_q=np.asarray(initial_q);self.arrays=arrays;self.generation=generation;self.executor=executor;self.blocking=blocking
  self.oracle=CollisionOracle(model,robot,arrays,initial_q,margin=POLICY["operating_margin_m"])
  self.history=[];self.chain=[];self.sensing_points=[];self.last_error=float("inf");self.external_time_charge=0.;self.track_history=[];self.future=None;self.retry_after=0;self.near_obstacle=False;self.last_q=self.initial_q.copy();self.command=self.target.copy();self.last_cycle=-1
  self.stats=SimpleNamespace(calls=0,failures=0,plan_ms=[],events=[],subgoals=[],regions=[])
  self.map_key=geometry_key(arrays,self.initial_q,self.target);self.waiting_for_map_generation=None;self.terminal_failure=None;self.rejected_route_signatures=set();self.accepted_route_signature=None
  self.subgoal_mode="unified_certified_chain";self.trigger="shared_stall_or_proactive";self.pre_step=True;self.pending_time=None
 @property
 def active(self):return bool(self.chain)
 def current_target(self):return self.command
 def clear(self):
  self.chain=[];self.track_history=[];self.controller.extra_joint_goal=None;self.controller.extra_task_frames=();self.command=self.target.copy()
 def connect(self,a,b):
  old=self.oracle.margin
  self.oracle.margin=POLICY["operating_margin_m"]
  try:
   a=np.asarray(a);b=np.asarray(b);count=max(1,int(np.ceil(np.max(np.abs(b-a))/POLICY["path_spacing_rad"])));nodes=[a+(b-a)*t for t in np.linspace(0,1,count+1)]
   return all(self.oracle.segment_free(x,y) and self.oracle.segment_certified(x,y) for x,y in zip(nodes[:-1],nodes[1:]))
  finally:self.oracle.margin=old
 def route_signature(self,path):
  return (self.map_key,hashlib.sha256(np.asarray(path,dtype=float).tobytes()).hexdigest())
 def tracking_feedback(self,q,waypoint,cycle):
  if self.accepted_route_signature is not None:self.rejected_route_signatures.add(self.accepted_route_signature)
  points=self.oracle.unknown_blocking_points([q,waypoint],POLICY["operating_margin_m"])
  self.clear();self.sensing_points=points
  if points:
   self.waiting_for_map_generation=self.generation;self.stats.failures+=1
   self.stats.events.append(dict(event="tracking_requires_observation",cycle=cycle,generation=self.generation,points=points))
  elif self.oracle.exact_clearance(q,POLICY["operating_margin_m"])<0:
   self.terminal_failure=dict(reason="operating_contract_unavailable",cycle=cycle,generation=self.generation)
   self.stats.events.append(dict(event="terminal_method_failure",**self.terminal_failure))
  else:
   self.stats.events.append(dict(event="tracking_replan_with_rejected_route",cycle=cycle,generation=self.generation))
  self.retry_after=cycle+10
 def on_map(self,arrays,generation,cycle):
  self.map_key=geometry_key(arrays,self.initial_q,self.target);self.waiting_for_map_generation=None
  self.arrays=arrays;self.generation=generation;self.oracle=CollisionOracle(self.model,self.robot,arrays,self.initial_q,margin=POLICY["operating_margin_m"])
  if self.chain and (self.oracle.exact_clearance(self.chain[-1],POLICY["goal_margin_m"])<0 or not self.connect(self.last_q,self.chain[0])):
   self.stats.events.append(dict(event="path_invalidated",cycle=cycle,generation=generation))
   self.tracking_feedback(self.last_q,self.chain[0],cycle)
 def accept(self,result,q,cycle):
  self.sensing_points=[] if result.get("status")=="path" else result.get("sensing_points",[])
  self.stats.plan_ms.append(1000*result.get("seconds",0));self.stats.events.append(dict(event="search_finished",cycle=cycle,**result))
  path=[np.asarray(p) for p in result.get("path",[])]
  if result.get("status")=="path":
   if not result.get("path_continuously_certified") or result.get("certified_margin_m",0.)+1e-12<POLICY["operating_margin_m"]:
    raise ValueError("planner certificate does not satisfy the normal controller contract")
   if path and np.linalg.norm(self.oracle.gripper_position(path[-1])-self.target)>=POLICY["goal_tolerance_m"]:
    raise ValueError("planner endpoint does not satisfy the declared task goal")
   if result.get("generation")!=self.generation:
    self.stats.events.append(dict(event="stale_path_rejected",cycle=cycle));path=[]
   elif path and self.route_signature(path) in self.rejected_route_signatures:
    self.terminal_failure=dict(reason="repeated_stalled_route",cycle=cycle,generation=self.generation);self.clear();path=[]
    self.stats.events.append(dict(event="terminal_method_failure",**self.terminal_failure))
  if result.get("status")=="path" and path and self.oracle.exact_clearance(path[-1],POLICY["goal_margin_m"])>=0:
   # Keep the certified route; a long shortcut at the hard margin can
   # discard the planner's operating clearance and stall the QP tracker.
   if not self.connect(q,path[0]):path=[]
   if path:self.accepted_route_signature=self.route_signature(path);self.chain=path;self.track_history=[];self.stats.subgoals.append([p.tolist() for p in path]);self.stats.events.append(dict(event="path_accepted",cycle=cycle,points=len(path)))
  if not self.chain:self.stats.failures+=1
  self.retry_after=cycle+POLICY["retry_cycles"]
 def update(self,q,gripper,cycle):
  q=np.asarray(q);gripper=np.asarray(gripper);joint_step=float(np.max(np.abs(q-self.last_q)));self.last_q=q.copy();error=float(np.linalg.norm(gripper-self.target));self.last_error=error
  if cycle!=self.last_cycle:self.history.append(error);self.history=self.history[-101:];self.last_cycle=cycle
  if self.future is not None and self.future.done():
   try:result=self.future.result()
   except Exception as ex:result=dict(status="worker_error",error=repr(ex),seconds=time.perf_counter()-self.pending_time)
   self.future=None;self.accept(result,q,cycle)
  if self.chain:
   if len(self.chain)>1 and cycle%POLICY.get("lookahead_check_cycles",5)==0:
    candidates=[i for i in range(1,min(len(self.chain),20)) if np.max(np.abs(q-self.chain[i]))<=POLICY.get("certified_tracking_lookahead_rad",.20)]
    if candidates:
     index=candidates[-1];old_deadline=self.oracle.deadline;old_margin=self.oracle.margin;self.oracle.deadline=time.perf_counter()+POLICY.get("lookahead_check_budget_s",.003);self.oracle.margin=POLICY["operating_margin_m"]
     try:certified=self.oracle.segment_certified(q,self.chain[index])
     except SearchDeadline:certified=False
     finally:self.oracle.deadline=old_deadline;self.oracle.margin=old_margin
     if certified:
      self.chain=self.chain[index:];self.track_history=[];self.stats.events.append(dict(event="certified_tracking_lookahead",cycle=cycle,skipped=index))
   while len(self.chain)>1 and np.max(np.abs(q-self.chain[0]))<POLICY["waypoint_tolerance_rad"] and self.connect(q,self.chain[1]):self.chain.pop(0);self.track_history=[]
   distance=float(np.linalg.norm(q-self.chain[0]));self.track_history.append(distance);self.track_history=self.track_history[-201:]
   if len(self.chain)==1 and np.max(np.abs(q-self.chain[0]))<POLICY["final_joint_tolerance_rad"] and error<POLICY["goal_tolerance_m"]:
    self.stats.events.append(dict(event="path_completed",cycle=cycle));self.clear()
   elif len(self.track_history)==201 and self.track_history[0]-min(self.track_history[-200:])<1e-5 and error>=POLICY["goal_tolerance_m"]:
    waypoint=self.chain[0].copy();self.stats.events.append(dict(event="tracking_stall",cycle=cycle,joint_gap=distance))
    self.tracking_feedback(q,waypoint,cycle)
   else:
    self.controller.extra_joint_goal=self.chain[0].copy();self.command=self.oracle.gripper_position(self.chain[0]);return self.command
  self.controller.extra_joint_goal=None
  if POLICY.get("certified_route_before_motion",False) and self.future is None and joint_step>1e-7:
   self.command=self.target.copy();return self.command
  stalled=len(self.history)>POLICY["stall_window"] and self.history[-51]-min(self.history[-50:])<POLICY["minimum_progress_m"]
  if cycle%POLICY.get("proactive_obstacle_check_cycles",25)==0:
   positions=self.oracle.sphere_positions(q)
   self.near_obstacle=float(self.oracle.guard.nearest(positions,self.oracle.radii)[0].min())<POLICY.get("proactive_obstacle_gap_m",.020)
  proactive=self.near_obstacle or (error<POLICY["proactive_error_m"] and cycle>=POLICY["proactive_after_cycle"])
  charged=cycle*POLICY["dt_s"]+(sum(self.stats.plan_ms)/1000 if self.blocking else 0.)+self.external_time_charge
  # The user prioritizes safe arrival: startup observation and planning wall
  # time remain reported, but do not consume the active control horizon.
  if POLICY.get("planning_budget_basis")=="active_control_time":
   remaining=POLICY["maximum_cycles"]*POLICY["dt_s"]-cycle*POLICY["dt_s"]
  else:remaining=120.-charged
  if self.terminal_failure is None and self.waiting_for_map_generation!=self.generation and self.future is None and cycle>=self.retry_after and error>POLICY["goal_tolerance_m"] and (stalled or proactive or POLICY.get("certified_route_before_motion",False)) and remaining>1.:
   self.stats.calls+=1;self.pending_time=time.perf_counter();args=(self.model,self.robot,self.arrays,self.initial_q,q.copy(),self.target.copy(),int(self.generation),self.stats.calls,min(POLICY["planner_budget_s"],remaining))
   self.stats.events.append(dict(event="search_started",cycle=cycle,generation=self.generation))
   if self.executor is None:self.accept(search(*args),q,cycle)
   elif self.blocking:
    self.future=self.executor.submit(search,*args);result=self.future.result();result["compute_seconds"]=result.get("seconds");result["seconds"]=time.perf_counter()-self.pending_time;self.accept(result,q,cycle);self.future=None
   else:self.future=self.executor.submit(search,*args)
   self.retry_after=cycle+POLICY["retry_cycles"]
  self.command=self.target.copy();return self.command
 def holding(self):return self.terminal_failure is not None or self.waiting_for_map_generation==self.generation or (POLICY.get("stop_when_goal_reached",False) and self.last_error<POLICY["goal_tolerance_m"]) or (POLICY.get("hold_robot_while_async_planning",True) and self.future is not None) or (POLICY.get("certified_route_before_motion",False) and not self.chain and self.last_error>=POLICY["goal_tolerance_m"])
 def finish(self,run_dir):
  if self.future is not None:self.future.cancel()
  if self.executor is not None:self.executor.shutdown(wait=True,cancel_futures=True)
  (run_dir/"guidance.json").write_text(json.dumps(dict(policy_sha256=POLICY_SHA256,events=self.stats.events,subgoals=self.stats.subgoals),default=float))
  return dict(mode="unified_certified_chain",policy_sha256=POLICY_SHA256,escapes=self.stats.calls,chains=sum(e["event"]=="path_accepted" for e in self.stats.events),search_s=[x/1000 for x in self.stats.plan_ms],pause_s=0.,terminal_failure=self.terminal_failure)
