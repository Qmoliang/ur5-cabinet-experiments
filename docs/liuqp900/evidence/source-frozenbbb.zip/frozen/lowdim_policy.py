"""Low-dimensional objective-only pilot: task plane plus one posture direction.

No route graph, waypoint list, IK search, or trajectory replay.
"""
from collections import deque,Counter
import time
import numpy as np,mujoco,osqp
from scipy import sparse
from scipy.optimize import linprog
from scipy.linalg import null_space
from model import certificate_world_state

PARAMETERS=dict(version='pilot_v1',task_rate_cap=.02,task_rate_floor=.0005,
    posture_rate_cap=.03,posture_rate_floor=.005,posture_drift=.001,
    effective_task_speed_cap=.36,trial_seconds=20.,episode_seconds=100.,
    posture_seconds=2.,posture_displacement=.05,max_task_trials=6,
    auxiliary_eps=1e-7,auxiliary_iterations=3000,realization_tolerance=1e-5,
    notes='Effective desired-speed cap is an objective bound, not physical speed; set uniformly to 2x original nominal task cap before modified runs. Original hard limits unchanged.')

def unit(x):
    x=np.asarray(x,dtype=float);n=np.linalg.norm(x)
    return None if n<1e-10 else x/n

class LowDimPolicy:
    def __init__(self,ctx,job,event):
        self.ctx=ctx;self.job=job;self.event=event;self.mode='TRACK';self.terminal=None
        self.history=deque(maxlen=800);self.mode_counts=Counter();self.rejections=Counter()
        self.trial=-1;self.hitV=None;self.episode_start=None;self.trial_start=0;self.frame_cycle=-100
        self.n=None;self.t=None;self.blocker=None;self.null_tries=0;self.z_mem=None
        self.expected=None;self.last_delta=np.zeros(6);self.events=[];self.aux_calls=0;self.lp_calls=0;self.cert_calls=0
        self.last_nominal_rate=0.;self.peak_error=0.;self.start_error=None;self.active_cycles=0;self.mode_progress=deque(maxlen=100)
        self.retreat_until=-1;self.last_pose_end=-100;self.last_change=0
        self.brake_pending=False;self.pending_blocker=None;self.pending_blocker_since=0

    def emit(self,name,**kw):
        data=dict(event=name,cycle=int(getattr(self.ctx.controller,'pilot_cycle',0)),mode=self.mode,**kw)
        self.events.append(data);self.event(**data)

    def observe(self,k,q,previous):
        self.k=k;self.q=np.asarray(q).copy();self.previous=np.asarray(previous).copy()
        self.ee=self.ctx.data.site_xpos[self.ctx.model.site('attachment_site').id].copy()
        self.error=float(np.linalg.norm(self.ee-self.ctx.target));self.peak_error=max(self.peak_error,self.error)
        self.history.append((k,self.error,self.q.copy(),self.ee.copy(),self.mode,self.trial,None if self.t is None else self.t.copy()))
        if self.brake_pending and np.max(np.abs(previous))<1e-8:self.brake_pending=False
        self.mode_counts[self.mode]+=1
        if self.hitV is not None:
            V=.5*self.error**2;delta=.05*max(self.hitV-.5e-6,0)
            if self.mode not in ('TRACK','RECOVER','STOP') and V<self.hitV-delta:
                self.resume_mode='TASK_ESCAPE';self.mode='RECOVER';self.recover_k=k;self.emit('release_candidate',error_m=self.error)
            elif self.mode=='RECOVER':
                if V>self.hitV-delta/2:
                    self.mode='TASK_ESCAPE';self.emit('recovery_reentered')
                elif k-self.recover_k>=50:
                    self.mode='TRACK';self.hitV=None;self.emit('recovered_original_controller')
            if self.episode_start is not None and k-self.episode_start>PARAMETERS['episode_seconds']/.02 and self.mode not in ('TRACK','RECOVER'):
                self.terminal='escape_budget_exhausted';self.mode='STOP'
        if self.mode in ('POSTURE','MIXED_ESCAPE') and (k-self.pose_k>PARAMETERS['posture_seconds']/.02 or np.linalg.norm(self.q-self.pose_q)>PARAMETERS['posture_displacement']):
            self.mode='TASK_ESCAPE';self.last_pose_end=k;self.emit('posture_phase_finished')

    def feedback(self,k,q,velocity,modified):
        if self.mode in ('TASK_ESCAPE','POSTURE','MIXED_ESCAPE'):
            self.active_cycles+=1
            if modified:self.rejections['guard_modified']+=1

    def _lp(self,d,A,l,u,extra=None,eq=None,eqb=None):
        up=np.isfinite(u);lo=np.isfinite(l);AA=np.vstack([A[up],-A[lo]]);bb=np.r_[u[up],-l[lo]]
        if extra:
            AA=np.vstack([AA,np.asarray([x[0] for x in extra])]);bb=np.r_[bb,[x[1] for x in extra]]
        self.lp_calls+=1
        result=linprog(-np.asarray(d),A_ub=AA,b_ub=bb,A_eq=eq,b_eq=eqb,bounds=[(None,None)]*6,method='highs')
        if not result.success:self.rejections['support_'+str(result.status)]+=1;return None
        return float(np.asarray(d)@result.x),result.x

    def _qp(self,H,g,A,l,u,rows,bounds,eq=None,eqb=None):
        m=len(A);AA=A;ll=l;uu=u
        if eq is not None:AA=np.vstack([AA,eq]);ll=np.r_[ll,eqb];uu=np.r_[uu,eqb]
        ecount=0 if eq is None else len(eq)
        if rows:AA=np.vstack([AA,rows]);ll=np.r_[ll,[-np.inf]*len(rows)];uu=np.r_[uu,bounds]
        solver=osqp.OSQP();solver.setup(P=sparse.triu(sparse.csc_matrix(H),format='csc'),q=g,A=sparse.csc_matrix(AA),l=ll,u=uu,verbose=False,eps_abs=PARAMETERS['auxiliary_eps'],eps_rel=PARAMETERS['auxiliary_eps'],max_iter=PARAMETERS['auxiliary_iterations'],adaptive_rho=True,polishing=False)
        self.aux_calls+=1;result=solver.solve(raise_error=False)
        if result.info.status.lower()!='solved':
            from verified_qp import solve_verified
            fallback=solve_verified(H,g,AA,ll,uu,result.x)
            if fallback is not None:result=fallback;self.rejections['numerical_fallback_used']+=1
        if result.x is None or not result.info.status.lower().startswith('solved'):
            self.rejections['aux_'+result.info.status]+=1;return None
        x=np.asarray(result.x);viol=max(float(np.max(ll-AA@x)),float(np.max(AA@x-uu)),0.)
        if viol>2e-6:self.rejections['aux_primal']+=1;return None
        eta=np.zeros(0) if not ecount else result.y[m:m+ecount]
        lam=result.y[m+ecount:m+ecount+len(rows)]
        if len(lam) and np.min(lam)<-1e-6:self.rejections['dual_sign']+=1;return None
        delta=np.zeros(6)
        if ecount:delta+=np.asarray(eq).T@eta
        if rows:delta+=np.asarray(rows).T@np.maximum(lam,0)
        return x,delta,eta,lam

    def _accept(self,v,delta,desired_eff,pose=False):
        if np.linalg.norm(desired_eff)>PARAMETERS['effective_task_speed_cap']:
            self.rejections['effective_desired_speed_cap']+=1;return False
        if pose:
            self.pose_data.qpos[:6]=self.q+.02*v;mujoco.mj_kinematics(self.ctx.model,self.pose_data)
            predicted=self.pose_data.site_xpos[self.ctx.model.site('attachment_site').id]
            if np.linalg.norm(predicted-self.pose_p)>.001:self.rejections['posture_drift']+=1;return False
        self.cert_calls+=1
        if not self.ctx.guard.braking_safe(self.ctx.proxy_guard,self.q,v):self.rejections['continuous_certificate']+=1;return False
        self.expected=np.asarray(v).copy();self.last_delta=np.asarray(delta).copy();return True

    def _frame(self,ctl,s,H,A,force=False):
        J=s['J'];weights=np.abs(s['y'])*np.linalg.norm(A,axis=1)
        i=int(np.argmax(weights));rid=tuple(s['row_ids'][i])
        if self.blocker is not None and not force:
            old=next((j for j,row in enumerate(s['row_ids']) if tuple(row)==self.blocker),None)
            if old is not None and rid!=self.blocker:
                if weights[i]<2*weights[old]:i=old
                else:
                    if self.pending_blocker!=rid:self.pending_blocker=rid;self.pending_blocker_since=self.k
                    if self.k-self.pending_blocker_since<10:i=old
            elif old is None and weights[i]<1e-6:return
        rid=tuple(s['row_ids'][i]);a=A[i]*(1 if s['y'][i]>=0 else -1)
        W=np.linalg.solve(H,J.T);L=W@np.linalg.pinv(J@W,rcond=1e-8);new=unit(L.T@a)
        if new is None or weights[i]<1e-6:new=unit(s['desired'])
        if new is None:new=np.array([1.,0,0])
        if self.n is not None and not force:
            dot=float(np.clip(self.n@new,-1,1))
            if dot<np.cos(np.pi/6) and np.max(np.abs(self.previous))>1e-8:self.brake_pending=True
            if dot>-.99:
                k=np.cross(self.n,new);transport=self.t+np.cross(k,self.t)+np.cross(k,np.cross(k,self.t))/(1+dot)
                self.t=unit(transport-new*(new@transport));self.n=new;self.blocker=rid;return
        basis=np.eye(3)[int(np.argmin(np.abs(new)))];base=unit(basis-new*(new@basis));angle=(self.trial//2)*np.pi/3;sign=1 if self.trial%2==0 else -1
        self.n=new;self.t=sign*(np.cos(angle)*base+np.sin(angle)*np.cross(new,base));self.blocker=rid
        self.emit('plane_selected',trial=self.trial,normal=self.n.tolist(),tangent=self.t.tolist(),blocker=rid)

    def _next_trial(self,ctl,s,H,A,reason):
        self.trial+=1;self.null_tries=0;self.trial_start=self.k;self.mode='TASK_ESCAPE';self.retreat_until=-1
        self.last_change=self.k
        if np.max(np.abs(self.previous))>1e-8:self.brake_pending=True
        if self.trial>=PARAMETERS['max_task_trials']:
            self.terminal='lowdim_trials_exhausted';self.mode='STOP';self.emit('trial_budget_exhausted',reason=reason);return
        self._frame(ctl,s,H,A,True);self.emit('task_trial_started',reason=reason)

    def _task(self,ctl,s,H,g,A,l,u,allow_retreat=True):
        J=s['J'];omega=ctl.task_weight
        directions=[(-self.n,'retreat'),(self.t,'tangent')] if self.k<self.retreat_until else [(self.t,'tangent'),(-self.n,'retreat')]
        if not allow_retreat:directions=[(self.t,'tangent')]
        for d,role in directions:
            row=d@J
            for cap in [0.,.01,None]:
                normal=self.n@J;extra=[] if cap is None else [(normal,cap)]
                support=self._lp(row,A,l,u,extra)
                if support is None or support[0]<2*PARAMETERS['task_rate_floor']:continue
                rate=min(.5*support[0],PARAMETERS['task_rate_cap'])
                for _ in range(6):
                    if rate<PARAMETERS['task_rate_floor']:break
                    rows=[-row]+([] if cap is None else [normal]);bb=[-rate]+([] if cap is None else [cap])
                    result=self._qp(H,g,A,l,u,rows,bb)
                    if result is not None:
                        v,delta,eta,lam=result;coeff=-max(0.,lam[0])*d+(0 if cap is None else max(0.,lam[1]))*self.n
                        if self._accept(v,delta,s['desired']-coeff/omega):
                            if role=='retreat' and self.k>=self.retreat_until:self.retreat_until=self.k+50;self.emit('retreat_phase',rate=rate)
                            return delta
                    rate*=.5
        return None

    def _posture_candidates(self,s,A):
        J=s['J'];Z=null_space(J,rcond=1e-7);weights=np.abs(s['y'])*np.linalg.norm(A,axis=1)
        selected=np.flatnonzero(weights>max(1e-5,.05*weights.max()))
        K=null_space(np.vstack([J,A[selected]]),rcond=1e-7)
        p,j,r=certificate_world_state(self.ctx.model,self.ctx.data,self.ctx.robot);scores=[];motion=np.zeros((6,6))
        top=np.argsort(-weights)[:6]
        for idx in top:
            rid=s['row_ids'][idx]
            if rid[0] in ('collision','frontier'):jj=j[int(rid[1]),:,:6]
            elif rid[0]=='self':jj=j[int(rid[1]),:,:6]-j[int(rid[2]),:,:6]
            else:jj=A[idx:idx+1]
            motion+=weights[idx]*(jj.T@jj)
        columns=[]
        for basis in [K,Z]:
            if not basis.shape[1]:continue
            values,vectors=np.linalg.eigh(basis.T@motion@basis)
            for idx in np.argsort(-values):
                if values[idx]>max(1e-12,float(values.max())*1e-8):columns.append((float(values[idx]),basis@vectors[:,idx]))
        for score,column in columns:
            z=unit(column)
            nz=np.flatnonzero(np.abs(z)>1e-8)
            if len(nz) and z[nz[0]]<0:z=-z
            scores.append((score,z))
        scores.sort(key=lambda x:-x[0]);out=[]
        for score,z in scores:
            for signed in [z,-z]:
                if not any(np.linalg.norm(signed-old)<1e-5 for old in out):out.append(signed)
        return out

    def _posture(self,ctl,s,H,g,A,l,u,choose=False):
        J=s['J'];N=np.eye(6)-np.linalg.pinv(J,rcond=1e-7)@J
        candidates=self._posture_candidates(s,A) if choose else [self.z_mem]
        if choose:
            self.pose_p=self.ee.copy();self.pose_q=self.q.copy();self.pose_k=self.k
            self.pose_data=mujoco.MjData(self.ctx.model)
        for seed in candidates:
            z=unit(N@seed)
            if z is None:continue
            hold=-2*(self.ee-self.pose_p)
            if np.linalg.norm(hold)>.02:hold*=.02/np.linalg.norm(hold)
            for factor in [1.,.5,0.]:
                vh=factor*hold;support=self._lp(z,A,l,u,eq=J,eqb=vh)
                if support is None or support[0]<2*PARAMETERS['posture_rate_floor']:continue
                rate=min(.5*support[0],PARAMETERS['posture_rate_cap'])
                for _ in range(4):
                    if rate<PARAMETERS['posture_rate_floor']:break
                    result=self._qp(H,g,A,l,u,[-z],[-rate],J,vh)
                    if result is not None:
                        v,delta,eta,lam=result
                        if self._accept(v,delta,s['desired']-eta/ctl.task_weight,True):
                            if choose:self.z_mem=seed.copy();self.mode='POSTURE';self.null_tries+=1;self.emit('posture_phase',rate=rate,direction=seed.tolist())
                            return delta
                    rate*=.5
        return None

    def _mixed(self,ctl,s,H,g,A,l,u):
        J=s['J'];d=-self.n;taskrow=d@J
        up=np.isfinite(u);lo=np.isfinite(l);baseA=np.vstack([A[up],-A[lo]]);baseb=np.r_[u[up],-l[lo]]
        candidates=[self.z_mem] if self.mode=='MIXED_ESCAPE' else self._posture_candidates(s,A)
        for seed in candidates:
            z=unit((np.eye(6)-np.linalg.pinv(J,rcond=1e-7)@J)@seed)
            if z is None:continue
            AA=np.c_[baseA,np.zeros(len(baseA))];bb=baseb
            AA=np.vstack([AA,np.r_[-taskrow,.01],np.r_[-z,.02]]);bb=np.r_[bb,0.,0.]
            self.lp_calls+=1;lp=linprog(np.r_[np.zeros(6),-1.],A_ub=AA,b_ub=bb,bounds=[(None,None)]*6+[(0,1)],method='highs')
            if not lp.success or lp.x[-1]<.5:continue
            scale=.5*lp.x[-1];result=self._qp(H,g,A,l,u,[-taskrow,-z],[-.01*scale,-.02*scale])
            if result is None:continue
            v,delta,eta,lam=result;desired=s['desired']+max(0.,lam[0])*d/ctl.task_weight
            if self._accept(v,delta,desired):
                if self.mode!='MIXED_ESCAPE':
                    self.z_mem=seed.copy();self.pose_q=self.q.copy();self.pose_k=self.k;self.mode='MIXED_ESCAPE';self.null_tries+=1;self.emit('mixed_phase',scale=scale,direction=seed.tolist())
                return delta
        return None

    def __call__(self,ctl,s,arrays):
        self.expected=None;self.last_delta=np.zeros(6);H,g,A,l,u=arrays
        if self.terminal:return np.zeros(6)
        J=s['J'];goal_dir=unit(s['desired']);self.last_nominal_rate=0. if goal_dir is None else float(goal_dir@J@s['x'])
        if self.mode=='TRACK':
            old=[x for x in self.history if self.k-x[0]>=100]
            stalled=bool(old and old[-1][1]-self.error<.0002 and self.last_nominal_rate<.0001 and self.error>.002)
            if not stalled and not self.job.get('force_escape',False):return np.zeros(6)
            self.hitV=.5*self.error**2;self.start_error=self.error;self.episode_start=self.k;self.trial=-1
            self.emit('escape_triggered',error_m=self.error,nominal_goal_rate=self.last_nominal_rate)
            self._next_trial(ctl,s,H,A,'stagnation')
        if self.mode=='RECOVER':return np.zeros(6)
        if self.mode=='TASK_ESCAPE' and self.k-self.last_change>=100 and self.k%10==0:
            repeated=any(100<=self.k-old[0]<=600 and old[4]=='TASK_ESCAPE' and old[5]==self.trial and old[6] is not None and float(old[6]@self.t)>.9 and np.max(np.abs(old[2]-self.q))<.005 and np.linalg.norm(old[3]-self.ee)<.002 and old[1]-self.error<.0002 for old in self.history)
            if repeated:
                if self.job.get('method')=='full' and self.null_tries<2:
                    value=self._posture(ctl,s,H,g,A,l,u,True)
                    if value is not None:self.last_change=self.k;return value
                    value=self._mixed(ctl,s,H,g,A,l,u)
                    if value is not None:self.last_change=self.k;return value
                self._next_trial(ctl,s,H,A,'cycle_return')
        if self.k-self.trial_start>PARAMETERS['trial_seconds']/.02:self._next_trial(ctl,s,H,A,'trial_time')
        if self.terminal:return np.zeros(6)
        if self.k-self.frame_cycle>=10 and self.mode=='TASK_ESCAPE':self._frame(ctl,s,H,A);self.frame_cycle=self.k
        if self.brake_pending:return np.zeros(6)
        if self.mode=='POSTURE':
            if self.k-self.pose_k>=10 and self.k%10==0:
                recovered=self._task(ctl,s,H,g,A,l,u,False)
                if recovered is not None:self.mode='TASK_ESCAPE';self.emit('task_capacity_restored');return recovered
            value=self._posture(ctl,s,H,g,A,l,u)
            if value is not None:return value
            self.mode='TASK_ESCAPE';self.emit('posture_unavailable')
        if self.mode=='MIXED_ESCAPE':
            value=self._mixed(ctl,s,H,g,A,l,u)
            if value is not None:return value
            self.mode='TASK_ESCAPE';self.emit('mixed_unavailable')
        allow_retreat=self.job.get('method')!='full' or self.k<self.retreat_until
        value=self._task(ctl,s,H,g,A,l,u,allow_retreat)
        if value is not None:return value
        if self.job.get('method')=='full' and self.null_tries<2:
            value=self._posture(ctl,s,H,g,A,l,u,True)
            if value is not None:return value
            value=self._mixed(ctl,s,H,g,A,l,u)
            if value is not None:return value
        if not allow_retreat:
            value=self._task(ctl,s,H,g,A,l,u,True)
            if value is not None:return value
        self._next_trial(ctl,s,H,A,'no_certified_lowdim_step')
        return np.zeros(6)

    def summary(self):
        return dict(parameters=PARAMETERS,mode_counts=dict(self.mode_counts),events=self.events,rejections=dict(self.rejections),auxiliary_qp_calls=self.aux_calls,support_lp_calls=self.lp_calls,precertification_calls=self.cert_calls,active_cycles=self.active_cycles,peak_error_m=self.peak_error,escape_start_error_m=self.start_error,terminal=self.terminal,path_planning_calls=0,history_replay=False)
