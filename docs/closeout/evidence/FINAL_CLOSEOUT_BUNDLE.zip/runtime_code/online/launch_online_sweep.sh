#!/bin/bash
# Online fairness sweep (spheres hug the surface more tightly) + real-time reruns.
cd /mnt/ssd2/hsjed/ur5_cabinet
export MUJOCO_GL=egl MUJOCO_EGL_DEVICE_ID=4 CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
run() { # dir id representation timing cpu_first extra...
  local dir=$1 id=$2 rep=$3 timing=$4 cpu=$5; shift 5
  mkdir -p v6runs/$dir
  systemd-run --user --scope -q -p MemoryMax=32G -E MUJOCO_GL -E MUJOCO_EGL_DEVICE_ID -E OMP_NUM_THREADS -E OPENBLAS_NUM_THREADS -E MKL_NUM_THREADS \
    timeout 21600 ~/envs/ur5cab/bin/python repo/experiment/runtimes/online_v6/run_v6_case.py $rep --map incremental --timing $timing --cpus $cpu:16 --out v6runs/$dir/$id "$@" > v6runs/$dir/$id.log 2>&1
}
run sphere_sweep S050_sph_sync sphere sync 0  --sphere-budget-scale 0.5  &
run sphere_sweep S025_sph_sync sphere sync 16 --sphere-budget-scale 0.25 &
run sphere_sweep S010_sph_sync sphere sync 32 --sphere-budget-scale 0.1  &
run realtime R1_ell_incr_paced ellipsoid paced 96  &
run realtime R2_sph_incr_paced sphere    paced 112 &
wait
echo DONE > v6runs/sphere_sweep/ALL_DONE
