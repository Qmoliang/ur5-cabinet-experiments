from pathlib import Path
import json,hashlib
POLICY_PATH=Path(__file__).with_name("policy.json")
POLICY=json.loads(POLICY_PATH.read_text())
POLICY_SHA256=hashlib.sha256(POLICY_PATH.read_bytes()).hexdigest()
