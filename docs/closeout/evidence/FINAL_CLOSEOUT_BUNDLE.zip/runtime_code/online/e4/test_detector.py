"""Offline detector check: one object crossing the workspace; frames from first visible to first detected,
certificate coverage, and false tracks while only the robot moves."""
import os
import sys
from pathlib import Path

os.environ.setdefault("UR5_OBJECTS", "1")
os.environ.setdefault("UR5_STATIC_CAMERAS", (
    "static_low:0.05,0.40,0.30:0.42,0.40,0.58;static_side:0.15,-0.20,0.85:0.40,0.40,0.58;"
    "static_top:-0.35,0.35,1.55:0.20,0.35,0.45:90"))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import mujoco  # noqa: E402
import numpy as np  # noqa: E402

import run_protocol_v3_async_online as online  # noqa: E402
from dynamic_perception import FixedCameraTracker  # noqa: E402
from model import build_model  # noqa: E402

scene = online._protocol_scene("camera_quarter")
model = build_model(scene)
names = [item.split(":")[0] for item in os.environ["UR5_STATIC_CAMERAS"].split(";")]
geoms = [g for g in range(model.ngeom) if model.body(int(model.geom_bodyid[g])).name.startswith("object")]
tracker = FixedCameraTracker(model, names, geoms)
q0 = np.asarray(scene.q0, float)
mocap = model.body("object0").mocapid[0]
data = mujoco.MjData(model)
pos = np.tile([5.0, 5.0, 5.0], (model.nmocap, 1))
quat = np.tile([1.0, 0.0, 0.0, 0.0], (model.nmocap, 1))
for path_name, start, velocity in (("side sweep", np.array([0.10, -0.40, 0.55]), np.array([0.0, 0.5, 0.0])),
                                   ("from above", np.array([0.15, 0.30, 1.10]), np.array([0.0, 0.0, -0.5]))):
    tracker = FixedCameraTracker(model, names, geoms)
    first_visible = first_detected = None
    false_frames = 0
    coverage = []
    for frame in range(60):
        t = frame / 25.0
        q = q0 + 0.2 * np.sin(t) * np.array([1, 0.5, 0.3, 0, 0, 0])     # the robot moves too
        p = start + velocity * max(0.0, t - 0.4) if t >= 0.4 else np.array([5.0, 5.0, 5.0])
        pos[mocap] = p
        out = tracker.step(t, q, pos, quat)
        visible = out["true_pixels"].get(int(model.body("object0").id), 0)
        if t < 0.4:
            false_frames += len(out["tracks"]) > 0
            continue
        if visible >= 10 and first_visible is None:
            first_visible = frame
        if len(out["centers"]):
            head = p + np.random.default_rng(frame).uniform(-1, 1, (200, 3)) * np.array([0.13, 0.13, 0.01])
            inside = np.any(np.linalg.norm(head[:, None, :] - out["centers"][None], axis=2) <= out["radii"][None], axis=1)
            if visible >= 10:
                coverage.append(float(inside.mean()))
            if first_detected is None and inside.any():
                first_detected = frame
    print(f"{path_name:11s} first visible frame {first_visible}, first detected {first_detected} "
          f"(delay {None if first_detected is None or first_visible is None else (first_detected - first_visible) * 40} ms), "
          f"head coverage mean {np.mean(coverage) if coverage else 0:.2f}, false-track frames before launch {false_frames}, "
          f"compute {out['foreground_points']} fg points")
