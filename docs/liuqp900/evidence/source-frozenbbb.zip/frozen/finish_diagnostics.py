from pathlib import Path
import json,os,subprocess,sys,collections
import numpy as np
ROOT=Path(__file__).resolve().parent
out=[]
for folder in sorted((ROOT/'trials').glob('*')):
 if not (folder/'result.json').exists():continue
 d=json.loads((folder/'result.json').read_text());s=d['policy_summary'];z=np.load(folder/'trajectory.npz');events=[json.loads(x) for x in (folder/'events.jsonl').read_text().splitlines()]
 record=dict(name=folder.name,trajectory_keys=list(z),event_keys=list(events[-1]) if events else [],summary={k:v for k,v in s.items() if k in ['reheading_count','reheading_braking_requests','old_heading_rejections','taboo_rejections','memory_count','rejections','mode_counts','last_improvement_cycle','feature_last_progress','reheading_rule']},last_events=events[-8:],last_reheading=s.get('reheading_events',[])[-1:])
 q=z['q'];record['last_60s_joint_span_rad']=np.ptp(q[-3001:],axis=0).tolist();record['last_60s_error_mm']=[float(np.min(z['goal_error'][-3000:])*1000),float(np.max(z['goal_error'][-3000:])*1000)];record['last_q']=q[-1].tolist()
 out.append(record)
 if not (folder/'workspace_refinement.json').exists():
  subprocess.run([sys.executable,str(ROOT/'audit_workspace_refined.py'),str(folder),'48,49,50,51'],check=True,stdout=subprocess.DEVNULL)
(ROOT/'FAILURE_DIAGNOSTICS.json').write_text(json.dumps(out,indent=2))
for r in out:
 if 'v2' in r['name']:
  print(json.dumps({k:v for k,v in r.items() if k not in ['last_events','last_reheading']},ensure_ascii=False),flush=True)
