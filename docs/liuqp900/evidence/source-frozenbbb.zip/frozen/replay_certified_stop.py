"""Offline replay of the existing deterministic brake, not a goal route."""
import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from scipy.optimize import linprog
from pilot_adapter import ROOT,build,online,POLICY
from goal_entry_policy_v6 import LowDimPolicy
from unified_joint_braking import joint_velocity_bounds
out=[]
for name in ['entry_v6_memory_stall_3','entry_v6_memory_initial']:
    folder=ROOT/'trials'/name;path=sorted(folder.glob('snapshot_final_*.npz'))[-1];z=np.load(path);q=z['q'].copy();previous=z['previous'].copy();ctx=build('iris_4shelves_t2',start=q,previous=previous);c=ctx.controller
    c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7
    policy=LowDimPolicy(ctx,json.loads((folder/'job.json').read_text()),lambda **kw:None);policy.memories=json.loads((folder/'goalward_memories.json').read_text());records=[];restored=False
    for step in range(11):
        online.set_configuration(ctx.model,ctx.data,q);c.applied_velocity=previous.copy();c.solve(ctx.target);H,g,A,l,u=c.last_qp_arrays;up=np.isfinite(u);lo=np.isfinite(l)
        feasible=linprog(np.zeros(6),A_ub=np.vstack([A[up],-A[lo]]),b_ub=np.r_[u[up],-l[lo]],bounds=[(None,None)]*6,method='highs',options=dict(primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9))
        record=dict(step=step,qp_feasible=bool(feasible.success),nominal_status=c.pilot_nominal['status'],maximum_previous_speed=float(np.max(np.abs(previous))))
        if feasible.success and step>0:records.append(record);restored=True;break
        lower,upper=joint_velocity_bounds(q,previous,ctx.guard.joint_min,ctx.guard.joint_max,ctx.guard.velocity_limits,.02,10.,.015)
        brake=np.clip(previous-np.clip(previous,-.2,.2),lower,upper);safe=ctx.guard.braking_safe(ctx.proxy_guard,q,brake);memory=policy.memory_safe(q,brake)
        record.update(brake=brake.tolist(),physical_braking_certified=bool(safe),memory_braking_certified=bool(memory));records.append(record)
        if not safe or not memory or np.max(np.abs(brake))<1e-12:break
        q+=.02*brake;previous=brake
    result=dict(source=name,restored_by_existing_certified_brake=restored,records=records,scope='diagnostic only; not used to relabel or resume the failed primary trial, no goal tracking or planning performed')
    out.append(result);print(json.dumps(result),flush=True)
(ROOT/'CERTIFIED_STOP_REPLAY.json').write_text(json.dumps(out,indent=2))
