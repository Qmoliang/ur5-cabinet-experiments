from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parent;p=R/'pilot_worker_progress.py';s=p.read_text().replace("        if job.get('policy_version')=='progress_incremental':","        if job.get('policy_version')=='progress_bypass':\n            from progress_bypass_policy import LowDimPolicy\n        elif job.get('policy_version')=='progress_incremental':");p.write_text(s)
j=json.loads((R/'development_jobs.json').read_text())
for x in j:x['name']=x['name'].replace('_v1','_v4');x['policy_version']='progress_bypass'
(R/'development_v4_jobs.json').write_text(json.dumps(j,indent=2));a=R/'revisions/progress_v4';a.mkdir(parents=True)
for p in R.glob('*.py'):shutil.copy2(p,a/p.name)
