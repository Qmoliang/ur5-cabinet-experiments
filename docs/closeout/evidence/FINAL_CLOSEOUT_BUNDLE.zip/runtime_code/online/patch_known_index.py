"""Add the UR5_KNOWN_INDEX switch to known_v6/run.py (idempotent)."""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
source = path.read_text()
anchor = """        simd=True,
    )
    common = dict("""
patch = """        simd=True,
    )
    # v6 index study: same candidates, different lookup.  "mvt" keeps the fused
    # native path; the other two use LiuQP's plain per-sphere candidate path.
    index_mode = os.environ.get("UR5_KNOWN_INDEX", "mvt")
    if index_mode != "mvt":
        sys.path.insert(0, str(ROOT.parent / "online_v6"))
        from ball_tree import NativeBallTree, UnfusedIndex
        if index_mode == "mvt_unfused":
            index = UnfusedIndex(index)
        elif index_mode == "ball_tree":
            index = NativeBallTree(
                cover.centers,
                cover.aabb_half_extents + MVT_OUTWARD_PADDING,
                query_padding=query_padding,
            )
        else:
            raise ValueError("UR5_KNOWN_INDEX must be mvt, mvt_unfused or ball_tree")
    common = dict("""
if "UR5_KNOWN_INDEX" not in source:
    assert source.count(anchor) == 1
    path.write_text(source.replace(anchor, patch))
print("patched")
