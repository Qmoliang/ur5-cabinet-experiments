from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent
jobs=[dict(j,name='persistent_'+j['name'],policy_version='progress_persistent') for j in json.loads((R/'final_jobs.json').read_text()) if j['name'].startswith('regression_')]
(R/'persistent_regression_jobs.json').write_text(json.dumps(jobs,indent=2));s=(R/'launch_frozen.py').read_text().replace("ROOT/'pilot_worker_progress.py'","ROOT/'pilot_worker_persistent_progress.py'");(R/'launch_persistent_regression.py').write_text(s)
(R/'PERSISTENT_REGRESSION_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,scope='all six unique previously successful cases, unchanged inputs, latest persistent-progress implementation; no selection by outcome',sources={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in ['progress_policy.py','progress_retreat_policy.py','progress_bypass_policy.py','progress_execution_policy.py','progress_persistent_policy.py','pilot_worker_persistent_progress.py']}),indent=2))
