from pathlib import Path
import json,hashlib,shutil
ROOT=Path(__file__).resolve().parent;archive=ROOT/'revisions/second_objective';archive.mkdir(parents=True,exist_ok=False)
for p in list(ROOT.glob('*.py'))+list(ROOT.glob('*.json')):shutil.copy2(p,archive/p.name)
shutil.copy2(ROOT/'code/online/protocol_liuqp_controller.py',archive/'controller.py')
p=ROOT/'release_policy.py';s=p.read_text();s=s.replace("return dict(velocity=result.x,delta=-alpha*b,release_dual=alpha,consumption_cost=0.,original_cost=float(.5*result.x@H@result.x+g@result.x))","return dict(velocity=result.x,delta=-alpha*b,release_dual=alpha,consumption_cost=0.,original_cost=float(.5*result.x@H@result.x+g@result.x),raw=result)")
p.write_text(s)
p=ROOT/'pilot_worker.py';s=p.read_text();old="        if job.get('policy_version')=='reserve_v2':";new="        if job.get('policy_version')=='reserve_v3':\n            from release_policy_v3 import LowDimPolicy\n        elif job.get('policy_version')=='reserve_v2':";assert old in s;s=s.replace(old,new)
s=s.replace("    if job.get('verified_forward',False):ctx.controller.pilot_force_verified_forward=True","    if job.get('verified_forward',False):ctx.controller.pilot_force_verified_forward=True\n    if job.get('certified_auxiliary',False):ctx.controller.pilot_use_certified_auxiliary=True")
s=s.replace("    result['mode_command_queue_flushes']=locals().get('mode_flushes',0)","    result['mode_command_queue_flushes']=locals().get('mode_flushes',0)\n    result['direct_auxiliary_certificates']=None if ctx is None else getattr(ctx.controller,'pilot_certificate_maxima',None)")
p.write_text(s)
p=ROOT/'code/online/protocol_liuqp_controller.py';s=p.read_text();s=s.replace('''            delta = np.asarray(hook(self, self.pilot_nominal, self.last_qp_arrays), dtype=float)''','''            self.pilot_supplied_solution = None
            delta = np.asarray(hook(self, self.pilot_nominal, self.last_qp_arrays), dtype=float)''')
old='''            if np.any(delta):
                solver.update(q=gradient+delta)'''
new='''            if getattr(self, "pilot_use_certified_auxiliary", False) and self.pilot_supplied_solution is not None:
                from certified_auxiliary import verify_solution
                result, certificate = verify_solution(hessian, gradient+delta, dense_matrix, lower_array, upper_array, self.pilot_supplied_solution)
                maxima = getattr(self, "pilot_certificate_maxima", {"count": 0})
                maxima["count"] += 1
                for key, value in certificate.items():
                    maxima[key] = max(maxima.get(key, 0.), value)
                self.pilot_certificate_maxima = maxima
            elif np.any(delta):
                solver.update(q=gradient+delta)'''
assert old in s;s=s.replace(old,new);p.write_text(s)
jobs=json.loads((ROOT/'v2_jobs.json').read_text())
for job in jobs:
    job['name']=job['name'].replace('_v2_','_v3_');job['policy_version']='reserve_v3';job['certified_auxiliary']=True
(ROOT/'v3_jobs.json').write_text(json.dumps(jobs,indent=2))
files=list(ROOT.glob('*.py'))+[ROOT/'v3_jobs.json',ROOT/'INPUTS.json',ROOT/'code/online/protocol_liuqp_controller.py',ROOT/'code/common/policy.json']
(ROOT/'STUDY_V3_FREEZE.json').write_text(json.dumps(dict(jobs=jobs,source_manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files},change='execute the new-QP minimizer after independent original-six-variable KKT and primal-dual gap verification; do not halt because a redundant approximate solve differs by 1e-5',objective_and_selection_unchanged=True,all_hard_constraints_unchanged=True,no_planner=True),indent=2))
print(json.dumps([x['name'] for x in jobs]))
