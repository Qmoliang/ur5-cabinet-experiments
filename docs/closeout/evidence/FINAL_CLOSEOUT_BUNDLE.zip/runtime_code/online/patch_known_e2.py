"""Pass UR5_GUIDANCE_SUBGOALS and UR5_GUIDANCE_TRIGGER through known_v6/run.py (idempotent)."""
from pathlib import Path

path = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/known_v6/run.py")
source = path.read_text()
old = "            minimum_margin=SAFETY_MARGIN, references=[initial_q],\n"
new = (
    "            minimum_margin=SAFETY_MARGIN, references=[initial_q],\n"
    "            subgoal_mode=os.environ.get(\"UR5_GUIDANCE_SUBGOALS\", \"iris\"),\n"
    "            trigger=os.environ.get(\"UR5_GUIDANCE_TRIGGER\", \"stall\"),\n"
)
if "UR5_GUIDANCE_SUBGOALS" not in source:
    assert source.count(old) == 1
    source = source.replace(old, new)
old = "        \"guidance_mode\": guidance_mode,\n"
new = (
    "        \"guidance_mode\": guidance_mode,\n"
    "        \"guidance_subgoals\": None if guidance is None else guidance.subgoal_mode,\n"
    "        \"guidance_trigger\": None if guidance is None else guidance.trigger,\n"
)
if "\"guidance_subgoals\"" not in source:
    assert source.count(old) == 1
    source = source.replace(old, new)
path.write_text(source)
print("patched")
