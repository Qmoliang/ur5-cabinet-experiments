"""Profile PerceptionWorker.process (CenterVox 5 mm + static cameras) on a recorded run's poses.

Usage: profile_proxy.py CASE_DIR [frames]   (run with the same env as the online run)
Prints per-stage times from the frame rows and the top cumulative functions.
"""
import cProfile
import os
import pstats
import sys
import time
from pathlib import Path

import numpy as np

ONLINE = Path("/mnt/ssd2/hsjed/ur5_cabinet/repo/experiment/runtimes/online_v6")
sys.path.insert(0, str(ONLINE))
import run_v6_case  # noqa: E402

os.environ["UR5_STATIC_CAMERAS"] = run_v6_case.STATIC_CAMERA_PRESETS["low_side"]
os.environ.setdefault("UR5_MAP_HISTORY_MODE", "running_bound")
os.environ["UR5_FRONTIER"] = "1"
os.environ["UR5_FRONTIER_CELL_VOXELS"] = "1"
import run_protocol_v3_async_online as online  # noqa: E402

case = Path(sys.argv[1])
frames = int(sys.argv[2]) if len(sys.argv) > 2 else 12
run = next(p for p in case.iterdir() if p.is_dir())
sources = np.load(run / "causal_source_configurations.npz")
names = ("ur5_depth_wrist", "ur5_depth_forearm", "static_low", "static_side")
worker = online.PerceptionWorker(
    "ellipsoid", "mvt_simd", centervox_size=float(os.environ.get("UR5_CENTERVOX", "0.005")),
    maximum_uncertainty_union_inflation=1.05, certificate_radius_limit=0.070,
    uncertainty_fusion_mode="separate_uncertainty", direct_thin_axis_inflation=1.0, direct_tangent_subdivisions=1,
    direct_partition_mode="grid", sphere_cover_mode="matched", ellipsoid_cover_mode="matched",
    radius_limit_representation="both", camera_width=320, camera_height=180, camera_pixel_stride=1,
    camera_names=names, scene_version="camera_quarter")
qs = sources["q"][:frames]
worker.process(qs[0], 0, 0, 0.0, include_dense_snapshot=False)  # first frame (cold) not profiled
profiler = cProfile.Profile()
rows = []
started = time.perf_counter()
profiler.enable()
for i, q in enumerate(qs[1:], start=1):
    packet = worker.process(q, i, i, 0.0, include_dense_snapshot=False)
    rows.append(packet.frame_row)
profiler.disable()
print(f"{len(rows)} frames in {time.perf_counter() - started:.1f} s")
for key in ("capture_ms", "map_update_ms", "proxy_update_ms", "manager_update_ms", "coverage_audit_ms",
            "frontier_ms", "mvt_update_ms", "frame_pipeline_ms", "proxy_count", "frontier_cells"):
    if key in rows[0]:
        print(f"  {key}: median {np.median([float(r[key]) for r in rows]):.1f}")
pstats.Stats(profiler).sort_stats("cumulative").print_stats(28)
worker.close()
