import os,json
os.sched_setaffinity(0,{60,61,62,63})
import numpy as np
from pilot_adapter import ROOT,build
from goal_entry_policy_v5 import LowDimPolicy
out=[]
for name in ['entry_v4_memory_stall_1','entry_v4_memory_stall_2','entry_v4_only_stall']:
    folder=ROOT/'trials'/name;q=np.load(folder/'trajectory.npz')['q'][-1];job=json.loads((folder/'job.json').read_text());r=json.loads((folder/'result.json').read_text());ctx=build('iris_4shelves_t2',start=q);c=ctx.controller
    c.pilot_verified_fallback=True;c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.solve(ctx.target)
    p=LowDimPolicy(ctx,job,lambda **kw:None);p.observe(0,q,np.zeros(6));s=c.pilot_nominal;arrays=c.last_qp_arrays;p.memories=json.loads((folder/'goalward_memories.json').read_text());p.blocker_id=r['policy_summary'].get('blocker_id')
    record=dict(state=name,error_mm=p.error*1000)
    answer=p._tracking_solution(c,s,arrays);record['tracking_solved']=answer is not None
    if p.blocker_id is not None:
        p.mode='BYPASS';geometry=p._geometry();HH,gg=p._terms(c,s);record['minimum_new_hessian_eigenvalue']=float(np.linalg.eigvalsh(arrays[0]+HH).min());assert record['minimum_new_hessian_eigenvalue']>0
        action=p._surface_action(c,s,arrays,geometry);record['surface_action_certified']=action is not None
        if action is not None:record.update(velocity=action[0][0]['velocity'].tolist(),safe_scale=action[0][1][1],chosen_sign=action[2])
    out.append(record);print(json.dumps(record),flush=True)
(ROOT/'SURFACE_PREFLIGHT.json').write_text(json.dumps(out,indent=2))
