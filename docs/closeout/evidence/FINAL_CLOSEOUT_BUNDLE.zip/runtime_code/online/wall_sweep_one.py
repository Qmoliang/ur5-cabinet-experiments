"""One wall layout: best goal-pose clearance found for ellipsoid and sphere covers.

Usage: wall_sweep_one.py TOP WALL_X BEHIND DEPTH  -> one JSON line
"""
import json
import sys

top, wall_x, behind, depth = map(float, sys.argv[1:5])
sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/goal_search.py").read().split("if __name__")[0])
payload = make_scenes.wall_scene(top, depth, wall_x, behind)
row = dict(top=top, wall_x=wall_x, behind=behind, depth=depth, target=payload["waypoints"][-1])
for rep in ("ellipsoid", "sphere"):
    best = -np.inf
    for seed in range(3):
        value, _ = search(payload, rep, attempts=150, seed=seed)
        best = max(best, value)
        if best >= 0.015:
            break
    row[rep + "_mm"] = round(1000 * best, 1)
print(json.dumps(row), flush=True)
