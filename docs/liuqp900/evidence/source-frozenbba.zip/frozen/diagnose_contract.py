"""Replay failed final states; no simulation state is fed back to a controller."""
import os,json,sys
os.sched_setaffinity(0,{56,57,58,59})
import numpy as np
import mujoco
from scipy.optimize import linprog
from pilot_adapter import ROOT,build,online
from viability_policy import LowDimPolicy
from verified_qp import solve_verified
from reserve_objective_contract import solve_reserve

output=[]
for name in sys.argv[1:]:
    folder=ROOT/'trials'/name
    if not (folder/'result.json').exists():continue
    tr=np.load(folder/'trajectory.npz');q=tr['q'][-1];previous=np.zeros(6)
    job=json.loads((folder/'job.json').read_text());ctx=build('iris_4shelves_t2',start=q,previous=previous);c=ctx.controller
    c.osqp_adaptive_row_threshold=10**9;c.osqp_max_iterations=3000;c.osqp_absolute_tolerance=1e-7;c.osqp_relative_tolerance=1e-7;c.pilot_verified_fallback=True
    c.solve(ctx.target);s=c.pilot_nominal;arrays=c.last_qp_arrays;H,g,A,l,u=arrays
    policy=LowDimPolicy(ctx,job,lambda **kw:None);policy.observe(0,q,previous)
    direction=(ctx.target-policy.ee)/policy.error
    up=np.isfinite(u);lo=np.isfinite(l)
    support=linprog(-direction@s['J'],A_ub=np.vstack([A[up],-A[lo]]),b_ub=np.r_[u[up],-l[lo]],bounds=[(None,None)]*6,method='highs')
    answer=policy._solve(c,s,arrays)
    p=ctx.guard.positions(q);gap,normal=ctx.proxy_guard.nearest(p,ctx.guard.radii,reach=.04)
    force=np.abs(s['y'])*np.linalg.norm(A,axis=1)
    order=np.argsort(-force)[:12]
    rec=dict(name=name,error_mm=1000*policy.error,q=q.tolist(),zero_original_qp_feasible=bool(np.all(l<=1e-10) and np.all(u>=-1e-10)),max_goal_rate_mm_s=None if not support.success else -1000*float(support.fun),minimum_proxy_gap_mm=1000*float(gap.min()),dominant_rows=[dict(id=s['row_ids'][i],upper=float(u[i]),dual=float(s['y'][i]),row=A[i].tolist(),force=float(force[i])) for i in order],repairs=policy.repair_records)
    if answer is not None:
        raw=answer['velocity'];v=np.clip(raw,*c.joint_velocity_bounds());record=[]
        for margin in [.006,.0065-2e-7]:
            ctx.guard.margin=margin
            scales=[a for a in [1.,.75,.5,.25,.125,.0625,0.] if ctx.guard.braking_safe(ctx.proxy_guard,q,a*v)]
            # Diagnose first failed segment, without calling sampled safety a proof.
            current=q.copy();speed=v.copy();failed=None
            for step in range(10):
                nxt=current+.02*speed
                if not ctx.guard.segment(ctx.proxy_guard,current,nxt):
                    sampled=[];selfgap=[];work=[]
                    for t in np.linspace(0,1,17):
                        ps=ctx.guard.positions(current+t*(nxt-current));gg,_=ctx.proxy_guard.nearest(ps,ctx.guard.radii,reach=.04)
                        sampled.append(float(gg.min()));selfgap.append(ctx.guard.self_gap(ps));work.append(float(min(np.min(ps-ctx.guard.radii[:,None]-ctx.guard.workspace_lower),np.min(ctx.guard.workspace_upper-ps-ctx.guard.radii[:,None]))))
                    failed=dict(step=step,minimum_sampled_proxy_gap_mm=1000*min(sampled),minimum_sampled_self_gap_mm=1000*min(selfgap),minimum_sampled_workspace_slack_mm=1000*min(work));break
                current=nxt;speed-=np.clip(speed,-.2,.2)
                if np.max(np.abs(speed))<1e-12:break
            record.append(dict(margin_m=margin,accepted_scales=scales,first_failed_segment=failed))
        rec.update(velocity=v.tolist(),delta=answer['delta'].tolist(),candidate_goal_rate_mm_s=1000*float(direction@s['J']@v),certificates=record)
    for row in rec['dominant_rows']:
        if row['id'][0] in ('collision','frontier'):
            row['robot_body']=mujoco.mj_id2name(ctx.model,mujoco.mjtObj.mjOBJ_BODY,int(ctx.guard.bodies[row['id'][1]]))
            row['distal_joint_coefficient_norm']=float(np.linalg.norm(row['row'][2:]))
    output.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'CONTRACT_DIAGNOSIS.json').write_text(json.dumps(output,indent=2))
