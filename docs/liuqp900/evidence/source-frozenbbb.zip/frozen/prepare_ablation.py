from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent;s=(r/'pilot_worker_continuation.py').read_text().replace("        if job.get('policy_version')=='continuation_certified':","        if job.get('policy_version')=='continuation_mean_ablation':\n            from continuation_mean_ablation import LowDimPolicy\n        elif job.get('policy_version')=='continuation_certified':");(r/'pilot_worker_ablation.py').write_text(s)
s=(r/'launch_cached.py').read_text().replace("ROOT/'pilot_worker_continuation.py'","ROOT/'pilot_worker_ablation.py'");(r/'launch_ablation.py').write_text(s)
j=json.loads((r/'final_jobs.json').read_text())[:2]
for i,x in enumerate(j,1):x.update(name='ablation_mean_'+str(i),policy_version='continuation_mean_ablation')
(r/'ablation_jobs.json').write_text(json.dumps(j,indent=2));(r/'ABLATION_FREEZE.json').write_text(json.dumps(dict(jobs=j,scope='post-development matched ablation on both fixed failure sequences; final controller unchanged; not part of predeclared final eight',source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in r.glob('continuation*.py')}),indent=2))
