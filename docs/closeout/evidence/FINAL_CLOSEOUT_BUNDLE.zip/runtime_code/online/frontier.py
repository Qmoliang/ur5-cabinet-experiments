"""Frontier proxies: unseen space inside the cabinet's box as LiuQP obstacles.

Inside a region of interest (the cabinet's bounding box plus a margin), every
coarse cell that still contains unseen voxels and borders observed free space
becomes an obstacle proxy: a sphere circumscribing the cell.  Outside the
region the robot cell is treated as a calibrated free staging volume, as the
runtime already supports; occupied voxels everywhere still become CenterVox
proxies as before.  Cells fully inside unseen space (no free neighbour) are not
needed: LiuQP can only reach them through a frontier cell first.
"""
from __future__ import annotations

import os
from dataclasses import replace

import numpy as np

UNKNOWN, FREE, OCCUPIED = 0, 1, 2
# No margin: cells beyond the cabinet's own box can only be free space in front
# of it, often unseen just because the arm blocks the cameras; every edge the
# arm can hit lies inside the box itself.
ROI_MARGIN = 0.0


class IncrementalFrontier:
    """Frontier cells kept up to date from the map's change journal.

    A dense state array covers only the region of interest (5 mm voxels), so
    each map update applies just the voxels whose state changed instead of
    exporting every known voxel.  Cells are cell_voxels^3 voxels.
    """

    def __init__(self, lower, upper, voxel: float, cell_voxels: int = 2):
        # z=0 is the calibrated ground/workspace boundary in both runtimes.
        # Space below that plane is not an unknown obstacle region. The same
        # workspace constraint (zero extra floor padding) is audited separately.
        lower = np.asarray(lower,dtype=float).copy()
        lower[2] = max(lower[2], 0.0)
        self.voxel = float(voxel)
        self.cell_voxels = int(cell_voxels)
        cell = self.cell_voxels * self.voxel
        # Snap the region outward to whole cells so the coarse reshape is exact.
        self.cell_lo = np.floor(np.asarray(lower) / cell).astype(np.int64)
        cell_hi = np.ceil(np.asarray(upper) / cell).astype(np.int64)
        self.cell_dims = cell_hi - self.cell_lo
        self.key_lo = self.cell_lo * self.cell_voxels
        self.dims = self.cell_dims * self.cell_voxels
        self.state = np.zeros(tuple(self.dims), dtype=np.int8)
        # Static-scene visibility is distinct from a probabilistic occupancy
        # score. Conflicting later measurements do not make a previously
        # observed voxel unseen again; all occupied measurement supports remain
        # in the accumulated observed-proxy set.
        self.observed = np.zeros(tuple(self.dims), dtype=bool)

    def apply(self, keys: np.ndarray, states: np.ndarray) -> None:
        local = keys.astype(np.int64) - self.key_lo
        inside = np.all((local >= 0) & (local < self.dims), axis=1)
        local = local[inside]
        self.state[local[:, 0], local[:, 1], local[:, 2]] = states[inside]
        self.observed[local[:, 0], local[:, 1], local[:, 2]] = True

    def cells(self, near_points=None):
        """near_points: with UR5_FRONTIER_MERGE, blocks within UR5_FRONTIER_FINE_RADIUS
        (default 0.15 m) of any of these points (robot spheres, target) stay fine."""
        c = self.cell_voxels
        nx, ny, nz = self.cell_dims
        blocks = self.observed.reshape(nx, c, ny, c, nz, c)
        known = np.count_nonzero(blocks, axis=(1, 3, 5))
        # Bound unseen space next to any observed voxel, including occupied
        # ones, so visibility-frontier coverage is conservative.
        free = np.any(blocks, axis=(1, 3, 5))
        has_unseen = known < c ** 3
        frontier = has_unseen & free
        # Unseen-containing cells next to observed free space (6-neighbourhood).
        grown = free.copy()
        grown[1:] |= free[:-1]
        grown[:-1] |= free[1:]
        grown[:, 1:] |= free[:, :-1]
        grown[:, :-1] |= free[:, 1:]
        grown[:, :, 1:] |= free[:, :, :-1]
        grown[:, :, :-1] |= free[:, :, 1:]
        frontier |= has_unseen & grown
        cell = c * self.voxel
        if os.environ.get("UR5_FRONTIER_MERGE", "0") == "1":
            return self._merged(frontier, cell, near_points)
        cells = np.argwhere(frontier) + self.cell_lo
        return (cells + 0.5) * cell, 0.5 * np.sqrt(3.0) * cell, cells

    def _merged(self, frontier, cell, near_points=None):
        """One certificate per 2x2x2 block that holds frontier cells: the
        axis-aligned bounding box of those cells, covered by the ellipsoid with
        semi-axes sqrt(3) x its half-sizes (which contains the box).  The
        frontier is a thin shell, so a flat 2x2 patch keeps the single cells'
        thickness while four cells share one certificate.  Blocks near
        near_points keep one certificate per cell (each its own 'block').
        Returns centres, circumscribed radii, axis-aligned shapes, block cells."""
        cells = np.argwhere(frontier)
        block = cells // 2
        fine = np.zeros(len(cells), dtype=bool)
        if near_points is not None and len(near_points) and len(cells):
            from scipy.spatial import cKDTree
            radius = float(os.environ.get("UR5_FRONTIER_FINE_RADIUS", "0.15"))
            block_centres = (2 * block + self.cell_lo + 1.0) * cell
            distance, _ = cKDTree(np.asarray(near_points, dtype=float)).query(block_centres)
            fine = distance < radius
        # Fine cells are their own groups; the rest are grouped by block with
        # one sort on a linear block index and reduced with reduceat.
        merged_cells = cells[~fine]
        if len(merged_cells):
            block_dims = np.asarray(frontier.shape) // 2 + 1
            linear = np.ravel_multi_index((merged_cells // 2).T, block_dims)
            order = np.argsort(linear, kind="stable")
            starts = np.r_[0, np.flatnonzero(np.diff(linear[order])) + 1]
            sorted_cells = merged_cells[order]
            block_low = np.minimum.reduceat(sorted_cells, starts, axis=0)
            block_high = np.maximum.reduceat(sorted_cells, starts, axis=0)
        else:
            block_low = block_high = np.empty((0, 3), dtype=np.int64)
        low = np.concatenate([cells[fine], block_low])
        high = np.concatenate([cells[fine], block_high])
        lower = (low + self.cell_lo) * cell
        upper = (high + 1 + self.cell_lo) * cell
        centres = 0.5 * (lower + upper)
        half = 0.5 * (upper - lower)
        shapes = np.zeros((len(low), 3, 3))
        shapes[:, [0, 1, 2], [0, 1, 2]] = 3.0 * half * half
        radii = np.linalg.norm(half, axis=1)
        return centres, radii, low + self.cell_lo, shapes


NEIGHBOURS6 = np.array([(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)])


def frontier_cells(keys: np.ndarray, states: np.ndarray, voxel: float, lower, upper, cell_voxels: int = 2):
    """Centres of frontier cells (edge = cell_voxels * voxel) inside [lower, upper].

    keys/states: the map's known voxels (unlisted voxels are unseen); a voxel
    with key k covers [k * voxel, (k + 1) * voxel).
    """
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)
    cell = cell_voxels * voxel
    c_lo = np.floor(lower / cell).astype(np.int64)
    c_hi = np.ceil(upper / cell).astype(np.int64)  # exclusive
    dims = c_hi - c_lo
    coarse = np.floor_divide(keys.astype(np.int64), cell_voxels) - c_lo
    inside = np.all((coarse >= 0) & (coarse < dims), axis=1)
    # The export can list voxels whose state is UNKNOWN; they are not seen.
    inside &= states != UNKNOWN
    coarse, states = coarse[inside], states[inside]
    linear = np.ravel_multi_index(coarse.T, dims)
    total = np.prod(dims)
    known = np.bincount(linear, minlength=total)
    free = np.bincount(linear, weights=(states == FREE), minlength=total) > 0
    full = cell_voxels ** 3
    has_unseen = known < full
    # Frontier: unseen-containing cells that hold, or touch, observed free space.
    frontier = has_unseen & free
    free_cells = np.array(np.unravel_index(np.flatnonzero(free), dims)).T
    for step in NEIGHBOURS6:
        neighbour = free_cells + step
        valid = np.all((neighbour >= 0) & (neighbour < dims), axis=1)
        index = np.ravel_multi_index(neighbour[valid].T, dims)
        frontier[index[has_unseen[index]]] = True
    cells = np.array(np.unravel_index(np.flatnonzero(frontier), dims)).T + c_lo
    centres = (cells + 0.5) * cell
    radius = 0.5 * np.sqrt(3.0) * cell
    return centres, radius, cells


def region_of_interest(boxes):
    """The cabinet's bounding box plus ROI_MARGIN (where the cabinet is, not its shape)."""
    lows = np.array([np.asarray(b.center) - np.asarray(b.half_size) for b in boxes])
    highs = np.array([np.asarray(b.center) + np.asarray(b.half_size) for b in boxes])
    return lows.min(axis=0) - ROI_MARGIN, highs.max(axis=0) + ROI_MARGIN


def merge_frontier(proxies, centres: np.ndarray, radius: float, cells: np.ndarray, shapes=None):
    """Append frontier spheres to a PointCloudProxySet as ordinary obstacles.

    Each frontier sphere is E(c, r^2 I) with zero measurement uncertainty and
    zero offset.  LiuQP keeps dense warm-start caches indexed by proxy ID, so
    frontier IDs must stay compact: they continue right after the largest
    CenterVox ID.  They are unique within a map; across maps they may be
    reassigned, which only affects warm starts.
    """
    count = len(centres)
    if not count:
        return proxies
    radius = np.broadcast_to(np.asarray(radius, dtype=float), (count,)).copy()  # scalar or per cell
    if shapes is None:
        shapes = (radius * radius)[:, None, None] * np.eye(3)[None]
    zeros = np.zeros((count, 3, 3))
    first = int(np.max(proxies.proxy_ids)) + 1 if len(proxies.proxy_ids) else 0
    ids = first + np.arange(count)

    def cat(existing, extra):
        return None if existing is None else np.concatenate([np.asarray(existing), extra], axis=0)

    keys = np.asarray(proxies.cluster_keys)
    extra_keys = np.full((count,) + keys.shape[1:], -1, dtype=keys.dtype)
    return replace(
        proxies,
        box_half_extents=np.concatenate([np.zeros_like(proxies.centers) if getattr(proxies,"box_half_extents",None) is None else proxies.box_half_extents, np.sqrt(np.maximum(np.diagonal(shapes,axis1=1,axis2=2)/3.,0))]),
        centers=cat(proxies.centers, centres),
        sphere_radii=cat(proxies.sphere_radii, radius),
        ellipsoid_shapes=cat(proxies.ellipsoid_shapes, shapes),
        rotations=cat(proxies.rotations, np.repeat(np.eye(3)[None], count, axis=0)),
        cluster_keys=np.concatenate([keys, extra_keys], axis=0),
        proxy_offset_radii=cat(proxies.proxy_offset_radii, np.zeros(count)),
        proxy_uncertainty_shapes=cat(proxies.proxy_uncertainty_shapes, zeros),
        base_sphere_radii=cat(proxies.base_sphere_radii, radius),
        base_ellipsoid_shapes=cat(proxies.base_ellipsoid_shapes, shapes),
        ellipsoid_outer_shapes=cat(proxies.ellipsoid_outer_shapes, shapes),
        proxy_ids=cat(proxies.proxy_ids, ids.astype(np.asarray(proxies.proxy_ids).dtype)),
    )
