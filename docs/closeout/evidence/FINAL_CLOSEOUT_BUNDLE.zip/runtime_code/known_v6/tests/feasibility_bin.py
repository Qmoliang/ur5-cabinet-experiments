"""Bin placement sweep: does a collision-free goal pose exist, and is the start pose valid?"""
import sys

sys.argv = sys.argv[:1]
exec(open("/mnt/ssd2/hsjed/ur5_cabinet/v6runs/feasibility.py").read().split("variants = []")[0])
from start_check import StartChecker  # noqa: E402

for x0 in (0.25, 0.30, 0.35, 0.40):
    for y0 in (0.10, 0.25):
        for depth in (0.10, 0.20):
            payload = make_scenes.bin_scene(0.66, x0, y0, 0.30, depth)
            scene = scene_of(payload)
            model = build_model(scene)
            data = mujoco.MjData(model)
            start_ok = StartChecker(scene.boxes, 0.075, 0.008).valid(model, data, np.asarray(scene.q0))
            e = feasible(payload, "ellipsoid", 300)[0]
            s = feasible(payload, "sphere", 300)[0]
            target = [round(v, 3) for v in payload["waypoints"][-1]]
            print(f"bin x0={x0} y0={y0} target {target} depth {depth}: start valid {start_ok}, "
                  f"ellipsoid {e}, sphere {s}", flush=True)
